
const { app, BrowserWindow, ipcMain, Tray, Menu } = require('electron');
const path = require('path');
const screenshot = require('screenshot-desktop');
const { initializeApp } = require('firebase/app');
const { getAuth, signInWithEmailAndPassword } = require('firebase/auth');
const { getStorage, ref, uploadBytes, getDownloadURL } = require('firebase/storage');
const { getFirestore, doc, setDoc, collection, addDoc, updateDoc, serverTimestamp } = require('firebase/firestore');
const fs = require('fs');

// Firebase Config
const firebaseConfig = {
    apiKey: "AIzaSyCyLm24JBC4CLJTrwrseOKtO-PQwm-gtUc",
    authDomain: "panimo-8da79.firebaseapp.com",
    projectId: "panimo-8da79",
    storageBucket: "panimo-8da79.firebasestorage.app",
    messagingSenderId: "1018156188522",
    appId: "1:1018156188522:web:ab7d2cc4d32e4679955b13",
    measurementId: "G-CPZDYFBQE8"
};

// Initialize Firebase
const firebaseApp = initializeApp(firebaseConfig);
const auth = getAuth(firebaseApp);
const storage = getStorage(firebaseApp);
const db = getFirestore(firebaseApp);

let mainWindow;
let tray = null;
let currentUser = null;
let screenshotInterval = null;
let usageInterval = null;

function createTray() {
    tray = new Tray(path.join(__dirname, 'icon.png'));
    const contextMenu = Menu.buildFromTemplate([
        { label: 'Panimo Cloud', enabled: false },
        { type: 'separator' },
        { label: 'Uygulamayı Göster', click: () => mainWindow.show() },
        { label: 'Çıkış', click: () => {
            app.isQuitting = true;
            app.quit();
        }}
    ]);
    tray.setToolTip('Panimo Cloud Agent');
    tray.setContextMenu(contextMenu);

    tray.on('click', () => {
        mainWindow.isVisible() ? mainWindow.hide() : mainWindow.show();
    });
}

function createWindow() {
    mainWindow = new BrowserWindow({
        width: 400,
        height: 550,
        frame: false,
        resizable: false,
        webPreferences: {
            nodeIntegration: true,
            contextIsolation: false
        },
        icon: path.join(__dirname, 'icon.png')
    });

    mainWindow.loadFile('index.html');

    mainWindow.on('close', (event) => {
        if (!app.isQuitting) {
            event.preventDefault();
            mainWindow.hide();
        }
        return false;
    });

    mainWindow.on('minimize', (event) => {
        event.preventDefault();
        mainWindow.hide();
    });
}

app.whenReady().then(() => {
    createWindow();
    createTray();
});

const CONFIG_PATH = path.join(app.getPath('userData'), 'config.json');

function saveConfig(data) {
    fs.writeFileSync(CONFIG_PATH, JSON.stringify(data));
}

function loadConfig() {
    if (fs.existsSync(CONFIG_PATH)) {
        return JSON.parse(fs.readFileSync(CONFIG_PATH));
    }
    return null;
}

ipcMain.on('login', async (event, { email, password }) => {
    try {
        const userCredential = await signInWithEmailAndPassword(auth, email, password);
        currentUser = {
            uid: userCredential.user.uid,
            email: userCredential.user.email
        };

        // Save for auto-login
        saveConfig({ email, password });

        event.reply('login-success', currentUser);
        startTracking();
        mainWindow.hide();
    } catch (error) {
        event.reply('login-error', error.message);
    }
});

ipcMain.on('hide-window', () => {
    if (mainWindow) mainWindow.hide();
});

function startTracking() {
    if (screenshotInterval) return;

    console.log("Tracking started for", currentUser.uid);

    // Initial tasks
    takeAndUploadScreenshot();
    trackAppUsage();

    // Fixed Screenshot interval (Every 15 mins)
    screenshotInterval = setInterval(() => {
        takeAndUploadScreenshot();
    }, 15 * 60 * 1000);

    // Usage tracking interval (every 60 seconds)
    usageInterval = setInterval(() => {
        trackAppUsage();
    }, 60000);
}

// Auto-login on startup
app.whenReady().then(() => {
    const config = loadConfig();
    if (config) {
        signInWithEmailAndPassword(auth, config.email, config.password)
            .then(userCredential => {
                currentUser = {
                    uid: userCredential.user.uid,
                    email: userCredential.user.email
                };
                console.log("Auto-login successful");
                startTracking();
                // We might want to show success view in UI too
                mainWindow.webContents.on('did-finish-load', () => {
                    mainWindow.webContents.send('login-success', currentUser);
                    mainWindow.hide();
                });
            })
            .catch(err => {
                console.error("Auto-login failed", err);
            });
    }
});

async function trackAppUsage() {
    if (!currentUser) return;

    try {
        // active-win is ESM, we use dynamic import
        const activeWin = await import('active-win');
        const result = await activeWin.activeWindow();

        if (result) {
            const usageData = {
                userId: currentUser.uid,
                userName: currentUser.email,
                appName: result.owner.name,
                title: result.title,
                timestamp: new Date().toISOString()
            };

            // Log usage history
            await addDoc(collection(db, "app_usage_logs"), usageData);

            // Update real-time activity status
            await setDoc(doc(db, "user_activity", currentUser.uid), {
                id: currentUser.uid,
                lastActivity: new Date().toISOString(),
                isIdle: false,
                tabStatus: 'Active',
                currentScreen: `${result.owner.name}: ${result.title}`
            }, { merge: true });

            console.log("App usage tracked:", result.owner.name);
        }
    } catch (error) {
        console.error("App tracking error:", error);
    }
}

async function takeAndUploadScreenshot() {
    if (!currentUser) return;

    try {
        const imgBuffer = await screenshot({ format: 'jpg' });
        const timestamp = new Date().toISOString();
        const dateStr = timestamp.split('T')[0];

        const fileName = `screenshots/${currentUser.uid}/${dateStr}/${Date.now()}.jpg`;
        const storageRef = ref(storage, fileName);

        await uploadBytes(storageRef, imgBuffer);
        const downloadURL = await getDownloadURL(storageRef);

        await addDoc(collection(db, "screenshot_logs"), {
            userId: currentUser.uid,
            userName: currentUser.email,
            imageUrl: downloadURL,
            timestamp: timestamp,
            status: 'success'
        });

        // Update last screenshot timestamp in user_activity
        await updateDoc(doc(db, "user_activity", currentUser.uid), {
            lastScreenshot: timestamp
        });

        console.log("Screenshot uploaded:", fileName);
    } catch (error) {
        console.error("Screenshot error:", error);
    }
}

app.on('window-all-closed', () => {
    if (process.platform !== 'darwin') app.quit();
});
