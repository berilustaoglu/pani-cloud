import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';

export default defineConfig(() => ({
  plugins: [react()],
  define: {
    // Tarayıcı paketine HİÇBİR ortam değişkeni gömülmez. Eskiden .env ve sistem değişkenlerinin
    // tamamı (API anahtarları dahil) pakete yazılıyordu. Gizli değerler yalnızca sunucu fonksiyonlarında durur.
    // 'process.env' boş nesne: process.env okuyan kütüphaneler hata vermesin diye.
    'process.env': '{}',
  },
  server: {
    port: 3000,
    host: '0.0.0.0',
  },
}));
