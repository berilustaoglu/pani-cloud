// Firestore güvenlik kuralı testleri.
// Çalıştırmak için (Java 11+ gerekir):
//   npm i -D firebase-tools @firebase/rules-unit-testing
//   RULES_PATH=./firestore.rules npx firebase emulators:exec --only firestore --project demo-panimo "node tests/firestore-rules.test.mjs"
import { initializeTestEnvironment, assertSucceeds, assertFails } from '@firebase/rules-unit-testing';
import { doc, getDoc, setDoc, updateDoc, deleteDoc, collection, getDocs, query, where, arrayUnion, deleteField } from 'firebase/firestore';
import fs from 'fs';

const env = await initializeTestEnvironment({
  projectId: 'demo-panimo',
  firestore: { rules: fs.readFileSync(process.env.RULES_PATH || './firestore.rules', 'utf8'), host: '127.0.0.1', port: 8080 },
});

await env.withSecurityRulesDisabled(async (ctx) => {
  const db = ctx.firestore();
  const u = (id, role, extra = {}) => setDoc(doc(db, 'users', id), { id, name: id, email: `${id}@x.com`, role, permissions: [], status: 'Offline', monthlySalary: 1000, ...extra });
  await u('a1', 'Admin'); await u('m1', 'Manager'); await u('s1', 'Staff'); await u('s2', 'Staff'); await u('acc', 'Accountant'); await u('s3', 'Staff');
  await u('pre1', 'Staff', { email: 'new@x.com' });
  await setDoc(doc(db, 'transactions', 't1'), { id: 't1', amount: 5 });
  await setDoc(doc(db, 'tasks', 'k1'), { id: 'k1', title: 'A', status: 'To Do', assignedTo: ['s1'], projectId: 'p1' });
  await setDoc(doc(db, 'projects', 'p1'), { id: 'p1', name: 'P', portalSettings: { isPublic: true } });
  await setDoc(doc(db, 'projects', 'p2'), { id: 'p2', name: 'Q', portalSettings: { isPublic: false } });
  await setDoc(doc(db, 'attendance', 'at1'), { id: 'at1', userId: 's1', clockIn: '09:00', date: '2026-10-12' });
  await setDoc(doc(db, 'leave_requests', 'l1'), { id: 'l1', userId: 's1', status: 'Pending' });
  await setDoc(doc(db, 'system_notifications', 'n1'), { title: 'x', readBy: [] });
  await setDoc(doc(db, 'chat_messages', 'c1'), { senderId: 's2', type: 'text', text: 'hi', readBy: [] });
  await setDoc(doc(db, 'chat_messages', 'c2'), { senderId: 's2', type: 'poll', text: '{}', readBy: [] });
  await setDoc(doc(db, 'meetings', 'mt1'), { createdBy: 'm1', participants: ['s1'], title: 'M', status: 'scheduled', notes: '' });
  await setDoc(doc(db, 'sms_secrets', 'config'), { password: 'p' });
  await setDoc(doc(db, 'audit_logs', 'al1'), { a: 1 });
  await setDoc(doc(db, 'whatever', 'w1'), { a: 1 });
  await setDoc(doc(db, 'user_private', 's1'), { id: 's1', monthlySalary: 50000, iban: 'TR1' });
  await setDoc(doc(db, 'user_private', 's3'), { id: 's3', monthlySalary: 60000, iban: 'TR3' });
  await setDoc(doc(db, 'attendance', 'at9'), { id: 'at9', userId: 's3', clockIn: '09:00', location: { lat: 1, lng: 2 } });
  await setDoc(doc(db, 'leave_requests', 'l9'), { id: 'l9', userId: 's3', status: 'Pending' });
  await setDoc(doc(db, 'staff_documents', 'd1'), { id: 'd1', userId: 's3', sharedById: 'm1', fileName: 'x' });
  await setDoc(doc(db, 'serviceSales', 'ss1'), { id: 'ss1', amount: 1 });
});

const as = (uid, email) => env.authenticatedContext(uid, { email: email || `${uid}@x.com` }).firestore();
const anon = env.unauthenticatedContext().firestore();
const results = [];
const t = async (name, p, expect) => {
  try { await (expect ? assertSucceeds(p) : assertFails(p)); results.push(['✓', name]); }
  catch (e) { results.push(['✗', name, e.message.split('\n')[0]]); }
};

const s1 = as('s1'), m1 = as('m1'), a1 = as('a1'), acc = as('acc');
await t('Personel kendi rolünü Admin yapamaz', updateDoc(doc(s1, 'users', 's1'), { role: 'Admin' }), false);
await t('Personel kendi maaşını değiştiremez', updateDoc(doc(s1, 'users', 's1'), { monthlySalary: 99999 }), false);
await t('Personel kendi durumunu güncelleyebilir', setDoc(doc(s1, 'users', 's1'), { id: 's1', status: 'Online' }, { merge: true }), true);
await t('Personel bildirim tercihini güncelleyebilir', setDoc(doc(s1, 'users', 's1'), { id: 's1', notificationPrefs: { chat: false } }, { merge: true }), true);
await t('Personel push anahtarı ekleyebilir', updateDoc(doc(s1, 'users', 's1'), { fcmTokens: arrayUnion('tok'), fcmToken: 'tok' }), true);
await t('Personel başkasının profilini değiştiremez', updateDoc(doc(s1, 'users', 's2'), { status: 'Online' }), false);
await t('Müdür yönetici hesabı oluşturamaz', setDoc(doc(m1, 'users', 'x9'), { role: 'Admin', email: 'x9@x.com' }), false);
await t('Müdür personel hesabı oluşturabilir', setDoc(doc(m1, 'users', 'x8'), { role: 'Staff', email: 'x8@x.com' }), true);
await t('Müdür yöneticinin profilini değiştiremez', updateDoc(doc(m1, 'users', 'a1'), { role: 'Staff' }), false);
await t('Müdür personeli müdür yapamaz', updateDoc(doc(m1, 'users', 's2'), { role: 'Manager' }), false);
await t('Yönetici herkesi düzenleyebilir', updateDoc(doc(a1, 'users', 's2'), { role: 'Manager' }), true);

await t('Tarayıcıdan kendine profil açılamaz (taşıma sunucuda)', setDoc(doc(as('n1', 'new@x.com'), 'users', 'n1'), { id: 'n1', email: 'new@x.com', role: 'Staff', permissions: [] }), false);
await t('Önceden tanımlı profil tarayıcıdan silinemez', deleteDoc(doc(as('n1', 'new@x.com'), 'users', 'pre1')), false);
await t('Tanımsız kişi kendine profil açamaz', setDoc(doc(as('z1', 'z@x.com'), 'users', 'z1'), { role: 'Staff' }), false);

await t('Personel muhasebe kaydı okuyamaz', getDoc(doc(s1, 'transactions', 't1')), false);
await t('Personel muhasebe kaydı yazamaz', setDoc(doc(s1, 'transactions', 't2'), { amount: 1 }), false);
await t('Muhasebeci muhasebe kaydı okuyabilir', getDoc(doc(acc, 'transactions', 't1')), true);
await t('Müdür muhasebe kaydı yazabilir', setDoc(doc(m1, 'transactions', 't3'), { amount: 1 }), true);

await t('Personel kendi görevinin durumunu değiştirebilir', updateDoc(doc(s1, 'tasks', 'k1'), { status: 'Doing' }), true);
await t('Personel kendi görevinin başlığını değiştiremez', updateDoc(doc(s1, 'tasks', 'k1'), { title: 'B' }), false);
await t('Personel başkasının görevini değiştiremez', updateDoc(doc(as('s3'), 'tasks', 'k1'), { status: 'Done' }), false);
await t('Personel görev silemez', deleteDoc(doc(s1, 'tasks', 'k1')), false);

await t('Personel kendi mesaisini başlatabilir', setDoc(doc(s1, 'attendance', 'at2'), { userId: 's1', clockIn: '09:00' }), true);
await t('Personel başkası adına mesai açamaz', setDoc(doc(s1, 'attendance', 'at3'), { userId: 's2', clockIn: '09:00' }), false);
await t('Personel kendi çıkışını yapabilir', updateDoc(doc(s1, 'attendance', 'at1'), { clockOut: '18:00' }), true);
await t('Personel giriş saatini değiştiremez', updateDoc(doc(s1, 'attendance', 'at1'), { clockIn: '07:00' }), false);

await t('Personel kendi iznini onaylayamaz', updateDoc(doc(s1, 'leave_requests', 'l1'), { status: 'Approved' }), false);
await t('Müdür izni onaylayabilir', updateDoc(doc(m1, 'leave_requests', 'l1'), { status: 'Approved' }), true);
await t('Personel onaylanmış izni iptal edemez', updateDoc(doc(s1, 'leave_requests', 'l1'), { status: 'Cancelled' }), false);
await t('Personel bekleyen izin talebi açabilir', setDoc(doc(s1, 'leave_requests', 'l2'), { userId: 's1', status: 'Pending' }), true);

await t('Bildirim: kendi adına oluşturulabilir', setDoc(doc(s1, 'system_notifications', 'n2'), { title: 'y', readBy: [], createdBy: 's1' }), true);
await t('Bildirim: başkası adına oluşturulamaz', setDoc(doc(s1, 'system_notifications', 'n3'), { title: 'y', readBy: [], createdBy: 'a1' }), false);
await t('Bildirim: okundu işaretlenebilir', updateDoc(doc(s1, 'system_notifications', 'n1'), { readBy: arrayUnion('s1') }), true);
await t('Bildirim: içeriği değiştirilemez', updateDoc(doc(s1, 'system_notifications', 'n1'), { title: 'z' }), false);

await t('Sohbet: başkasının mesaj metni değiştirilemez', updateDoc(doc(s1, 'chat_messages', 'c1'), { text: 'hack' }), false);
await t('Sohbet: ankete oy verilebilir', updateDoc(doc(s1, 'chat_messages', 'c2'), { text: '{"v":1}' }), true);
await t('Sohbet: başkası adına mesaj yazılamaz', setDoc(doc(s1, 'chat_messages', 'c3'), { senderId: 's2', text: 'x' }), false);

await t('Toplantı: katılımcı not ekleyebilir', updateDoc(doc(s1, 'meetings', 'mt1'), { notes: 'karar', status: 'completed' }), true);
await t('Toplantı: katılımcı başlığı değiştiremez', updateDoc(doc(s1, 'meetings', 'mt1'), { title: 'X' }), false);

await t('Giriş yapmadan görevler okunamaz', getDocs(query(collection(anon, 'tasks'), where('projectId', '==', 'p1'))), false);
await t('Giriş yapmadan açık portal projesi okunabilir', getDoc(doc(anon, 'projects', 'p1')), true);
await t('Giriş yapmadan kapalı portal projesi okunamaz', getDoc(doc(anon, 'projects', 'p2')), false);
await t('Giriş yapmadan kullanıcılar okunamaz', getDoc(doc(anon, 'users', 's1')), false);

await t('Yönetici bile SMS şifresini okuyamaz', getDoc(doc(a1, 'sms_secrets', 'config')), false);
await t('Personel denetim kayıtlarını okuyamaz', getDoc(doc(s1, 'audit_logs', 'al1')), false);
await t('Denetim kaydı değiştirilemez', updateDoc(doc(a1, 'audit_logs', 'al1'), { a: 2 }), false);
await t('Tanımsız koleksiyon: personel erişemez', getDoc(doc(s1, 'whatever', 'w1')), false);
await t('Tanımsız koleksiyon: yönetici erişebilir', getDoc(doc(a1, 'whatever', 'w1')), true);
await t('Yönetici SMS şifresini yazabilir', setDoc(doc(a1, 'sms_secrets', 'config'), { password: 'q' }), true);
await t('Yönetici denetim kayıtlarını okuyabilir', getDoc(doc(a1, 'audit_logs', 'al1')), true);

await t('Personel kendi maaş bilgisini okuyabilir', getDoc(doc(s1, 'user_private', 's1')), true);
await t('Personel başkasının maaş bilgisini okuyamaz', getDoc(doc(s1, 'user_private', 's3')), false);
await t('Personel kendi maaşını değiştiremez (gizli koleksiyon)', setDoc(doc(s1, 'user_private', 's1'), { monthlySalary: 99999 }, { merge: true }), false);
await t('Muhasebe maaş bilgilerini okuyabilir', getDoc(doc(acc, 'user_private', 's3')), true);
await t('Müdür personelin maaşını güncelleyebilir', setDoc(doc(m1, 'user_private', 's3'), { monthlySalary: 61000 }, { merge: true }), true);
await t('Müdür profile gizli alan yazamaz', updateDoc(doc(m1, 'users', 's3'), { iban: 'TRX' }), false);
await t('Müdür profile gizli alan içeren kişi oluşturamaz', setDoc(doc(m1, 'users', 'x7'), { role: 'Staff', email: 'x7@x.com', monthlySalary: 1 }), false);
await t('Yönetici eski profillerden gizli alanları kaldırabilir', updateDoc(doc(a1, 'users', 's3'), { monthlySalary: deleteField() }), true);

await t('Personel başkasının mesai kaydını okuyamaz (konum)', getDoc(doc(s1, 'attendance', 'at9')), false);
await t('Personel kendi mesai kayıtlarını sorgulayabilir', getDocs(query(collection(s1, 'attendance'), where('userId', '==', 's1'))), true);
await t('Personel herkesin mesai kaydını sorgulayamaz', getDocs(collection(s1, 'attendance')), false);
await t('Müdür tüm mesai kayıtlarını görebilir', getDocs(collection(m1, 'attendance')), true);
await t('Personel başkasının izin talebini okuyamaz', getDoc(doc(s1, 'leave_requests', 'l9')), false);
await t('Personel kendi izin taleplerini sorgulayabilir', getDocs(query(collection(s1, 'leave_requests'), where('userId', '==', 's1'))), true);
await t('Personel başkasına gönderilen dosyayı okuyamaz', getDoc(doc(s1, 'staff_documents', 'd1')), false);
await t('Alıcı kendi dosyasını okuyabilir', getDoc(doc(as('s3'), 'staff_documents', 'd1')), true);
await t('Gönderen müdür dosyayı okuyabilir', getDoc(doc(m1, 'staff_documents', 'd1')), true);
await t('Muhasebe hizmet satışlarını (serviceSales) okuyabilir', getDoc(doc(acc, 'serviceSales', 'ss1')), true);
await t('Personel hizmet satışlarını okuyamaz', getDoc(doc(s1, 'serviceSales', 'ss1')), false);

results.forEach(r => console.log(r.join('  ')));
const failed = results.filter(r => r[0] === '✗').length;
console.log(`\n${results.length - failed}/${results.length} geçti`);
await env.cleanup();
process.exit(failed ? 1 : 0);
