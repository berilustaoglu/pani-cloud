
import React, { useState, useEffect, useRef, useMemo, Suspense, lazy } from 'react';
import {
  Briefcase,
  MessageSquare,
  Monitor,
  Download,
  Bell,
  Cpu,
  LogOut,
  FileText,
  Menu,
  CheckSquare,
  Wallet,
  Clock,
  X,
  ShoppingBag,
  FolderOpen,
  Loader2,
  Database,
  ShieldCheck,
  Zap,
  Key as KeyIcon,
  Settings,
  GripHorizontal,
  Trash2,
  Sun,
  Moon,
  Eye,
  EyeOff,
  Package,
  ShoppingCart,
  CalendarDays,
  Archive,
  Shield,
  Users,
  DollarSign,
  CreditCard,
  TrendingUp,
  Box,
  ShieldAlert,
  Video,
  Gauge,
  Languages,
  ChevronLeft,
  Sunrise,
  UsersRound,
} from 'lucide-react';

// ✅ LAZY LOADING: Bileşenleri dinamik yükle
const ProjectsView = lazy(() => import('./components/ProjectsView'));
const TasksView = lazy(() => import('./components/TasksView'));
const AccountingView = lazy(() => import('./components/AccountingView'));
const SalesView = lazy(() => import('./components/SalesView'));
const TeamView = lazy(() => import('./components/TeamView'));
const AttendanceView = lazy(() => import('./components/AttendanceView'));
const AIView = lazy(() => import('./components/AIView'));
const LoginView = lazy(() => import('./components/LoginView'));
const StaffView = lazy(() => import('./components/StaffView'));
const MyDayView = lazy(() => import('./components/MyDayView'));
const MyTeamView = lazy(() => import('./components/MyTeamView'));
const CustomerSMSView = lazy(() => import('./components/CustomerSMSView'));
const InvoicesView = lazy(() => import('./components/InvoicesView'));
const DuePaymentsModal = lazy(() => import('./components/DuePaymentsModal'));
const StaffDocumentsView = lazy(() => import('./components/StaffDocumentsView'));
const MessagesView = lazy(() => import('./components/MessagesView'));
const CustomerModal = lazy(() => import('./components/CustomerModal'));
const TeamMonitoring = lazy(() => import('./components/TeamMonitoring'));
const CRMView = lazy(() => import('./components/CRMView'));
const ScreenShareModal = lazy(() => import('./components/ScreenShareModal'));
const PersonnelFinanceView = lazy(() => import('./components/PersonnelFinanceView'));
const ScreenshotGallery = lazy(() => import('./components/ScreenshotGallery'));
const ScreenViewerModal = lazy(() => import('./components/ScreenViewerModal'));
const LeaveView = lazy(() => import('./components/LeaveView'));
const InventoryView = lazy(() => import('./components/InventoryView'));
const PurchasingView = lazy(() => import('./components/PurchasingView'));
const CopilotPanel = lazy(() => import('./components/CopilotPanel'));
const NotificationsPanel = lazy(() => import('./components/NotificationsPanel'));
// Ek işler bileşeni
const ExtraJobView = lazy(() => import('./components/ExtraJobView'));
const ArchiveView = lazy(() => import('./components/ArchiveView'));
const ClientPortalPreview = lazy(() => import('./components/ClientPortalPreview'));
const ProposalGenerator = lazy(() => import('./components/ProposalGenerator'));
const PortalManagementView = lazy(() => import('./components/PortalManagementView'));
const SettingsView = lazy(() => import('./components/SettingsView'));
const TicketsView = lazy(() => import('./components/TicketsView'));
const MeetingsView = lazy(() => import('./components/MeetingsView'));
const OperationsCenterView = lazy(() => import('./components/OperationsCenterView'));
const CommandPalette = lazy(() => import('./components/CommandPalette'));
import TopBar from './components/TopBar';
import Toaster from './components/Toaster';
import { buildInsights } from './services/insights';

import {
  addDoc,
  collection,
  onSnapshot,
  doc,
  setDoc,
  deleteDoc,
  query,
  orderBy,
  updateDoc,
  getDoc,
  getDocs,
  where,
  writeBatch,
  limit,
  deleteField,
  or
} from 'firebase/firestore';
import { onAuthStateChanged, signOut, sendEmailVerification } from 'firebase/auth';
import { getFunctions, httpsCallable } from 'firebase/functions';
import { db, auth, app, refreshPushToken, onForegroundPush } from './firebase';
import { markNotificationsRead } from './services/notificationService';
import { toast } from './services/toast';
import {
  User,
  UserRole,
  Project,
  Task,
  Transaction,
  AttendanceRecord,
  Customer,
  Subscription,
  LicenseSale,
  ServiceSale,
  BillingCycle,
  StaffDocument,
  SMSConfig,
  SMSLog,
  SMSTemplate,
  Invoice,
  ChatMessage,
  Currency,
  Debt,
  SalaryPayment,
  Installment,
  ProjectType,
  UserActivity,
  ScreenRequest,
  Deal,
  DealStatus,
  PersonnelTransaction,
  LeaveRequest,
  InventoryItem,
  Vendor,
  PurchaseOrder,
  TaskStatus,
  ExtraJob,
  PortalSettings,
  HRSettings,
  FinanceSettings,
  SystemNotification,
  Meeting,
  CRMActivity,
  Ticket,
  ProjectFormSettings,
  DEFAULT_PROJECT_FORM_SETTINGS,
  CompanySettings,
  AlertSettings,
  DEFAULT_ALERT_SETTINGS
} from './types';
import type { SettingsTab } from './components/SettingsView';
import { translations } from './translations';
import { logAudit } from './services/auditService';

const getLocalISODate = () => {
  const d = new Date();
  const year = d.getFullYear();
  const month = String(d.getMonth() + 1).padStart(2, '0');
  const day = String(d.getDate()).padStart(2, '0');
  return `${year}-${month}-${day}`;
};

// Audio system (unchanged)
const playSimpleBeep = () => {
  try {
    const beep = "data:audio/wav;base64,UklGRl9vT19XQVZFZm10IBAAAAABAAEAQB8AAEAfAAABAAgAZGF0YU";
    const audio = new Audio(beep);
    audio.volume = 0.5;
    audio.play().catch(e => console.log("Audio play error", e));
  } catch (e) {
    // Ignore
  }
};

let audioCtx: AudioContext | null = null;

const initAudio = () => {
  if (!audioCtx) {
    const Ctx = window.AudioContext || (window as any).webkitAudioContext;
    if (Ctx) {
      audioCtx = new Ctx();
    }
  }
};

const playPingSound = () => {
  if (!audioCtx) initAudio();
  if (!audioCtx) {
    playSimpleBeep();
    return;
  }

  if (audioCtx.state === 'suspended') {
    audioCtx.resume().catch(() => playSimpleBeep());
  }

  try {
    const osc = audioCtx.createOscillator();
    const gain = audioCtx.createGain();

    osc.connect(gain);
    gain.connect(audioCtx.destination);

    osc.type = 'sine';
    const now = audioCtx.currentTime;

    osc.frequency.setValueAtTime(880, now);
    osc.frequency.exponentialRampToValueAtTime(440, now + 0.5);

    gain.gain.setValueAtTime(0.1, now);
    gain.gain.linearRampToValueAtTime(0.3, now + 0.05);
    gain.gain.exponentialRampToValueAtTime(0.001, now + 0.5);

    osc.start(now);
    osc.stop(now + 0.5);
  } catch (e) {
    playSimpleBeep();
  }
};

// Error Boundary (unchanged)
interface ErrorBoundaryProps {
  children: React.ReactNode;
  language: 'tr' | 'en';
}

interface ErrorBoundaryState {
  hasError: boolean;
}

class ErrorBoundary extends React.Component<ErrorBoundaryProps, ErrorBoundaryState> {
  constructor(props: ErrorBoundaryProps) {
    super(props);
    this.state = { hasError: false };
  }

  static getDerivedStateFromError() {
    return { hasError: true };
  }

  componentDidCatch(error: any, errorInfo: any) {
    console.error("React Error Boundary caught an error:", error, errorInfo);
  }

  render() {
    if (this.state.hasError) {
      return (
        <div className="h-dvh w-screen flex flex-col items-center justify-center bg-[#020617] text-white p-6 text-center">
          <h2 className="text-2xl font-bold mb-4">
            {this.props.language === 'tr' ? 'Bir şeyler ters gitti.' : 'Something went wrong.'}
          </h2>
          <p className="text-slate-400 mb-8 max-w-md">
            {this.props.language === 'tr' 
              ? 'Uygulama yüklenirken bir hata oluştu. Lütfen sayfayı yenilemeyi deneyin.' 
              : 'An error occurred while loading the application. Please try refreshing the page.'}
          </p>
          <button 
            onClick={() => window.location.reload()}
            className="bg-indigo-600 px-8 py-4 rounded-2xl font-bold uppercase tracking-widest hover:bg-indigo-500 transition-all"
          >
            {this.props.language === 'tr' ? 'SAYFAYI YENİLE' : 'REFRESH PAGE'}
          </button>
        </div>
      );
    }
    return this.props.children;
  }
}

// Loading fallback component
const LoadingFallback = () => (
  <div className="h-dvh w-screen flex flex-col items-center justify-center bg-[#020617] text-white gap-8">
    <div className="relative">
      <div className="w-20 h-20 border-4 border-indigo-500/20 border-t-indigo-500 rounded-full animate-spin"></div>
      <div className="absolute inset-0 flex items-center justify-center">
        <Loader2 size={24} className="text-indigo-500 animate-pulse" />
      </div>
    </div>
    <p className="text-[10px] font-black text-slate-500 uppercase tracking-[0.3em]">YÜKLENİYOR...</p>
  </div>
);

// Yeni tasarım diliyle yeniden yazılan sayfalar; diğerlerine pc-legacy uyum katmanı uygulanır
const PRIVATE_USER_KEYS = ['monthlySalary', 'salaryCurrency', 'iban', 'bankName', 'tcNo'] as const;

const REVISED_TABS = new Set(['myday', 'myteam', 'operations', 'projects', 'extrajobs', 'accounting', 'settings', 'mytasks', 'tasks', 'kanban', 'leave', 'tickets', 'inventory', 'purchasing', 'meetings', 'sales', 'attendance', 'staffdocs', 'personnelfinance', 'archive', 'ai', 'clientportal', 'portalmanagement', 'teammonitoring', 'invoices', 'crm', 'team', 'customersms', 'messages']);

// Modül yüklenirken gösterilen parıltılı iskelet
const ViewSkeleton = () => (
  <div className="space-y-6 animate-in fade-in duration-300">
    <div className="h-40 rounded-[32px] pc-skeleton" />
    <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-4 gap-4">
      {[0, 1, 2, 3].map(i => <div key={i} className="h-36 rounded-[28px] pc-skeleton" style={{ animationDelay: `${i * 120}ms` }} />)}
    </div>
    <div className="h-72 rounded-[32px] pc-skeleton" />
  </div>
);

const App: React.FC = () => {
  const [activeTab, setActiveTab] = useState('');
  const [showCustomerModal, setShowCustomerModal] = useState(false);
  const [editingCustomer, setEditingCustomer] = useState<Customer | null>(null);
  const [showNotifications, setShowNotifications] = useState(false);
  const [selectedPortalProjectId, setSelectedPortalProjectId] = useState<string | null>(null);
  const [language, setLanguage] = useState<'tr' | 'en'>(() => {
    try { return localStorage.getItem('panimo-language') === 'en' ? 'en' : 'tr'; } catch { return 'tr'; }
  });
  useEffect(() => {
    try { localStorage.setItem('panimo-language', language); } catch {}
    document.documentElement.lang = language;
  }, [language]);
  const [reduceMotion, setReduceMotion] = useState<boolean>(() => {
    try { return localStorage.getItem('panimo-reduce-motion') === '1'; } catch { return false; }
  });
  useEffect(() => {
    try { localStorage.setItem('panimo-reduce-motion', reduceMotion ? '1' : '0'); } catch {}
    document.documentElement.classList.toggle('pc-reduce-motion', reduceMotion);
  }, [reduceMotion]);
  const [currentUser, setCurrentUser] = useState<User | null>(null);
  const showFinancials = currentUser ? ['Admin', 'Manager', 'Accountant'].includes(currentUser.role) : false;

  type ThemeMode = 'auto' | 'dark' | 'light';

  const [themeMode, setThemeMode] = useState<ThemeMode>(() => {
    try {
      const saved = localStorage.getItem('panimo-darkmode');
      if (saved === 'dark' || saved === 'light' || saved === 'auto') return saved as ThemeMode;
      if (saved === 'true') return 'dark';
      if (saved === 'false') return 'light';
    } catch {}
    return 'auto';
  });

  const [isDark, setIsDark] = useState<boolean>(() => {
    if (themeMode === 'dark') return true;
    if (themeMode === 'light') return false;
    return typeof window !== 'undefined' && window.matchMedia('(prefers-color-scheme: dark)').matches;
  });

  // Dynamic automatic dark mode effect with OS listener
  useEffect(() => {
    const mediaQuery = window.matchMedia('(prefers-color-scheme: dark)');

    const applyTheme = () => {
      let active = false;
      if (themeMode === 'dark') {
        active = true;
      } else if (themeMode === 'light') {
        active = false;
      } else {
        active = mediaQuery.matches;
      }

      setIsDark(active);
      if (active) {
        document.documentElement.classList.add('dark');
      } else {
        document.documentElement.classList.remove('dark');
      }
    };

    applyTheme();

    const handleSystemChange = (e: MediaQueryListEvent) => {
      if (themeMode === 'auto') {
        setIsDark(e.matches);
        if (e.matches) {
          document.documentElement.classList.add('dark');
        } else {
          document.documentElement.classList.remove('dark');
        }
      }
    };

    if (mediaQuery.addEventListener) {
      mediaQuery.addEventListener('change', handleSystemChange);
    } else {
      mediaQuery.addListener(handleSystemChange);
    }

    try { localStorage.setItem('panimo-darkmode', themeMode); } catch {}

    return () => {
      if (mediaQuery.removeEventListener) {
        mediaQuery.removeEventListener('change', handleSystemChange);
      } else {
        mediaQuery.removeListener(handleSystemChange);
      }
    };
  }, [themeMode]);

  const cycleTheme = () => {
    if (themeMode === 'auto') setThemeMode('dark');
    else if (themeMode === 'dark') setThemeMode('light');
    else setThemeMode('auto');
  };

  // ✅ OPTIMIZED LOADING STATES
  const [loadingAuth, setLoadingAuth] = useState(true);
  const [loadingInitialData, setLoadingInitialData] = useState(false);
  const [loadingBackgroundData, setLoadingBackgroundData] = useState(false);

  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const [showPalette, setShowPalette] = useState(false);
  const [sidebarCollapsed, setSidebarCollapsed] = useState<boolean>(() => {
    try { return localStorage.getItem('panimo-sidebar-collapsed') === '1'; } catch { return false; }
  });
  useEffect(() => {
    try { localStorage.setItem('panimo-sidebar-collapsed', sidebarCollapsed ? '1' : '0'); } catch {}
  }, [sidebarCollapsed]);

  // ⌘K / Ctrl+K: komut paleti
  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if ((e.metaKey || e.ctrlKey) && e.key.toLowerCase() === 'k') {
        e.preventDefault();
        setShowPalette(v => !v);
      }
    };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, []);
  const [rates, setRates] = useState({ TRY: 34.35, EUR: 0.92 });
  const [loadingRates, setLoadingRates] = useState(false);

  // ✅ CRITICAL DATA (ilk yüklemede gerekli)
  const [usersRaw, setUsers] = useState<User[]>([]);
  // Maaş/IBAN/TC gibi gizli bilgiler user_private koleksiyonundadır; yetkisi olan görür ve profillerle birleştirilir
  const [privateData, setPrivateData] = useState<Record<string, Partial<User>>>({});
  const users = useMemo(() => usersRaw.map(u => (privateData[u.id] ? { ...u, ...privateData[u.id] } : u)), [usersRaw, privateData]);
  // Giriş ekranında gösterilecek bilgilendirme (doğrulama e-postası, tanımsız e-posta vb.)
  const [authNotice, setAuthNotice] = useState<string | null>(null);
  const [projects, setProjects] = useState<Project[]>([]);
  const [tasks, setTasks] = useState<Task[]>([]);

  // ✅ SECONDARY DATA (arka planda yüklenir)
  const [transactions, setTransactions] = useState<Transaction[]>([]);
  const [subscriptions, setSubscriptions] = useState<Subscription[]>([]);
  const [sales, setSales] = useState<LicenseSale[]>([]);
  const [serviceSales, setServiceSales] = useState<ServiceSale[]>([]);
  const [attendance, setAttendance] = useState<AttendanceRecord[]>([]);
  const [customers, setCustomers] = useState<Customer[]>([]);
  const [staffDocuments, setStaffDocuments] = useState<StaffDocument[]>([]);
  const [invoices, setInvoices] = useState<Invoice[]>([]);
  const [debts, setDebts] = useState<Debt[]>([]);
  const [salaryPayments, setSalaryPayments] = useState<SalaryPayment[]>([]);
  const [personnelTransactions, setPersonnelTransactions] = useState<PersonnelTransaction[]>([]);
  const [leaveRequests, setLeaveRequests] = useState<LeaveRequest[]>([]);
  const [inventoryItems, setInventoryItems] = useState<InventoryItem[]>([]);
  const [vendors, setVendors] = useState<Vendor[]>([]);
  const [purchaseOrders, setPurchaseOrders] = useState<PurchaseOrder[]>([]);
  const [smsConfig, setSmsConfig] = useState<SMSConfig>({ usercode: '', password: '', msgheader: '' });
  const [smsTemplates, setSmsTemplates] = useState<SMSTemplate[]>([]);
  const [screenRequests, setScreenRequests] = useState<ScreenRequest[]>([]);
  const [deals, setDeals] = useState<Deal[]>([]);
  const [systemNotifications, setSystemNotifications] = useState<SystemNotification[]>([]);
  const [userActivities, setUserActivities] = useState<UserActivity[]>([]);
  const [extraJobs, setExtraJobs] = useState<ExtraJob[]>([]);
  const [tickets, setTickets] = useState<Ticket[]>([]);
  const [meetings, setMeetings] = useState<Meeting[]>([]);
  const [crmActivities, setCrmActivities] = useState<CRMActivity[]>([]);
  const [hrSettings, setHrSettings] = useState<HRSettings>({ dailyWorkHours: 9, defaultAnnualLeaveDays: 14 });
  const [financeSettings, setFinanceSettings] = useState<FinanceSettings>({ defaultTaxRate: 20 });
  const [projectFormSettings, setProjectFormSettings] = useState<ProjectFormSettings>(DEFAULT_PROJECT_FORM_SETTINGS);
  const [companySettings, setCompanySettings] = useState<CompanySettings>({});
  const [alertSettings, setAlertSettings] = useState<AlertSettings>(DEFAULT_ALERT_SETTINGS);
  const [settingsTab, setSettingsTab] = useState<SettingsTab>('appearance');

  // ✅ AUTH LISTENER (Hızlı - sadece user ID ve role)
  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, async (firebaseUser) => {
      if (firebaseUser) {
        try {
          const userDocRef = doc(db, "users", firebaseUser.uid);
          let userDoc = await getDoc(userDocRef);
          
          if (userDoc.exists()) {
            setCurrentUser({ ...userDoc.data(), id: firebaseUser.uid } as User);
          } else {
            // İlk giriş: yönetimin tanımladığı profil sunucu tarafında bu hesaba taşınır (linkAccount).
            // E-posta doğrulanmadan taşınmaz; tanımsız e-postayla açılan hesap sunucuda silinir.
            try {
              await httpsCallable(getFunctions(app), 'linkAccount')({});
              userDoc = await getDoc(userDocRef);
              if (userDoc.exists()) setCurrentUser({ ...userDoc.data(), id: firebaseUser.uid } as User);
            } catch (e: any) {
              const code = String(e?.code || '');
              if (code.includes('failed-precondition')) {
                try { await sendEmailVerification(firebaseUser); } catch { /* sık gönderimde Firebase sınırlar */ }
                setAuthNotice(`Hesabını etkinleştirmek için ${firebaseUser.email} adresine gönderilen doğrulama bağlantısına tıkla, ardından giriş yap.`);
              } else if (code.includes('not-found')) {
                setAuthNotice('Bu e-posta sistemde tanımlı değil. Yöneticinden seni ekip listesine eklemesini iste.');
              } else {
                setAuthNotice('Hesap bağlanamadı. Lütfen biraz sonra tekrar dene.');
              }
              await signOut(auth);
            }
          }
        } catch (error) {
          console.error("User fetch/linking error:", error);
        }
      } else {
        setCurrentUser(null);
        setActiveTab(prev => prev === 'public-portal' ? prev : '');
      }
      setLoadingAuth(false);
    });
    return () => unsubscribe();
  }, []);

  // ✅ GİZLİ ALANLAR: kişiye göre dinle; yönetici açıldığında eski kayıtları otomatik taşı
  const canSeePrivate = !!currentUser && (['Admin', 'Manager', 'Accountant'].includes(currentUser.role) || !!currentUser.permissions?.includes('personnel'));
  useEffect(() => {
    if (!currentUser) { setPrivateData({}); return; }
    const toMap = (docs: { id: string; data: () => any }[]) => Object.fromEntries(docs.map(d => [d.id, d.data()]));
    if (canSeePrivate) {
      return onSnapshot(collection(db, 'user_private'), snap => setPrivateData(toMap(snap.docs)), () => setPrivateData({}));
    }
    return onSnapshot(doc(db, 'user_private', currentUser.id), snap => setPrivateData(snap.exists() ? { [snap.id]: snap.data() as Partial<User> } : {}), () => setPrivateData({}));
  }, [currentUser?.id, canSeePrivate]); // eslint-disable-line react-hooks/exhaustive-deps

  const migratedPrivateRef = useRef(false);
  useEffect(() => {
    if (currentUser?.role !== 'Admin' || migratedPrivateRef.current || usersRaw.length === 0) return;
    const legacy = usersRaw.filter(u => PRIVATE_USER_KEYS.some(k => (u as any)[k] !== undefined) || (u as any).password !== undefined);
    migratedPrivateRef.current = true;
    if (!legacy.length) return;
    (async () => {
      for (const u of legacy) {
        const priv: any = { id: u.id };
        PRIVATE_USER_KEYS.forEach(k => { if ((u as any)[k] !== undefined) priv[k] = (u as any)[k]; });
        await setDoc(doc(db, 'user_private', u.id), priv, { merge: true });
        const strip: any = { password: deleteField() };
        PRIVATE_USER_KEYS.forEach(k => { strip[k] = deleteField(); });
        await updateDoc(doc(db, 'users', u.id), strip);
      }
      console.log(`${legacy.length} kullanıcının gizli bilgileri user_private koleksiyonuna taşındı.`);
    })().catch(e => console.error('Private data migration failed', e));
  }, [currentUser?.role, usersRaw]);

  // ✅ PUBLIC PORTAL ACCESS CHECK
  useEffect(() => {
    const params = new URLSearchParams(window.location.search);
    const portalId = params.get('portal');
    if (portalId) {
      setSelectedPortalProjectId(portalId);
      setActiveTab('public-portal');
    }
  }, []);

  // ✅ INITIAL TAB SETTING BASED ON ROLE
  useEffect(() => {
    if (currentUser && activeTab === '') {
      // Push bildirimine tıklanınca gelen ?tab= yönlendirmesi
      const deepTab = new URLSearchParams(window.location.search).get('tab');
      if (deepTab) { window.history.replaceState(null, '', '/'); if (deepTab === 'archive') setSettingsTab('archive'); setActiveTab(deepTab === 'systemlogs' || deepTab === 'archive' ? 'settings' : deepTab); return; }
      if (currentUser.role === 'Admin' || currentUser.role === 'Manager' || currentUser.permissions?.includes('dashboard')) {
        setActiveTab('operations');
      } else if (currentUser.role === 'Sales') {
        setActiveTab('crm');
      } else {
        setActiveTab('myday');
      }
    }
  }, [currentUser, activeTab]);

  // ✅ CRITICAL DATA LOADING (İlk yüklemede gösterilir)
  useEffect(() => {
    if (!currentUser && activeTab !== 'public-portal') return;

    setLoadingInitialData(true);
    const criticalCollections = new Set<string>();
    const timeout = setTimeout(() => setLoadingInitialData(false), 8000);

    const checkCriticalLoaded = (collectionName: string) => {
      criticalCollections.add(collectionName);
      if (criticalCollections.size >= 3) {
        clearTimeout(timeout);
        setLoadingInitialData(false);
      }
    };

    let unsubUsers = () => {};
    let unsubProjects = () => {};
    let unsubTasks = () => {};

    if (!currentUser && activeTab === 'public-portal' && selectedPortalProjectId) {
      unsubUsers = onSnapshot(collection(db, "users"), (snapshot) => {
        setUsers(snapshot.docs.map(doc => ({ ...doc.data(), id: doc.id } as User)));
        checkCriticalLoaded('users');
      }, () => checkCriticalLoaded('users'));
      
      unsubProjects = onSnapshot(
        doc(db, "projects", selectedPortalProjectId),
        (docSnap) => {
          if (docSnap.exists()) {
            setProjects([{ id: docSnap.id, ...docSnap.data() } as Project]);
          }
          checkCriticalLoaded('projects');
        },
        () => checkCriticalLoaded('projects')
      );

      unsubTasks = onSnapshot(
        query(collection(db, "tasks"), where("projectId", "==", selectedPortalProjectId)),
        (snapshot) => {
          setTasks(snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as Task)));
          checkCriticalLoaded('tasks');
        },
        () => checkCriticalLoaded('tasks')
      );
    } else {
      unsubUsers = onSnapshot(collection(db, "users"), (snapshot) => {
        setUsers(snapshot.docs.map(doc => ({ ...doc.data(), id: doc.id } as User)));
        checkCriticalLoaded('users');
      }, () => checkCriticalLoaded('users'));

      unsubProjects = onSnapshot(
        query(collection(db, "projects"), orderBy("name"), limit(100)),
        (snapshot) => {
          setProjects(snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as Project)));
          checkCriticalLoaded('projects');
        },
        () => checkCriticalLoaded('projects')
      );

      unsubTasks = onSnapshot(
        query(collection(db, "tasks"), limit(100)),
        (snapshot) => {
          setTasks(snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as Task)));
          checkCriticalLoaded('tasks');
        },
        () => checkCriticalLoaded('tasks')
      );
    }

    return () => {
      unsubUsers();
      unsubProjects();
      unsubTasks();
      clearTimeout(timeout);
    };
  }, [currentUser, activeTab, selectedPortalProjectId]);

  // ✅ BACKGROUND DATA LOADING (Arka planda, kullanıcı görmez)
  useEffect(() => {
    if (!currentUser || loadingInitialData) return;

    setLoadingBackgroundData(true);
    const backgroundTimeout = setTimeout(() => setLoadingBackgroundData(false), 15000);
    
    // Yükleme başladığında FCM token izinlerini iste (arka planda)
    // İzin penceresi açılmaz; izin daha önce verilmişse bu cihazın push anahtarı tazelenir
    refreshPushToken(currentUser.id).catch(console.error);

    const syncCollection = <T extends { id: string }>(
      collectionName: string,
      setter: React.Dispatch<React.SetStateAction<T[]>>,
      queryFn?: (c: any) => any
    ) => {
      const colRef = collection(db, collectionName);
      const q = queryFn ? queryFn(colRef) : colRef;
      return onSnapshot(q, (snapshot) => {
        setter(snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as T)));
      }, (error) => {
        console.log(`Permission restricted or error for ${collectionName}`);
      });
    };

    const unsubTransactions = syncCollection<Transaction>('transactions', setTransactions, (c) => query(c, orderBy("date", "desc"), limit(500)));
    const unsubSubscriptions = syncCollection<Subscription>('subscriptions', setSubscriptions, (c) => query(c, orderBy("nextBillingDate")));
    const unsubSales = syncCollection<LicenseSale>('sales', setSales, (c) => query(c, orderBy("expiryDate")));
    const unsubServiceSales = syncCollection<ServiceSale>('serviceSales', setServiceSales, (c) => query(c, orderBy("nextBillingDate")));
    // Mesai, izin ve personel dosyalarında kişi yalnızca kendi kayıtlarını görebilir (kurallar da bunu zorunlu kılar)
    const seesAllPeople = ['Admin', 'Manager', 'Accountant'].includes(currentUser.role);
    const unsubAttendance = syncCollection<AttendanceRecord>('attendance', setAttendance, seesAllPeople
      ? (c) => query(c, orderBy("id", "desc"), limit(1000))
      : (c) => query(c, where('userId', '==', currentUser.id), limit(1000)));
    const unsubCustomers = syncCollection<Customer>('customers', setCustomers);
    const unsubDocs = syncCollection<StaffDocument>('staff_documents', setStaffDocuments, currentUser.role === 'Admin' ? undefined
      : (c) => query(c, or(where('userId', '==', currentUser.id), where('sharedById', '==', currentUser.id))));
    const unsubInvoices = syncCollection<Invoice>('invoices', setInvoices);
    // sms_logs artık burada dinlenmiyor: Müşteri SMS sayfası geçmişi 10'arlı sayfalarla sunucudan çeker
    const unsubDebts = syncCollection<Debt>('debts', setDebts);
    const unsubSalaryPayments = syncCollection<SalaryPayment>('salary_payments', setSalaryPayments);
    const unsubPersonnelTransactions = syncCollection<PersonnelTransaction>('personnel_transactions', setPersonnelTransactions);
    const unsubLeaveRequests = syncCollection<LeaveRequest>('leave_requests', setLeaveRequests, seesAllPeople ? undefined : (c) => query(c, where('userId', '==', currentUser.id)));
    const unsubInventory = syncCollection<InventoryItem>('inventory', setInventoryItems);
    const unsubVendors = syncCollection<Vendor>('vendors', setVendors);
    const unsubPurchaseOrders = syncCollection<PurchaseOrder>('purchase_orders', setPurchaseOrders);
    // İzleme yetkisi olmayan kişi yalnızca kendisine gelen ekran paylaşım isteklerini dinler (kurallar da bunu zorunlu kılar)
    const canMonitor = currentUser.role === 'Admin' || currentUser.role === 'Manager' || !!currentUser.permissions?.includes('monitoring');
    const unsubScreenRequests = syncCollection<ScreenRequest>('screen_requests', setScreenRequests, canMonitor ? undefined : (c) => query(c, where('toId', '==', currentUser.id)));
    const unsubDeals = syncCollection<Deal>('deals', setDeals);
    const unsubUserActivities = syncCollection<UserActivity>('user_activity', setUserActivities);
    const unsubExtraJobs = syncCollection<ExtraJob>('extra_jobs', setExtraJobs);
    const unsubTickets = syncCollection<Ticket>('tickets', setTickets);
    const unsubMeetings = syncCollection<Meeting>('meetings', setMeetings);
    const unsubCrmActivities = syncCollection<CRMActivity>('crm_activities', setCrmActivities);
    const unsubSystemNotifs = syncCollection<SystemNotification>('system_notifications', setSystemNotifications, (c) => query(c, orderBy("createdAt", "desc"), limit(50)));

    const unsubSmsTemplates = syncCollection<SMSTemplate>('sms_templates', setSmsTemplates);
    const unsubSmsConfig = onSnapshot(doc(db, "sms_settings", "config"), (snapshot) => {
      if (snapshot.exists()) {
        setSmsConfig(snapshot.data() as SMSConfig);
      }
    }, () => {});

    const unsubHrSettings = onSnapshot(doc(db, "system_settings", "hr"), (snapshot) => {
      if (snapshot.exists()) {
        setHrSettings(snapshot.data() as HRSettings);
      }
    });

    const unsubFinanceSettings = onSnapshot(doc(db, "system_settings", "finance"), (snapshot) => {
      if (snapshot.exists()) {
        setFinanceSettings(snapshot.data() as FinanceSettings);
      }
    });

    const unsubCompanySettings = onSnapshot(doc(db, "system_settings", "company"), (snapshot) => {
      setCompanySettings((snapshot.data() as CompanySettings) || {});
    }, () => {});
    const unsubAlertSettings = onSnapshot(doc(db, "system_settings", "alerts"), (snapshot) => {
      setAlertSettings({ ...DEFAULT_ALERT_SETTINGS, ...((snapshot.data() as AlertSettings) || {}) });
    }, () => {});

    const unsubProjectFormSettings = onSnapshot(doc(db, "system_settings", "projectForm"), (snapshot) => {
      const data = snapshot.data() as ProjectFormSettings | undefined;
      setProjectFormSettings(data?.required ? data : DEFAULT_PROJECT_FORM_SETTINGS);
    }, () => {});

    setTimeout(() => setLoadingBackgroundData(false), 12000);

    return () => {
      unsubTransactions();
      unsubSubscriptions();
      unsubSales();
      unsubServiceSales();
      unsubAttendance();
      unsubCustomers();
      unsubDocs();
      unsubInvoices();
      unsubSmsTemplates();
      unsubDebts();
      unsubSalaryPayments();
      unsubPersonnelTransactions();
      unsubLeaveRequests();
      unsubInventory();
      unsubVendors();
      unsubPurchaseOrders();
      unsubScreenRequests();
      unsubDeals();
      unsubUserActivities();
      unsubExtraJobs();
      unsubTickets();
      unsubMeetings();
      unsubCrmActivities();
      unsubSystemNotifs();
      unsubSmsConfig();
      unsubHrSettings();
      unsubFinanceSettings();
      unsubProjectFormSettings();
      unsubCompanySettings();
      unsubAlertSettings();
      clearTimeout(backgroundTimeout);
    };
  }, [currentUser, loadingInitialData]);

  const fetchRates = async () => {
    setLoadingRates(true);
    try {
      const res = await fetch('https://open.er-api.com/v6/latest/USD');
      const data = await res.json();
      if (data && data.rates) {
        setRates({ TRY: data.rates.TRY, EUR: data.rates.EUR });
      }
    } catch (error) {
      console.error("Currency fetch error:", error);
    } finally {
      setLoadingRates(false);
    }
  };

  useEffect(() => {
    fetchRates();
  }, []);

  const t = translations[language];

  // ✅ CRUD HANDLERS
  const upsertDoc = async (collectionName: string, data: any) => {
    // Firestore undefined kabul etmez: üst seviyede undefined = alanı sil, iç içe olanlar ayıklanır
    const clean = (v: any): any => Array.isArray(v) ? v.filter(x => x !== undefined).map(clean)
      : v && typeof v === 'object' && Object.getPrototypeOf(v) === Object.prototype ? Object.fromEntries(Object.entries(v).filter(([, x]) => x !== undefined).map(([k, x]) => [k, clean(x)])) : v;
    const payload = Object.fromEntries(Object.entries(data).map(([k, v]) => [k, v === undefined ? deleteField() : clean(v)]));
    await setDoc(doc(db, collectionName, data.id), payload, { merge: true });
  };

  const handleUpsertTicket = async (ticket: Ticket) => {
    await upsertDoc('tickets', ticket);
  };

  const deleteDocById = async (collectionName: string, id: string) => {
    await deleteDoc(doc(db, collectionName, id));
  };

  const handleUpsertProject = async (p: any) => { await upsertDoc('projects', p); if (currentUser) logAudit(currentUser, 'UPDATE', 'Project', `Proje güncellendi: ${p.name || p.id}`, p.id); };
  const handleDeleteProject = async (id: string) => { await deleteDocById('projects', id); if (currentUser) logAudit(currentUser, 'DELETE', 'Project', `Proje silindi: ${id}`, id); };
  const handleAddTask = async (task: any) => { 
    await addDoc(collection(db, 'tasks'), task); 
    if (currentUser) logAudit(currentUser, 'CREATE', 'Task', `Görev eklendi: ${task.title}`);
  };

  const handleNavigate = (tab: string, param?: string) => {
    // Sistem kayıtları artık Ayarlar içinde
    if (tab === 'systemlogs') { setSettingsTab('logs'); tab = 'settings'; }
    else if (tab === 'archive') { setSettingsTab('archive'); tab = 'settings'; }
    else if (tab === 'settings' && param) setSettingsTab(param as SettingsTab);
    setActiveTab(tab);
    if (tab === 'clientportal' && param) {
      setSelectedPortalProjectId(param);
      window.history.pushState(null, '', `?portal=${param}`);
    } else {
      window.history.pushState(null, '', '/');
    }
    setIsMobileMenuOpen(false);
  };
  const handleUpdateTask = async (task: any) => { await upsertDoc('tasks', task); if (currentUser) logAudit(currentUser, 'UPDATE', 'Task', `Görev güncellendi: ${task.title || task.id}`, task.id); };
  const handleDeleteTask = async (id: string) => { await deleteDocById('tasks', id); if (currentUser) logAudit(currentUser, 'DELETE', 'Task', `Görev silindi: ${id}`, id); };
  const handleUpsertTransaction = async (tx: any) => { await upsertDoc('transactions', tx); if (currentUser) logAudit(currentUser, 'UPDATE', 'Transaction', `Finansal işlem: ${tx.amount} ${tx.currency}`, tx.id); };
  const handleDeleteTransaction = async (id: string) => { await deleteDocById('transactions', id); if (currentUser) logAudit(currentUser, 'DELETE', 'Transaction', `Finansal işlem silindi: ${id}`, id); };
  const handleUpsertSubscription = async (sub: any) => { await upsertDoc('subscriptions', sub); if (currentUser) logAudit(currentUser, 'UPDATE', 'Transaction', `Abonelik güncellendi: ${sub.name}`, sub.id); };
  const handleDeleteSubscription = async (id: string) => { await deleteDocById('subscriptions', id); if (currentUser) logAudit(currentUser, 'DELETE', 'Transaction', `Abonelik silindi: ${id}`, id); };
  const handleUpsertDebt = async (debt: any) => { await upsertDoc('debts', debt); if (currentUser) logAudit(currentUser, 'UPDATE', 'Transaction', `Borç kaydı güncellendi: ${debt.amount} ${debt.currency}`, debt.id); };
  const handleDeleteDebt = async (id: string) => { await deleteDocById('debts', id); if (currentUser) logAudit(currentUser, 'DELETE', 'Transaction', `Borç kaydı silindi: ${id}`, id); };
  const handleUpsertSalaryPayment = async (p: any) => { await upsertDoc('salary_payments', p); if (currentUser) logAudit(currentUser, 'UPDATE', 'Transaction', `Maaş ödemesi: ${p.amount} ${p.currency} -> ${p.userName}`, p.id); };
  const handleDeleteSalaryPayment = async (id: string) => { await deleteDocById('salary_payments', id); if (currentUser) logAudit(currentUser, 'DELETE', 'Transaction', `Maaş ödemesi silindi: ${id}`, id); };
  const handleUpsertSale = async (sale: any) => { await upsertDoc('sales', sale); if (currentUser) logAudit(currentUser, 'UPDATE', 'Transaction', `Satış güncellendi: ${sale.amount} ${sale.currency}`, sale.id); };
  const handleDeleteSale = async (id: string) => { await deleteDocById('sales', id); if (currentUser) logAudit(currentUser, 'DELETE', 'Transaction', `Satış silindi: ${id}`, id); };
  const handleUpsertServiceSale = async (s: any) => { await upsertDoc('serviceSales', s); if (currentUser) logAudit(currentUser, 'UPDATE', 'Transaction', `Hizmet satışı güncellendi: ${s.amount} ${s.currency}`, s.id); };
  const handleDeleteServiceSale = async (id: string) => { await deleteDocById('serviceSales', id); if (currentUser) logAudit(currentUser, 'DELETE', 'Transaction', `Hizmet satışı silindi: ${id}`, id); };
  const handleUpsertUser = async (u: any) => {
    // Gizli alanlar (maaş, IBAN, banka, TC) profilde değil user_private koleksiyonunda tutulur
    const pub: any = {}; const priv: any = { id: u.id }; let hasPriv = false;
    Object.entries(u).forEach(([k, v]) => { if (k === 'password') return; if ((PRIVATE_USER_KEYS as readonly string[]).includes(k)) { priv[k] = v; hasPriv = true; } else pub[k] = v; });
    await upsertDoc('users', pub);
    if (hasPriv) await upsertDoc('user_private', priv);
    if (currentUser) logAudit(currentUser, 'UPDATE', 'User', `Kullanıcı güncellendi: ${u.name}`, u.id);
  };
  const handleDeleteUser = async (id: string) => { await deleteDocById('users', id); await deleteDocById('user_private', id).catch(() => {}); if (currentUser) logAudit(currentUser, 'DELETE', 'User', `Kullanıcı silindi: ${id}`, id); };
  const handleUpsertExtraJob = async (job: any) => { await upsertDoc('extra_jobs', job); if (currentUser) logAudit(currentUser, 'UPDATE', 'Project', `Ek İş: ${job.title}`, job.id); };
  const handleDeleteExtraJob = async (id: string) => { await deleteDocById('extra_jobs', id); if (currentUser) logAudit(currentUser, 'DELETE', 'Project', `Ek İş silindi: ${id}`, id); };
  const handleUpsertMeeting = async (meeting: any) => { await upsertDoc('meetings', meeting); if (currentUser) logAudit(currentUser, 'UPDATE', 'Other', `Toplantı güncellendi: ${meeting.title}`, meeting.id); };
  const handleDeleteMeeting = async (id: string) => { await deleteDocById('meetings', id); if (currentUser) logAudit(currentUser, 'DELETE', 'Other', `Toplantı silindi: ${id}`, id); };

  const getCurrentLocation = (): Promise<{ lat: number, lng: number, address?: string } | null> => {
    return new Promise((resolve) => {
      if (!navigator.geolocation) {
        resolve(null);
        return;
      }
      navigator.geolocation.getCurrentPosition(
        (position) => {
          resolve({
            lat: position.coords.latitude,
            lng: position.coords.longitude,
            address: `Lat: ${position.coords.latitude.toFixed(4)}, Lng: ${position.coords.longitude.toFixed(4)}`
          });
        },
        () => resolve(null),
        { timeout: 10000 }
      );
    });
  };

  const isClockingInRef = useRef(false);

  const handleClockIn = async (userId: string, userName: string) => {
    if (isClockingInRef.current) return;
    isClockingInRef.current = true;

    try {
      const today = getLocalISODate();
      const hasActive = attendance.some(rec => rec.userId === userId && rec.date === today && !rec.clockOut);
      if (hasActive) return;

      const id = `att_${userId}_${Date.now()}`;
      const now = new Date().toLocaleTimeString('tr-TR', { hour: '2-digit', minute: '2-digit' });
      const location = await getCurrentLocation();
      
      await upsertDoc('attendance', { 
        id, 
        userId, 
        userName, 
        date: today, 
        clockIn: now,
        location: location || undefined
      });

      if (currentUser) {
        // Yalnızca durum alanı yazılır; tüm profili geri yazmak yönetimin yaptığı değişiklikleri ezer
        await upsertDoc('users', { id: currentUser.id, status: 'Online' });
      }
    } finally {
      isClockingInRef.current = false;
    }
  };

  const handleLogout = async () => {
    try {
      const activeRecords = attendance.filter(rec => rec.userId === currentUser?.id && !rec.clockOut);
      const now = new Date().toLocaleTimeString('tr-TR', { hour: '2-digit', minute: '2-digit' });
      const location = await getCurrentLocation();
      
      for (const rec of activeRecords) {
        await upsertDoc('attendance', { 
          ...rec, 
          clockOut: now,
          location: location || rec.location // Use latest location or keep entry location
        });
      }

      if (currentUser) {
        localStorage.removeItem(`last_clock_in_${currentUser.id}`);
        await upsertDoc('users', { id: currentUser.id, status: 'Offline' });
      }

      await signOut(auth);
    } catch (error) {
      console.error("Logout error:", error);
      await signOut(auth);
    }
  };

  // ✅ AUTO CLOCK-IN ON LOGIN
  useEffect(() => {
    if (currentUser && attendance.length > 0 && activeTab !== 'public-portal') {
      const today = getLocalISODate();
      const hasRecordToday = attendance.some(rec => rec.userId === currentUser.id && rec.date === today);
      
      if (!hasRecordToday) {
        handleClockIn(currentUser.id, currentUser.name);
      }
    }
  }, [currentUser, attendance.length, activeTab]);
  const handleUpsertCustomer = async (c: any) => { await upsertDoc('customers', c); if (currentUser) logAudit(currentUser, 'UPDATE', 'Other', `Müşteri güncellendi: ${c.name}`, c.id); };
  const handleDeleteCustomer = async (id: string) => { await deleteDocById('customers', id); if (currentUser) logAudit(currentUser, 'DELETE', 'Other', `Müşteri silindi: ${id}`, id); };
  const handleUpsertInvoice = async (inv: any) => { await upsertDoc('invoices', inv); if (currentUser) logAudit(currentUser, 'UPDATE', 'Invoice', `Fatura: ${inv.invoiceNumber}`, inv.id); };
  const handleDeleteInvoice = async (id: string) => { await deleteDocById('invoices', id); if (currentUser) logAudit(currentUser, 'DELETE', 'Invoice', `Fatura silindi: ${id}`, id); };
  const handleUpsertPersonnelTransaction = async (pt: any) => { await upsertDoc('personnel_transactions', pt); if (currentUser) logAudit(currentUser, 'UPDATE', 'Transaction', `Personel işlemi: ${pt.amount} ${pt.currency}`, pt.id); };
  const handleDeletePersonnelTransaction = async (id: string) => { await deleteDocById('personnel_transactions', id); if (currentUser) logAudit(currentUser, 'DELETE', 'Transaction', `Personel işlemi silindi: ${id}`, id); };
  const handleUpsertLeaveRequest = async (lr: any) => { await upsertDoc('leave_requests', lr); if (currentUser) logAudit(currentUser, 'UPDATE', 'Other', `İzin talebi güncellendi`, lr.id); };
  const handleDeleteLeaveRequest = async (id: string) => { await deleteDocById('leave_requests', id); if (currentUser) logAudit(currentUser, 'DELETE', 'Other', `İzin talebi silindi: ${id}`, id); };
  const handleUpsertInventoryItem = async (item: any) => { await upsertDoc('inventory', item); if (currentUser) logAudit(currentUser, 'UPDATE', 'Other', `Envanter: ${item.name}`, item.id); };
  const handleDeleteInventoryItem = async (id: string) => { await deleteDocById('inventory', id); if (currentUser) logAudit(currentUser, 'DELETE', 'Other', `Envanter öğesi silindi: ${id}`, id); };
  const handleUpsertVendor = async (v: any) => { await upsertDoc('vendors', v); if (currentUser) logAudit(currentUser, 'UPDATE', 'Other', `Tedarikçi: ${v.name}`, v.id); };
  const handleDeleteVendor = async (id: string) => { await deleteDocById('vendors', id); if (currentUser) logAudit(currentUser, 'DELETE', 'Other', `Tedarikçi silindi: ${id}`, id); };
  const handleUpsertPurchaseOrder = async (po: any) => { await upsertDoc('purchase_orders', po); if (currentUser) logAudit(currentUser, 'UPDATE', 'Other', `Satınalma: ${po.orderNumber}`, po.id); };
  const handleDeletePurchaseOrder = async (id: string) => { await deleteDocById('purchase_orders', id); if (currentUser) logAudit(currentUser, 'DELETE', 'Other', `Satınalma silindi: ${id}`, id); };
  const handleUpsertDeal = async (deal: any) => { await upsertDoc('deals', deal); if (currentUser) logAudit(currentUser, 'UPDATE', 'Deal', `Fırsat: ${deal.contactName}`, deal.id); };
  const handleDeleteDeal = async (id: string) => { await deleteDocById('deals', id); if (currentUser) logAudit(currentUser, 'DELETE', 'Deal', `Fırsat silindi: ${id}`, id); };
  const handleUpsertCrmActivity = async (activity: any) => { await upsertDoc('crm_activities', activity); if (currentUser) logAudit(currentUser, 'UPDATE', 'Deal', `Aktivite eklendi: ${activity.type}`, activity.id); };
  const handleDeleteCrmActivity = async (id: string) => { await deleteDocById('crm_activities', id); if (currentUser) logAudit(currentUser, 'DELETE', 'Deal', `Aktivite silindi: ${id}`, id); };

  // ✅ YÖNETİM ANALİZİ (üst bar rozetleri için; hook'lar erken return'lerden önce olmalı)
  const canSeeOps = currentUser?.role === 'Admin' || currentUser?.role === 'Manager' || !!currentUser?.permissions?.includes('dashboard');
  const insightInput = useMemo(() => {
    const myTasks = currentUser ? tasks.filter(t => (t.assignedTo || []).includes(currentUser.id)) : [];
    return {
      language, rates, canSeeFinance: showFinancials, users,
      projects: canSeeOps ? projects : [],
      tasks: canSeeOps ? tasks : myTasks,
      transactions, invoices, debts, subscriptions, sales, serviceSales, deals, crmActivities,
      leaveRequests: canSeeOps ? leaveRequests : [],
      attendance: canSeeOps ? attendance : attendance.filter(a => a.userId === currentUser?.id),
      inventoryItems: canSeeOps ? inventoryItems : [],
      purchaseOrders: canSeeOps ? purchaseOrders : [],
      tickets: canSeeOps ? tickets : [],
      extraJobs: canSeeOps ? extraJobs : [],
      meetings,
      alerts: alertSettings,
    };
  }, [alertSettings, language, rates, showFinancials, canSeeOps, currentUser, users, projects, tasks, transactions, invoices, debts, subscriptions, sales, serviceSales, deals, crmActivities, leaveRequests, attendance, inventoryItems, purchaseOrders, tickets, extraJobs, meetings]);
  const headerInsights = useMemo(() => (currentUser ? buildInsights(insightInput) : []), [insightInput, currentUser]);
  const criticalCount = headerInsights.filter(i => i.severity === 'critical').length;
  const urgentCount = headerInsights.filter(i => i.severity === 'critical' || i.severity === 'high').length;

  // ✅ BİLDİRİMLER: kişiye özel olanlar + (yönetici/müdür ise) genel olanlar; kendi oluşturduklarım okunmamış sayılmaz
  const myNotifications = useMemo(() => {
    if (!currentUser) return [];
    const manager = currentUser.role === 'Admin' || currentUser.role === 'Manager';
    return systemNotifications.filter(n => n.userId ? n.userId === currentUser.id : manager);
  }, [systemNotifications, currentUser]);
  const unreadNotifCount = useMemo(() => currentUser ? myNotifications.filter(n => !n.readBy?.includes(currentUser.id) && n.createdBy !== currentUser.id).length : 0, [myNotifications, currentUser]);

  // Uygulama açıkken yeni bildirim gelince kısa uyarı göster (ilk yüklemedekiler hariç)
  const seenNotifIds = useRef<Set<string> | null>(null);
  useEffect(() => {
    if (!currentUser) return;
    if (seenNotifIds.current === null) { if (myNotifications.length || !loadingInitialData) seenNotifIds.current = new Set(myNotifications.map(n => n.id)); return; }
    myNotifications.forEach(n => {
      if (seenNotifIds.current!.has(n.id)) return;
      seenNotifIds.current!.add(n.id);
      if (n.createdBy === currentUser.id) return;
      const kind = n.type === 'error' ? 'error' : n.type === 'warning' ? 'warning' : n.type === 'success' ? 'success' : 'info';
      toast(`${n.title}${n.description ? ` — ${n.description}` : ''}`, kind as any, 6000);
    });
  }, [myNotifications, currentUser, loadingInitialData]);

  // Uygulama açıkken gelen push'lar (sohbet) tarayıcıda gösterilmez; mesajlar sayfasında değilsek uygulama içinde göster
  const activeTabRef = useRef(activeTab);
  useEffect(() => { activeTabRef.current = activeTab; }, [activeTab]);
  useEffect(() => {
    if (!currentUser) return;
    let off: (() => void) | undefined;
    onForegroundPush(p => {
      if (!p.data?.url?.includes('tab=messages') || activeTabRef.current === 'messages') return;
      toast(`💬 ${p.title}: ${p.body}`, 'info', 5000);
    }).then(fn => { off = fn; }).catch(() => {});
    return () => off?.();
  }, [currentUser?.id]);

  // ✅ PUBLIC VIEW
  if (activeTab === 'public-portal' && selectedPortalProjectId) {
    if (loadingInitialData) {
      // The loader will be handled by the next condition, or we can just let it fall through
    } else {
      const project = projects.find(p => p.id === selectedPortalProjectId);
      if (project) {
        return (
          <Suspense fallback={<div className="h-dvh bg-[#020617] flex items-center justify-center"><Loader2 className="animate-spin text-white" /></div>}>
            <div className="h-dvh w-screen overflow-y-auto bg-slate-50 dark:bg-slate-950">
              <ClientPortalPreview project={project} tasks={tasks} language={language} users={users} tickets={tickets} onAddTicket={handleUpsertTicket} onUpdateProject={handleUpsertProject} company={companySettings} publicMode={!currentUser} />
            </div>
          </Suspense>
        );
      } else {
        // Data failed to load or project not found
        return (
          <div className="h-dvh w-screen flex flex-col items-center justify-center bg-[#020617] text-white">
            <Shield size={64} className="text-red-500 mb-6" />
            <h2 className="text-2xl font-black">
              {language === 'tr' ? 'Proje Bulunamadı veya Erişim Reddedildi' : 'Project Not Found or Access Denied'}
            </h2>
            <p className="text-slate-400 mt-2 text-center max-w-md">
              {language === 'tr' 
                ? 'Lütfen size verilen bağlantının doğru olduğundan emin olun. Veritabanı izinleri henüz güncellenmemiş olabilir.' 
                : 'Please ensure your link is correct. Database permissions might not be updated yet.'}
            </p>
          </div>
        );
      }
    }
  }

  // ✅ OPTIMIZED LOADING SCREEN
  if (loadingAuth || (currentUser && loadingInitialData) || (activeTab === 'public-portal' && loadingInitialData)) {
    return (
      <div className="h-dvh w-screen flex flex-col items-center justify-center bg-[#020617] text-white gap-8 relative overflow-hidden">
        <div className="absolute -top-32 -left-20 w-[28rem] h-[28rem] rounded-full bg-indigo-600/30 blur-3xl pc-blob"></div>
        <div className="absolute -bottom-40 -right-20 w-[30rem] h-[30rem] rounded-full bg-orange-500/20 blur-3xl pc-blob" style={{ animationDelay: '-7s' }}></div>
        <div className="absolute inset-0 opacity-[0.06]" style={{ backgroundImage: 'radial-gradient(circle at 1px 1px, white 1px, transparent 0)', backgroundSize: '24px 24px' }}></div>
        <div className="relative z-10 flex flex-col items-center gap-6">
          <div className="relative w-28 h-28 flex items-center justify-center">
            <div className="absolute inset-0 rounded-full border border-indigo-500/20 pc-orbit">
              <span className="absolute -top-1.5 left-1/2 -translate-x-1/2 w-3 h-3 rounded-full bg-indigo-400 shadow-[0_0_12px_#818cf8]"></span>
            </div>
            <div className="absolute inset-3 rounded-full border border-orange-500/20 pc-orbit" style={{ animationDuration: '9s', animationDirection: 'reverse' }}>
              <span className="absolute -bottom-1 left-1/2 -translate-x-1/2 w-2 h-2 rounded-full bg-orange-400 shadow-[0_0_10px_#fb923c]"></span>
            </div>
            <div className="w-14 h-14 bg-gradient-to-br from-indigo-500 to-violet-600 rounded-2xl flex items-center justify-center shadow-2xl shadow-indigo-500/40 pc-logo-in">
              <Shield size={26} className="text-white" />
            </div>
          </div>
          <div className="text-center animate-in fade-in slide-in-from-bottom-4 duration-700">
            <h1 className="text-3xl font-black italic tracking-tighter mb-3">Panimo<span className="text-orange-500">Cloud</span> <span className="text-indigo-400">ERP</span></h1>
            <div className="mx-auto mb-4 h-1 w-48 rounded-full bg-white/10 overflow-hidden">
              <div className="h-full w-1/3 rounded-full bg-gradient-to-r from-indigo-500 via-fuchsia-500 to-orange-500 pc-loader-bar"></div>
            </div>
            <div className="flex items-center justify-center gap-2">
              {loadingAuth ? (
                <span className="text-[10px] font-black text-slate-500 uppercase tracking-[0.3em] animate-pulse">KİMLİK DOĞRULANIYOR...</span>
              ) : (
                <>
                  <Loader2 size={12} className="animate-spin text-indigo-500" />
                  <span className="text-[10px] font-black text-indigo-400 uppercase tracking-[0.3em]">BAŞLANGIÇ VERİLERİ YÜKLENİYOR...</span>
                </>
              )}
            </div>
          </div>
        </div>
      </div>
    );
  }

  if (!currentUser) return (
    <ErrorBoundary language={language}>
      <Suspense fallback={<LoadingFallback />}>
        <LoginView onLogin={() => { }} language={language} notice={authNotice} onDismissNotice={() => setAuthNotice(null)} />
      </Suspense>
    </ErrorBoundary>
  );

  // ✅ MAIN APP
  const isAdmin = currentUser?.role === 'Admin';
  const isManager = currentUser?.role === 'Manager';
  const isSales = currentUser?.role === 'Sales';
  const hasPermission = (perm: string) => {
    if (isAdmin) return true;
    return currentUser?.permissions?.includes(perm);
  };

  const hasFinance = isAdmin || isManager || currentUser?.role === 'Accountant' || hasPermission('accounting') || hasPermission('sales');
  const hasCrmAccess = isAdmin || isManager || isSales || hasPermission('crm');

  // ✅ MENÜ TANIMI (kenar çubuğu, komut paleti ve üst bar aynı kaynaktan beslenir)
  type NavEntry = { tab: string; label: string; icon: React.ReactNode; show: boolean; badge?: number };
  const tr = language === 'tr';
  const navSectionsRaw: { title: string; items: NavEntry[] }[] = [
    {
      title: tr ? 'GENEL' : 'GENERAL',
      items: [
        { tab: 'myday', label: tr ? 'Bugünüm' : 'My Day', icon: <Sunrise size={18} />, show: true },
        { tab: 'operations', label: tr ? 'Yönetim Merkezi' : 'Operations Center', icon: <Gauge size={18} />, show: canSeeOps, badge: criticalCount || undefined },
        { tab: 'myteam', label: tr ? 'Ekibim' : 'My Team', icon: <UsersRound size={18} />, show: isAdmin || isManager, badge: (isAdmin || isManager) ? ((leaveRequests.filter(l => l.status === 'Pending').length + tasks.filter(tk => tk.status === TaskStatus.BLOCKED).length) || undefined) : undefined },
        { tab: 'messages', label: t.messages, icon: <MessageSquare size={18} />, show: true },
        { tab: 'meetings', label: t.meetings || 'Meetings', icon: <Video size={18} />, show: true },
        (isAdmin || isManager)
          ? { tab: 'mytasks', label: tr ? 'Görevlerim' : 'My Tasks', icon: <CheckSquare size={18} />, show: true }
          : { tab: 'tasks', label: t.tasks, icon: <CheckSquare size={18} />, show: true },
      ],
    },
    {
      title: tr ? 'PROJELER & GÖREVLER' : 'PROJECTS & TASKS',
      items: (isAdmin || isManager || hasPermission('projects') || hasPermission('kanban')) ? [
        { tab: 'projects', label: t.projects, icon: <Briefcase size={18} />, show: !!(isAdmin || isManager || hasPermission('projects')) },
        { tab: 'extrajobs', label: t.extra_jobs || 'Ek İşler', icon: <Briefcase size={18} />, show: isAdmin || isManager },
        { tab: 'tasks', label: (isAdmin || isManager) ? (tr ? 'Görev Yönetimi' : 'Task Management') : t.tasks, icon: <CheckSquare size={18} />, show: isAdmin || isManager },
        { tab: 'kanban', label: 'Kanban', icon: <GripHorizontal size={18} />, show: !!(isAdmin || isManager || hasPermission('kanban')) },
      ] : [],
    },
    {
      title: tr ? 'FİNANS' : 'FINANCE',
      items: (hasFinance || hasPermission('accounting') || hasPermission('sales')) ? [
        { tab: 'accounting', label: t.accounting, icon: <Wallet size={18} />, show: !!hasPermission('accounting') },
        { tab: 'sales', label: t.sales, icon: <ShoppingBag size={18} />, show: !!hasPermission('sales') },
        { tab: 'invoices', label: t.invoices, icon: <FileText size={18} />, show: !!hasPermission('invoices') },
        { tab: 'personnelfinance', label: tr ? 'Personel Finans' : 'Personnel Finance', icon: <Wallet size={18} />, show: !!hasPermission('personnel') },
      ] : [],
    },
    {
      title: tr ? 'EKİP' : 'TEAM',
      items: [
        { tab: 'team', label: t.team, icon: <Users size={18} />, show: !!(isAdmin || isManager || hasPermission('team')) },
        { tab: 'attendance', label: t.attendance, icon: <Clock size={18} />, show: true },
        { tab: 'staffdocs', label: tr ? 'Personel Dosyaları' : 'Staff Documents', icon: <FolderOpen size={18} />, show: true },
        { tab: 'leave', label: t.leave_management, icon: <CalendarDays size={18} />, show: true, badge: (isAdmin || isManager) ? (leaveRequests.filter(l => l.status === 'Pending').length || undefined) : undefined },
        { tab: 'teammonitoring', label: tr ? 'Ekip İzleme' : 'Team Monitoring', icon: <Monitor size={18} />, show: !!hasPermission('monitoring') },
      ],
    },
    {
      title: tr ? 'MÜŞTERİ' : 'CUSTOMERS',
      items: (hasCrmAccess || hasPermission('sms')) ? [
        { tab: 'crm', label: 'CRM', icon: <Briefcase size={18} />, show: !!hasCrmAccess },
        { tab: 'tickets', label: tr ? 'Müşteri Talepleri' : 'Tickets', icon: <MessageSquare size={18} />, show: isAdmin || isManager, badge: (isAdmin || isManager) ? (tickets.filter(tk => tk.status === 'Open').length || undefined) : undefined },
        { tab: 'clientportal', label: tr ? 'Müşteri Portalı' : 'Client Portal', icon: <Shield size={18} />, show: isAdmin || isManager },
        { tab: 'customersms', label: t.customer_sms, icon: <MessageSquare size={18} />, show: !!hasPermission('sms') },
      ] : [],
    },
    {
      title: tr ? 'DEPO & SATIN ALMA' : 'INVENTORY & PURCHASING',
      items: (isAdmin || isManager || hasPermission('inventory') || hasPermission('purchasing')) ? [
        { tab: 'inventory', label: t.inventory, icon: <Package size={18} />, show: !!hasPermission('inventory') },
        { tab: 'purchasing', label: t.purchasing, icon: <ShoppingCart size={18} />, show: !!hasPermission('purchasing') },
      ] : [],
    },
    {
      title: tr ? 'ZEKA' : 'INTELLIGENCE',
      items: [
        { tab: 'ai', label: t.ai, icon: <Cpu size={18} />, show: !!hasPermission('ai') },
      ],
    },
  ];
  const navSections = navSectionsRaw
    .map(s => ({ ...s, items: s.items.filter(i => i.show) }))
    .filter(s => s.items.length > 0);
  const flatNav = navSections.flatMap(s => s.items.map(i => ({ ...i, section: s.title })));
  const activeNav = flatNav.find(n => n.tab === activeTab);
  const paletteNav = flatNav
    .filter((n, i, arr) => arr.findIndex(x => x.tab === n.tab) === i)
    .map(n => ({ tab: n.tab, label: n.label, section: n.section, icon: n.icon }));
  const paletteActions = [
    { id: 'theme', label: tr ? 'Temayı değiştir' : 'Toggle theme', hint: themeMode, icon: isDark ? <Sun size={16} /> : <Moon size={16} />, run: cycleTheme },
    { id: 'lang', label: tr ? 'Switch to English' : 'Türkçe’ye geç', hint: 'TR / EN', icon: <Languages size={16} />, run: () => setLanguage(tr ? 'en' : 'tr') },
    { id: 'notif', label: tr ? 'Bildirimleri aç' : 'Open notifications', icon: <Bell size={16} />, run: () => setShowNotifications(true) },
    { id: 'settings', label: tr ? 'Ayarlar' : 'Settings', hint: tr ? 'Görünüm, dil, tema' : 'Appearance, language, theme', icon: <Settings size={16} />, run: () => handleNavigate('settings', isAdmin ? undefined : 'appearance') },
    { id: 'logout', label: t.logout, icon: <LogOut size={16} />, run: handleLogout },
  ];
  const pageTitles: Record<string, string> = {
    archive: tr ? 'Arşiv' : 'Archive',
    settings: tr ? 'Ayarlar' : 'Settings',
    proposal: tr ? 'Teklif Oluşturucu' : 'Proposal Generator',
    portalmanagement: tr ? 'Portal Yönetimi' : 'Portal Management',
    myday: tr ? 'Bugünüm' : 'My Day',
    myteam: tr ? 'Ekibim' : 'My Team',
  };

  return (
    <ErrorBoundary language={language}>
      <Toaster />
      <Suspense fallback={<LoadingFallback />}>
        <div className="flex h-dvh bg-slate-100 dark:bg-slate-950 font-sans overflow-hidden relative transition-colors duration-300">
          {isMobileMenuOpen && (
            <div className="fixed inset-0 bg-slate-950/50 backdrop-blur-sm z-[45] lg:hidden pc-backdrop" onClick={() => setIsMobileMenuOpen(false)} />
          )}

          <div className="relative shrink-0 lg:h-full">
          <button
            onClick={() => setSidebarCollapsed(v => !v)}
            title={sidebarCollapsed ? (language === 'tr' ? 'Menüyü aç' : 'Expand menu') : (language === 'tr' ? 'Menüyü daralt' : 'Collapse menu')}
            aria-label="Toggle sidebar"
            className="hidden lg:flex absolute top-10 -right-3.5 z-[55] w-7 h-7 items-center justify-center rounded-full bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-500 hover:text-white hover:bg-indigo-600 hover:border-indigo-600 shadow-md"
          >
            <ChevronLeft size={15} className={`transition-transform duration-300 ${sidebarCollapsed ? 'rotate-180' : ''}`} />
          </button>
          <aside
            className={`fixed inset-y-0 left-0 w-[min(18rem,85vw)] ${sidebarCollapsed ? 'pc-rail' : 'lg:w-72'} text-slate-800 dark:text-white flex flex-col p-5 lg:p-6 h-full shadow-2xl z-[50] lg:relative lg:translate-x-0 lg:shadow-none pc-aside overflow-x-hidden overflow-y-auto custom-scrollbar overscroll-contain ${
              isMobileMenuOpen ? 'translate-x-0' : '-translate-x-full lg:translate-x-0'
            } border-r border-slate-200 dark:border-slate-800/60 bg-white dark:bg-[#020617]`}
            style={{
              background: isDark ? '#020617' : 'linear-gradient(to bottom, #ffffff, #fff7ed)',
              paddingTop: 'max(env(safe-area-inset-top, 0px) + 1rem, 1.25rem)',
              paddingBottom: 'max(env(safe-area-inset-bottom, 0px) + 1rem, 1.25rem)',
            }}
          >
            <div className={`mb-8 lg:mb-10 mt-2 shrink-0 flex items-center gap-3 ${sidebarCollapsed ? 'lg:justify-center' : ''}`}>
              <button
                onClick={() => setIsMobileMenuOpen(false)}
                className="lg:hidden order-last ml-auto p-2 rounded-xl text-slate-500 hover:bg-slate-100 dark:hover:bg-white/10"
                aria-label="Close menu"
              >
                <X size={20} />
              </button>
              <div className="w-10 h-10 shrink-0 bg-indigo-600 rounded-[14px] flex items-center justify-center shadow-lg shadow-indigo-900/50 dark:shadow-none">
                <Shield size={22} className="text-white" />
              </div>
              <div className={`whitespace-nowrap ${sidebarCollapsed ? 'lg:hidden' : ''}`}>
                 <h1 className="text-xl font-black tracking-tighter italic">
                    <span className="text-blue-900 dark:text-white">Panimo</span>
                    <span className="text-orange-500">Cloud</span>
                 </h1>
                 <p className="text-[8px] font-black text-indigo-500 dark:text-indigo-400 uppercase tracking-[0.3em]">Advanced ERP v3.0</p>
              </div>
            </div>

            <nav className="flex-1 space-y-1" key={language}>
              {navSections.map((section, sIdx) => (
                <div key={section.title} className="pc-nav-section">
                  {sidebarCollapsed && sIdx > 0 && <div className="hidden lg:block mx-3 my-3 h-px bg-slate-200 dark:bg-white/10" />}
                  <p className={`text-[9px] font-black text-slate-400 dark:text-slate-500 uppercase tracking-[0.3em] px-4 py-2 whitespace-nowrap ${sIdx === 0 ? 'mt-2' : 'mt-4'} ${sidebarCollapsed ? 'lg:hidden' : ''}`} style={{ animationDelay: `${sIdx * 60}ms` }}>{section.title}</p>
                  {section.items.map((item, iIdx) => (
                    <button
                      key={item.tab + item.label}
                      onClick={() => handleNavigate(item.tab)}
                      data-active={activeTab === item.tab}
                      title={sidebarCollapsed ? item.label : undefined}
                      style={{ animationDelay: `${sIdx * 60 + (iIdx + 1) * 35}ms` }}
                      className={`pc-nav-item relative w-full flex items-center gap-3 px-4 py-3 rounded-2xl text-sm font-black transition-all ${sidebarCollapsed ? 'lg:justify-center lg:px-0' : ''} ${
                        activeTab === item.tab
                          ? 'text-white shadow-lg shadow-indigo-500/30 dark:shadow-indigo-950/50'
                          : 'text-slate-500 hover:bg-indigo-50 hover:text-indigo-600 hover:translate-x-1 dark:text-slate-400 dark:hover:bg-white/5 dark:hover:text-white'
                      }`}
                    >
                      {item.icon}
                      <span className={`text-[11px] uppercase tracking-wider flex-1 text-left whitespace-nowrap ${sidebarCollapsed ? 'lg:hidden' : ''}`}>{item.label}</span>
                      {item.badge ? (
                        <span className={`min-w-[20px] h-5 px-1.5 rounded-full bg-rose-500 text-white text-[10px] font-black flex items-center justify-center ${sidebarCollapsed ? 'lg:absolute lg:top-1 lg:right-2 lg:min-w-[16px] lg:h-4 lg:text-[9px] lg:px-1' : ''}`}>{item.badge}</span>
                      ) : null}
                    </button>
                  ))}
                </div>
              ))}
            </nav>

            <div className="mt-6 pt-4 border-t border-slate-200 dark:border-white/5 space-y-2 shrink-0">
              <button
                onClick={() => setShowNotifications(!showNotifications)}
                className={`w-full flex items-center gap-3 px-4 py-3 rounded-2xl transition-all text-[11px] font-black uppercase relative ${sidebarCollapsed ? 'lg:justify-center lg:px-0' : ''} ${
                  showNotifications ? 'bg-indigo-600 text-white' : 'text-slate-500 hover:bg-indigo-50 hover:text-indigo-600 dark:text-slate-400 dark:hover:bg-white/5 dark:hover:text-white'
                }`}
              >
                <Bell size={16} className="shrink-0" />
                <span className={`whitespace-nowrap ${sidebarCollapsed ? 'lg:hidden' : ''}`}>{language === 'tr' ? 'Bildirimler' : 'Notifications'}</span>
              </button>
              <button
                onClick={() => handleNavigate('settings', isAdmin ? undefined : 'appearance')}
                data-active={activeTab === 'settings'}
                className={`pc-nav-item w-full flex items-center gap-3 px-4 py-3 rounded-2xl ${sidebarCollapsed ? 'lg:justify-center lg:px-0' : ''} ${activeTab === 'settings' ? 'text-white shadow-lg shadow-indigo-500/30' : 'text-slate-500 hover:bg-indigo-50 hover:text-indigo-600 dark:text-slate-400 dark:hover:bg-white/5 dark:hover:text-white'} transition-all text-[11px] font-black uppercase`}
                title={sidebarCollapsed ? (language === 'tr' ? 'Ayarlar' : 'Settings') : undefined}
              >
                <Settings size={16} className="shrink-0" />
                <span className={`whitespace-nowrap flex-1 text-left ${sidebarCollapsed ? 'lg:hidden' : ''}`}>{language === 'tr' ? 'Ayarlar' : 'Settings'}</span>
                <span className={`text-slate-400 ${sidebarCollapsed ? 'lg:hidden' : ''} ${activeTab === 'settings' ? 'text-white/70' : ''}`}>
                  {themeMode === 'auto' ? <Monitor size={13} /> : themeMode === 'dark' ? <Moon size={13} /> : <Sun size={13} />}
                </span>
                <span className={`text-[9px] font-bold ${sidebarCollapsed ? 'lg:hidden' : ''} ${activeTab === 'settings' ? 'text-white/70' : 'text-slate-400'}`}>{language.toUpperCase()}</span>
              </button>
              <button
                onClick={handleLogout}
                className={`w-full flex items-center gap-3 px-4 py-3 rounded-2xl ${sidebarCollapsed ? 'lg:justify-center lg:px-0' : ''} text-red-600 hover:bg-red-50 dark:text-red-500 dark:hover:bg-red-500/10 transition-all text-[11px] font-black uppercase`}
                title={sidebarCollapsed ? t.logout : undefined}
              >
                <LogOut size={16} className="shrink-0" /> <span className={`whitespace-nowrap ${sidebarCollapsed ? 'lg:hidden' : ''}`}>{t.logout}</span>
              </button>
            </div>
          </aside>
          </div>

          {/* ANA İÇERİK */}
          <main className="flex-1 overflow-y-auto overflow-x-hidden p-4 lg:p-8 bg-slate-50 dark:bg-[#020617] text-slate-900 dark:text-slate-100 transition-colors duration-500 custom-scrollbar overscroll-contain">
            <TopBar
              language={language}
              section={activeNav?.section}
              title={activeNav?.label || pageTitles[activeTab] || 'PanimoCloud'}
              icon={activeNav?.icon}
              currentUser={currentUser!}
              alertCount={unreadNotifCount}
              criticalCount={criticalCount}
              canSeeOps={canSeeOps}
              onOpenPalette={() => setShowPalette(true)}
              onOpenNotifications={() => setShowNotifications(true)}
              onOpenOps={() => handleNavigate('operations')}
              onOpenMenu={() => setIsMobileMenuOpen(true)}
            />
            <Suspense fallback={<ViewSkeleton />}>
             <div key={activeTab} className={`pc-page ${REVISED_TABS.has(activeTab) && !(activeTab === "clientportal" && !(isAdmin || isManager)) ? "" : "pc-legacy"}`}>
              {activeTab === 'operations' && canSeeOps && (
                <OperationsCenterView {...insightInput} currentUser={currentUser!} onNavigate={handleNavigate} />
              )}
              {activeTab === 'extrajobs' && <ExtraJobView extraJobs={extraJobs} users={users} customers={customers} currentUser={currentUser!} language={language} onUpsertExtraJob={handleUpsertExtraJob} onDeleteExtraJob={handleDeleteExtraJob} onAddTransaction={handleUpsertTransaction} financeSettings={financeSettings} rates={rates} onOpenArchive={() => handleNavigate('archive')} />}
              {activeTab === 'meetings' && <MeetingsView meetings={meetings} users={users} currentUser={currentUser!} language={language} onUpsertMeeting={handleUpsertMeeting} onDeleteMeeting={handleDeleteMeeting} />}
              {activeTab === 'tickets' && <TicketsView tickets={tickets} projects={projects} currentUser={currentUser!} language={language} onUpsertTicket={handleUpsertTicket} />}
              {activeTab === 'settings' && (
                <SettingsView
                  language={language}
                  isAdmin={isAdmin}
                  themeMode={themeMode}
                  onThemeModeChange={setThemeMode}
                  isDark={isDark}
                  onLanguageChange={setLanguage}
                  reduceMotion={reduceMotion}
                  onReduceMotionChange={setReduceMotion}
                  projectFormSettings={projectFormSettings}
                  onSaveProjectFormSettings={async (ps) => { await upsertDoc('system_settings', { ...ps, id: 'projectForm' }); logAudit(currentUser!, 'UPDATE', 'System', 'Proje formu zorunlu alan ayarları güncellendi'); }}
                  hrSettings={hrSettings}
                  onSaveHrSettings={async (h) => { await upsertDoc('system_settings', { ...h, id: 'hr' }); logAudit(currentUser!, 'UPDATE', 'System', 'İK ayarları güncellendi'); }}
                  financeSettings={financeSettings}
                  onSaveFinanceSettings={async (f) => { await upsertDoc('system_settings', { ...f, id: 'finance' }); logAudit(currentUser!, 'UPDATE', 'System', 'Finans ayarları güncellendi'); }}
                  companySettings={companySettings}
                  onSaveCompanySettings={async (c) => { await upsertDoc('system_settings', { ...c, id: 'company' }); logAudit(currentUser!, 'UPDATE', 'System', 'Şirket bilgileri güncellendi'); }}
                  alertSettings={alertSettings}
                  onSaveAlertSettings={async (a) => { await upsertDoc('system_settings', { ...a, id: 'alerts' }); logAudit(currentUser!, 'UPDATE', 'System', 'Uyarı eşikleri güncellendi'); }}
                  initialTab={settingsTab}
                  onTabChange={setSettingsTab}
                  canSeeArchive={isAdmin || isManager}
                  renderArchive={() => <ArchiveView embedded projects={projects} extraJobs={extraJobs} language={language} users={users} rates={rates} onUpsertProject={handleUpsertProject} onUpsertExtraJob={handleUpsertExtraJob} canEdit={isAdmin || isManager} />}
                  getBackupData={() => ({ users: users.map(({ password, fcmToken, ...u }: any) => u), projects, tasks, transactions, invoices, debts, subscriptions, sales, serviceSales, salaryPayments, personnelTransactions, customers, deals, crmActivities, extraJobs, leaveRequests, attendance, inventory: inventoryItems, vendors, purchaseOrders, tickets, meetings })}
                />
              )}
              {activeTab === 'messages' && <MessagesView currentUser={currentUser!} users={users} language={language} />}
              {activeTab === 'projects' && <ProjectsView projects={projects} tasks={tasks} setProjects={handleUpsertProject} language={language} onAddTransaction={handleUpsertTransaction} onDeleteProject={handleDeleteProject} onAddTask={handleAddTask} users={users} currentUser={currentUser!} showFinancials={showFinancials} onOpenArchive={() => handleNavigate('archive')} financeSettings={financeSettings} projectFormSettings={projectFormSettings} customers={customers} rates={rates} onOpenSettings={isAdmin ? () => handleNavigate('settings') : undefined} onDeleteTransaction={handleDeleteTransaction} onOpenTasks={() => handleNavigate('tasks')} />}
              {activeTab === 'tasks' && (
                currentUser!.role === 'Staff' ? (
                  <StaffView tasks={tasks} onUpdateTask={handleUpdateTask} currentUser={currentUser!} projects={projects} language={language} />
                ) : (
                  <TasksView tasks={tasks} setTasks={handleUpdateTask} projects={projects} users={users} language={language} onDeleteTask={handleDeleteTask} />
                )
              )}
              {activeTab === 'myday' && <MyDayView currentUser={currentUser!} language={language} tasks={tasks} projects={projects} meetings={meetings} attendance={attendance} leaveRequests={leaveRequests} staffDocuments={staffDocuments} notifications={myNotifications} hrSettings={hrSettings} onClockIn={handleClockIn} onUpsertAttendance={async (r: any) => upsertDoc('attendance', r)} onUpdateTask={handleUpdateTask} onNavigate={handleNavigate} tasksTab={isAdmin || isManager ? 'mytasks' : 'tasks'} />}
              {activeTab === 'myteam' && (isAdmin || isManager) && <MyTeamView currentUser={currentUser!} users={users} tasks={tasks} projects={projects} attendance={attendance} leaveRequests={leaveRequests} language={language} onUpsertLeave={handleUpsertLeaveRequest} onUpdateTask={handleUpdateTask} onNavigate={handleNavigate} />}
              {activeTab === 'mytasks' && (
                <StaffView tasks={tasks} onUpdateTask={handleUpdateTask} currentUser={currentUser!} projects={projects} language={language} onUpdateProject={handleUpsertProject} />
              )}
              {activeTab === 'kanban' && <TasksView tasks={tasks} setTasks={handleUpdateTask} projects={projects} users={users} language={language} onDeleteTask={handleDeleteTask} initialView="board" />}
              {activeTab === 'accounting' && hasFinance && <AccountingView transactions={transactions} onUpsertTransaction={handleUpsertTransaction} onDeleteTransaction={handleDeleteTransaction} projects={projects} subscriptions={subscriptions} onUpsertSubscription={handleUpsertSubscription} onDeleteSubscription={handleDeleteSubscription} language={language} rates={rates} onRefreshRates={fetchRates} loadingRates={loadingRates} debts={debts} onUpsertDebt={handleUpsertDebt} onDeleteDebt={handleDeleteDebt} salaryPayments={salaryPayments} onUpsertSalaryPayment={handleUpsertSalaryPayment} onDeleteSalaryPayment={handleDeleteSalaryPayment} staffList={users} onAddMainTransaction={handleUpsertTransaction} showFinancials={showFinancials} financeSettings={financeSettings} onUpdateFinanceSettings={async (f: any) => upsertDoc('system_settings', { ...f, id: 'finance' })} onOpenSettings={isAdmin ? () => handleNavigate('settings', 'finance') : undefined} />}
              {activeTab === 'sales' && hasFinance && <SalesView sales={sales} serviceSales={serviceSales} onUpsertSale={handleUpsertSale} onDeleteSale={handleDeleteSale} onUpsertServiceSale={handleUpsertServiceSale} onDeleteServiceSale={handleDeleteServiceSale} onAddTransaction={handleUpsertTransaction} language={language} rates={rates} showFinancials={showFinancials} />}
              {activeTab === 'invoices' && hasFinance && <InvoicesView invoices={invoices} customers={customers} language={language} onAddInvoice={handleUpsertInvoice} onDeleteInvoice={handleDeleteInvoice} onAddTransaction={handleUpsertTransaction} onDeleteTransaction={handleDeleteTransaction} rates={rates} company={companySettings} showFinancials={showFinancials} />}
              {activeTab === 'personnelfinance' && hasFinance && <PersonnelFinanceView staffList={users} transactions={personnelTransactions} onUpsertTransaction={handleUpsertPersonnelTransaction} onDeleteTransaction={handleDeletePersonnelTransaction} language={language} onAddMainTransaction={handleUpsertTransaction} onDeleteMainTransaction={handleDeleteTransaction} rates={rates} showFinancials={showFinancials} />}
              {activeTab === 'team' && <TeamView language={language} staffList={users} projects={projects} tasks={tasks} hrSettings={hrSettings} onAddUser={handleUpsertUser} onUpdateUser={handleUpsertUser} onDeleteUser={handleDeleteUser} onAssignTask={handleUpdateTask} onAddStaffDoc={async (d: any) => upsertDoc('staff_documents', d)} currentUserRole={currentUser!.role} currentUser={currentUser!} attendance={attendance} />}
              {activeTab === 'attendance' && <AttendanceView attendance={attendance} onUpsertAttendance={async (r: any) => upsertDoc('attendance', r)} currentUser={currentUser!} staffList={users} language={language} onClockIn={handleClockIn} hrSettings={hrSettings} onUpdateHrSettings={async (h) => upsertDoc('system_settings', { ...h, id: 'hr' })} />}
              {activeTab === 'staffdocs' && <StaffDocumentsView currentUser={currentUser!} staffDocuments={staffDocuments} language={language} onDeleteStaffDoc={async (id: string) => deleteDocById('staff_documents', id)} staffList={users} projects={projects} onAddStaffDoc={async (d: any) => upsertDoc('staff_documents', d)} />}
              {activeTab === 'leave' && <LeaveView leaves={leaveRequests} onUpsertLeave={handleUpsertLeaveRequest} currentUser={currentUser!} staffList={users} language={language} hrSettings={hrSettings} />}
              {activeTab === 'teammonitoring' && (isAdmin || isManager) && <TeamMonitoring staffList={users} userActivities={userActivities} screenRequests={screenRequests} currentUser={currentUser!} language={language} activeStreams={{}} connectionStates={{}} candidateCounts={{}} onReconnect={() => {}} onShowGallery={() => {}} onShowViewer={() => {}} />}
              {activeTab === 'crm' && hasCrmAccess && <CRMView deals={deals} crmActivities={crmActivities} onUpsertCrmActivity={handleUpsertCrmActivity} onDeleteCrmActivity={handleDeleteCrmActivity} language={language} onUpsertDeal={handleUpsertDeal} onDeleteDeal={handleDeleteDeal} showFinancials={showFinancials} currentUser={currentUser!} rates={rates} onUpsertProject={handleUpsertProject} onAddTask={handleAddTask} financeSettings={financeSettings} customers={customers} onUpsertCustomer={handleUpsertCustomer} />}
              {activeTab === 'customersms' && <CustomerSMSView language={language} customers={customers} smsConfig={smsConfig} smsTemplates={smsTemplates} onAddCustomer={handleUpsertCustomer} onDeleteCustomer={handleDeleteCustomer} onSaveConfig={async (c: any) => upsertDoc('sms_settings', { ...c, id: 'config' })} onAddLog={async (l: any) => upsertDoc('sms_logs', l)} onUpsertTemplate={async (t: any) => upsertDoc('sms_templates', t)} onDeleteTemplate={async (id: string) => deleteDocById('sms_templates', id)} onOpenCustomerModal={(c?: Customer) => { setEditingCustomer(c || null); setShowCustomerModal(true); }} />}
              {activeTab === 'inventory' && <InventoryView inventory={inventoryItems} onUpsertItem={handleUpsertInventoryItem} onDeleteItem={handleDeleteInventoryItem} currentUser={currentUser!} language={language} rates={rates} />}
              {activeTab === 'purchasing' && <PurchasingView vendors={vendors} purchaseOrders={purchaseOrders} inventory={inventoryItems} onUpsertVendor={handleUpsertVendor} onDeleteVendor={handleDeleteVendor} onUpsertPO={handleUpsertPurchaseOrder} onDeletePO={handleDeletePurchaseOrder} onUpsertInventory={handleUpsertInventoryItem} onAddTransaction={handleUpsertTransaction} currentUser={currentUser!} language={language} rates={rates} />}
              {activeTab === 'ai' && <AIView tasks={tasks} transactions={transactions} projects={projects} deals={deals} users={users} attendance={attendance} subscriptions={subscriptions} licenseSales={sales} serviceSales={serviceSales} customers={customers} language={language} />}
              {activeTab === 'proposal' && <ProposalGenerator language={language} />}
              {activeTab === 'portalmanagement' && isAdmin && (
                <PortalManagementView 
                  language={language} 
                  projects={projects}
                  tasks={tasks}
                  onSelectProject={(id) => { setSelectedPortalProjectId(id); setActiveTab('clientportal'); }}
                  onUpdateProject={handleUpsertProject} 
                />
              )}
              {activeTab === 'clientportal' && (
                projects.length > 0 ? (
                  isAdmin || isManager ? (
                    <PortalManagementView 
                      projects={projects} 
                      tasks={tasks} 
                      language={language} 
                      onSelectProject={(id) => { setSelectedPortalProjectId(id); }}
                      onUpdateProject={handleUpsertProject}
                    />
                  ) : (
                    <ClientPortalPreview 
                      project={projects.find(p => p.id === selectedPortalProjectId) || projects[0]} 
                      tasks={tasks} 
                      language={language} 
                      users={users}
                      company={companySettings}
                    />
                  )
                ) : (
                  <div className="flex flex-col items-center justify-center h-full opacity-50">
                    <Shield size={64} className="mb-4 text-slate-300" />
                    <p className="font-black uppercase tracking-widest text-xs text-slate-400">Henüz proje bulunamadı</p>
                  </div>
                )
              )}
              {activeTab === '' && (
                <div className="flex flex-col items-center justify-center h-full gap-6 opacity-20">
                  <Briefcase size={80} className="text-slate-300" />
                  <p className="text-[10px] font-black text-slate-400 uppercase tracking-[0.5em]">PanimoCloud ERP v3.0</p>
                </div>
              )}
             </div>
            </Suspense>
          </main>

          {loadingBackgroundData && (
            <div className="fixed bottom-4 left-1/2 -translate-x-1/2 lg:left-auto lg:right-4 lg:translate-x-0 text-[9px] font-black text-slate-500 dark:text-slate-300 uppercase tracking-widest flex items-center gap-2 bg-white/90 dark:bg-slate-900/90 backdrop-blur px-3 py-2 rounded-xl shadow-lg border border-slate-100 dark:border-white/10 z-50 animate-in fade-in slide-in-from-bottom-4 duration-500">
              <Loader2 size={12} className="animate-spin text-indigo-500" /> Senkronize ediliyor...
            </div>
          )}

          <CustomerModal 
            show={showCustomerModal} 
            customer={editingCustomer} 
            language={language} 
            onClose={() => { setShowCustomerModal(false); setEditingCustomer(null); }} 
            onSave={handleUpsertCustomer} 
          />

          {showPalette && (
            <Suspense fallback={null}>
              <CommandPalette
                open={showPalette}
                onClose={() => setShowPalette(false)}
                language={language}
                navItems={paletteNav}
                actions={paletteActions}
                onNavigate={handleNavigate}
                data={{ projects, tasks, users, customers, deals, invoices, inventoryItems, tickets }}
              />
            </Suspense>
          )}

          {/* Bildirim Paneli */}
          {showNotifications && currentUser && (
            <Suspense fallback={null}>
              <NotificationsPanel
                onClose={() => setShowNotifications(false)}
                attendance={attendance}
                leaveRequests={leaveRequests}
                projects={projects}
                tasks={tasks}
                currentUser={currentUser}
                language={language}
                onNavigate={handleNavigate}
                systemNotifications={myNotifications}
                onMarkRead={(ids: string[]) => markNotificationsRead(ids, currentUser.id)}
                onUpdateUser={async (u: any) => upsertDoc('users', { id: u.id, notificationPrefs: u.notificationPrefs })}
              />
            </Suspense>
          )}
        </div>
      </Suspense>
    </ErrorBoundary>
  );
};

export default App;
