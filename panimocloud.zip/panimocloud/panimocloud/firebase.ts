import { initializeApp } from 'firebase/app';
import { getFirestore } from 'firebase/firestore';
import { getAuth } from 'firebase/auth';
import { getStorage } from 'firebase/storage';

const firebaseConfig = {
  apiKey: "",
  authDomain: "",
  projectId: "",
  storageBucket: "",
  messagingSenderId: "",
  appId: "",
  measurementId: ""
};

// Initialize Firebase
export const app = initializeApp(firebaseConfig);

// ✅ CRITICAL SERVICES (Eagerly initialized)
export const db = getFirestore(app);
export const auth = getAuth(app);
export const storage = getStorage(app);

// ✅ Corporate browser cookie/IndexedDB fallback persistence
if (typeof window !== 'undefined') {
  import('firebase/auth').then(({ setPersistence, browserLocalPersistence, browserSessionPersistence }) => {
    setPersistence(auth, browserLocalPersistence).catch(() => {
      setPersistence(auth, browserSessionPersistence).catch(err => {
        console.warn("Firebase Auth persistence fallback error:", err);
      });
    });
  });
}

// ✅ LAZY LOADING: FCM'i lazy load yap
let messagingInstance: any = null;
let messagingPromise: Promise<any> | null = null;

export const getMessagingInstance = async () => {
  if (messagingInstance) return messagingInstance;
  
  if (!messagingPromise) {
    messagingPromise = (async () => {
      try {
        const { getMessaging } = await import('firebase/messaging');
        messagingInstance = getMessaging(app);
        return messagingInstance;
      } catch (error) {
        console.warn("Firebase Messaging not available:", error);
        return null;
      }
    })();
  }

  return messagingPromise;
};

// VAPID KEY - Replace with actual key from Firebase Console -> Project Settings -> Cloud Messaging -> Web Push certificates
export const VAPID_KEY = "BKxoQgHXgsEYv8eIHU7dw_aX3UoOOr0Cn1AnbiemAWBcUXHX2VLsjzcs89nrbFCdOznrSdJPZYOQ4qmRcpX7_VA";

// ---------------------------------------------------------------------------
// PUSH BİLDİRİMLERİ
// - İzin YALNIZCA kullanıcı bir düğmeye bastığında istenir (iOS başka türlü izin vermez).
// - iOS'ta web push yalnızca ana ekrana eklenmiş uygulamada çalışır (iOS 16.4+).
// - Her cihazın anahtarı users/{id}.fcmTokens dizisine eklenir; tek cihazla sınırlı değildir.
// ---------------------------------------------------------------------------

export type PushStatus = 'unsupported' | 'ios-needs-install' | 'default' | 'granted' | 'denied';

const isIOS = () => typeof navigator !== 'undefined' && (/iPhone|iPad|iPod/.test(navigator.userAgent) || (navigator.platform === 'MacIntel' && navigator.maxTouchPoints > 1));
const isStandalone = () => typeof window !== 'undefined' && ((navigator as any).standalone === true || window.matchMedia('(display-mode: standalone)').matches);

export const getPushStatus = async (): Promise<PushStatus> => {
  if (typeof window === 'undefined') return 'unsupported';
  if (isIOS() && !isStandalone()) return 'ios-needs-install';
  if (!('Notification' in window) || !('serviceWorker' in navigator)) return 'unsupported';
  try {
    const { isSupported } = await import('firebase/messaging');
    if (!(await isSupported())) return 'unsupported';
  } catch { return 'unsupported'; }
  return Notification.permission as PushStatus;
};

const saveToken = async (userId: string, token: string) => {
  const { doc, updateDoc, arrayUnion } = await import('firebase/firestore');
  // fcmToken eski sürümlerle uyumluluk için son cihazı tutar
  await updateDoc(doc(db, 'users', userId), { fcmTokens: arrayUnion(token), fcmToken: token });
};

const fetchToken = async () => {
  const msg = await getMessagingInstance();
  if (!msg) return null;
  const { getToken } = await import('firebase/messaging');
  const registration = await navigator.serviceWorker.register('/firebase-messaging-sw.js', { scope: '/firebase-cloud-messaging-push-scope' });
  return getToken(msg, { vapidKey: VAPID_KEY, serviceWorkerRegistration: registration });
};

/** Kullanıcı düğmeye bastığında çağrılır: izin ister ve cihazı kaydeder */
export const enablePushNotifications = async (userId: string): Promise<PushStatus> => {
  const status = await getPushStatus();
  if (status === 'unsupported' || status === 'ios-needs-install' || status === 'denied') return status;
  const permission = status === 'granted' ? 'granted' : await Notification.requestPermission();
  if (permission !== 'granted') return permission as PushStatus;
  const token = await fetchToken();
  if (token) await saveToken(userId, token);
  return 'granted';
};

/** Açılışta sessizce çağrılır: izin zaten verilmişse anahtarı tazeler, asla izin penceresi açmaz */
export const refreshPushToken = async (userId: string) => {
  try {
    if ((await getPushStatus()) !== 'granted') return;
    const token = await fetchToken();
    if (token) await saveToken(userId, token);
  } catch (error) {
    console.warn('Push token refresh failed:', error);
  }
};

/** Uygulama açıkken gelen push'lar tarayıcıda gösterilmez; bunları uygulama içinde yakalamak için */
export const onForegroundPush = async (cb: (p: { title?: string; body?: string; data?: Record<string, string> }) => void) => {
  const msg = await getMessagingInstance();
  if (!msg) return () => {};
  const { onMessage } = await import('firebase/messaging');
  return onMessage(msg, payload => cb({ title: payload.notification?.title || payload.data?.title, body: payload.notification?.body || payload.data?.body, data: payload.data }));
};

/** Eski çağrılar için: artık izin penceresi açmaz, sadece izin varsa anahtarı tazeler */
export const requestNotificationPermission = refreshPushToken;

// ---------------------------------------------------------------------------
// MÜŞTERİ PORTALI: giriş yapmamış müşteri Firestore'a doğrudan yazamaz (kurallar gereği).
// Portal işlemleri, projenin portalı açık mı diye kontrol eden sunucu fonksiyonundan geçer.
// ---------------------------------------------------------------------------
export const callPortal = async <T = any>(action: string, payload: Record<string, any>): Promise<T> => {
  const { getFunctions, httpsCallable } = await import('firebase/functions');
  const fn = httpsCallable(getFunctions(app), 'portalAction');
  const res = await fn({ action, ...payload });
  return res.data as T;
};
