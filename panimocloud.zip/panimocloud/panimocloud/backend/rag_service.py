import os
import json
from typing import List, Dict, Any
from langchain_community.embeddings import HuggingFaceEmbeddings
from langchain_community.vectorstores import Chroma
from langchain_community.llms import Ollama
from langchain.docstore.document import Document
from langchain.chains import RetrievalQA

# Ollama model configuration
OLLAMA_MODEL = os.getenv("OLLAMA_MODEL", "llama3") # Or mistral, qwen
OLLAMA_URL = os.getenv("OLLAMA_URL", "http://localhost:11434")

class RAGService:
    def __init__(self, db_dir: str = "./chroma_db"):
        self.db_dir = db_dir
        # Use sentence-transformers for fast local embeddings
        self.embeddings = HuggingFaceEmbeddings(model_name="all-MiniLM-L6-v2")
        self.vector_db = None
        self._init_db()
        self.llm = Ollama(model=OLLAMA_MODEL, base_url=OLLAMA_URL)

    def _init_db(self):
        """Initialize ChromaDB vector store."""
        # Create directory if it doesn't exist
        os.makedirs(self.db_dir, exist_ok=True)
        self.vector_db = Chroma(
            embedding_function=self.embeddings,
            persist_directory=self.db_dir
        )

    def ingest_data(self, data_list: List[Dict[str, Any]], namespace: str):
        """
        Convert raw JSON data into Document objects and store them in ChromaDB.
        """
        documents = []
        for item in data_list:
            # Convert dict to string representation for content
            content = json.dumps(item, ensure_ascii=False)
            doc = Document(
                page_content=content,
                metadata={"source": namespace, "id": str(item.get("id", ""))}
            )
            documents.append(doc)
            
        if documents:
            self.vector_db.add_documents(documents)
            self.vector_db.persist()
            return {"status": "success", "count": len(documents)}
        return {"status": "empty"}

    def ask_copilot(self, query: str, context_data: Any = None) -> str:
        """
        RAG architecture:
        1. Retrieve relevant documents from ChromaDB based on user query.
        2. Combine retrieved documents with the current UI context (context_data).
        3. Pass to Ollama LLM to generate an answer.
        """
        try:
            # 1. Retrieve similar documents from the knowledge base
            retriever = self.vector_db.as_retriever(search_kwargs={"k": 5})
            relevant_docs = retriever.get_relevant_documents(query)
            db_context = "\n".join([doc.page_content for doc in relevant_docs])
            
            # 2. Combine with UI context
            ui_context = json.dumps(context_data, ensure_ascii=False) if context_data else "None"
            
            # 3. Construct the prompt
            prompt = f"""
Sen PanimoCloud ERP sisteminin akıllı yapay zeka asistanı "Panimo Copilot"sun. 
Kullanıcının sorusunu yanıtlarken aşağıdaki bilgileri DİKKATLİCE kullan:

[VERİTABANI GEÇMİŞİ (RAG)]:
{db_context}

[MEVCUT EKRAN BAĞLAMI]:
{ui_context}

[KULLANICI SORUSU]:
{query}

Lütfen yukarıdaki verilere dayanarak anlaşılır, profesyonel ve yardımcı bir dilde Türkçe cevap ver.
Eğer verilen bağlamlarda cevap yoksa, mantıklı bir tahminde bulunma, "Bu bilgiye şu an ulaşamıyorum" de.
"""
            # 4. Generate response via Ollama
            response = self.llm.invoke(prompt)
            return response
            
        except Exception as e:
            print(f"RAG Error: {e}")
            return "Üzgünüm, şu anda yanıt veremiyorum (Yerel AI Sunucu Hatası)."

    def analyze_operations(self, prompt: str) -> str:
        """Standard direct call without RAG for analysis endpoints."""
        try:
            return self.llm.invoke(prompt)
        except Exception as e:
            print(f"Analysis Error: {e}")
            return "{}"

rag_service = RAGService()
