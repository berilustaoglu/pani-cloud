# PanimoCloud Özel Yapay Zeka (AI Gateway) Kurulum Rehberi

Bu klasör, PanimoCloud ERP sisteminin tamamen yerel, kapalı devre ve güvenli (Veri gizliliği %100) bir şekilde çalışmasını sağlayan yapay zeka arka uç (backend) kodlarını içerir.

## 1. Gereksinimler

1. **Python 3.10+** (Yüklü olduğundan emin olun)
2. **Ollama**: Yerel yapay zeka modelini (LLM) çalıştırmak için kullanılan motor.
   - İndirin: [https://ollama.com/](https://ollama.com/)
   - Ollama'yı kurduktan sonra terminal/komut satırını açıp şu komutu çalıştırarak bir model indirin:
     ```bash
     ollama run llama3
     ```
     *(Eğer Türkçe'de daha iyi bir model arıyorsanız `ollama run aya` veya `ollama run command-r` deneyebilirsiniz. `rag_service.py` içindeki `OLLAMA_MODEL` değişkenini buna göre güncelleyin.)*

## 2. Kurulum

Terminal/Powershell üzerinden bu `backend` klasörüne girin ve aşağıdaki komutları çalıştırın:

```bash
# 1. Sanal ortam (Virtual Environment) oluşturun (İsteğe bağlı ama önerilir)
python -m venv venv

# 2. Sanal ortamı aktifleştirin
# Windows için:
.\venv\Scripts\activate
# Mac/Linux için:
source venv/bin/activate

# 3. Bağımlılıkları yükleyin
pip install -r requirements.txt
```

## 3. Sistemi Çalıştırma

Ollama arka planda açıkken, bu klasörde şu komutu çalıştırın:

```bash
uvicorn main:app --host 0.0.0.0 --port 8000 --reload
```

Sistem `http://localhost:8000` adresinde ayağa kalkacaktır. Tarayıcıdan `http://localhost:8000/docs` adresine giderek API dokümantasyonunu (Swagger UI) görebilir ve test edebilirsiniz.

## Mimarisi

- **`main.py`**: Gelen HTTP isteklerini (React'tan) karşılar.
- **`rag_service.py`**: Vektör veritabanını (ChromaDB) yönetir ve gelen verileri yapay zekaya bağlam olarak sunar.
- **`chroma_db/`**: Otomatik oluşacak bu klasör, ERP verilerinizin (projeler, müşteriler vs.) şifreli/vektörel hallerini yerel diskinizde saklar.
