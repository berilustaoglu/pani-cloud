from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
from typing import List, Dict, Any, Optional

from rag_service import rag_service

app = FastAPI(title="PanimoCloud Custom AI Gateway", version="1.0.0")

# Allow CORS for the React frontend
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"], # In production, restrict this to your frontend domain
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

class CopilotRequest(BaseModel):
    prompt: str
    contextData: Optional[Any] = None
    language: str = "tr"

class AnalyzeRequest(BaseModel):
    prompt: str
    language: str = "tr"

class IngestRequest(BaseModel):
    data: List[Dict[str, Any]]
    namespace: str

@app.get("/")
def read_root():
    return {"status": "ok", "service": "PanimoCloud AI Gateway", "llm": "Ollama (Local)"}

@app.post("/api/chat")
async def chat_endpoint(req: CopilotRequest):
    """Handles conversational RAG queries."""
    try:
        response_text = rag_service.ask_copilot(req.prompt, req.contextData)
        return {"response": response_text}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@app.post("/api/analyze")
async def analyze_endpoint(req: AnalyzeRequest):
    """Handles structured JSON generation via Local LLM."""
    try:
        # We append a strong directive to output JSON only
        full_prompt = f"{req.prompt}\n\nLÜTFEN SADECE VE SADECE GEÇERLİ BİR JSON FORMATI DÖNDÜR. Markdown işaretleri (```json vb) KULLANMA."
        response_text = rag_service.analyze_operations(full_prompt)
        return {"response": response_text}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@app.post("/api/ingest")
async def ingest_endpoint(req: IngestRequest):
    """Endpoint to push data (deals, projects) into the Vector DB."""
    try:
        result = rag_service.ingest_data(req.data, req.namespace)
        return result
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

if __name__ == "__main__":
    import uvicorn
    # Run the server on port 8000
    uvicorn.run("main:app", host="0.0.0.0", port=8000, reload=True)
