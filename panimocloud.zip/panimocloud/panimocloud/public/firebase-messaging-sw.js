importScripts('https://www.gstatic.com/firebasejs/10.8.0/firebase-app-compat.js');
importScripts('https://www.gstatic.com/firebasejs/10.8.0/firebase-messaging-compat.js');

const firebaseConfig = {
  apiKey: "AIzaSyCyLm24JBC4CLJTrwrseOKtO-PQwm-gtUc",
  authDomain: "panimo-8da79.firebaseapp.com",
  projectId: "panimo-8da79",
  storageBucket: "panimo-8da79.firebasestorage.app",
  messagingSenderId: "1018156188522",
  appId: "1:1018156188522:web:ab7d2cc4d32e4679955b13",
  measurementId: "G-CPZDYFBQE8"
};

firebase.initializeApp(firebaseConfig);
const messaging = firebase.messaging();

// Arka plan bildirimleri
// Sunucu 'notification' alanıyla gönderdiğinde Firebase bildirimi KENDİSİ gösterir; burada tekrar göstermek
// aynı bildirimin iki kez çıkmasına yol açar. Yalnızca veri (data) mesajlarını burada gösteriyoruz.
messaging.onBackgroundMessage((payload) => {
  if (payload.notification) return;
  const data = payload.data || {};
  return self.registration.showNotification(data.title || 'Panimo Cloud', {
    body: data.body || 'Yeni bildiriminiz var.',
    icon: data.icon || 'https://i.imgur.com/bhZymBT.png',
    badge: 'https://i.imgur.com/bhZymBT.png',
    tag: data.tag || undefined,
    data: { url: data.url || '/' },
  });
});

// Bildirime tıklanınca: açık bir uygulama penceresi varsa onu öne getir ve ilgili sayfaya yönlendir, yoksa aç
self.addEventListener('notificationclick', (event) => {
  event.notification.close();
  const d = event.notification.data || {};
  const url = (d.FCM_MSG && d.FCM_MSG.data && d.FCM_MSG.data.url) || d.url || '/';
  event.waitUntil((async () => {
    const all = await clients.matchAll({ type: 'window', includeUncontrolled: true });
    for (const c of all) {
      if (new URL(c.url).origin === self.location.origin) {
        await c.focus();
        if ('navigate' in c && url !== '/') { try { await c.navigate(url); } catch (e) {} }
        return;
      }
    }
    if (clients.openWindow) await clients.openWindow(url);
  })());
});
