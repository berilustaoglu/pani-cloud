const functions = require("firebase-functions/v1");
const admin = require("firebase-admin");
admin.initializeApp();
const db = admin.firestore();

const ICON = "https://i.imgur.com/bhZymBT.png";

// --- SAĞLIK KONTROLÜ ---
exports.checkHealth = functions.https.onRequest((req, res) => {
  res.status(200).send("Panimo Cloud Functions: Online ve Çalışıyor!");
});

// ---------------------------------------------------------------------------
// Yardımcılar
// ---------------------------------------------------------------------------

/** Bir kullanıcının tüm cihaz anahtarları (yeni dizi + eski tek alan) */
const tokensOf = (data) => {
  if (!data) return [];
  const list = Array.isArray(data.fcmTokens) ? [...data.fcmTokens] : [];
  if (data.fcmToken) list.push(data.fcmToken);
  return [...new Set(list.filter(Boolean))];
};

/**
 * Kullanıcılara push gönderir ve artık geçerli olmayan anahtarları kullanıcı kaydından siler.
 * targets: [{ id, tokens }]
 */
const sendPush = async (targets, { title, body, url = "/", tag, icon }) => {
  const owners = new Map(); // token -> userId
  targets.forEach(t => t.tokens.forEach(tok => owners.set(tok, t.id)));
  const tokens = [...owners.keys()];
  if (!tokens.length) return { successCount: 0, failureCount: 0 };

  let success = 0, failure = 0;
  const dead = new Map(); // userId -> [token]
  for (let i = 0; i < tokens.length; i += 500) {
    const chunk = tokens.slice(i, i + 500);
    const res = await admin.messaging().sendEachForMulticast({
      tokens: chunk,
      notification: { title, body },
      data: { url, title, body },
      apns: { payload: { aps: { sound: "default" } } },
      webpush: {
        headers: { Urgency: "high" },
        notification: { title, body, icon: icon || ICON, badge: ICON, ...(tag ? { tag, renotify: true } : {}) },
      },
    });
    success += res.successCount;
    failure += res.failureCount;
    res.responses.forEach((r, idx) => {
      const code = r.error && r.error.code;
      if (code === "messaging/registration-token-not-registered" || code === "messaging/invalid-registration-token") {
        const tok = chunk[idx]; const uid = owners.get(tok);
        dead.set(uid, [...(dead.get(uid) || []), tok]);
      }
    });
  }

  // Ölü anahtarları temizle
  for (const [uid, toks] of dead) {
    const ref = db.collection("users").doc(uid);
    const snap = await ref.get();
    const upd = { fcmTokens: admin.firestore.FieldValue.arrayRemove(...toks) };
    if (snap.exists && toks.includes(snap.data().fcmToken)) upd.fcmToken = admin.firestore.FieldValue.delete();
    await ref.update(upd).catch(() => null);
  }
  console.log(`Push: ${success} ok, ${failure} failed, ${[...dead.values()].flat().length} dead tokens removed`);
  return { successCount: success, failureCount: failure };
};

const usersWhere = async (filterFn) => {
  const snap = await db.collection("users").get();
  return snap.docs.filter(d => filterFn(d.id, d.data())).map(d => ({ id: d.id, data: d.data(), tokens: tokensOf(d.data()) }));
};

const truncate = (s, n = 140) => { s = String(s || ""); return s.length > n ? s.slice(0, n - 1) + "…" : s; };

/** Sohbet mesajının bildirimde görünecek metni (anket/etkinlik/görsel ham veri olarak gitmesin) */
const chatPreview = (m) => {
  try {
    if (m.type === "image") return "📷 Fotoğraf gönderdi";
    if (m.type === "poll") return `📊 Anket: ${JSON.parse(m.text).question}`;
    if (m.type === "event") { const e = JSON.parse(m.text); return `📅 Etkinlik: ${e.title} · ${e.date} ${e.time}`; }
  } catch (e) { /* bozuk veri: düz metne düş */ }
  return truncate(m.text);
};

// ---------------------------------------------------------------------------
// SOHBET BİLDİRİMİ
// ---------------------------------------------------------------------------
exports.sendChatNotification = functions.firestore
  .document("chat_messages/{messageId}")
  .onCreate(async (snap) => {
    const m = snap.data();
    if (!m) return null;
    const { senderId, channelId } = m;
    try {
      let targets = [];
      if (channelId === "general" || channelId === "announcements") {
        targets = await usersWhere((id, d) => id !== senderId && !(d.notificationPrefs && d.notificationPrefs.chat === false));
      } else if (channelId && channelId.includes("_")) {
        const target = channelId.split("_").find(id => id !== senderId);
        if (target) {
          const d = await db.collection("users").doc(target).get();
          if (d.exists && !(d.data().notificationPrefs && d.data().notificationPrefs.chat === false)) targets = [{ id: d.id, tokens: tokensOf(d.data()) }];
        }
      }
      const where = channelId === "announcements" ? " · Duyuru" : channelId === "general" ? " · Genel" : "";
      return await sendPush(targets, {
        title: `${m.senderName || "Panimo"}${where}`,
        body: chatPreview(m),
        url: "/?tab=messages",
        tag: `chat-${channelId}`,
        icon: m.senderAvatar && !String(m.senderAvatar).startsWith("data:") ? m.senderAvatar : ICON,
      });
    } catch (error) {
      console.error("Chat push error:", error);
      return null;
    }
  });

// ---------------------------------------------------------------------------
// SİSTEM BİLDİRİMİ → PUSH
// userId varsa yalnızca o kişiye; yoksa yönetici ve müdürlere gider. Oluşturan kişiye gitmez.
// ---------------------------------------------------------------------------
exports.onSystemNotificationCreated = functions.firestore
  .document("system_notifications/{id}")
  .onCreate(async (snap) => {
    const n = snap.data();
    if (!n) return null;
    try {
      const allowed = (d) => !(d.notificationPrefs && d.notificationPrefs.system === false);
      const targets = n.userId
        ? await usersWhere((id, d) => id === n.userId && id !== n.createdBy && allowed(d))
        : await usersWhere((id, d) => (d.role === "Admin" || d.role === "Manager") && id !== n.createdBy && allowed(d));
      return await sendPush(targets, {
        title: n.title || "Panimo Cloud",
        body: truncate(n.description),
        url: n.tab ? `/?tab=${encodeURIComponent(n.tab)}` : "/",
        tag: `sys-${snap.id}`,
      });
    } catch (error) {
      console.error("System push error:", error);
      return null;
    }
  });

// ---------------------------------------------------------------------------
// PERSONEL AKTİF OLDU — yalnızca bu bildirimi açıkça isteyen yönetici/müdürlere
// (eskiden her girişte tüm yöneticilere gidiyordu)
// ---------------------------------------------------------------------------
exports.onUserOnlineStatusChanged = functions.firestore
  .document("users/{userId}")
  .onUpdate(async (change, context) => {
    const before = change.before.data(); const after = change.after.data();
    if (!(after.status === "Online" && before.status !== "Online")) return null;
    try {
      const targets = await usersWhere((id, d) => id !== context.params.userId && (d.role === "Admin" || d.role === "Manager") && d.notificationPrefs && d.notificationPrefs.staffOnline === true);
      return await sendPush(targets, { title: "Ekip", body: `${after.name || "Bir personel"} çevrim içi oldu.`, url: "/?tab=teammonitoring", tag: "status-push" });
    } catch (error) {
      console.error("Status push error:", error);
      return null;
    }
  });

// ---------------------------------------------------------------------------
// MÜŞTERİ PORTALI
// Müşteri giriş yapmaz; Firestore kuralları ona doğrudan yazma izni vermez. Portal işlemleri buradan geçer:
// proje portalı açık mı diye bakılır ve yalnızca izin verilen alanlar değiştirilir.
// ---------------------------------------------------------------------------
const HttpsError = functions.https.HttpsError;
const str = (v, max) => { if (typeof v !== "string") return ""; return v.trim().slice(0, max); };

const loadPublicProject = async (projectId) => {
  if (typeof projectId !== "string" || !projectId || projectId.includes("/")) throw new HttpsError("invalid-argument", "Geçersiz proje.");
  const ref = db.collection("projects").doc(projectId);
  const snap = await ref.get();
  if (!snap.exists) throw new HttpsError("not-found", "Proje bulunamadı.");
  const p = snap.data();
  if (!(p.portalSettings && p.portalSettings.isPublic === true)) throw new HttpsError("permission-denied", "Portal erişime kapalı.");
  return { ref, p };
};

const notifyTeam = (title, description, type, tab) =>
  db.collection("system_notifications").add({ title, description, type, tab, createdAt: new Date().toISOString(), readBy: [], createdBy: "client-portal" });

exports.portalAction = functions.https.onCall(async (data) => {
  const action = data && data.action;
  const { ref, p } = await loadPublicProject(data && data.projectId);

  switch (action) {
    // Portalın ihtiyaç duyduğu, giriş gerektiren veriler (yalnızca bu projeye ait ve sınırlı alanlar)
    case "getData": {
      const tSnap = await db.collection("tickets").where("projectId", "==", data.projectId).get();
      const tickets = tSnap.docs.map(d => ({ id: d.id, ...d.data() }));
      const taskSnap = await db.collection("tasks").where("projectId", "==", data.projectId).get();
      // Müşteriye yalnızca başlık, durum ve tarih gider (iç notlar, engel gerekçeleri gitmez)
      const tasks = taskSnap.docs.map(d => ({ id: d.id, projectId: data.projectId, title: d.data().title, status: d.data().status, deadline: d.data().deadline || "", assignedTo: d.data().assignedTo || [], progress: d.data().progress || 0 }));
      let team = [];
      if (p.portalSettings.showTeam !== false) {
        const ids = [p.projectManagerId, ...(p.teamMemberIds || [])].filter(Boolean);
        taskSnap.forEach(t => (t.data().assignedTo || []).forEach(id => ids.push(id)));
        const uniq = [...new Set(ids)].slice(0, 30);
        const docs = await Promise.all(uniq.map(id => db.collection("users").doc(id).get()));
        team = docs.filter(d => d.exists).map(d => ({ id: d.id, name: d.data().name, jobTitle: d.data().jobTitle || "", avatar: d.data().avatar || "", role: d.data().role }));
      }
      const companySnap = await db.collection("system_settings").doc("company").get();
      const c = companySnap.exists ? companySnap.data() : {};
      const company = { name: c.name, legalName: c.legalName, email: c.email, phone: c.phone, website: c.website, logoUrl: c.logoUrl, ...(p.portalSettings.showFinancials !== false ? { iban: c.iban } : {}) };
      return { tickets, team, company, tasks };
    }

    case "decideDoc": {
      const approved = data.approved === true;
      const note = str(data.note, 1000);
      if (!approved && !note) throw new HttpsError("invalid-argument", "Revizyon notu gerekli.");
      let name = "";
      const patch = (list) => (list || []).map(d => {
        if (d.id !== data.docId) return d;
        name = d.name;
        return { ...d, approvalStatus: approved ? "approved" : "rejected", ...(approved ? {} : { feedback: note }) };
      });
      const documents = patch(p.documents); const contracts = patch(p.contracts);
      if (!name) throw new HttpsError("not-found", "Belge bulunamadı.");
      await ref.update({ documents, contracts, ...(approved ? {} : { status: "Revizyonda" }) });
      await notifyTeam(approved ? "Doküman onaylandı" : "Revizyon istendi", `${p.name} · ${name}${approved ? "" : ` — "${note}"`}`, approved ? "success" : "warning", "projects");
      return { ok: true };
    }

    case "feedback": {
      const score = Number(data.score);
      if (!(score >= 1 && score <= 5)) throw new HttpsError("invalid-argument", "Puan 1-5 olmalı.");
      const comment = str(data.comment, 1000);
      const entry = { score: Math.round(score), date: new Date().toISOString(), ...(comment ? { comment } : {}) };
      await ref.update({ clientFeedback: admin.firestore.FieldValue.arrayUnion(entry) });
      await notifyTeam("Müşteri değerlendirmesi", `${p.name}: ${"★".repeat(entry.score)}${comment ? ` — "${comment}"` : ""}`, entry.score >= 4 ? "success" : "warning", "projects");
      return { ok: true };
    }

    case "createTicket": {
      const title = str(data.title, 200); const description = str(data.description, 4000);
      if (!title || !description) throw new HttpsError("invalid-argument", "Konu ve açıklama gerekli.");
      const priority = ["Low", "Medium", "High"].includes(data.priority) ? data.priority : "Medium";
      const now = new Date().toISOString();
      const id = `ticket_${Date.now()}`;
      const ticket = { id, projectId: data.projectId, title, description, status: "Open", priority, createdAt: now, updatedAt: now, responses: [] };
      await db.collection("tickets").doc(id).set(ticket);
      await notifyTeam("Yeni müşteri talebi", `${p.name}: ${title}`, "info", "tickets");
      return { ticket };
    }

    case "replyTicket": {
      const message = str(data.message, 4000);
      if (!message) throw new HttpsError("invalid-argument", "Mesaj boş olamaz.");
      const tRef = db.collection("tickets").doc(String(data.ticketId || "x"));
      const t = await tRef.get();
      if (!t.exists || t.data().projectId !== data.projectId) throw new HttpsError("not-found", "Talep bulunamadı.");
      if (t.data().status === "Closed") throw new HttpsError("failed-precondition", "Talep kapatılmış.");
      const now = new Date().toISOString();
      const response = { id: `resp_${Date.now()}`, userId: "client", message, createdAt: now, isClient: true };
      await tRef.update({ responses: admin.firestore.FieldValue.arrayUnion(response), updatedAt: now, ...(t.data().status === "Resolved" ? { status: "Open" } : {}) });
      await notifyTeam("Müşteri yanıtladı", `${p.name} · ${t.data().title}: ${truncate(message, 100)}`, "info", "tickets");
      return { response };
    }

    default:
      throw new HttpsError("invalid-argument", "Bilinmeyen işlem.");
  }
});

// ---------------------------------------------------------------------------
// YETKİ YARDIMCISI (sunucu tarafı; kurallarla aynı mantık)
// ---------------------------------------------------------------------------
const requireUser = async (context, check) => {
  if (!context.auth) throw new HttpsError("unauthenticated", "Giriş gerekli.");
  const snap = await db.collection("users").doc(context.auth.uid).get();
  if (!snap.exists) throw new HttpsError("permission-denied", "Kullanıcı profili bulunamadı.");
  const u = snap.data();
  if (check && !check(u)) throw new HttpsError("permission-denied", "Bu işlem için yetkiniz yok.");
  return u;
};
const hasPerm = (u, p) => u.role === "Admin" || (Array.isArray(u.permissions) && u.permissions.includes(p));

// ---------------------------------------------------------------------------
// YAPAY ZEKÂ VEKİLİ
// Gemini anahtarı tarayıcıda değil, Firebase Secret Manager'da (GEMINI_API_KEY) durur.
// Kurulum:  firebase functions:secrets:set GEMINI_API_KEY
// Model adları gerekirse ortam değişkeniyle değiştirilebilir (GEMINI_MODEL_FAST / GEMINI_MODEL_PRO).
// ---------------------------------------------------------------------------
const AI_LIMIT_PER_HOUR = 60;
exports.aiGenerate = functions.runWith({ secrets: ["GEMINI_API_KEY"], timeoutSeconds: 120, memory: "512MB" }).https.onCall(async (data, context) => {
  await requireUser(context);
  const prompt = typeof data?.prompt === "string" ? data.prompt : "";
  if (!prompt || prompt.length > 200000) throw new HttpsError("invalid-argument", "Geçersiz istek.");
  const file = data?.file;
  if (file && (typeof file.data !== "string" || file.data.length > 10 * 1024 * 1024 || typeof file.mimeType !== "string")) throw new HttpsError("invalid-argument", "Dosya çok büyük ya da geçersiz.");

  // Basit kötüye kullanım sınırı: kişi başı saatte AI_LIMIT_PER_HOUR istek
  const hourKey = new Date().toISOString().slice(0, 13);
  const quotaRef = db.collection("ai_quota").doc(`${context.auth.uid}_${hourKey}`);
  const used = await db.runTransaction(async tx => {
    const q = await tx.get(quotaRef);
    const n = (q.exists ? q.data().count : 0) + 1;
    tx.set(quotaRef, { count: n, uid: context.auth.uid, hour: hourKey }, { merge: true });
    return n;
  });
  if (used > AI_LIMIT_PER_HOUR) throw new HttpsError("resource-exhausted", "Saatlik yapay zekâ kullanım sınırına ulaşıldı.");

  const model = data?.tier === "pro" ? (process.env.GEMINI_MODEL_PRO || "gemini-2.5-pro") : (process.env.GEMINI_MODEL_FAST || "gemini-2.5-flash");
  const parts = [{ text: prompt }];
  if (file) parts.push({ inline_data: { mime_type: file.mimeType, data: file.data } });
  const res = await fetch(`https://generativelanguage.googleapis.com/v1beta/models/${model}:generateContent`, {
    method: "POST",
    headers: { "Content-Type": "application/json", "x-goog-api-key": process.env.GEMINI_API_KEY },
    body: JSON.stringify({ contents: [{ parts }] }),
  });
  const body = await res.json().catch(() => ({}));
  if (!res.ok) {
    console.error("Gemini error", res.status, body && body.error && body.error.message);
    throw new HttpsError("unavailable", "Yapay zekâ servisine ulaşılamadı.");
  }
  const text = body && body.candidates && body.candidates[0] && body.candidates[0].content && body.candidates[0].content.parts
    ? body.candidates[0].content.parts.map(p => p.text || "").join("") : "";
  if (!text) throw new HttpsError("unavailable", "Yapay zekâ boş yanıt döndürdü.");
  return { text };
});

// ---------------------------------------------------------------------------
// SMS (Netgsm) — şifre istemciye hiç gelmez
// Ayarlar: sms_settings/config (kullanıcı kodu, başlık) + sms_secrets/config (şifre; istemci okuyamaz)
// ---------------------------------------------------------------------------
const loadSmsConfig = async () => {
  const [cfgSnap, secSnap] = await Promise.all([db.collection("sms_settings").doc("config").get(), db.collection("sms_secrets").doc("config").get()]);
  const cfg = cfgSnap.exists ? cfgSnap.data() : {};
  const password = (secSnap.exists && secSnap.data().password) || cfg.password || ""; // eski kayıtlarda şifre config içindeydi
  if (!cfg.usercode || !password || !cfg.msgheader) throw new HttpsError("failed-precondition", "Netgsm ayarları eksik.");
  return { usercode: cfg.usercode, msgheader: cfg.msgheader, password };
};
const cleanPhone = (p) => { let c = String(p || "").replace(/\D/g, ""); if (c.startsWith("90")) c = c.slice(2); if (c.startsWith("0")) c = c.slice(1); return c; };

exports.sendSms = functions.runWith({ timeoutSeconds: 300 }).https.onCall(async (data, context) => {
  await requireUser(context, u => hasPerm(u, "sms"));
  const list = Array.isArray(data?.messages) ? data.messages : [];
  if (!list.length || list.length > 1000) throw new HttpsError("invalid-argument", "Alıcı listesi geçersiz (en fazla 1000).");
  const cfg = await loadSmsConfig();
  const results = [];
  for (const m of list) {
    const phone = cleanPhone(m && m.to);
    const text = String((m && m.message) || "").slice(0, 1000);
    let status = "Failed";
    if (phone.length === 10 && text) {
      try {
        const url = `https://api.netgsm.com.tr/sms/send/get/?usercode=${encodeURIComponent(cfg.usercode)}&password=${encodeURIComponent(cfg.password)}&gsmno=${phone}&message=${encodeURIComponent(text)}&msgheader=${encodeURIComponent(cfg.msgheader)}&filter=0`;
        const r = await fetch(url);
        if ((await r.text()).startsWith("00")) status = "Sent";
      } catch (e) { /* başarısız sayılır */ }
    }
    const id = `l${Date.now()}_${phone || "x"}`;
    await db.collection("sms_logs").doc(id).set({ id, to: (m && m.to) || "", message: text, date: new Date().toISOString(), status, sentBy: context.auth.uid });
    results.push({ to: (m && m.to) || "", status });
  }
  return { results };
});

exports.smsBalance = functions.https.onCall(async (data, context) => {
  await requireUser(context, u => hasPerm(u, "sms"));
  const cfg = await loadSmsConfig();
  try {
    const r = await fetch(`https://api.netgsm.com.tr/balance/list/get/?usercode=${encodeURIComponent(cfg.usercode)}&password=${encodeURIComponent(cfg.password)}`);
    const t = await r.text();
    return { balance: t.startsWith("00") ? t.replace(/^00/, "").trim() : null };
  } catch (e) {
    return { balance: null };
  }
});

// ---------------------------------------------------------------------------
// HESAP BAĞLAMA (ilk giriş)
// Yönetim çalışanı önce e-postasıyla tanımlar (geçici kimlikli profil). Çalışan aynı e-postayla
// kayıt olup e-postasını DOĞRULADIKTAN sonra, profil ve gizli bilgileri (user_private) onun giriş
// kimliğine taşınır. Doğrulama zorunlu: aksi halde başkasının e-postasıyla önce kayıt olup hesabını
// ele geçirmek mümkün olurdu. Tanımlı olmayan e-postayla açılan hesap silinir.
// ---------------------------------------------------------------------------
exports.linkAccount = functions.https.onCall(async (data, context) => {
  if (!context.auth) throw new HttpsError("unauthenticated", "Giriş gerekli.");
  const uid = context.auth.uid;
  const own = await db.collection("users").doc(uid).get();
  if (own.exists) return { linked: true };

  const email = String(context.auth.token.email || "").trim().toLowerCase();
  if (!email) throw new HttpsError("failed-precondition", "E-posta adresi yok.");

  const matches = await db.collection("users").where("email", "==", email).limit(2).get();
  const source = matches.docs.find(d => d.id !== uid);
  if (!source) {
    // Yönetimin tanımlamadığı biri: açılan giriş hesabını kaldır
    await admin.auth().deleteUser(uid).catch(() => null);
    throw new HttpsError("not-found", "Bu e-posta sistemde tanımlı değil.");
  }
  if (context.auth.token.email_verified !== true) {
    throw new HttpsError("failed-precondition", "E-posta doğrulanmadı.");
  }

  const priv = await db.collection("user_private").doc(source.id).get();
  const batch = db.batch();
  batch.set(db.collection("users").doc(uid), { ...source.data(), id: uid, email });
  if (priv.exists) {
    batch.set(db.collection("user_private").doc(uid), { ...priv.data(), id: uid });
    batch.delete(priv.ref);
  }
  batch.delete(source.ref);
  await batch.commit();
  await db.collection("audit_logs").add({ action: "LINK", entity: "User", details: `Hesap bağlandı: ${email}`, entityId: uid, timestamp: new Date().toISOString(), userId: uid });
  return { linked: true };
});
