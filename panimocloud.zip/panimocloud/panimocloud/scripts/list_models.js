
import { GoogleGenerativeAI } from "@google/generative-ai";
import dotenv from "dotenv";
import fs from "fs";

dotenv.config();

const genAI = new GoogleGenerativeAI(process.env.VITE_GEMINI_API_KEY || process.env.API_KEY || "");

async function list() {
  try {
    const result = await genAI.listModels();
    fs.writeFileSync("/tmp/models.json", JSON.stringify(result, null, 2));
    console.log("Models listed successfully");
  } catch (e) {
    fs.writeFileSync("/tmp/models_error.txt", e.message);
    console.error("Error listing models:", e);
  }
}

list();
