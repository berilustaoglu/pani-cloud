import React, { useState } from 'react';
import { Star, MessageSquare, Send, CheckCircle2, Shield } from 'lucide-react';

interface Props {
  projectName: string;
  language: 'tr' | 'en';
  onSubmited?: (score: number, comment: string) => void;
}

const ClientFeedbackView: React.FC<Props> = ({ projectName, language, onSubmited }) => {
  const [score, setScore] = useState(0);
  const [comment, setComment] = useState('');
  const [submitted, setSubmitted] = useState(false);

  const handleSubmit = () => {
    if (score > 0) {
      setSubmitted(true);
      onSubmited?.(score, comment);
    }
  };

  if (submitted) {
    return (
      <div className="bg-emerald-50 dark:bg-emerald-900/20 p-12 rounded-[48px] border border-emerald-100 dark:border-emerald-900/30 text-center space-y-6 animate-in zoom-in duration-500">
         <div className="w-24 h-24 bg-white dark:bg-slate-900 rounded-full mx-auto flex items-center justify-center text-emerald-500 shadow-xl">
            <CheckCircle2 size={48} />
         </div>
         <div>
            <h3 className="text-3xl font-black text-emerald-900 dark:text-emerald-400 tracking-tighter">
               {language === 'tr' ? 'Teşekkürler!' : 'Thank You!'}
            </h3>
            <p className="text-emerald-700 dark:text-emerald-500/80 font-bold mt-2">
               {language === 'tr' ? 'Geri bildiriminiz başarıyla alındı.' : 'Your feedback has been received.'}
            </p>
         </div>
      </div>
    );
  }

  return (
    <div className="bg-white dark:bg-slate-900 p-10 lg:p-14 rounded-[48px] border border-slate-100 dark:border-slate-800 shadow-2xl relative overflow-hidden">
      <div className="absolute top-0 right-0 p-10 opacity-[0.03] pointer-events-none">
         <Star size={200} />
      </div>

      <div className="relative z-10">
         <div className="flex items-center gap-4 mb-10">
            <div className="p-4 bg-indigo-600 text-white rounded-[28px] shadow-xl shadow-indigo-100 dark:shadow-none">
               <MessageSquare size={32} />
            </div>
            <div>
               <h3 className="text-3xl font-black text-slate-900 dark:text-white tracking-tighter italic">Experience Review</h3>
               <p className="text-[10px] font-black text-slate-400 uppercase tracking-[0.4em] mt-1">{projectName}</p>
            </div>
         </div>

         <p className="text-slate-500 dark:text-slate-400 font-bold text-lg mb-10 leading-relaxed">
            {language === 'tr' 
              ? 'Projenizin son aşamasını nasıl değerlendirirsiniz? Deneyiminizi iyileştirmemize yardımcı olun.' 
              : 'How would you rate the last phase of your project? Help us improve your experience.'}
         </p>

         <div className="flex items-center justify-center gap-4 mb-12">
            {[1, 2, 3, 4, 5].map(s => (
              <button 
                key={s} 
                onClick={() => setScore(s)}
                className={`p-4 rounded-3xl transition-all ${score >= s ? 'bg-amber-400 text-white scale-110' : 'bg-slate-100 dark:bg-slate-800 text-slate-300 hover:bg-slate-200'}`}
              >
                 <Star size={32} fill={score >= s ? 'currentColor' : 'none'} />
              </button>
            ))}
         </div>

         <div className="space-y-4 mb-12">
            <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest ml-4">{language === 'tr' ? 'YORUMLARINIZ (OPSİYONEL)' : 'YOUR COMMENTS (OPTIONAL)'}</label>
            <textarea 
              value={comment}
              onChange={(e) => setComment(e.target.value)}
              className="w-full bg-slate-50 dark:bg-slate-800/50 border border-slate-100 dark:border-slate-800 rounded-[32px] p-8 font-bold text-slate-700 dark:text-slate-300 focus:ring-2 ring-indigo-500/20 outline-none h-40 resize-none transition-all"
              placeholder={language === 'tr' ? 'Fikirlerinizi buraya yazabilirsiniz...' : 'Write your thoughts here...'}
            />
         </div>

         <div className="flex flex-col sm:flex-row gap-4">
            <button 
              onClick={handleSubmit}
              disabled={score === 0}
              className="flex-1 py-6 bg-indigo-600 text-white rounded-[32px] font-black uppercase tracking-[0.2em] text-xs hover:bg-indigo-700 transition-all shadow-2xl shadow-indigo-100 dark:shadow-none flex items-center justify-center gap-3 disabled:opacity-50"
            >
               <Send size={18} /> {language === 'tr' ? 'DEĞERLENDİRMEYİ GÖNDER' : 'SUBMIT REVIEW'}
            </button>
            <div className="flex items-center gap-3 px-8 text-slate-400 font-bold text-[10px] uppercase tracking-widest border border-slate-100 dark:border-slate-800 rounded-[32px]">
               <Shield size={16} className="text-indigo-500" /> Secure & Anonymous
            </div>
         </div>
      </div>
    </div>
  );
};

export default ClientFeedbackView;
