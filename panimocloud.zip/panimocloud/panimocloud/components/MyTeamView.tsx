import React, { useMemo, useState } from 'react';
import { Users, UserCheck, Palmtree, Hand, AlertTriangle, Check, X, PlayCircle, CalendarDays, ChevronRight, Clock, Loader2, ClipboardList } from 'lucide-react';
import { Task, TaskStatus, Project, User, UserRole, AttendanceRecord, LeaveRequest } from '../types';
import { PageHeader, KpiGrid, Segmented, EmptyState, Avatar, cardCls } from './ui/Kit';
import { GrowBar } from './ui/Motion';
import { localISO, dayDiff, suspendedProjectIds } from '../services/insights';
import { countLeaveDays } from './LeaveView';
import { pushNotification } from '../services/notificationService';
import { toast } from '../services/toast';

interface Props {
  currentUser: User;
  users: User[];
  tasks: Task[];
  projects: Project[];
  attendance: AttendanceRecord[];
  leaveRequests: LeaveRequest[];
  language: 'tr' | 'en';
  onUpsertLeave: (l: LeaveRequest) => Promise<void>;
  onUpdateTask: (t: Task) => Promise<void>;
  onNavigate: (tab: string) => void;
}

type Presence = 'working' | 'left' | 'leave' | 'absent';

const MyTeamView: React.FC<Props> = ({ currentUser, users, tasks, projects, attendance, leaveRequests, language, onUpsertLeave, onUpdateTask, onNavigate }) => {
  const tr = language === 'tr';
  const today = localISO();
  const [sort, setSort] = useState<'attention' | 'name' | 'load'>('attention');
  const [busy, setBusy] = useState<string | null>(null);
  const [rejecting, setRejecting] = useState<{ id: string; note: string } | null>(null);

  // Müdür yöneticileri görmez (diğer ekranlarla aynı kural)
  const team = useMemo(() => users.filter(u => u.id !== currentUser.id && (currentUser.role === UserRole.ADMIN || u.role !== UserRole.ADMIN)), [users, currentUser]);
  const teamIds = new Set(team.map(u => u.id));

  const onLeaveToday = (uid: string) => leaveRequests.find(l => l.userId === uid && l.status === 'Approved' && l.startDate <= today && l.endDate >= today);
  const presenceOf = (uid: string): Presence => {
    const recs = attendance.filter(a => a.userId === uid && a.date === today);
    if (recs.some(r => !r.clockOut)) return 'working';
    if (onLeaveToday(uid)) return 'leave';
    return recs.length ? 'left' : 'absent';
  };

  const held = useMemo(() => suspendedProjectIds(projects), [projects]);
  const rows = useMemo(() => team.map(u => {
    const mine = tasks.filter(t => t.assignedTo?.includes(u.id) && t.status !== TaskStatus.DONE);
    const overdue = mine.filter(t => t.deadline && t.deadline < today && !held.has(t.projectId)).length;
    const blocked = mine.filter(t => t.status === TaskStatus.BLOCKED).length;
    const dueToday = mine.filter(t => t.deadline === today).length;
    const firstIn = attendance.filter(a => a.userId === u.id && a.date === today).map(a => a.clockIn).sort()[0];
    return { u, open: mine.length, overdue, blocked, dueToday, presence: presenceOf(u.id), firstIn, attention: overdue * 2 + blocked * 3 };
  }), [team, tasks, attendance, leaveRequests, today, held]); // eslint-disable-line react-hooks/exhaustive-deps

  const sorted = [...rows].sort((a, b) => sort === 'name' ? a.u.name.localeCompare(b.u.name, 'tr') : sort === 'load' ? b.open - a.open : (b.attention - a.attention) || (b.open - a.open));
  const maxLoad = Math.max(1, ...rows.map(r => r.open));

  const pending = leaveRequests.filter(l => l.status === 'Pending' && teamIds.has(l.userId)).sort((a, b) => a.startDate.localeCompare(b.startDate));
  const blockedTasks = tasks.filter(t => t.status === TaskStatus.BLOCKED && t.assignedTo?.some(id => teamIds.has(id)));
  const counts = { working: rows.filter(r => r.presence === 'working').length, leave: rows.filter(r => r.presence === 'leave').length, overdue: rows.reduce((a, r) => a + r.overdue, 0) };

  // Bu hafta kim izinde (Pzt–Paz)
  const week = useMemo(() => {
    const d = new Date(); const dow = (d.getDay() + 6) % 7;
    return Array.from({ length: 7 }, (_, i) => { const x = new Date(d.getFullYear(), d.getMonth(), d.getDate() - dow + i); const iso = localISO(x); return { iso, label: x.toLocaleDateString(tr ? 'tr-TR' : 'en-US', { weekday: 'short' }), day: x.getDate(), off: leaveRequests.filter(l => l.status === 'Approved' && teamIds.has(l.userId) && l.startDate <= iso && l.endDate >= iso) }; });
  }, [leaveRequests, team, tr]); // eslint-disable-line react-hooks/exhaustive-deps

  const decide = async (l: LeaveRequest, status: 'Approved' | 'Rejected', note?: string) => {
    setBusy(l.id);
    try {
      await onUpsertLeave({ ...l, status, ...(note?.trim() ? { managerNotes: note.trim() } : {}) });
      await pushNotification(status === 'Approved' ? 'İzin talebiniz onaylandı' : 'İzin talebiniz reddedildi', `${l.type} · ${l.startDate} → ${l.endDate}${note?.trim() ? ` — ${note.trim()}` : ''}`, status === 'Approved' ? 'success' : 'warning', 'leave', l.userId);
      toast(status === 'Approved' ? (tr ? `${l.userName} için izin onaylandı` : 'Approved') : (tr ? 'Talep reddedildi' : 'Rejected'), status === 'Approved' ? 'success' : 'info');
      setRejecting(null);
    } catch (e: any) { toast.error(e?.message || 'Hata'); } finally { setBusy(null); }
  };
  const unblock = async (t: Task) => {
    setBusy(t.id);
    try {
      await onUpdateTask({ ...t, status: TaskStatus.DOING, blockedReason: '' });
      for (const uid of t.assignedTo || []) await pushNotification('Engel kaldırıldı', `"${t.title}" görevine devam edebilirsiniz.`, 'info', 'tasks', uid);
      toast.success(tr ? 'Engel kaldırıldı, ekip üyesine bildirildi' : 'Unblocked');
    } finally { setBusy(null); }
  };

  const P: Record<Presence, { l: string; c: string; d: string }> = {
    working: { l: tr ? 'İşte' : 'Working', c: 'bg-emerald-50 text-emerald-700 dark:bg-emerald-500/10 dark:text-emerald-300', d: 'bg-emerald-500' },
    left: { l: tr ? 'Çıkış yaptı' : 'Left', c: 'bg-slate-100 text-slate-600 dark:bg-white/5 dark:text-slate-300', d: 'bg-slate-400' },
    leave: { l: tr ? 'İzinde' : 'On leave', c: 'bg-sky-50 text-sky-700 dark:bg-sky-500/10 dark:text-sky-300', d: 'bg-sky-500' },
    absent: { l: tr ? 'Giriş yok' : 'Not in', c: 'bg-amber-50 text-amber-700 dark:bg-amber-500/10 dark:text-amber-300', d: 'bg-amber-500' },
  };
  const userOf = (id: string) => users.find(u => u.id === id);

  return (
    <div className="space-y-5 pb-10">
      <PageHeader title={tr ? 'Ekibim' : 'My team'} subtitle={tr ? 'Bugün kim işte, kim izinde, onay bekleyenler ve takılan işler.' : "Today's team at a glance."} />

      <KpiGrid items={[
        { label: tr ? 'Şu an işte' : 'Working now', value: counts.working, icon: UserCheck, grad: 'from-emerald-500 to-teal-600', sub: `${team.length} ${tr ? 'kişilik ekip' : 'in team'}`, bar: team.length ? (counts.working / team.length) * 100 : 0, onClick: () => onNavigate('attendance') },
        { label: tr ? 'Bugün izinde' : 'On leave today', value: counts.leave, icon: Palmtree, grad: 'from-sky-500 to-blue-600', sub: pending.length ? (tr ? `${pending.length} talep onay bekliyor` : `${pending.length} pending`) : (tr ? 'Bekleyen talep yok' : 'No pending') },
        { label: tr ? 'Takılan iş' : 'Blocked', value: blockedTasks.length, icon: Hand, grad: blockedTasks.length ? 'from-orange-500 to-amber-600' : 'from-slate-500 to-slate-700', sub: tr ? 'Desteğinizi bekliyor' : 'Need your help' },
        { label: tr ? 'Geciken görev' : 'Overdue', value: counts.overdue, icon: AlertTriangle, grad: counts.overdue ? 'from-rose-500 to-red-600' : 'from-emerald-500 to-teal-600', sub: `${rows.filter(r => r.overdue).length} ${tr ? 'kişide' : 'people'}`, onClick: () => onNavigate('tasks') },
      ]} />

      {(pending.length > 0 || blockedTasks.length > 0) && (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-4 items-start">
          {pending.length > 0 && (
            <div className={`${cardCls} overflow-hidden`}>
              <div className="px-4 py-3 border-b border-slate-100 dark:border-slate-800 flex items-center gap-2"><Palmtree size={16} className="text-sky-500" /><h3 className="font-bold text-slate-900 dark:text-white flex-1">{tr ? 'Onay bekleyen izinler' : 'Leave approvals'}</h3><button onClick={() => onNavigate('leave')} className="text-xs font-semibold text-indigo-600 hover:underline">{tr ? 'İzinler' : 'Leave'}</button></div>
              <div className="divide-y divide-slate-100 dark:divide-slate-800">
                {pending.map(l => { const days = countLeaveDays(l.startDate, l.endDate, l.includeWeekends); const overlap = pending.concat(leaveRequests.filter(x => x.status === 'Approved' && teamIds.has(x.userId))).filter(x => x.id !== l.id && x.userId !== l.userId && x.startDate <= l.endDate && x.endDate >= l.startDate); const u = userOf(l.userId); return (
                  <div key={l.id} className="px-4 py-3">
                    <div className="flex items-start gap-3">
                      <Avatar name={l.userName} src={u?.avatar} size="w-9 h-9" />
                      <div className="min-w-0 flex-1">
                        <p className="text-sm font-semibold text-slate-800 dark:text-slate-100">{l.userName} <span className="font-normal text-slate-500">· {l.type}</span></p>
                        <p className="text-xs text-slate-500">{l.startDate} → {l.endDate} · <b>{days} {tr ? 'gün' : 'days'}</b>{(dayDiff(l.startDate) ?? 99) <= 3 && <span className="text-amber-600"> · {tr ? 'yakında başlıyor' : 'starts soon'}</span>}</p>
                        {l.reason && <p className="text-xs text-slate-500 mt-0.5 line-clamp-2">“{l.reason}”</p>}
                        {overlap.length > 0 && <p className="text-[11px] text-amber-700 dark:text-amber-300 mt-1">⚠ {tr ? `Aynı tarihlerde izinli: ${[...new Set(overlap.map(o => o.userName))].join(', ')}` : 'Overlaps with others'}</p>}
                      </div>
                      {rejecting?.id !== l.id && <div className="flex gap-1 shrink-0">
                        <button disabled={busy === l.id} onClick={() => decide(l, 'Approved')} title={tr ? 'Onayla' : 'Approve'} className="h-8 w-8 rounded-lg flex items-center justify-center text-emerald-600 bg-emerald-50 hover:bg-emerald-100 dark:bg-emerald-500/10 disabled:opacity-50">{busy === l.id ? <Loader2 size={14} className="animate-spin" /> : <Check size={15} />}</button>
                        <button onClick={() => setRejecting({ id: l.id, note: '' })} title={tr ? 'Reddet' : 'Reject'} className="h-8 w-8 rounded-lg flex items-center justify-center text-rose-600 bg-rose-50 hover:bg-rose-100 dark:bg-rose-500/10"><X size={15} /></button>
                      </div>}
                    </div>
                    {rejecting?.id === l.id && (
                      <div className="mt-2 ml-12 flex gap-2 animate-in fade-in duration-200">
                        <input autoFocus value={rejecting.note} onChange={e => setRejecting({ id: l.id, note: e.target.value })} placeholder={tr ? 'Gerekçe (isteğe bağlı)' : 'Reason (optional)'} className="flex-1 h-9 px-3 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-sm outline-none focus:border-rose-400" />
                        <button disabled={busy === l.id} onClick={() => decide(l, 'Rejected', rejecting.note)} className="h-9 px-3 rounded-xl bg-rose-600 text-white text-xs font-semibold disabled:opacity-50">{tr ? 'Reddet' : 'Reject'}</button>
                        <button onClick={() => setRejecting(null)} className="h-9 px-2 rounded-xl text-xs font-semibold text-slate-500">{tr ? 'Vazgeç' : 'Cancel'}</button>
                      </div>
                    )}
                  </div>); })}
              </div>
            </div>
          )}
          {blockedTasks.length > 0 && (
            <div className={`${cardCls} overflow-hidden`}>
              <div className="px-4 py-3 border-b border-slate-100 dark:border-slate-800 flex items-center gap-2"><Hand size={16} className="text-orange-500" /><h3 className="font-bold text-slate-900 dark:text-white flex-1">{tr ? 'Takılan işler' : 'Blocked tasks'}</h3></div>
              <div className="divide-y divide-slate-100 dark:divide-slate-800">
                {blockedTasks.map(t => (
                  <div key={t.id} className="px-4 py-3 flex items-start gap-3">
                    <div className="flex -space-x-2 shrink-0">{(t.assignedTo || []).slice(0, 2).map(id => <Avatar key={id} name={userOf(id)?.name || '?'} src={userOf(id)?.avatar} size="w-8 h-8" className="ring-2 ring-white dark:ring-slate-900 !rounded-full" />)}</div>
                    <div className="min-w-0 flex-1">
                      <p className="text-sm font-semibold text-slate-800 dark:text-slate-100">{t.title}</p>
                      <p className="text-[11px] text-slate-400">{(t.assignedTo || []).map(id => userOf(id)?.name).filter(Boolean).join(', ')} · {projects.find(p => p.id === t.projectId)?.name || (tr ? 'Genel' : 'General')}</p>
                      {t.blockedReason && <p className="text-xs text-orange-700 dark:text-orange-300 mt-1 bg-orange-50 dark:bg-orange-500/10 rounded-lg px-2 py-1">⛔ {t.blockedReason}</p>}
                    </div>
                    <button disabled={busy === t.id} onClick={() => unblock(t)} className="shrink-0 h-8 px-2.5 rounded-lg text-[11px] font-semibold text-sky-700 bg-sky-50 hover:bg-sky-100 dark:bg-sky-500/10 dark:text-sky-300 inline-flex items-center gap-1 disabled:opacity-50">{busy === t.id ? <Loader2 size={12} className="animate-spin" /> : <PlayCircle size={12} />}{tr ? 'Engeli kaldır' : 'Unblock'}</button>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      )}

      {/* Bu hafta izinliler */}
      <div className={`${cardCls} p-4`}>
        <div className="flex items-center gap-2 mb-3"><CalendarDays size={16} className="text-indigo-500" /><h3 className="font-bold text-slate-900 dark:text-white">{tr ? 'Bu hafta kim izinde?' : "Who's off this week"}</h3></div>
        <div className="grid grid-cols-7 gap-1.5">
          {week.map(d => (
            <div key={d.iso} className={`rounded-xl p-2 min-h-[72px] ${d.iso === today ? 'bg-indigo-50 dark:bg-indigo-500/10 ring-1 ring-indigo-200 dark:ring-indigo-500/30' : 'bg-slate-50 dark:bg-white/[0.03]'}`}>
              <p className={`text-[10px] font-semibold ${d.iso === today ? 'text-indigo-600' : 'text-slate-400'}`}>{d.label} {d.day}</p>
              <div className="mt-1 flex flex-wrap gap-0.5">{d.off.slice(0, 4).map(l => <span key={l.id} title={`${l.userName} · ${l.type}`}><Avatar name={l.userName} src={userOf(l.userId)?.avatar} size="w-6 h-6" className="!rounded-full" /></span>)}{d.off.length > 4 && <span className="text-[10px] text-slate-400">+{d.off.length - 4}</span>}</div>
            </div>
          ))}
        </div>
      </div>

      {/* Ekip listesi */}
      <div className={`${cardCls} overflow-hidden`}>
        <div className="px-4 py-3 border-b border-slate-100 dark:border-slate-800 flex flex-col sm:flex-row sm:items-center gap-2">
          <div className="flex items-center gap-2 flex-1"><Users size={16} className="text-indigo-500" /><h3 className="font-bold text-slate-900 dark:text-white">{tr ? 'Ekip durumu' : 'Team status'}</h3></div>
          <Segmented<'attention' | 'name' | 'load'> value={sort} onChange={setSort} options={[{ value: 'attention', label: tr ? 'Dikkat gerektiren' : 'Attention' }, { value: 'load', label: tr ? 'İş yükü' : 'Load' }, { value: 'name', label: tr ? 'Ad' : 'Name' }]} />
        </div>
        {sorted.length === 0 ? <EmptyState icon={Users} text={tr ? 'Ekibinizde kimse yok' : 'No team members'} /> : (
          <div className="divide-y divide-slate-100 dark:divide-slate-800 pc-stagger">
            {sorted.map(r => { const p = P[r.presence]; return (
              <div key={r.u.id} className="grid grid-cols-12 gap-3 items-center px-4 py-3 hover:bg-slate-50/70 dark:hover:bg-white/[0.02]">
                <div className="col-span-12 sm:col-span-4 flex items-center gap-3 min-w-0">
                  <span className="relative"><Avatar name={r.u.name} src={r.u.avatar} /><span className={`absolute -bottom-0.5 -right-0.5 w-3 h-3 rounded-full border-2 border-white dark:border-slate-900 ${p.d}`} /></span>
                  <div className="min-w-0"><p className="text-sm font-semibold text-slate-800 dark:text-slate-100 truncate">{r.u.name}</p><p className="text-[11px] text-slate-400 truncate">{r.u.jobTitle || ({ Admin: tr ? 'Yönetici' : 'Admin', Manager: tr ? 'Müdür' : 'Manager', Staff: tr ? 'Personel' : 'Staff', Accountant: tr ? 'Muhasebe' : 'Accountant', Sales: tr ? 'Satış' : 'Sales' } as Record<string, string>)[r.u.role] || r.u.role}</p></div>
                </div>
                <div className="col-span-5 sm:col-span-2"><span className={`text-[11px] font-semibold px-2 py-0.5 rounded-md ${p.c}`}>{p.l}</span>{r.firstIn && <p className="text-[10px] text-slate-400 mt-0.5 flex items-center gap-0.5"><Clock size={9} />{r.firstIn}</p>}</div>
                <div className="col-span-7 sm:col-span-4">
                  <div className="flex items-center justify-between text-[11px] mb-1"><span className="text-slate-500">{r.open} {tr ? 'açık görev' : 'open'}{r.dueToday ? ` · ${r.dueToday} ${tr ? 'bugün' : 'today'}` : ''}</span>
                    <span className="flex gap-1">{r.overdue > 0 && <span className="px-1.5 rounded bg-rose-50 text-rose-600 dark:bg-rose-500/10 font-semibold">{r.overdue} {tr ? 'gecikmiş' : 'late'}</span>}{r.blocked > 0 && <span className="px-1.5 rounded bg-orange-50 text-orange-600 dark:bg-orange-500/10 font-semibold">⛔ {r.blocked}</span>}</span></div>
                  <GrowBar value={(r.open / maxLoad) * 100} className={r.overdue ? 'bg-rose-500' : 'bg-indigo-500'} />
                </div>
                <div className="col-span-12 sm:col-span-2 flex justify-end"><button onClick={() => onNavigate('team')} className="text-xs font-semibold text-indigo-600 hover:underline inline-flex items-center gap-0.5"><ClipboardList size={12} />{tr ? 'Görev ata' : 'Assign'}<ChevronRight size={12} /></button></div>
              </div>); })}
          </div>
        )}
      </div>
    </div>
  );
};

export default MyTeamView;
