import React, { useMemo, useState } from 'react';
import { Package, Plus, AlertTriangle, Edit2, Sparkles, Loader2, ArrowDownToLine, ArrowUpFromLine, History, Boxes, Wallet, PackageX, MapPin, LayoutGrid, List, X } from 'lucide-react';
import { InventoryItem, Currency, User, StockMovement } from '../types';
import { analyzeInventoryRisks } from '../services/aiService';
import { PageHeader, KpiGrid, SearchBox, Segmented, Field, EmptyState, DeleteButton, Sheet, inputCls, selectSm, cardCls, btnPrimary, btnGhost, money } from './ui/Kit';
import { toTRY, formatTRY } from '../services/insights';
import { toast } from '../services/toast';

interface Props {
  inventory: InventoryItem[];
  onUpsertItem: (item: InventoryItem) => Promise<void>;
  onDeleteItem?: (id: string) => Promise<void>;
  currentUser: User;
  language: 'tr' | 'en';
  rates?: { TRY: number; EUR: number };
}

type StockState = 'all' | 'ok' | 'low' | 'out';
const UNITS = ['adet', 'kutu', 'paket', 'kg', 'lt', 'metre', 'set'];
const stateOf = (i: InventoryItem): Exclude<StockState, 'all'> => (i.currentQuantity <= 0 ? 'out' : i.currentQuantity <= i.minQuantity ? 'low' : 'ok');
const empty = (): Partial<InventoryItem> => ({ sku: '', name: '', description: '', category: '', currentQuantity: 0, minQuantity: 5, unitPrice: 0, currency: Currency.TRY, location: '', unit: 'adet' });

const InventoryView: React.FC<Props> = ({ inventory, onUpsertItem, onDeleteItem, currentUser, language, rates = { TRY: 34, EUR: 0.92 } }) => {
  const tr = language === 'tr';
  const [search, setSearch] = useState('');
  const [stateF, setStateF] = useState<StockState>('all');
  const [catF, setCatF] = useState('all');
  const [view, setView] = useState<'table' | 'cards'>('table');
  const [form, setForm] = useState<Partial<InventoryItem> | null>(null);
  const [touched, setTouched] = useState(false);
  const [saving, setSaving] = useState(false);
  const [move, setMove] = useState<{ item: InventoryItem; type: 'in' | 'out'; qty: number; note: string } | null>(null);
  const [historyOf, setHistoryOf] = useState<InventoryItem | null>(null);
  const [ai, setAi] = useState<{ riskyItems: { itemId: string; itemName: string; riskLevel: string; suggestion: string }[]; overallAdvice: string } | null>(null);
  const [aiLoading, setAiLoading] = useState(false);

  const categories = useMemo(() => [...new Set(inventory.map(i => i.category).filter(Boolean))].sort((a, b) => a.localeCompare(b, 'tr')), [inventory]);
  const valueOf = (i: InventoryItem) => toTRY((i.unitPrice || 0) * (i.currentQuantity || 0), i.currency, rates);

  const filtered = useMemo(() => {
    const q = search.trim().toLocaleLowerCase('tr-TR');
    return inventory.filter(i =>
      (stateF === 'all' || stateOf(i) === stateF) && (catF === 'all' || i.category === catF) &&
      (!q || [i.name, i.sku, i.category, i.location, i.description].join(' ').toLocaleLowerCase('tr-TR').includes(q))
    ).sort((a, b) => ({ out: 0, low: 1, ok: 2 }[stateOf(a)] - { out: 0, low: 1, ok: 2 }[stateOf(b)]) || a.name.localeCompare(b.name, 'tr'));
  }, [inventory, search, stateF, catF]);

  const stats = useMemo(() => ({
    items: inventory.length,
    units: inventory.reduce((s, i) => s + (i.currentQuantity || 0), 0),
    value: inventory.reduce((s, i) => s + valueOf(i), 0),
    low: inventory.filter(i => stateOf(i) === 'low').length,
    out: inventory.filter(i => stateOf(i) === 'out').length,
  }), [inventory, rates]);

  // ---------- Form ----------
  const errors: Record<string, string> = {};
  if (form) {
    if (!form.name?.trim()) errors.name = tr ? 'Ürün adı zorunlu.' : 'Name required.';
    if (!form.sku?.trim()) errors.sku = tr ? 'Stok kodu zorunlu.' : 'SKU required.';
    else if (inventory.some(i => i.sku.toLowerCase() === form.sku!.trim().toLowerCase() && i.id !== form.id)) errors.sku = tr ? 'Bu stok kodu zaten kullanılıyor.' : 'SKU already exists.';
    if ((form.currentQuantity || 0) < 0) errors.qty = tr ? 'Stok negatif olamaz.' : 'Cannot be negative.';
  }
  const err = (k: string) => (touched ? errors[k] : undefined);
  const save = async () => {
    setTouched(true);
    if (!form || Object.keys(errors).length) return;
    setSaving(true);
    try {
      const prev = inventory.find(i => i.id === form.id);
      const qty = Number(form.currentQuantity) || 0;
      const movements = [...(prev?.movements || [])];
      if (!prev && qty > 0) movements.push({ id: `mv_${Date.now()}`, type: 'in', quantity: qty, date: new Date().toISOString(), note: tr ? 'Açılış stoğu' : 'Opening stock', userName: currentUser.name });
      if (prev && prev.currentQuantity !== qty) movements.push({ id: `mv_${Date.now()}`, type: 'adjust', quantity: qty - prev.currentQuantity, date: new Date().toISOString(), note: tr ? 'Manuel düzeltme' : 'Manual correction', userName: currentUser.name });
      await onUpsertItem({
        id: form.id || `inv_${Date.now()}`, sku: form.sku!.trim(), name: form.name!.trim(), description: form.description || '', category: form.category?.trim() || (tr ? 'Genel' : 'General'),
        currentQuantity: qty, minQuantity: Number(form.minQuantity) || 0, unitPrice: Number(form.unitPrice) || 0, currency: form.currency || Currency.TRY,
        location: form.location || '', unit: form.unit || 'adet', lastUpdated: new Date().toISOString(), movements: movements.slice(-100),
      });
      toast.success(prev ? (tr ? 'Ürün güncellendi' : 'Item updated') : (tr ? 'Ürün eklendi' : 'Item added'));
      setForm(null);
    } catch (e: any) { toast.error(e?.message || 'Hata'); } finally { setSaving(false); }
  };

  const applyMove = async () => {
    if (!move || !(move.qty > 0)) return;
    const { item, type, qty, note } = move;
    if (type === 'out' && qty > item.currentQuantity) { toast.warning(tr ? `Stokta sadece ${item.currentQuantity} ${item.unit || 'adet'} var` : `Only ${item.currentQuantity} in stock`); return; }
    const mv: StockMovement = { id: `mv_${Date.now()}`, type, quantity: qty, date: new Date().toISOString(), note: note.trim() || undefined, userName: currentUser.name };
    if (!mv.note) delete mv.note;
    const next = { ...item, currentQuantity: item.currentQuantity + (type === 'in' ? qty : -qty), lastUpdated: mv.date, movements: [...(item.movements || []), mv].slice(-100) };
    await onUpsertItem(next);
    toast.success(type === 'in' ? (tr ? `${qty} ${item.unit || 'adet'} stok girişi yapıldı` : 'Stock in recorded') : (tr ? `${qty} ${item.unit || 'adet'} stok çıkışı yapıldı` : 'Stock out recorded'));
    if (stateOf(next) !== 'ok') toast.warning(tr ? `${item.name} kritik seviyede (${next.currentQuantity})` : `${item.name} is low`);
    setMove(null);
  };

  const runAi = async () => {
    setAiLoading(true);
    try { setAi(await analyzeInventoryRisks(inventory, language)); } catch (e: any) { toast.error(e?.message || 'AI'); } finally { setAiLoading(false); }
  };

  // ---------- Parçalar ----------
  const stateChip = (i: InventoryItem) => {
    const s = stateOf(i);
    const m = { ok: [tr ? 'Yeterli' : 'OK', 'bg-emerald-50 text-emerald-700 dark:bg-emerald-500/10 dark:text-emerald-300'], low: [tr ? 'Kritik' : 'Low', 'bg-amber-50 text-amber-700 dark:bg-amber-500/10 dark:text-amber-300'], out: [tr ? 'Tükendi' : 'Out', 'bg-rose-50 text-rose-700 dark:bg-rose-500/10 dark:text-rose-300'] }[s];
    return <span className={`text-[11px] font-semibold px-2 py-0.5 rounded-md ${m[1]}`}>{m[0]}</span>;
  };
  const level = (i: InventoryItem) => {
    const max = Math.max(i.minQuantity * 3, i.currentQuantity, 1);
    const pct = Math.min(100, (i.currentQuantity / max) * 100);
    const s = stateOf(i);
    return (
      <div className="relative h-1.5 w-full rounded-full bg-slate-100 dark:bg-white/5">
        <div className={`h-full rounded-full pc-grow-x ${s === 'ok' ? 'bg-emerald-500' : s === 'low' ? 'bg-amber-400' : 'bg-rose-500'}`} style={{ width: `${pct}%` }} />
        <span className="absolute -top-0.5 -bottom-0.5 w-0.5 bg-slate-500/60 rounded" style={{ left: `${(i.minQuantity / max) * 100}%` }} title={tr ? 'Minimum seviye' : 'Minimum'} />
      </div>
    );
  };
  const actions = (i: InventoryItem) => (
    <div className="flex items-center gap-1" onClick={e => e.stopPropagation()}>
      <button onClick={() => setMove({ item: i, type: 'in', qty: Math.max(1, i.minQuantity * 2 - i.currentQuantity), note: '' })} title={tr ? 'Stok girişi' : 'Stock in'} className="p-1.5 rounded-lg text-emerald-600 hover:bg-emerald-50 dark:hover:bg-emerald-500/10"><ArrowDownToLine size={15} /></button>
      <button onClick={() => setMove({ item: i, type: 'out', qty: 1, note: '' })} disabled={i.currentQuantity <= 0} title={tr ? 'Stok çıkışı' : 'Stock out'} className="p-1.5 rounded-lg text-orange-600 hover:bg-orange-50 dark:hover:bg-orange-500/10 disabled:opacity-30"><ArrowUpFromLine size={15} /></button>
      <button onClick={() => setHistoryOf(i)} title={tr ? 'Hareketler' : 'History'} className="p-1.5 rounded-lg text-slate-400 hover:text-indigo-600 hover:bg-indigo-50 dark:hover:bg-white/5"><History size={15} /></button>
      <button onClick={() => { setForm({ ...i }); setTouched(false); }} title={tr ? 'Düzenle' : 'Edit'} className="p-1.5 rounded-lg text-slate-400 hover:text-indigo-600 hover:bg-indigo-50 dark:hover:bg-white/5"><Edit2 size={15} /></button>
      {onDeleteItem && <DeleteButton language={language} onConfirm={async () => { await onDeleteItem(i.id); toast(tr ? 'Ürün silindi' : 'Deleted', 'info'); }} />}
    </div>
  );

  const table = () => (
    <div className={`${cardCls} overflow-hidden`}>
      <div className="hidden md:grid grid-cols-12 gap-3 px-4 py-2.5 text-[10px] font-black uppercase tracking-widest text-slate-400 border-b border-slate-100 dark:border-slate-800">
        <span className="col-span-4">{tr ? 'Ürün' : 'Item'}</span><span className="col-span-2">{tr ? 'Konum' : 'Location'}</span><span className="col-span-3">{tr ? 'Stok' : 'Stock'}</span><span className="col-span-1 text-right">{tr ? 'Değer' : 'Value'}</span><span className="col-span-2 text-right">{tr ? 'İşlem' : 'Actions'}</span>
      </div>
      <div className="divide-y divide-slate-100 dark:divide-slate-800 pc-stagger">
        {filtered.map(i => (
          <div key={i.id} className="grid grid-cols-12 gap-3 items-center px-4 py-3 hover:bg-slate-50/70 dark:hover:bg-white/[0.02]">
            <div className="col-span-12 md:col-span-4 min-w-0 flex items-center gap-3">
              <span className="w-10 h-10 shrink-0 rounded-xl bg-blue-50 dark:bg-blue-500/10 text-blue-600 flex items-center justify-center"><Package size={18} /></span>
              <div className="min-w-0"><p className="text-sm font-semibold text-slate-800 dark:text-slate-100 truncate">{i.name}</p><p className="text-[11px] text-slate-400 truncate"><span className="font-mono">{i.sku}</span> · {i.category}</p></div>
            </div>
            <div className="col-span-6 md:col-span-2 text-xs text-slate-500 flex items-center gap-1 truncate">{i.location ? <><MapPin size={12} />{i.location}</> : '—'}</div>
            <div className="col-span-6 md:col-span-3">
              <div className="flex items-center justify-between text-xs mb-1"><span className="font-bold text-slate-900 dark:text-white">{i.currentQuantity} <span className="font-normal text-slate-400">{i.unit || 'adet'} · min {i.minQuantity}</span></span>{stateChip(i)}</div>
              {level(i)}
            </div>
            <div className="col-span-6 md:col-span-1 text-right text-xs font-semibold text-slate-700 dark:text-slate-200">{i.unitPrice ? money(i.unitPrice * i.currentQuantity, i.currency) : '—'}</div>
            <div className="col-span-6 md:col-span-2 flex justify-end">{actions(i)}</div>
          </div>
        ))}
      </div>
    </div>
  );

  const cards = () => (
    <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-3 gap-4 pc-stagger">
      {filtered.map(i => (
        <div key={i.id} className={`${cardCls} p-4 pc-lift ${stateOf(i) === 'out' ? '!border-rose-200 dark:!border-rose-500/30' : ''}`}>
          <div className="flex items-start justify-between gap-2"><div className="min-w-0"><p className="font-bold text-slate-900 dark:text-white truncate">{i.name}</p><p className="text-[11px] text-slate-400"><span className="font-mono">{i.sku}</span> · {i.category}</p></div>{stateChip(i)}</div>
          <p className="text-3xl font-black text-slate-900 dark:text-white mt-3">{i.currentQuantity}<span className="text-sm font-semibold text-slate-400 ml-1">{i.unit || 'adet'}</span></p>
          <div className="mt-2">{level(i)}</div>
          <div className="flex items-center justify-between mt-3 text-[11px] text-slate-500"><span className="inline-flex items-center gap-1"><MapPin size={11} />{i.location || '—'}</span><span>{i.unitPrice ? money(i.unitPrice, i.currency, 2) + ' / ' + (i.unit || 'adet') : ''}</span></div>
          <div className="mt-3 pt-3 border-t border-slate-100 dark:border-slate-800 flex justify-end">{actions(i)}</div>
        </div>
      ))}
    </div>
  );

  return (
    <div className="space-y-5 pb-10">
      <PageHeader title={tr ? 'Depo & Envanter' : 'Inventory'} subtitle={tr ? 'Stok seviyeleri, hareketler ve kritik ürün takibi.' : 'Stock levels, movements and alerts.'}
        actions={<>
          <button onClick={runAi} disabled={aiLoading || !inventory.length} className={btnGhost}>{aiLoading ? <Loader2 size={16} className="animate-spin" /> : <Sparkles size={16} />} {tr ? 'AI analizi' : 'AI analysis'}</button>
          <button onClick={() => { setForm(empty()); setTouched(false); }} className={btnPrimary}><Plus size={16} /> {tr ? 'Yeni ürün' : 'New item'}</button>
        </>} />

      <KpiGrid cols="lg:grid-cols-4" items={[
        { label: tr ? 'Ürün çeşidi' : 'Items', value: stats.items, sub: `${stats.units.toLocaleString('tr-TR')} ${tr ? 'birim stokta' : 'units'}`, icon: Boxes, grad: 'from-blue-500 to-indigo-600', onClick: () => setStateF('all'), active: stateF === 'all' },
        { label: tr ? 'Stok değeri' : 'Stock value', value: stats.value, format: formatTRY, sub: tr ? 'Birim fiyat × miktar' : 'Price × qty', icon: Wallet, grad: 'from-emerald-500 to-teal-600' },
        { label: tr ? 'Kritik seviye' : 'Low stock', value: stats.low, sub: tr ? 'Minimumda veya altında' : 'At/below min', icon: AlertTriangle, grad: 'from-amber-500 to-orange-600', onClick: () => setStateF(s => (s === 'low' ? 'all' : 'low')), active: stateF === 'low' },
        { label: tr ? 'Tükenen' : 'Out of stock', value: stats.out, sub: tr ? 'Stokta yok' : 'Zero stock', icon: PackageX, grad: 'from-rose-500 to-red-600', onClick: () => setStateF(s => (s === 'out' ? 'all' : 'out')), active: stateF === 'out' },
      ]} />

      {ai && (
        <div className="relative rounded-[20px] p-5 text-white bg-gradient-to-br from-indigo-600 to-violet-700 shadow-xl animate-in fade-in slide-in-from-top-2 duration-300">
          <button onClick={() => setAi(null)} className="absolute top-3 right-3 p-1.5 rounded-lg hover:bg-white/10"><X size={16} /></button>
          <p className="font-bold flex items-center gap-2"><Sparkles size={17} />{tr ? 'Yapay zeka stok önerileri' : 'AI stock insights'}</p>
          <p className="text-sm text-indigo-100 mt-1">{ai.overallAdvice}</p>
          {ai.riskyItems?.length > 0 && <div className="mt-3 grid grid-cols-1 md:grid-cols-2 gap-2">{ai.riskyItems.map((r, i) => <div key={i} className="rounded-xl bg-white/10 p-3 text-sm"><p className="font-semibold">{r.itemName} <span className="text-[10px] px-1.5 py-0.5 rounded bg-amber-400/30 ml-1">{r.riskLevel}</span></p><p className="text-xs text-indigo-100 mt-0.5">{r.suggestion}</p></div>)}</div>}
        </div>
      )}

      <div className={`${cardCls} p-3 flex flex-col lg:flex-row gap-2`}>
        <SearchBox value={search} onChange={setSearch} placeholder={tr ? 'Ürün, stok kodu, kategori, konum ara…' : 'Search…'} />
        <div className="flex flex-wrap gap-2">
          <Segmented<StockState> value={stateF} onChange={setStateF} options={[{ value: 'all', label: tr ? 'Tümü' : 'All' }, { value: 'ok', label: tr ? 'Yeterli' : 'OK' }, { value: 'low', label: tr ? 'Kritik' : 'Low' }, { value: 'out', label: tr ? 'Tükenen' : 'Out' }]} />
          <select value={catF} onChange={e => setCatF(e.target.value)} className={selectSm}><option value="all">{tr ? 'Tüm kategoriler' : 'All categories'}</option>{categories.map(c => <option key={c} value={c}>{c}</option>)}</select>
          <Segmented<"table" | "cards"> value={view} onChange={setView} options={[{ value: 'table', label: <List size={15} /> }, { value: 'cards', label: <LayoutGrid size={15} /> }]} />
        </div>
      </div>

      <div key={view}>{filtered.length === 0 ? <div className={cardCls}><EmptyState icon={Package} text={inventory.length ? (tr ? 'Filtrelere uyan ürün yok' : 'No matches') : (tr ? 'Henüz ürün eklenmedi' : 'No items yet')} action={!inventory.length && <button onClick={() => setForm(empty())} className="text-xs font-semibold text-indigo-600 hover:underline">{tr ? 'İlk ürünü ekle' : 'Add first item'}</button>} /></div> : view === 'table' ? table() : cards()}</div>

      {/* Ürün formu */}
      <Sheet open={!!form} language={language} title={form?.id ? (tr ? 'Ürünü düzenle' : 'Edit item') : (tr ? 'Yeni ürün' : 'New item')} subtitle={form?.name} icon={Package} tone="from-blue-500 to-indigo-600"
        onClose={() => setForm(null)} onSubmit={save} saving={saving}
        footerLeft={form && Number(form.unitPrice) > 0 ? <span className="text-slate-400">{tr ? 'Stok değeri' : 'Value'} <b className="text-slate-800 dark:text-slate-100">{money((Number(form.unitPrice) || 0) * (Number(form.currentQuantity) || 0), form.currency, 2)}</b></span> : undefined}>
        {form && <>
          <Field label={tr ? 'Ürün adı' : 'Name'} required error={err('name')}><input autoFocus className={inputCls(err('name'))} value={form.name || ''} onChange={e => setForm({ ...form, name: e.target.value })} /></Field>
          <div className="grid grid-cols-2 gap-4">
            <Field label={tr ? 'Stok kodu (SKU)' : 'SKU'} required error={err('sku')}><input className={inputCls(err('sku')) + ' font-mono'} value={form.sku || ''} onChange={e => setForm({ ...form, sku: e.target.value.toUpperCase() })} placeholder="VR-Q3-128" /></Field>
            <Field label={tr ? 'Kategori' : 'Category'}><input list="inv-cats" className={inputCls()} value={form.category || ''} onChange={e => setForm({ ...form, category: e.target.value })} placeholder={tr ? 'Donanım' : 'Hardware'} /><datalist id="inv-cats">{categories.map(c => <option key={c} value={c} />)}</datalist></Field>
          </div>
          <div className="grid grid-cols-3 gap-4">
            <Field label={form.id ? (tr ? 'Mevcut stok' : 'Stock') : (tr ? 'Açılış stoğu' : 'Opening stock')} error={err('qty')} hint={form.id ? (tr ? 'Değiştirirseniz düzeltme hareketi oluşur' : 'Creates an adjustment') : undefined}><input type="number" min={0} className={inputCls(err('qty'))} value={form.currentQuantity ?? 0} onChange={e => setForm({ ...form, currentQuantity: Number(e.target.value) })} /></Field>
            <Field label={tr ? 'Minimum stok' : 'Minimum'}><input type="number" min={0} className={inputCls()} value={form.minQuantity ?? 0} onChange={e => setForm({ ...form, minQuantity: Number(e.target.value) })} /></Field>
            <Field label={tr ? 'Birim' : 'Unit'}><select className={inputCls()} value={form.unit || 'adet'} onChange={e => setForm({ ...form, unit: e.target.value })}>{UNITS.map(u => <option key={u} value={u}>{u}</option>)}</select></Field>
          </div>
          <div className="grid grid-cols-3 gap-4">
            <Field label={tr ? 'Birim fiyat' : 'Unit price'} className="col-span-2"><input type="number" min={0} step="0.01" className={inputCls()} value={form.unitPrice || ''} onChange={e => setForm({ ...form, unitPrice: Number(e.target.value) })} /></Field>
            <Field label={tr ? 'Para birimi' : 'Currency'}><select className={inputCls()} value={form.currency} onChange={e => setForm({ ...form, currency: e.target.value as Currency })}>{Object.values(Currency).map(c => <option key={c} value={c}>{c}</option>)}</select></Field>
          </div>
          <Field label={tr ? 'Konum' : 'Location'}><input className={inputCls()} value={form.location || ''} onChange={e => setForm({ ...form, location: e.target.value })} placeholder={tr ? 'Depo A, Raf 3' : 'Warehouse A, Shelf 3'} /></Field>
          <Field label={tr ? 'Açıklama' : 'Description'}><textarea rows={2} className={inputCls() + ' h-auto py-2.5 resize-none'} value={form.description || ''} onChange={e => setForm({ ...form, description: e.target.value })} /></Field>
        </>}
      </Sheet>

      {/* Stok giriş / çıkış */}
      <Sheet open={!!move} language={language} width="max-w-md" title={move?.type === 'in' ? (tr ? 'Stok girişi' : 'Stock in') : (tr ? 'Stok çıkışı' : 'Stock out')} subtitle={move ? `${move.item.name} · ${tr ? 'mevcut' : 'current'} ${move.item.currentQuantity} ${move.item.unit || 'adet'}` : ''}
        icon={move?.type === 'in' ? ArrowDownToLine : ArrowUpFromLine} tone={move?.type === 'in' ? 'from-emerald-500 to-teal-600' : 'from-orange-500 to-rose-500'} onClose={() => setMove(null)} onSubmit={applyMove} submitLabel={tr ? 'Kaydet' : 'Save'}>
        {move && <>
          <Field label={tr ? 'Miktar' : 'Quantity'} required hint={<span>{tr ? 'İşlem sonrası stok' : 'After'}: <b className="text-slate-700 dark:text-slate-200">{move.item.currentQuantity + (move.type === 'in' ? move.qty : -move.qty)}</b></span>}>
            <div className="flex items-center gap-2">
              <button onClick={() => setMove({ ...move, qty: Math.max(1, move.qty - 1) })} className="h-11 w-11 rounded-xl border border-slate-200 dark:border-slate-700 text-lg font-bold">−</button>
              <input autoFocus type="number" min={1} className={inputCls() + ' text-center text-lg font-bold'} value={move.qty || ''} onChange={e => setMove({ ...move, qty: Number(e.target.value) })} />
              <button onClick={() => setMove({ ...move, qty: move.qty + 1 })} className="h-11 w-11 rounded-xl border border-slate-200 dark:border-slate-700 text-lg font-bold">+</button>
            </div>
          </Field>
          <Field label={tr ? 'Not' : 'Note'}><input className={inputCls()} value={move.note} onChange={e => setMove({ ...move, note: e.target.value })} placeholder={move.type === 'in' ? (tr ? 'Örn: PO-2026-014 teslim alındı' : 'e.g. PO received') : (tr ? 'Örn: VR projesine çıkış' : 'e.g. issued to project')} /></Field>
        </>}
      </Sheet>

      {/* Hareket geçmişi */}
      <Sheet open={!!historyOf} language={language} width="max-w-lg" title={tr ? 'Stok hareketleri' : 'Stock movements'} subtitle={historyOf?.name} icon={History} onClose={() => setHistoryOf(null)}>
        {historyOf && ((historyOf.movements || []).length === 0 ? <EmptyState icon={History} text={tr ? 'Henüz hareket kaydı yok' : 'No movements yet'} /> : (
          <ol className="relative border-l-2 border-slate-100 dark:border-slate-800 ml-2 space-y-4">
            {[...(inventory.find(i => i.id === historyOf.id)?.movements || [])].reverse().map(m => (
              <li key={m.id} className="ml-4">
                <span className={`absolute -left-[7px] mt-1.5 w-3 h-3 rounded-full ring-4 ring-white dark:ring-slate-900 ${m.type === 'in' ? 'bg-emerald-500' : m.type === 'out' ? 'bg-orange-500' : 'bg-slate-400'}`} />
                <p className="text-sm font-semibold text-slate-800 dark:text-slate-100">{m.type === 'in' || (m.type === 'adjust' && m.quantity >= 0) ? '+' : '−'}{Math.abs(m.quantity)} {historyOf.unit || 'adet'} · {m.type === 'in' ? (tr ? 'Giriş' : 'In') : m.type === 'out' ? (tr ? 'Çıkış' : 'Out') : (tr ? 'Düzeltme' : 'Adjustment')}</p>
                <p className="text-[11px] text-slate-400">{new Date(m.date).toLocaleString(tr ? 'tr-TR' : 'en-US', { dateStyle: 'medium', timeStyle: 'short' })}{m.userName ? ` · ${m.userName}` : ''}{m.note ? ` · ${m.note}` : ''}</p>
              </li>
            ))}
          </ol>
        ))}
      </Sheet>
    </div>
  );
};

export default InventoryView;
