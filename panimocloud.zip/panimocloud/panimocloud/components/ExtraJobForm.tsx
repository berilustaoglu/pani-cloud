import React, { useEffect, useMemo, useRef, useState } from 'react';
import { X, Check, AlertCircle, Plus, Trash2, BookUser, Save, Loader2, Wallet, CalendarRange, Users, FileText, Timer, CheckCircle2, Banknote } from 'lucide-react';
import { ExtraJob, ExtraJobPayment, ExtraJobStatus, User as AppUser, Customer, Currency, ProjectPriority } from '../types';
import ModalPortal from './ModalPortal';
import { EXTRA_JOB_CATEGORIES, STATUS_META, PAYMENT_META, jobTotal, jobPaid, derivePaymentStatus } from '../services/extraJobMetrics';
import { PRIORITY_META } from '../services/projectMetrics';
import { toast } from '../services/toast';

interface Props {
  show: boolean;
  job: ExtraJob | null;
  users: AppUser[];
  customers?: Customer[];
  onClose: () => void;
  onSave: (job: ExtraJob, previous: ExtraJob | null) => Promise<void> | void;
  language: 'tr' | 'en';
  financeSettings?: any;
}

const sym = (c?: Currency) => (c === Currency.TRY ? '₺' : c === Currency.EUR ? '€' : '$');
const money = (n: number, c?: Currency) => `${sym(c)}${(Number(n) || 0).toLocaleString('tr-TR', { maximumFractionDigits: 2 })}`;
const round2 = (n: number) => Math.round(n * 100) / 100;
const today = () => new Date().toISOString().split('T')[0];

const inputBase = 'w-full h-11 px-3.5 rounded-xl bg-white dark:bg-slate-800 border text-sm font-medium text-slate-900 dark:text-white outline-none transition-all placeholder:text-slate-400 focus:ring-4';
const inputCls = (err?: string) => `${inputBase} ${err ? 'border-rose-300 focus:border-rose-400 focus:ring-rose-500/10' : 'border-slate-200 dark:border-slate-700 focus:border-indigo-500 focus:ring-indigo-500/10'}`;

const Field: React.FC<{ label: string; required?: boolean; error?: string; hint?: string; className?: string; children: React.ReactNode; language: 'tr' | 'en' }> = ({ label, required, error, hint, className = '', children, language }) => (
  <div className={className}>
    <label className="flex items-center gap-1 text-xs font-semibold text-slate-600 dark:text-slate-300 mb-1.5">
      {label}{required ? <span className="text-rose-500">*</span> : <span className="font-normal text-slate-400">({language === 'tr' ? 'isteğe bağlı' : 'optional'})</span>}
    </label>
    {children}
    {error ? <p className="mt-1 text-[11px] font-semibold text-rose-600 flex items-center gap-1 animate-in fade-in slide-in-from-top-2 duration-200"><AlertCircle size={12} /> {error}</p>
      : hint ? <p className="mt-1 text-[11px] text-slate-400">{hint}</p> : null}
  </div>
);

const Section: React.FC<{ icon: React.ElementType; title: string; children: React.ReactNode }> = ({ icon: Icon, title, children }) => (
  <section className="space-y-4">
    <h4 className="flex items-center gap-2 text-sm font-bold text-slate-900 dark:text-white"><span className="p-1.5 rounded-lg bg-indigo-50 dark:bg-indigo-500/10 text-indigo-600 dark:text-indigo-300"><Icon size={15} /></span>{title}</h4>
    {children}
  </section>
);

const emptyJob = (taxRate: number): Partial<ExtraJob> => ({
  title: '', description: '', clientName: '', price: 0, currency: Currency.TRY, taxRate, taxAmount: 0, totalAmountWithTax: 0,
  deadline: '', status: 'Bekliyor', paymentStatus: 'Ödenmedi', assignedTo: [], payments: [],
});

const ExtraJobForm: React.FC<Props> = ({ show, job, users, customers = [], onClose, onSave, language, financeSettings }) => {
  const tr = language === 'tr';
  const defaultTax = financeSettings?.defaultTaxRate ?? 20;
  const [j, setJ] = useState<Partial<ExtraJob>>(emptyJob(defaultTax));
  const [touched, setTouched] = useState(false);
  const [saving, setSaving] = useState(false);
  const [confirmClose, setConfirmClose] = useState(false);
  const [payDraft, setPayDraft] = useState<{ amount: string; date: string; note: string } | null>(null);
  const initialJson = useRef('');

  useEffect(() => {
    if (!show) return;
    const start: Partial<ExtraJob> = job
      ? { ...job, payments: job.payments || [], taxRate: job.taxRate ?? 0, totalAmountWithTax: job.totalAmountWithTax || job.price }
      : emptyJob(defaultTax);
    setJ(start);
    initialJson.current = JSON.stringify(start);
    setTouched(false); setSaving(false); setConfirmClose(false); setPayDraft(null);
  }, [show, job]);

  const dirty = show && JSON.stringify(j) !== initialJson.current;
  const set = (patch: Partial<ExtraJob>) => setJ(prev => ({ ...prev, ...patch }));
  const setMoney = (price: number, rate: number) => {
    const tax = round2((price * rate) / 100);
    set({ price, taxRate: rate, taxAmount: tax, totalAmountWithTax: round2(price + tax) });
  };

  const total = jobTotal(j);
  const paid = jobPaid(j);
  const remaining = round2(Math.max(0, total - paid));
  const paymentStatus = derivePaymentStatus(j);
  const legacyPaid = (!j.payments || !j.payments.length) && j.paymentStatus === 'Ödendi';

  const errors = useMemo(() => {
    const e: Record<string, string> = {};
    if (!j.title?.trim()) e.title = tr ? 'İş adı zorunludur.' : 'Title is required.';
    if (!j.clientName?.trim()) e.clientName = tr ? 'Müşteri adı zorunludur.' : 'Client is required.';
    if (!(Number(j.price) > 0)) e.price = tr ? 'Fiyat sıfırdan büyük olmalı.' : 'Price must be greater than zero.';
    if (j.startDate && j.deadline && j.startDate > j.deadline) e.deadline = tr ? 'Teslim tarihi başlangıçtan önce olamaz.' : 'Deadline before start.';
    if (paid > total + 0.01) e.payments = tr ? 'Tahsilat toplamı iş tutarını aşıyor.' : 'Payments exceed the total.';
    return e;
  }, [j, paid, total, tr]);
  const err = (k: string) => (touched ? errors[k] : undefined);

  const submit = async () => {
    setTouched(true);
    if (Object.keys(errors).length) { toast.warning(tr ? `${Object.keys(errors).length} alanı düzeltin` : 'Fix the highlighted fields'); return; }
    setSaving(true);
    const out: ExtraJob = {
      ...(j as ExtraJob),
      id: job?.id || `ej_${Date.now()}`,
      title: j.title!.trim(),
      clientName: j.clientName!.trim(),
      price: Number(j.price),
      taxRate: Number(j.taxRate || 0),
      taxAmount: Number(j.taxAmount || 0),
      totalAmountWithTax: Number(j.totalAmountWithTax || j.price),
      assignedTo: j.assignedTo || [],
      payments: j.payments || [],
      paymentStatus,
      createdAt: job?.createdAt || new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    Object.keys(out).forEach(k => (out as any)[k] === undefined && delete (out as any)[k]);
    try {
      await onSave(out, job);
    } catch (e: any) {
      toast.error((tr ? 'Kaydedilemedi: ' : 'Save failed: ') + (e?.message || ''));
    } finally {
      setSaving(false);
    }
  };

  const requestClose = () => {
    if (dirty && !confirmClose) { setConfirmClose(true); return; }
    onClose();
  };

  useEffect(() => {
    if (!show) return;
    const onKey = (e: KeyboardEvent) => {
      if (e.key === 'Escape') { e.preventDefault(); requestClose(); }
      if ((e.ctrlKey || e.metaKey) && e.key === 'Enter') { e.preventDefault(); submit(); }
    };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  });

  if (!show) return null;

  const addPayment = (amount: number, date: string, note?: string) => {
    if (!(amount > 0)) return;
    const p: ExtraJobPayment = { id: `pay_${Date.now()}`, amount: round2(amount), date, ...(note ? { note } : {}) };
    set({ payments: [...(j.payments || []), p] });
    setPayDraft(null);
  };
  const pickCustomer = (id: string) => {
    const c = customers.find(x => x.id === id);
    if (!c) { set({ customerId: undefined }); return; }
    set({ customerId: c.id, clientName: c.company || c.name });
  };

  return (
    <ModalPortal>
      <div className="fixed inset-0 z-[1100] flex items-center justify-center p-0 sm:p-4" role="dialog" aria-modal="true">
        <div className="absolute inset-0 bg-slate-950/60 backdrop-blur-md pc-backdrop" onClick={requestClose} />
        <div className="relative w-full max-w-5xl h-full sm:h-auto sm:max-h-[92vh] bg-white dark:bg-slate-900 sm:rounded-[28px] shadow-2xl flex flex-col overflow-hidden pc-pop border border-white/10">
          {/* Başlık */}
          <div className="flex items-center gap-3 px-5 sm:px-6 py-4 border-b border-slate-100 dark:border-slate-800" style={{ paddingTop: 'max(env(safe-area-inset-top, 0px), 1rem)' }}>
            <span className={`w-10 h-10 shrink-0 rounded-xl bg-gradient-to-br ${STATUS_META[(j.status || 'Bekliyor') as ExtraJobStatus].col} text-white flex items-center justify-center shadow-md`}><Banknote size={18} /></span>
            <div className="flex-1 min-w-0">
              <h3 className="text-lg font-bold text-slate-900 dark:text-white truncate">{job ? (tr ? 'Ek işi düzenle' : 'Edit extra job') : (tr ? 'Yeni ek iş' : 'New extra job')}{j.title ? <span className="text-slate-400 font-medium"> · {j.title}</span> : null}</h3>
              <p className="text-xs text-slate-400">{tr ? 'Proje dışı, freelance veya kısa süreli işler' : 'Freelance or short jobs outside projects'}</p>
            </div>
            {confirmClose ? (
              <div className="flex items-center gap-2 animate-in fade-in slide-in-from-right-4 duration-200">
                <span className="hidden sm:inline text-xs font-semibold text-rose-600">{tr ? 'Değişiklikler kaybolacak' : 'Changes will be lost'}</span>
                <button onClick={() => setConfirmClose(false)} className="h-9 px-3 rounded-lg text-xs font-semibold text-slate-600 hover:bg-slate-100 dark:hover:bg-white/5">{tr ? 'Vazgeç' : 'Cancel'}</button>
                <button onClick={onClose} className="h-9 px-3 rounded-lg text-xs font-semibold text-white bg-rose-600 hover:bg-rose-500">{tr ? 'Kapat' : 'Discard'}</button>
              </div>
            ) : (
              <button onClick={requestClose} className="p-2 rounded-xl text-slate-400 hover:text-slate-700 hover:bg-slate-100 dark:hover:bg-white/5" aria-label="Close"><X size={20} /></button>
            )}
          </div>

          <div className="flex-1 flex min-h-0">
            {/* Form */}
            <div className="flex-1 min-w-0 overflow-y-auto custom-scrollbar p-5 sm:p-7 space-y-8">
              <Section icon={FileText} title={tr ? 'İş bilgileri' : 'Job details'}>
                <Field label={tr ? 'İşin adı' : 'Title'} required language={language} error={err('title')}>
                  <input autoFocus className={inputCls(err('title')) + ' h-12 text-base font-semibold'} value={j.title || ''} onChange={e => set({ title: e.target.value })} placeholder={tr ? 'Örn: Logo revizyonu' : 'e.g. Logo revision'} />
                </Field>
                <Field label={tr ? 'Kategori' : 'Category'} language={language}>
                  <div className="flex flex-wrap gap-1.5">
                    {EXTRA_JOB_CATEGORIES.map(c => (
                      <button key={c} type="button" onClick={() => set({ category: j.category === c ? undefined : c })}
                        className={`h-8 px-3 rounded-lg text-xs font-semibold border transition-all ${j.category === c ? 'border-indigo-500 bg-indigo-50 text-indigo-700 dark:bg-indigo-500/10 dark:text-indigo-200' : 'border-slate-200 dark:border-slate-700 text-slate-600 dark:text-slate-300 hover:border-slate-300'}`}>{c}</button>
                    ))}
                  </div>
                </Field>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <Field label={tr ? 'Durum' : 'Status'} required language={language}>
                    <div className="grid grid-cols-4 gap-1 p-1 rounded-xl bg-slate-100 dark:bg-slate-800">
                      {(Object.keys(STATUS_META) as ExtraJobStatus[]).map(s => (
                        <button key={s} type="button" onClick={() => set({ status: s })} className={`h-9 rounded-lg text-[11px] font-semibold inline-flex items-center justify-center gap-1 transition-all ${j.status === s ? 'bg-white dark:bg-slate-900 shadow-sm text-slate-900 dark:text-white' : 'text-slate-500 hover:text-slate-700'}`}>
                          <span className={`w-1.5 h-1.5 rounded-full ${STATUS_META[s].dot}`} />{tr ? STATUS_META[s].tr : STATUS_META[s].en}
                        </button>
                      ))}
                    </div>
                  </Field>
                  <Field label={tr ? 'Öncelik' : 'Priority'} language={language}>
                    <div className="grid grid-cols-4 gap-1 p-1 rounded-xl bg-slate-100 dark:bg-slate-800">
                      {(['Low', 'Medium', 'High', 'Critical'] as ProjectPriority[]).map(k => (
                        <button key={k} type="button" onClick={() => set({ priority: j.priority === k ? undefined : k })} className={`h-9 rounded-lg text-[11px] font-semibold inline-flex items-center justify-center gap-1 transition-all ${j.priority === k ? 'bg-white dark:bg-slate-900 shadow-sm text-slate-900 dark:text-white' : 'text-slate-500 hover:text-slate-700'}`}>
                          <span className={`w-1.5 h-1.5 rounded-full ${PRIORITY_META[k].dot}`} />{tr ? PRIORITY_META[k].tr : PRIORITY_META[k].en}
                        </button>
                      ))}
                    </div>
                  </Field>
                </div>
                <Field label={tr ? 'Açıklama' : 'Description'} language={language}>
                  <textarea rows={3} className={inputCls() + ' h-auto py-3 resize-none'} value={j.description || ''} onChange={e => set({ description: e.target.value })} placeholder={tr ? 'İşin kapsamı, teslim edilecekler…' : 'Scope, deliverables…'} />
                </Field>
              </Section>

              <Section icon={Users} title={tr ? 'Müşteri & ekip' : 'Client & team'}>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <Field label={tr ? 'Müşteri / firma' : 'Client'} required language={language} error={err('clientName')}>
                    <input className={inputCls(err('clientName'))} value={j.clientName || ''} onChange={e => set({ clientName: e.target.value, customerId: undefined })} placeholder={tr ? 'Firma veya kişi adı' : 'Company or person'} />
                  </Field>
                  {customers.length > 0 && (
                    <Field label={tr ? 'Kayıtlı müşteriden seç' : 'Pick saved customer'} language={language}>
                      <div className="relative">
                        <BookUser size={16} className="absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-400 pointer-events-none" />
                        <select className={inputCls() + ' pl-10'} value={j.customerId || ''} onChange={e => pickCustomer(e.target.value)}>
                          <option value="">—</option>
                          {customers.map(c => <option key={c.id} value={c.id}>{c.company ? `${c.company} · ${c.name}` : c.name}</option>)}
                        </select>
                      </div>
                    </Field>
                  )}
                </div>
                <Field label={`${tr ? 'Görevli personel' : 'Assignees'} (${(j.assignedTo || []).length})`} language={language}>
                  <div className="flex flex-wrap gap-2">
                    {users.map(u => {
                      const on = (j.assignedTo || []).includes(u.id);
                      return (
                        <button key={u.id} type="button" onClick={() => set({ assignedTo: on ? (j.assignedTo || []).filter(x => x !== u.id) : [...(j.assignedTo || []), u.id] })}
                          className={`inline-flex items-center gap-2 pl-1 pr-3 h-9 rounded-full border text-xs font-semibold transition-all ${on ? 'bg-indigo-600 border-indigo-600 text-white shadow-md shadow-indigo-500/20' : 'border-slate-200 dark:border-slate-700 text-slate-600 dark:text-slate-300 hover:border-indigo-300'}`}>
                          {u.avatar ? <img src={u.avatar} alt="" className="w-7 h-7 rounded-full object-cover" /> : <span className={`w-7 h-7 rounded-full flex items-center justify-center text-[11px] font-bold ${on ? 'bg-white/20' : 'bg-indigo-50 text-indigo-600 dark:bg-indigo-500/10'}`}>{u.name?.[0]}</span>}
                          {u.name}{on && <Check size={13} className="animate-in zoom-in-50 duration-200" />}
                        </button>
                      );
                    })}
                  </div>
                </Field>
              </Section>

              <Section icon={CalendarRange} title={tr ? 'Zamanlama' : 'Schedule'}>
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                  <Field label={tr ? 'Başlangıç' : 'Start'} language={language}>
                    <input type="date" className={inputCls()} value={j.startDate || ''} onChange={e => set({ startDate: e.target.value })} />
                  </Field>
                  <Field label={tr ? 'Teslim tarihi' : 'Deadline'} language={language} error={err('deadline')}>
                    <input type="date" min={j.startDate || undefined} className={inputCls(err('deadline'))} value={j.deadline || ''} onChange={e => set({ deadline: e.target.value })} />
                  </Field>
                  <Field label={tr ? 'Tahmini süre (saat)' : 'Estimated hours'} language={language}
                    hint={j.estimatedHours && j.price ? `${tr ? 'Saatlik' : 'Hourly'} ≈ ${money(Number(j.price) / j.estimatedHours, j.currency)}` : undefined}>
                    <div className="relative"><Timer size={16} className="absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-400 pointer-events-none" />
                      <input type="number" min={0} className={inputCls() + ' pl-10'} value={j.estimatedHours || ''} onChange={e => set({ estimatedHours: Number(e.target.value) || undefined })} placeholder="8" /></div>
                  </Field>
                </div>
              </Section>

              <Section icon={Wallet} title={tr ? 'Ücret & tahsilat' : 'Fee & collection'}>
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                  <Field label={tr ? 'Para birimi' : 'Currency'} required language={language}>
                    <div className="grid grid-cols-3 gap-1 p-1 rounded-xl bg-slate-100 dark:bg-slate-800">
                      {[Currency.TRY, Currency.USD, Currency.EUR].map(c => (
                        <button key={c} type="button" onClick={() => set({ currency: c })} className={`h-9 rounded-lg text-xs font-bold transition-all ${j.currency === c ? 'bg-white dark:bg-slate-900 shadow-sm text-indigo-600' : 'text-slate-500'}`}>{sym(c)} {c}</button>
                      ))}
                    </div>
                  </Field>
                  <Field label={tr ? 'Fiyat (KDV hariç)' : 'Price (excl. VAT)'} required language={language} error={err('price')}>
                    <div className="relative"><span className="absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-400 font-bold">{sym(j.currency)}</span>
                      <input type="number" min={0} step="0.01" className={inputCls(err('price')) + ' pl-9 font-bold'} value={j.price || ''} onChange={e => setMoney(Number(e.target.value), Number(j.taxRate || 0))} /></div>
                  </Field>
                  <Field label={tr ? 'KDV oranı (%)' : 'VAT rate (%)'} required language={language}>
                    <input type="number" min={0} max={100} className={inputCls()} value={j.taxRate ?? ''} onChange={e => setMoney(Number(j.price || 0), Number(e.target.value))} />
                    <div className="flex gap-1 mt-1.5">
                      {[0, 1, 10, 20].map(r => <button key={r} type="button" onClick={() => setMoney(Number(j.price || 0), r)} className={`h-7 px-2.5 rounded-lg text-[11px] font-bold border transition-colors ${Number(j.taxRate) === r ? 'border-indigo-500 text-indigo-600 bg-indigo-50 dark:bg-indigo-500/10' : 'border-slate-200 dark:border-slate-700 text-slate-500'}`}>%{r}</button>)}
                    </div>
                  </Field>
                </div>

                {/* Tahsilatlar */}
                <div className="rounded-2xl border border-slate-200 dark:border-slate-700 overflow-hidden">
                  <div className="flex flex-wrap items-center justify-between gap-2 px-4 py-3 bg-slate-50 dark:bg-white/[0.03] border-b border-slate-200 dark:border-slate-700">
                    <p className="text-sm font-semibold text-slate-800 dark:text-slate-100 flex items-center gap-2">{tr ? 'Tahsilatlar' : 'Payments'}
                      <span className={`text-[11px] font-semibold px-2 py-0.5 rounded-md ${PAYMENT_META[paymentStatus].chip}`}>{tr ? PAYMENT_META[paymentStatus].tr : PAYMENT_META[paymentStatus].en}</span>
                    </p>
                    {!legacyPaid && remaining > 0 && total > 0 && (
                      <div className="flex gap-1.5">
                        <button type="button" onClick={() => setPayDraft({ amount: String(remaining), date: today(), note: '' })} className="h-8 px-2.5 rounded-lg text-xs font-semibold border border-slate-200 dark:border-slate-700 text-slate-600 dark:text-slate-300 hover:text-indigo-600 inline-flex items-center gap-1"><Plus size={13} /> {tr ? 'Ödeme ekle' : 'Add payment'}</button>
                        <button type="button" onClick={() => addPayment(remaining, today(), tr ? 'Tam ödeme' : 'Full payment')} className="h-8 px-2.5 rounded-lg text-xs font-semibold text-white bg-emerald-600 hover:bg-emerald-500 inline-flex items-center gap-1"><CheckCircle2 size={13} /> {tr ? 'Tamamı ödendi' : 'Mark fully paid'}</button>
                      </div>
                    )}
                  </div>

                  {payDraft && (
                    <div className="grid grid-cols-12 gap-2 items-end px-4 py-3 bg-indigo-50/50 dark:bg-indigo-500/5 border-b border-slate-200 dark:border-slate-700 animate-in fade-in slide-in-from-top-2 duration-200">
                      <div className="col-span-4 sm:col-span-3"><label className="text-[11px] text-slate-500">{tr ? 'Tutar' : 'Amount'}</label>
                        <input type="number" autoFocus className="w-full h-9 px-2.5 rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-sm font-semibold" value={payDraft.amount} onChange={e => setPayDraft({ ...payDraft, amount: e.target.value })} /></div>
                      <div className="col-span-4 sm:col-span-3"><label className="text-[11px] text-slate-500">{tr ? 'Tarih' : 'Date'}</label>
                        <input type="date" className="w-full h-9 px-2 rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-xs" value={payDraft.date} onChange={e => setPayDraft({ ...payDraft, date: e.target.value })} /></div>
                      <div className="col-span-4 sm:col-span-4"><label className="text-[11px] text-slate-500">{tr ? 'Not' : 'Note'}</label>
                        <input className="w-full h-9 px-2.5 rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-sm" value={payDraft.note} onChange={e => setPayDraft({ ...payDraft, note: e.target.value })} placeholder={tr ? 'Havale, nakit…' : 'Transfer, cash…'} /></div>
                      <div className="col-span-12 sm:col-span-2 flex gap-1 justify-end">
                        <button type="button" onClick={() => setPayDraft(null)} className="h-9 px-2.5 rounded-lg text-xs font-semibold text-slate-500 hover:bg-slate-100 dark:hover:bg-white/5">{tr ? 'İptal' : 'Cancel'}</button>
                        <button type="button" onClick={() => addPayment(Number(payDraft.amount), payDraft.date || today(), payDraft.note.trim() || undefined)} className="h-9 px-3 rounded-lg text-xs font-semibold text-white bg-indigo-600 hover:bg-indigo-500">{tr ? 'Ekle' : 'Add'}</button>
                      </div>
                    </div>
                  )}

                  <div className="divide-y divide-slate-100 dark:divide-slate-800">
                    {legacyPaid && <p className="px-4 py-3 text-xs text-slate-500">{tr ? 'Bu iş eski sistemde "Ödendi" olarak işaretlenmiş (tahsilat detayı yok).' : 'Marked as paid in the old system (no payment details).'}</p>}
                    {(j.payments || []).map(p => {
                      const isNew = !(job?.payments || []).some(x => x.id === p.id);
                      return (
                        <div key={p.id} className="flex items-center gap-3 px-4 py-2.5 animate-in fade-in duration-200">
                          <span className="p-1.5 rounded-lg bg-emerald-50 dark:bg-emerald-500/10 text-emerald-600"><Banknote size={14} /></span>
                          <div className="flex-1 min-w-0">
                            <p className="text-sm font-semibold text-slate-800 dark:text-slate-100">{money(p.amount, j.currency)}</p>
                            <p className="text-[11px] text-slate-400 truncate">{p.date}{p.note ? ` · ${p.note}` : ''}{isNew ? (tr ? ' · kaydedince finansa aktarılacak' : ' · will post to finance on save') : ''}</p>
                          </div>
                          {isNew
                            ? <button type="button" onClick={() => set({ payments: (j.payments || []).filter(x => x.id !== p.id) })} className="p-1.5 rounded-lg text-slate-400 hover:text-rose-600 hover:bg-rose-50"><Trash2 size={14} /></button>
                            : <span className="text-[10px] font-semibold text-slate-400" title={tr ? 'Finansa aktarıldı; düzeltme için muhasebe kaydını kullanın' : 'Posted to finance'}>{tr ? 'Aktarıldı' : 'Posted'}</span>}
                        </div>
                      );
                    })}
                    {!legacyPaid && !(j.payments || []).length && !payDraft && <p className="px-4 py-4 text-xs text-slate-400 text-center">{tr ? 'Henüz tahsilat yok.' : 'No payments yet.'}</p>}
                  </div>
                  {err('payments') && <p className="px-4 pb-3 text-[11px] font-semibold text-rose-600 flex items-center gap-1"><AlertCircle size={12} /> {err('payments')}</p>}
                </div>
              </Section>

              <Field label={tr ? 'İç notlar' : 'Internal notes'} language={language}>
                <textarea rows={2} className={inputCls() + ' h-auto py-3 resize-none'} value={j.notes || ''} onChange={e => set({ notes: e.target.value })} />
              </Field>
            </div>

            {/* Özet */}
            <aside className="hidden lg:flex w-72 shrink-0 flex-col gap-4 p-5 border-l border-slate-100 dark:border-slate-800 bg-slate-50/60 dark:bg-white/[0.02] overflow-y-auto">
              <p className="text-[10px] font-black uppercase tracking-[0.2em] text-slate-400">{tr ? 'Özet' : 'Summary'}</p>
              <div className="rounded-2xl bg-white dark:bg-slate-900 border border-slate-100 dark:border-slate-800 p-4 space-y-2 text-sm">
                <div className="flex justify-between"><span className="text-slate-400">{tr ? 'Ara toplam' : 'Subtotal'}</span><span className="font-semibold">{money(Number(j.price || 0), j.currency)}</span></div>
                <div className="flex justify-between"><span className="text-slate-400">{tr ? 'KDV' : 'VAT'} %{j.taxRate || 0}</span><span className="font-semibold">{money(Number(j.taxAmount || 0), j.currency)}</span></div>
                <div className="flex justify-between pt-2 border-t border-slate-100 dark:border-slate-800"><span className="font-semibold">{tr ? 'Toplam' : 'Total'}</span><span className="font-black text-indigo-600 text-base">{money(total, j.currency)}</span></div>
              </div>
              <div className="rounded-2xl bg-white dark:bg-slate-900 border border-slate-100 dark:border-slate-800 p-4">
                <div className="flex items-center justify-between text-xs mb-2"><span className="font-semibold text-slate-600 dark:text-slate-300">{tr ? 'Tahsilat' : 'Collected'}</span><span className="font-bold text-emerald-600">%{total ? Math.min(100, Math.round((paid / total) * 100)) : 0}</span></div>
                <div className="h-2 rounded-full bg-slate-100 dark:bg-white/5"><div className="h-full rounded-full bg-gradient-to-r from-emerald-400 to-teal-500 transition-all duration-500" style={{ width: `${total ? Math.min(100, (paid / total) * 100) : 0}%` }} /></div>
                <div className="flex justify-between text-[11px] mt-2 text-slate-500"><span>{tr ? 'Ödenen' : 'Paid'} {money(paid, j.currency)}</span><span>{tr ? 'Kalan' : 'Left'} {money(remaining, j.currency)}</span></div>
              </div>
              <p className="text-[11px] text-slate-400 leading-relaxed">{tr ? 'Eklediğiniz her tahsilat kaydedildiğinde finansa gelir olarak işlenir. Ödeme durumu tahsilatlara göre otomatik belirlenir.' : 'Each new payment posts as income on save. Payment status is derived automatically.'}</p>
              <div className="mt-auto text-[11px] text-slate-400 space-y-1">
                <p><kbd className="px-1 rounded border border-slate-200 dark:border-slate-700">Ctrl</kbd> + <kbd className="px-1 rounded border border-slate-200 dark:border-slate-700">Enter</kbd> {tr ? 'kaydet' : 'save'}</p>
                <p><kbd className="px-1 rounded border border-slate-200 dark:border-slate-700">Esc</kbd> {tr ? 'kapat' : 'close'}</p>
              </div>
            </aside>
          </div>

          {/* Alt çubuk */}
          <div className="flex items-center gap-2 px-5 sm:px-6 py-3 border-t border-slate-100 dark:border-slate-800" style={{ paddingBottom: 'max(env(safe-area-inset-bottom, 0px), 0.75rem)' }}>
            <div className="lg:hidden text-sm"><span className="text-slate-400">{tr ? 'Toplam' : 'Total'} </span><b className="text-indigo-600">{money(total, j.currency)}</b></div>
            <div className="flex-1" />
            <button onClick={requestClose} className="h-10 px-4 rounded-xl text-sm font-semibold text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-white/5">{tr ? 'Vazgeç' : 'Cancel'}</button>
            <button onClick={submit} disabled={saving} className="h-10 px-5 rounded-xl text-sm font-semibold text-white bg-indigo-600 hover:bg-indigo-500 disabled:opacity-60 shadow-lg shadow-indigo-500/25 inline-flex items-center gap-2">
              {saving ? <Loader2 size={16} className="animate-spin" /> : <Save size={16} />}{job ? (tr ? 'Güncelle' : 'Update') : (tr ? 'Ek işi kaydet' : 'Save job')}
            </button>
          </div>
        </div>
      </div>
    </ModalPortal>
  );
};

export default ExtraJobForm;
