
import React from 'react';
import { Subscription, ServiceSale, LicenseSale, Currency, Project, Installment } from '../types';
import { translations } from '../translations';
import {
  Bell,
  X,
  CreditCard,
  CheckCircle,
  Clock,
  AlertCircle,
  TrendingDown,
  TrendingUp,
  Package,
  Layers,
  ArrowDownLeft,
  ShieldCheck
} from 'lucide-react';

import ModalPortal from './ModalPortal';

interface Props {
  dueFinancials: {
    subscriptions: Subscription[];
    services: ServiceSale[];
    licenses: LicenseSale[];
    projectInstallments: { project: Project, installment: Installment, index: number }[];
  };
  onAction: (item: any, type: 'sub' | 'service' | 'license' | 'project_installment', action: 'pay' | 'snooze') => Promise<void>;
  onClose: () => void;
  language: 'tr' | 'en';
  showFinancials: boolean;
}

const DuePaymentsModal: React.FC<Props> = ({ dueFinancials, onAction, onClose, language, showFinancials }) => {
  const t = translations[language];

  const getCurrencySymbol = (c: Currency) => {
    switch (c) {
      case Currency.TRY: return '₺';
      case Currency.EUR: return '€';
      default: return '$';
    }
  };

  const hasItems = dueFinancials.subscriptions.length > 0 ||
    dueFinancials.services.length > 0 ||
    dueFinancials.licenses.length > 0 ||
    dueFinancials.projectInstallments.length > 0;

  if (!hasItems) return null;

  return (
    <ModalPortal>
      <div className="fixed inset-0 bg-slate-950/40 z-[10000] flex items-center justify-center p-6 backdrop-blur-2xl animate-in fade-in duration-300">
        <div className="bg-white rounded-[50px] w-full max-w-2xl overflow-hidden shadow-2xl border border-white/20 animate-in zoom-in duration-300">
          <div className="bg-slate-900 p-8 lg:p-12 text-white relative">
            <div className="absolute top-0 right-0 p-8 opacity-10"><Bell size={120} /></div>
            <div className="flex justify-between items-start relative z-10">
              <div className="flex items-center gap-6">
                <div className="p-5 bg-indigo-600 rounded-[30px] shadow-lg">
                  <AlertCircle size={40} className="text-white" />
                </div>
                <div>
                  <h3 className="text-3xl font-black tracking-tight">{language === 'tr' ? 'Finans Takvimi' : 'Finance Scheduler'}</h3>
                  <p className="text-indigo-400 font-bold uppercase text-[10px] tracking-[0.3em] mt-2">Vadesi Gelen İşlemler</p>
                </div>
              </div>
              <button onClick={onClose} className="p-3 hover:bg-white/10 rounded-full transition-colors"><X size={28} /></button>
            </div>
          </div>

          <div className="p-8 lg:p-10 space-y-6 max-h-[60vh] overflow-y-auto custom-scrollbar bg-slate-50/50">

            {/* GELİRLER BÖLÜMÜ */}
            {(dueFinancials.services.length > 0 || dueFinancials.licenses.length > 0 || dueFinancials.projectInstallments.length > 0) && (
              <div className="space-y-4">
                <h4 className="text-[10px] font-black text-green-600 uppercase tracking-widest ml-4 flex items-center gap-2">
                  <TrendingUp size={14} /> {language === 'tr' ? 'BEKLEYEN TAHSİLATLAR' : 'PENDING COLLECTIONS'}
                </h4>

                {dueFinancials.projectInstallments.map(item => (
                  <div key={`${item.project.id}-${item.index}`} className="bg-white p-6 rounded-[35px] border border-slate-100 shadow-sm flex flex-col md:flex-row items-center justify-between gap-6 group hover:border-green-200 transition-all">
                    <div className="flex items-center gap-5 flex-1 min-w-0">
                      <div className="w-14 h-14 bg-indigo-50 text-indigo-600 rounded-2xl flex items-center justify-center shadow-inner shrink-0">
                        <Layers size={24} />
                      </div>
                      <div className="min-w-0">
                        <h4 className="text-lg font-black text-slate-900 truncate">{item.project.name}</h4>
                        <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest">{item.installment.label}</p>
                      </div>
                    </div>
                    <div className="flex items-center gap-4">
                      <div className="text-right">
                        <p className="text-xl font-black text-green-600">{showFinancials ? <>{getCurrencySymbol(item.project.currency)}{item.installment.amount.toLocaleString()}</> : '**'}</p>
                        <span className="bg-green-50 text-green-600 px-2 py-0.5 rounded text-[8px] font-black uppercase">{language === 'tr' ? 'PROJE GELİRİ' : 'PROJECT INCOME'}</span>
                      </div>
                      <div className="flex flex-col gap-2">
                        <button onClick={() => onAction(item, 'project_installment', 'pay')} className="bg-green-600 text-white px-4 py-2 rounded-xl font-black hover:bg-green-700 text-[9px] uppercase tracking-widest flex items-center gap-2 shadow-lg shadow-green-100">
                          <CheckCircle size={14} /> {language === 'tr' ? 'ALINDI' : 'RECEIVED'}
                        </button>
                        <button onClick={() => onAction(item, 'project_installment', 'snooze')} className="bg-white border border-slate-200 text-slate-400 px-4 py-2 rounded-xl font-black text-[9px] uppercase tracking-widest">
                          <Clock size={14} /> {language === 'tr' ? 'ERTELE' : 'SNOOZE'}
                        </button>
                      </div>
                    </div>
                  </div>
                ))}

                {dueFinancials.services.map(item => (
                  <div key={item.id} className="bg-white p-6 rounded-[35px] border border-slate-100 shadow-sm flex flex-col md:flex-row items-center justify-between gap-6 group hover:border-green-200 transition-all">
                    <div className="flex items-center gap-5 flex-1 min-w-0">
                      <div className="w-14 h-14 bg-green-50 text-green-600 rounded-2xl flex items-center justify-center shadow-inner shrink-0">
                        <Layers size={24} />
                      </div>
                      <div className="min-w-0">
                        <h4 className="text-lg font-black text-slate-900 truncate">{item.serviceName}</h4>
                        <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest">{item.customerName}</p>
                      </div>
                    </div>
                    <div className="flex items-center gap-4">
                      <div className="text-right">
                        <p className="text-xl font-black text-green-600">{showFinancials ? <>{getCurrencySymbol(item.currency)}{item.amount.toLocaleString()}</> : '**'}</p>
                        <span className="bg-green-50 text-green-600 px-2 py-0.5 rounded text-[8px] font-black uppercase">GELİR</span>
                      </div>
                      <div className="flex flex-col gap-2">
                        <button onClick={() => onAction(item, 'service', 'pay')} className="bg-green-600 text-white px-4 py-2 rounded-xl font-black hover:bg-green-700 text-[9px] uppercase tracking-widest flex items-center gap-2 shadow-lg shadow-green-100">
                          <CheckCircle size={14} /> {language === 'tr' ? 'ALINDI' : 'RECEIVED'}
                        </button>
                        <button onClick={() => onAction(item, 'service', 'snooze')} className="bg-white border border-slate-200 text-slate-400 px-4 py-2 rounded-xl font-black text-[9px] uppercase tracking-widest">
                          <Clock size={14} /> {language === 'tr' ? 'ERTELE' : 'SNOOZE'}
                        </button>
                      </div>
                    </div>
                  </div>
                ))}

                {dueFinancials.licenses.map(item => (
                  <div key={item.id} className="bg-white p-6 rounded-[35px] border border-slate-100 shadow-sm flex flex-col md:flex-row items-center justify-between gap-6 group hover:border-green-200 transition-all">
                    <div className="flex items-center gap-5 flex-1 min-w-0">
                      <div className="w-14 h-14 bg-green-50 text-green-600 rounded-2xl flex items-center justify-center shadow-inner shrink-0">
                        <Package size={24} />
                      </div>
                      <div className="min-w-0">
                        <h4 className="text-lg font-black text-slate-900 truncate">{item.productName} Yenileme</h4>
                        <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest">{item.customerName}</p>
                      </div>
                    </div>
                    <div className="flex items-center gap-4">
                      <div className="text-right">
                        <p className="text-xl font-black text-green-600">{showFinancials ? <>{getCurrencySymbol(item.currency)}{item.amount.toLocaleString()}</> : '**'}</p>
                        <span className="bg-green-50 text-green-600 px-2 py-0.5 rounded text-[8px] font-black uppercase">LİSANS GELİRİ</span>
                      </div>
                      <div className="flex flex-col gap-2">
                        <button onClick={() => onAction(item, 'license', 'pay')} className="bg-green-600 text-white px-4 py-2 rounded-xl font-black hover:bg-green-700 text-[9px] uppercase tracking-widest flex items-center gap-2 shadow-lg shadow-green-100">
                          <CheckCircle size={14} /> {language === 'tr' ? 'TAHSİL ET' : 'COLLECT'}
                        </button>
                        <button onClick={() => onAction(item, 'license', 'snooze')} className="bg-white border border-slate-200 text-slate-400 px-4 py-2 rounded-xl font-black text-[9px] uppercase tracking-widest">
                          <Clock size={14} /> {language === 'tr' ? 'ERTELE' : 'SNOOZE'}
                        </button>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            )}

            {/* GİDERLER BÖLÜMÜ */}
            {dueFinancials.subscriptions.length > 0 && (
              <div className="space-y-4 pt-4 border-t border-slate-200">
                <h4 className="text-[10px] font-black text-red-600 uppercase tracking-widest ml-4 flex items-center gap-2">
                  <TrendingDown size={14} /> {language === 'tr' ? 'BEKLEYEN ÖDEMELER' : 'PENDING PAYMENTS'}
                </h4>
                {dueFinancials.subscriptions.map(item => (
                  <div key={item.id} className="bg-white p-6 rounded-[35px] border border-slate-100 shadow-sm flex flex-col md:flex-row items-center justify-between gap-6 group hover:border-red-200 transition-all">
                    <div className="flex items-center gap-5 flex-1 min-w-0">
                      <div className="w-14 h-14 bg-red-50 text-red-600 rounded-2xl flex items-center justify-center shadow-inner shrink-0">
                        <CreditCard size={24} />
                      </div>
                      <div className="min-w-0">
                        <h4 className="text-lg font-black text-slate-900 truncate">{item.name}</h4>
                        <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest">{item.provider}</p>
                      </div>
                    </div>
                    <div className="flex items-center gap-4">
                      <div className="text-right">
                        <p className="text-xl font-black text-red-600">{showFinancials ? <>{getCurrencySymbol(item.currency)}{item.amount.toLocaleString()}</> : '**'}</p>
                        <span className="bg-red-50 text-red-600 px-2 py-0.5 rounded text-[8px] font-black uppercase">GİDER</span>
                      </div>
                      <div className="flex flex-col gap-2">
                        <button onClick={() => onAction(item, 'sub', 'pay')} className="bg-slate-900 text-white px-4 py-2 rounded-xl font-black hover:bg-black text-[9px] uppercase tracking-widest flex items-center gap-2 shadow-lg shadow-slate-200">
                          <ArrowDownLeft size={14} /> {language === 'tr' ? 'ÖDENDİ' : 'PAID'}
                        </button>
                        <button onClick={() => onAction(item, 'sub', 'snooze')} className="bg-white border border-slate-200 text-slate-400 px-4 py-2 rounded-xl font-black text-[9px] uppercase tracking-widest">
                          <Clock size={14} /> {language === 'tr' ? 'ERTELE' : 'SNOOZE'}
                        </button>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>

          <div className="p-8 bg-white border-t border-slate-50 flex items-center justify-between">
            <div className="flex items-center gap-3 text-[10px] font-black text-slate-400 uppercase tracking-widest leading-relaxed">
              <ShieldCheck size={20} className="text-indigo-500" />
              {language === 'tr'
                ? 'Onaylanan işlemler otomatik olarak ön muhasebe (Gelir/Gider) kayıtlarına eklenir.'
                : 'Confirmed actions are auto-added to accounting (Income/Expense) logs.'}
            </div>
            <button onClick={onClose} className="px-8 py-4 bg-indigo-600 text-white rounded-2xl font-black uppercase tracking-widest text-[10px] hover:bg-indigo-700 transition-all shadow-xl shadow-indigo-100">
              {language === 'tr' ? 'KAPAT' : 'CLOSE'}
            </button>
          </div>
        </div>
      </div>
    </ModalPortal>
  );
};

export default DuePaymentsModal;
