import React, { useMemo, useRef, useState } from 'react';
import { Mail, Phone, Plus, Briefcase, Edit2, CalendarCheck, User as UserIcon, Landmark, FileUp, Shield, Lock, BarChart3, Users, AlertTriangle, Wifi, Award, Upload, X, Check, ListChecks, Copy, Palmtree, Loader2 } from 'lucide-react';
import { User, UserRole, Project, Task, TaskStatus, StaffDocument, ChecklistItem, Currency, AttendanceRecord } from '../types';
import PerformanceScorecard from './PerformanceScorecard';
import { ref, uploadBytes, getDownloadURL } from 'firebase/storage';
import { storage } from '../firebase';
import { PageHeader, KpiGrid, SearchBox, Segmented, Field, EmptyState, DeleteButton, Sheet, Avatar, inputCls, selectSm, cardCls, btnPrimary, btnGhost } from './ui/Kit';
import { ProgressRing, GrowBar } from './ui/Motion';
import { localISO } from '../services/insights';
import { toast } from '../services/toast';

interface Props {
  language: 'tr' | 'en';
  staffList: User[];
  projects: Project[];
  tasks: Task[];
  onAddUser: (user: User) => void | Promise<void>;
  onUpdateUser: (user: User) => void | Promise<void>;
  onDeleteUser: (userId: string) => void | Promise<void>;
  onAssignTask: (task: Task) => Promise<void> | void;
  onAddStaffDoc: (doc: StaffDocument) => Promise<void>;
  currentUserRole: UserRole;
  hrSettings?: any;
  currentUser?: User;
  attendance?: AttendanceRecord[];
}

const PERMS = (tr: boolean) => [
  { id: 'dashboard', label: tr ? 'Yönetim Merkezi' : 'Operations' }, { id: 'projects', label: tr ? 'Projeler' : 'Projects' }, { id: 'tasks', label: tr ? 'Görevler' : 'Tasks' },
  { id: 'kanban', label: 'Kanban' }, { id: 'crm', label: 'CRM' }, { id: 'sms', label: tr ? 'Müşteri SMS' : 'SMS' },
  { id: 'accounting', label: tr ? 'Muhasebe' : 'Accounting' }, { id: 'sales', label: tr ? 'Satış' : 'Sales' }, { id: 'invoices', label: tr ? 'Faturalar' : 'Invoices' },
  { id: 'personnel', label: tr ? 'Personel finans' : 'Payroll' }, { id: 'team', label: tr ? 'Ekip' : 'Team' }, { id: 'monitoring', label: tr ? 'Ekip izleme' : 'Monitoring' },
  { id: 'inventory', label: tr ? 'Envanter' : 'Inventory' }, { id: 'purchasing', label: tr ? 'Satın alma' : 'Purchasing' }, { id: 'ai', label: tr ? 'Yapay zekâ' : 'AI' },
];
const ROLE_META: Record<string, { tr: string; en: string; icon: React.ElementType; chip: string }> = {
  Admin: { tr: 'Yönetici (Admin)', en: 'Admin', icon: Shield, chip: 'bg-rose-50 text-rose-700 dark:bg-rose-500/10 dark:text-rose-300' },
  Manager: { tr: 'Müdür', en: 'Manager', icon: Briefcase, chip: 'bg-violet-50 text-violet-700 dark:bg-violet-500/10 dark:text-violet-300' },
  Accountant: { tr: 'Muhasebe', en: 'Accountant', icon: Landmark, chip: 'bg-sky-50 text-sky-700 dark:bg-sky-500/10 dark:text-sky-300' },
  Sales: { tr: 'Satış', en: 'Sales', icon: Award, chip: 'bg-amber-50 text-amber-700 dark:bg-amber-500/10 dark:text-amber-300' },
  Staff: { tr: 'Personel', en: 'Staff', icon: UserIcon, chip: 'bg-slate-100 text-slate-600 dark:bg-white/5 dark:text-slate-300' },
};
type QT = { title: string; notes: string; deadline: string; checklist: string[]; draft: string };
const newQT = (): QT => ({ title: '', notes: '', deadline: localISO(), checklist: [], draft: '' });

/** Seçilen görseli 256px'e küçültüp data URL döner (Firestore belgesini küçük tutar) */
const shrinkImage = (file: File) => new Promise<string>((res, rej) => {
  const img = new Image(); const url = URL.createObjectURL(file);
  img.onload = () => { const s = 256; const c = document.createElement('canvas'); const r = Math.min(1, s / Math.max(img.width, img.height)); c.width = img.width * r; c.height = img.height * r; c.getContext('2d')!.drawImage(img, 0, 0, c.width, c.height); URL.revokeObjectURL(url); res(c.toDataURL('image/jpeg', 0.85)); };
  img.onerror = rej; img.src = url;
});

const TeamView: React.FC<Props> = ({ language, staffList, projects, tasks, onAddUser, onUpdateUser, onDeleteUser, onAssignTask, onAddStaffDoc, currentUserRole, hrSettings, currentUser, attendance = [] }) => {
  const tr = language === 'tr';
  const today = localISO();
  const [roleF, setRoleF] = useState('all');
  const [search, setSearch] = useState('');
  const [sort, setSort] = useState<'name' | 'kpi' | 'load'>('name');
  const [member, setMember] = useState<Partial<User> | null>(null);
  const [touched, setTouched] = useState(false);
  const [saving, setSaving] = useState(false);
  const [assignee, setAssignee] = useState<User | null>(null);
  const [qts, setQts] = useState<QT[]>([newQT()]);
  const [project, setProject] = useState('general_tasks');
  const [docTo, setDocTo] = useState<User | null>(null);
  const [docFile, setDocFile] = useState<File | null>(null);
  const [docProject, setDocProject] = useState('general');
  const [docNote, setDocNote] = useState('');
  const [card, setCard] = useState<User | null>(null);
  const avatarInput = useRef<HTMLInputElement>(null);

  const canManage = (u: User) => !(currentUserRole === UserRole.MANAGER && (u.role === UserRole.ADMIN || u.role === UserRole.MANAGER));
  const allowedRoles = [UserRole.ADMIN, UserRole.MANAGER, UserRole.STAFF, UserRole.ACCOUNTANT, UserRole.SALES].filter(r => currentUserRole === UserRole.ADMIN || (r !== UserRole.ADMIN && r !== UserRole.MANAGER));

  const metrics = useMemo(() => {
    const m = new Map<string, { open: number; done: number; total: number; overdue: number; kpi: number }>();
    staffList.forEach(u => {
      const ut = tasks.filter(t => t.assignedTo?.includes(u.id));
      const done = ut.filter(t => t.status === TaskStatus.DONE).length;
      const overdue = ut.filter(t => t.status !== TaskStatus.DONE && t.deadline && t.deadline < today).length;
      let kpi = 100; ut.forEach(t => { const late = t.deadline && t.deadline < today; if (t.status === TaskStatus.DONE && late) kpi -= 5; else if (t.status !== TaskStatus.DONE && late) kpi -= 10; });
      m.set(u.id, { open: ut.length - done, done, total: ut.length, overdue, kpi: Math.max(0, Math.min(100, kpi)) });
    });
    return m;
  }, [staffList, tasks, today]);
  const M = (id: string) => metrics.get(id) || { open: 0, done: 0, total: 0, overdue: 0, kpi: 100 };

  const q = search.trim().toLocaleLowerCase('tr-TR');
  const list = staffList.filter(u => (roleF === 'all' || u.role === roleF) && (!q || [u.name, u.email, u.jobTitle, u.phone].join(' ').toLocaleLowerCase('tr-TR').includes(q)))
    .sort((a, b) => sort === 'kpi' ? M(a.id).kpi - M(b.id).kpi : sort === 'load' ? M(b.id).open - M(a.id).open : a.name.localeCompare(b.name, 'tr'));
  const roles = Array.from(new Set(staffList.map(u => u.role)));
  const avgKpi = staffList.length ? Math.round(staffList.reduce((a, u) => a + M(u.id).kpi, 0) / staffList.length) : 0;

  // ---------- Üye formu ----------
  const errs: Record<string, string> = {};
  if (member) {
    if (!member.name?.trim()) errs.name = tr ? 'Ad soyad zorunlu.' : 'Required.';
    const em = (member.email || '').trim().toLowerCase();
    if (!/^\S+@\S+\.\S+$/.test(em)) errs.email = tr ? 'Geçerli bir e-posta girin.' : 'Invalid email.';
    else if (staffList.some(u => u.id !== member.id && u.email?.toLowerCase() === em)) errs.email = tr ? 'Bu e-posta başka bir üyede kayıtlı.' : 'Email in use.';
    if (member.tcNo && !/^\d{11}$/.test(member.tcNo)) errs.tc = tr ? 'TC kimlik no 11 hane olmalı.' : '11 digits.';
    if (member.iban && !/^TR\d{24}$/.test(member.iban.replace(/\s/g, ''))) errs.iban = tr ? 'IBAN "TR" + 24 rakam olmalı.' : 'Invalid IBAN.';
  }
  const fe = (k: string) => (touched ? errs[k] : undefined);
  const saveMember = async () => {
    setTouched(true);
    if (!member || Object.keys(errs).length) return;
    setSaving(true);
    try {
      const u: User = { ...(member as User), id: member.id || `temp_${Date.now()}`, name: member.name!.trim(), email: member.email!.toLowerCase().trim(), status: member.status || 'Offline', avatar: member.avatar || '', iban: member.iban ? member.iban.replace(/\s/g, '').toUpperCase() : member.iban };
      if (!u.annualLeaveAllowance && hrSettings) u.annualLeaveAllowance = hrSettings.defaultAnnualLeaveDays || 14;
      const exists = staffList.some(x => x.id === u.id);
      await (exists ? onUpdateUser(u) : onAddUser(u));
      toast.success(exists ? (tr ? `${u.name} güncellendi` : 'Updated') : (tr ? `${u.name} ekibe eklendi · ilk girişte şifresini belirleyecek` : 'Member added'));
      setMember(null);
    } catch (e: any) { toast.error(e?.message || 'Hata'); } finally { setSaving(false); }
  };
  const fmtIban = (v: string) => v.replace(/\s/g, '').toUpperCase().replace(/(.{4})/g, '$1 ').trim();

  // ---------- Görev atama ----------
  const assign = async () => {
    if (!assignee) return;
    const valid = qts.filter(x => x.title.trim());
    if (!valid.length) { toast.warning(tr ? 'En az bir görev başlığı girin' : 'Enter a title'); return; }
    setSaving(true);
    try {
      for (const x of valid) {
        const checklist: ChecklistItem[] = x.checklist.map(text => ({ id: `cl_${Date.now()}_${Math.random().toString(36).slice(2, 9)}`, text, isCompleted: false }));
        await onAssignTask({ id: `t${Date.now()}_${Math.random().toString(36).slice(2, 7)}`, projectId: project || 'general_tasks', title: x.title.trim(), managerNotes: x.notes.trim(), assignedTo: [assignee.id], status: TaskStatus.TODO, deadline: x.deadline || today, progress: 0, checklist } as Task);
      }
      toast.success(tr ? `${assignee.name} için ${valid.length} görev atandı` : 'Assigned');
      setAssignee(null);
    } finally { setSaving(false); }
  };
  const setQ = (i: number, patch: Partial<QT>) => setQts(qts.map((x, j) => j === i ? { ...x, ...patch } : x));

  // ---------- Dosya ----------
  const sendDoc = async () => {
    if (!docTo || !docFile) { toast.warning(tr ? 'Dosya seçin' : 'Select a file'); return; }
    setSaving(true);
    try {
      const r = ref(storage, `staff_documents/${docTo.id}/${Date.now()}_${docFile.name}`);
      await uploadBytes(r, docFile);
      await onAddStaffDoc({ id: `sdoc_${Date.now()}`, userId: docTo.id, projectId: docProject, projectName: projects.find(p => p.id === docProject)?.name || (tr ? 'Genel doküman' : 'General'), fileName: docFile.name, fileType: docFile.name.split('.').pop()?.toLowerCase() || 'file', uploadDate: today, note: docNote.trim(), fileUrl: await getDownloadURL(r), sharedById: currentUser?.id, sharedByName: currentUser?.name, fileSize: docFile.size });
      toast.success(tr ? `${docFile.name} → ${docTo.name}` : 'Sent');
      setDocTo(null);
    } catch (e: any) { toast.error((tr ? 'Yükleme hatası: ' : 'Upload error: ') + (e?.message || '')); } finally { setSaving(false); }
  };

  const roleChip = (r: string) => { const R = ROLE_META[r] || ROLE_META.Staff; return <span className={`text-[10px] font-semibold px-1.5 py-0.5 rounded-md ${R.chip}`}>{tr ? R.tr : R.en}</span>; };

  return (
    <div className="space-y-5 pb-10">
      <PageHeader title={tr ? 'Ekip' : 'Team'} subtitle={tr ? 'Üyeler, roller, yetkiler ve iş yükü.' : 'Members, roles, permissions and workload.'}
        actions={<button onClick={() => { setTouched(false); setMember({ role: UserRole.STAFF, status: 'Offline', permissions: [], salaryCurrency: Currency.TRY }); }} className={btnPrimary}><Plus size={16} />{tr ? 'Yeni üye' : 'New member'}</button>} />

      <KpiGrid items={[
        { label: tr ? 'Ekip üyesi' : 'Members', value: staffList.length, icon: Users, grad: 'from-indigo-500 to-violet-600', sub: roles.map(r => `${staffList.filter(u => u.role === r).length} ${(tr ? ROLE_META[r]?.tr : ROLE_META[r]?.en) || r}`).slice(0, 2).join(' · ') },
        { label: tr ? 'Çevrim içi' : 'Online', value: staffList.filter(u => u.status === 'Online').length, icon: Wifi, grad: 'from-emerald-500 to-teal-600', bar: staffList.length ? (staffList.filter(u => u.status === 'Online').length / staffList.length) * 100 : 0 },
        { label: tr ? 'Geciken görevi olan' : 'With overdue', value: staffList.filter(u => M(u.id).overdue > 0).length, icon: AlertTriangle, grad: 'from-rose-500 to-red-600', sub: `${tasks.filter(t => t.status !== TaskStatus.DONE && t.deadline && t.deadline < today).length} ${tr ? 'geciken görev' : 'overdue tasks'}`, onClick: () => setSort('kpi'), active: sort === 'kpi' },
        { label: tr ? 'Ortalama KPI' : 'Avg KPI', value: avgKpi, format: n => `${n}/100`, icon: Award, grad: 'from-amber-500 to-orange-600', bar: avgKpi },
      ]} />

      <div className={`${cardCls} p-3 flex flex-col lg:flex-row gap-2`}>
        <Segmented<string> value={roleF} onChange={setRoleF} options={[{ value: 'all', label: tr ? 'Tümü' : 'All' }, ...roles.map(r => ({ value: r, label: (tr ? ROLE_META[r]?.tr : ROLE_META[r]?.en) || r }))]} />
        <SearchBox value={search} onChange={setSearch} placeholder={tr ? 'Ad, e-posta, pozisyon ara…' : 'Search…'} />
        <select value={sort} onChange={e => setSort(e.target.value as any)} className={selectSm}><option value="name">{tr ? 'Ada göre' : 'By name'}</option><option value="kpi">{tr ? 'KPI (düşükten)' : 'KPI (low first)'}</option><option value="load">{tr ? 'İş yüküne göre' : 'By workload'}</option></select>
      </div>

      {list.length === 0 ? <div className={cardCls}><EmptyState icon={Users} text={tr ? 'Üye bulunamadı' : 'No members'} /></div> : (
        <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-3 pc-stagger">
          {list.map(u => {
            const m = M(u.id); const pct = m.total ? (m.done / m.total) * 100 : 0;
            const leaveLeft = (u.annualLeaveAllowance ?? hrSettings?.defaultAnnualLeaveDays ?? 14) - (u.usedLeaveDays || 0);
            const kpiColor = m.kpi >= 80 ? '#10b981' : m.kpi >= 50 ? '#f59e0b' : '#ef4444';
            return (
              <div key={u.id} className={`${cardCls} p-4 flex flex-col gap-3 pc-lift group`}>
                <div className="flex items-start gap-3">
                  <div className="relative"><Avatar name={u.name} src={u.avatar} size="w-12 h-12" /><span className={`absolute -bottom-0.5 -right-0.5 w-3.5 h-3.5 rounded-full border-2 border-white dark:border-slate-900 ${u.status === 'Online' ? 'bg-emerald-500' : u.status === 'Busy' ? 'bg-amber-500' : 'bg-slate-300'}`} /></div>
                  <div className="min-w-0 flex-1">
                    <div className="flex items-center gap-1.5"><p className="text-sm font-bold text-slate-900 dark:text-white truncate">{u.name}</p>{roleChip(u.role)}</div>
                    <p className="text-[11px] text-slate-400 truncate">{u.jobTitle || (tr ? 'Pozisyon girilmedi' : 'No title')}</p>
                    <div className="flex items-center gap-2 mt-1 text-[11px]">
                      <a href={`mailto:${u.email}`} className="text-slate-500 hover:text-indigo-600 inline-flex items-center gap-1 truncate"><Mail size={11} />{u.email}</a>
                      {u.phone && <a href={`tel:${u.phone}`} className="text-slate-500 hover:text-indigo-600 inline-flex items-center gap-1 shrink-0"><Phone size={11} /></a>}
                    </div>
                  </div>
                  <ProgressRing value={m.kpi} size={46} stroke={5} color={kpiColor}><span className="text-[11px] font-black">{m.kpi}</span></ProgressRing>
                </div>
                <div className="grid grid-cols-3 gap-2 text-center">
                  <div className="rounded-xl bg-slate-50 dark:bg-white/[0.03] py-2"><p className="text-base font-black text-slate-900 dark:text-white">{m.open}</p><p className="text-[10px] text-slate-400">{tr ? 'açık görev' : 'open'}</p></div>
                  <div className={`rounded-xl py-2 ${m.overdue ? 'bg-rose-50 dark:bg-rose-500/10' : 'bg-slate-50 dark:bg-white/[0.03]'}`}><p className={`text-base font-black ${m.overdue ? 'text-rose-600' : 'text-slate-900 dark:text-white'}`}>{m.overdue}</p><p className="text-[10px] text-slate-400">{tr ? 'geciken' : 'overdue'}</p></div>
                  <div className="rounded-xl bg-slate-50 dark:bg-white/[0.03] py-2"><p className="text-base font-black text-slate-900 dark:text-white">{leaveLeft}</p><p className="text-[10px] text-slate-400 inline-flex items-center gap-0.5"><Palmtree size={9} />{tr ? 'izin günü' : 'leave'}</p></div>
                </div>
                <div><div className="flex justify-between text-[10px] mb-1"><span className="text-slate-400">{tr ? 'Görev tamamlama' : 'Completion'} {m.done}/{m.total}</span><span className="font-semibold text-slate-500">%{Math.round(pct)}</span></div><GrowBar value={pct} className={m.overdue ? 'bg-rose-500' : 'bg-indigo-500'} /></div>
                <div className="mt-auto pt-2 border-t border-slate-100 dark:border-slate-800 flex items-center gap-1">
                  <button onClick={() => { setAssignee(u); setQts([newQT()]); setProject(projects.find(p => p.status === 'Active')?.id || 'general_tasks'); }} className="flex-1 h-8 rounded-lg text-xs font-semibold text-indigo-700 bg-indigo-50 hover:bg-indigo-100 dark:bg-indigo-500/10 dark:text-indigo-300 inline-flex items-center justify-center gap-1.5"><CalendarCheck size={13} />{tr ? 'Görev ata' : 'Assign'}</button>
                  <button onClick={() => { setDocTo(u); setDocFile(null); setDocNote(''); setDocProject('general'); }} title={tr ? 'Dosya gönder' : 'Send file'} className="p-2 rounded-lg text-slate-400 hover:text-indigo-600 hover:bg-indigo-50 dark:hover:bg-white/5"><FileUp size={15} /></button>
                  <button onClick={() => setCard(u)} title={tr ? 'Performans karnesi' : 'Scorecard'} className="p-2 rounded-lg text-slate-400 hover:text-indigo-600 hover:bg-indigo-50 dark:hover:bg-white/5"><BarChart3 size={15} /></button>
                  {canManage(u) && <>
                    <button onClick={() => { setTouched(false); setMember({ ...u, permissions: [...(u.permissions || [])] }); }} title={tr ? 'Düzenle' : 'Edit'} className="p-2 rounded-lg text-slate-400 hover:text-indigo-600 hover:bg-indigo-50 dark:hover:bg-white/5"><Edit2 size={14} /></button>
                    {u.id !== currentUser?.id && <DeleteButton language={language} onConfirm={async () => { await onDeleteUser(u.id); toast(tr ? `${u.name} ekipten çıkarıldı` : 'Removed', 'info'); }} />}
                  </>}
                </div>
              </div>
            );
          })}
        </div>
      )}

      {/* Üye formu */}
      <Sheet open={!!member} language={language} width="max-w-2xl" title={member?.id ? (tr ? 'Üyeyi düzenle' : 'Edit member') : (tr ? 'Yeni ekip üyesi' : 'New member')} subtitle={member?.id ? member.email : (tr ? 'Şifreyi kişi ilk girişte kendisi belirler' : 'Password set on first login')} icon={UserIcon} onClose={() => setMember(null)} onSubmit={saveMember} saving={saving}>
        {member && <>
          <div className="flex items-center gap-4">
            <div className="relative">
              <Avatar name={member.name || '?'} src={member.avatar} size="w-20 h-20" />
              <button type="button" onClick={() => avatarInput.current?.click()} className="absolute -bottom-1 -right-1 p-1.5 rounded-lg bg-indigo-600 text-white shadow-md"><Upload size={13} /></button>
              <input ref={avatarInput} type="file" accept="image/*" className="hidden" onChange={async e => { const f = e.target.files?.[0]; if (f) { try { setMember({ ...member, avatar: await shrinkImage(f) }); } catch { toast.error(tr ? 'Görsel okunamadı' : 'Bad image'); } } e.target.value = ''; }} />
            </div>
            <div className="flex-1 grid grid-cols-1 gap-3">
              <Field label={tr ? 'Ad soyad' : 'Full name'} required error={fe('name')}><input autoFocus className={inputCls(fe('name'))} value={member.name || ''} onChange={e => setMember({ ...member, name: e.target.value })} /></Field>
            </div>
          </div>
          <Field label={tr ? 'Rol' : 'Role'}>
            <div className="flex flex-wrap gap-1.5">{allowedRoles.map(r => { const R = ROLE_META[r]; const I = R.icon; return <button key={r} type="button" onClick={() => setMember({ ...member, role: r })} className={`h-9 px-3 rounded-xl text-xs font-semibold inline-flex items-center gap-1.5 border transition-all ${member.role === r ? 'bg-indigo-600 border-indigo-600 text-white shadow-md' : 'border-slate-200 dark:border-slate-700 text-slate-600 dark:text-slate-300 hover:border-indigo-300'}`}><I size={13} />{tr ? R.tr : R.en}</button>; })}</div>
          </Field>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <Field label={tr ? 'E-posta (giriş)' : 'Email (login)'} required error={fe('email')}><input type="email" className={inputCls(fe('email'))} value={member.email || ''} onChange={e => setMember({ ...member, email: e.target.value })} /></Field>
            <Field label={tr ? 'Pozisyon' : 'Job title'}><input className={inputCls()} value={member.jobTitle || ''} onChange={e => setMember({ ...member, jobTitle: e.target.value })} /></Field>
            <Field label={tr ? 'Telefon' : 'Phone'}><input type="tel" className={inputCls()} value={member.phone || ''} onChange={e => setMember({ ...member, phone: e.target.value })} /></Field>
            <Field label={tr ? 'TC kimlik no' : 'National ID'} error={fe('tc')}><input inputMode="numeric" maxLength={11} className={inputCls(fe('tc'))} value={member.tcNo || ''} onChange={e => setMember({ ...member, tcNo: e.target.value.replace(/\D/g, '') })} /></Field>
          </div>
          <div className="rounded-2xl border border-slate-100 dark:border-slate-800 p-4 space-y-4">
            <p className="text-xs font-semibold text-slate-500 flex items-center gap-1.5"><Landmark size={13} />{tr ? 'Bordro ve izin' : 'Payroll & leave'}</p>
            <div className="grid grid-cols-3 gap-4">
              <Field label={tr ? 'Aylık maaş' : 'Salary'} className="col-span-2"><input type="number" min={0} className={inputCls()} value={member.monthlySalary || ''} onChange={e => setMember({ ...member, monthlySalary: Number(e.target.value) })} /></Field>
              <Field label={tr ? 'Birim' : 'Currency'}><select className={inputCls()} value={member.salaryCurrency || Currency.TRY} onChange={e => setMember({ ...member, salaryCurrency: e.target.value as Currency })}>{Object.values(Currency).map(c => <option key={c}>{c}</option>)}</select></Field>
              <Field label={tr ? 'Banka' : 'Bank'}><input className={inputCls()} value={member.bankName || ''} onChange={e => setMember({ ...member, bankName: e.target.value })} /></Field>
              <Field label="IBAN" error={fe('iban')} className="col-span-2"><input className={inputCls(fe('iban')) + ' font-mono'} value={member.iban ? fmtIban(member.iban) : ''} onChange={e => setMember({ ...member, iban: e.target.value.replace(/\s/g, '').toUpperCase() })} placeholder="TR00 0000 0000 0000 0000 0000 00" /></Field>
              <Field label={tr ? 'Yıllık izin hakkı (gün)' : 'Annual leave'}><input type="number" min={0} className={inputCls()} value={member.annualLeaveAllowance ?? ''} placeholder={String(hrSettings?.defaultAnnualLeaveDays ?? 14)} onChange={e => setMember({ ...member, annualLeaveAllowance: e.target.value === '' ? undefined : Number(e.target.value) })} /></Field>
            </div>
          </div>
          {member.role !== UserRole.ADMIN && (
            <div className="rounded-2xl border border-slate-100 dark:border-slate-800 p-4 space-y-3">
              <div className="flex items-center gap-2"><p className="text-xs font-semibold text-slate-500 flex items-center gap-1.5 flex-1"><Lock size={13} />{tr ? 'Modül yetkileri' : 'Permissions'}</p>
                <button type="button" onClick={() => setMember({ ...member, permissions: (member.permissions || []).length === PERMS(tr).length ? [] : PERMS(tr).map(p => p.id) })} className="text-[11px] font-semibold text-indigo-600 hover:underline">{(member.permissions || []).length === PERMS(tr).length ? (tr ? 'Hiçbiri' : 'None') : (tr ? 'Tümü' : 'All')}</button></div>
              <div className="flex flex-wrap gap-1.5">
                {PERMS(tr).map(p => { const on = (member.permissions || []).includes(p.id); return (
                  <button key={p.id} type="button" onClick={() => setMember({ ...member, permissions: on ? member.permissions!.filter(x => x !== p.id) : [...(member.permissions || []), p.id] })} className={`h-8 px-2.5 rounded-lg text-xs font-semibold inline-flex items-center gap-1 border transition-all ${on ? 'bg-indigo-50 border-indigo-300 text-indigo-700 dark:bg-indigo-500/10 dark:border-indigo-500/40 dark:text-indigo-300' : 'border-slate-200 dark:border-slate-700 text-slate-500'}`}>{on && <Check size={12} />}{p.label}</button>); })}
              </div>
              <p className="text-[11px] text-slate-400">{tr ? 'Müdür rolü çoğu modüle zaten erişir; burada ek yetki verilir.' : 'Managers already access most modules.'}</p>
            </div>
          )}
        </>}
      </Sheet>

      {/* Görev atama */}
      <Sheet open={!!assignee} language={language} width="max-w-2xl" title={tr ? 'Görev ata' : 'Assign tasks'} subtitle={assignee?.name} icon={CalendarCheck} tone="from-emerald-500 to-teal-600" onClose={() => setAssignee(null)} onSubmit={assign} saving={saving} submitLabel={tr ? `${qts.filter(x => x.title.trim()).length || ''} görevi ata` : 'Assign'}>
        {assignee && <>
          <Field label={tr ? 'Proje' : 'Project'}><select className={inputCls()} value={project} onChange={e => setProject(e.target.value)}><option value="general_tasks">{tr ? 'Genel görevler' : 'General'}</option>{projects.filter(p => p.status !== 'Completed').map(p => <option key={p.id} value={p.id}>{p.name}</option>)}</select></Field>
          {qts.map((x, i) => (
            <div key={i} className="rounded-2xl border border-slate-100 dark:border-slate-800 p-3 space-y-2 animate-in fade-in slide-in-from-top-1 duration-200">
              <div className="flex gap-2">
                <input autoFocus={i === qts.length - 1} placeholder={tr ? 'Görev başlığı' : 'Task title'} className={inputCls() + ' flex-1 font-semibold'} value={x.title} onChange={e => setQ(i, { title: e.target.value })} />
                <input type="date" className={inputCls() + ' !w-40'} value={x.deadline} onChange={e => setQ(i, { deadline: e.target.value })} />
                {qts.length > 1 && <button onClick={() => setQts(qts.filter((_, j) => j !== i))} className="p-2 text-slate-400 hover:text-rose-500"><X size={16} /></button>}
              </div>
              <input placeholder={tr ? 'Yönetici notu (opsiyonel)' : 'Manager note'} className={inputCls() + ' !h-10 text-xs'} value={x.notes} onChange={e => setQ(i, { notes: e.target.value })} />
              <div className="flex flex-wrap gap-1.5 items-center">
                {x.checklist.map((c, k) => <span key={k} className="h-7 pl-2 pr-1 rounded-lg bg-slate-100 dark:bg-white/5 text-xs inline-flex items-center gap-1"><ListChecks size={11} className="text-slate-400" />{c}<button onClick={() => setQ(i, { checklist: x.checklist.filter((_, j) => j !== k) })} className="p-0.5 text-slate-400 hover:text-rose-500"><X size={11} /></button></span>)}
                <input placeholder={tr ? '+ kontrol maddesi (Enter)' : '+ checklist (Enter)'} className="h-7 px-2 rounded-lg bg-transparent border border-dashed border-slate-300 dark:border-slate-700 text-xs outline-none focus:border-indigo-400 pc-plain-input" value={x.draft} onChange={e => setQ(i, { draft: e.target.value })} onKeyDown={e => { if (e.key === 'Enter' && x.draft.trim()) { e.preventDefault(); setQ(i, { checklist: [...x.checklist, x.draft.trim()], draft: '' }); } }} />
              </div>
            </div>
          ))}
          <button onClick={() => setQts([...qts, newQT()])} className={btnGhost + ' w-full'}><Plus size={15} />{tr ? 'Bir görev daha' : 'Add another'}</button>
        </>}
      </Sheet>

      {/* Dosya gönder */}
      <Sheet open={!!docTo} language={language} title={tr ? 'Dosya gönder' : 'Send file'} subtitle={docTo?.name} icon={FileUp} onClose={() => setDocTo(null)} onSubmit={sendDoc} saving={saving} submitLabel={tr ? 'Gönder' : 'Send'}>
        <label className={`cursor-pointer rounded-2xl border-2 border-dashed p-6 flex flex-col items-center gap-2 text-center transition-colors ${docFile ? 'border-indigo-300 bg-indigo-50/50 dark:bg-indigo-500/10' : 'border-slate-200 dark:border-slate-700 hover:border-indigo-300'}`}>
          {saving ? <Loader2 size={24} className="animate-spin text-indigo-500" /> : <Upload size={24} className={docFile ? 'text-indigo-500' : 'text-slate-300'} />}
          <span className="text-sm font-semibold text-slate-600 dark:text-slate-300">{docFile ? docFile.name : (tr ? 'Dosya seçin' : 'Choose a file')}</span>
          <input type="file" className="hidden" onChange={e => setDocFile(e.target.files?.[0] || null)} />
        </label>
        <Field label={tr ? 'Proje' : 'Project'}><select className={inputCls()} value={docProject} onChange={e => setDocProject(e.target.value)}><option value="general">{tr ? 'Genel doküman' : 'General'}</option>{projects.map(p => <option key={p.id} value={p.id}>{p.name}</option>)}</select></Field>
        <Field label={tr ? 'Not' : 'Note'}><input className={inputCls()} value={docNote} onChange={e => setDocNote(e.target.value)} /></Field>
      </Sheet>

      {/* Performans karnesi */}
      <Sheet open={!!card} language={language} width="max-w-5xl" hideFooter title={tr ? 'Performans karnesi' : 'Scorecard'} subtitle={card?.name} icon={BarChart3} onClose={() => setCard(null)}>
        {card && <PerformanceScorecard user={card} tasks={tasks} attendance={attendance} language={language} />}
      </Sheet>
    </div>
  );
};

export default TeamView;
