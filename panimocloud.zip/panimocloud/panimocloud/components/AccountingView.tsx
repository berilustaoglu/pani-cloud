import React, { useEffect, useMemo, useState } from 'react';
import {
  Transaction, Project, Currency, Subscription, Debt, SalaryPayment, User, DebtPayment,
  DEFAULT_INCOME_CATEGORIES, DEFAULT_EXPENSE_CATEGORIES
} from '../types';
import {
  Plus, TrendingUp, TrendingDown, Search, Edit2, X, Check, Trash2, RefreshCw, CreditCard, FileSpreadsheet, Download,
  CircleDollarSign, Users, History, ArrowUpRight, ArrowDownRight, Paperclip, Eye, CloudUpload, Zap, Settings, Wallet,
  Receipt, Scale, LayoutDashboard, AlertCircle, AlertTriangle, ChevronLeft, ChevronRight, ArrowUpDown, Loader2, Save,
  Landmark, CalendarClock, FileText as FileIcon, Copy
} from 'lucide-react';
import { ref, uploadBytes, getDownloadURL } from 'firebase/storage';
import { storage } from '../firebase';
import * as AIService from '../services/aiService';
import { ComposedChart, Bar, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, PieChart, Pie, Cell } from 'recharts';
import * as XLSX from 'xlsx';
import JSZip from 'jszip';
import { saveAs } from 'file-saver';
import SubscriptionsView from './SubscriptionsView';
import ModalPortal from './ModalPortal';
import { AnimatedNumber, GrowBar } from './ui/Motion';
import { dayDiff, localISO } from '../services/insights';
import { toast } from '../services/toast';

interface Props {
  transactions: Transaction[];
  onUpsertTransaction: (transaction: Transaction) => Promise<void>;
  onDeleteTransaction: (id: string) => Promise<void>;
  projects: Project[];
  subscriptions: Subscription[];
  onUpsertSubscription: (sub: Subscription) => Promise<void>;
  onDeleteSubscription: (id: string) => Promise<void>;
  language: 'tr' | 'en';
  rates: { TRY: number; EUR: number };
  onRefreshRates: () => Promise<void>;
  loadingRates: boolean;
  debts: Debt[];
  onUpsertDebt: (debt: Debt) => Promise<void>;
  onDeleteDebt: (id: string) => Promise<void>;
  salaryPayments: SalaryPayment[];
  onUpsertSalaryPayment: (payment: SalaryPayment) => Promise<void>;
  onDeleteSalaryPayment: (id: string) => Promise<void>;
  staffList: User[];
  onAddMainTransaction: (tx: Transaction) => Promise<void>;
  showFinancials: boolean;
  financeSettings?: any;
  onUpdateFinanceSettings?: (settings: any) => Promise<void>;
  onOpenSettings?: () => void;
}

type Tab = 'overview' | 'transactions' | 'debts' | 'salaries' | 'subscriptions';
type Period = 'month' | 'lastMonth' | 'quarter' | 'year' | 'all' | 'custom';
type Sheet = null | 'tx' | 'debt' | 'salary' | 'payDebt';

const SYM: Record<string, string> = { TRY: '₺', USD: '$', EUR: '€' };
const sym = (c?: Currency | string) => SYM[c || 'USD'] || '$';
const round2 = (n: number) => Math.round(n * 100) / 100;
const fmt = (n: number, c?: Currency | string, digits = 0) => `${sym(c)}${(Number(n) || 0).toLocaleString('tr-TR', { maximumFractionDigits: digits, minimumFractionDigits: digits })}`;
const COLORS = ['#6366f1', '#f97316', '#10b981', '#ef4444', '#0ea5e9', '#a855f7', '#eab308', '#64748b'];

const inputBase = 'w-full h-11 px-3.5 rounded-xl bg-white dark:bg-slate-800 border text-sm font-medium text-slate-900 dark:text-white outline-none transition-all placeholder:text-slate-400 focus:ring-4';
const inputCls = (err?: string) => `${inputBase} ${err ? 'border-rose-300 focus:border-rose-400 focus:ring-rose-500/10' : 'border-slate-200 dark:border-slate-700 focus:border-indigo-500 focus:ring-indigo-500/10'}`;

const Field: React.FC<{ label: string; required?: boolean; error?: string; hint?: string; children: React.ReactNode; className?: string }> = ({ label, required, error, hint, children, className = '' }) => (
  <div className={className}>
    <label className="flex items-center gap-1 text-xs font-semibold text-slate-600 dark:text-slate-300 mb-1.5">{label}{required && <span className="text-rose-500">*</span>}</label>
    {children}
    {error ? <p className="mt-1 text-[11px] font-semibold text-rose-600 flex items-center gap-1 animate-in fade-in slide-in-from-top-2 duration-200"><AlertCircle size={12} /> {error}</p>
      : hint ? <p className="mt-1 text-[11px] text-slate-400">{hint}</p> : null}
  </div>
);

/** Muhasebe formları için ortak panel. */
const SheetShell: React.FC<{ title: string; subtitle?: string; icon: React.ElementType; tone: string; onClose: () => void; onSubmit: () => void; submitLabel: string; saving?: boolean; children: React.ReactNode; footerLeft?: React.ReactNode; width?: string }> =
  ({ title, subtitle, icon: Icon, tone, onClose, onSubmit, submitLabel, saving, children, footerLeft, width = 'max-w-xl' }) => {
    useEffect(() => {
      const onKey = (e: KeyboardEvent) => {
        if (e.key === 'Escape') { e.preventDefault(); onClose(); }
        if ((e.ctrlKey || e.metaKey) && e.key === 'Enter') { e.preventDefault(); onSubmit(); }
      };
      window.addEventListener('keydown', onKey);
      return () => window.removeEventListener('keydown', onKey);
    });
    return (
      <ModalPortal>
        <div className="fixed inset-0 z-[1100] flex items-center justify-center p-0 sm:p-4" role="dialog" aria-modal="true">
          <div className="absolute inset-0 bg-slate-950/60 backdrop-blur-md pc-backdrop" onClick={onClose} />
          <div className={`relative w-full ${width} h-full sm:h-auto sm:max-h-[92vh] bg-white dark:bg-slate-900 sm:rounded-[28px] shadow-2xl flex flex-col overflow-hidden pc-pop border border-white/10`}>
            <div className="flex items-center gap-3 px-5 sm:px-6 py-4 border-b border-slate-100 dark:border-slate-800" style={{ paddingTop: 'max(env(safe-area-inset-top, 0px), 1rem)' }}>
              <span className={`w-10 h-10 shrink-0 rounded-xl bg-gradient-to-br ${tone} text-white flex items-center justify-center shadow-md`}><Icon size={18} /></span>
              <div className="flex-1 min-w-0">
                <h3 className="text-lg font-bold text-slate-900 dark:text-white truncate">{title}</h3>
                {subtitle && <p className="text-xs text-slate-400 truncate">{subtitle}</p>}
              </div>
              <button onClick={onClose} className="p-2 rounded-xl text-slate-400 hover:text-slate-700 hover:bg-slate-100 dark:hover:bg-white/5" aria-label="Close"><X size={20} /></button>
            </div>
            <div className="flex-1 overflow-y-auto custom-scrollbar p-5 sm:p-6 space-y-5">{children}</div>
            <div className="flex items-center gap-2 px-5 sm:px-6 py-3 border-t border-slate-100 dark:border-slate-800" style={{ paddingBottom: 'max(env(safe-area-inset-bottom, 0px), 0.75rem)' }}>
              <div className="flex-1 min-w-0 text-sm">{footerLeft}</div>
              <button onClick={onClose} className="h-10 px-4 rounded-xl text-sm font-semibold text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-white/5">Vazgeç</button>
              <button onClick={onSubmit} disabled={saving} className="h-10 px-5 rounded-xl text-sm font-semibold text-white bg-indigo-600 hover:bg-indigo-500 disabled:opacity-60 shadow-lg shadow-indigo-500/25 inline-flex items-center gap-2">
                {saving ? <Loader2 size={16} className="animate-spin" /> : <Save size={16} />}{submitLabel}
              </button>
            </div>
          </div>
        </div>
      </ModalPortal>
    );
  };

const AccountingView: React.FC<Props> = ({
  transactions, onUpsertTransaction, onDeleteTransaction, projects, subscriptions, onUpsertSubscription, onDeleteSubscription,
  language, rates, onRefreshRates, loadingRates, debts, onUpsertDebt, onDeleteDebt, salaryPayments, onUpsertSalaryPayment,
  onDeleteSalaryPayment, staffList, onAddMainTransaction, showFinancials, financeSettings, onOpenSettings
}) => {
  const tr = language === 'tr';
  const defaultTax = financeSettings?.defaultTaxRate ?? 20;
  const defaultCur: Currency = financeSettings?.defaultCurrency || Currency.TRY;
  const incomeCats: string[] = financeSettings?.incomeCategories?.length ? financeSettings.incomeCategories : DEFAULT_INCOME_CATEGORIES;
  const expenseCats: string[] = financeSettings?.expenseCategories?.length ? financeSettings.expenseCategories : DEFAULT_EXPENSE_CATEGORIES;

  const [tab, setTab] = useState<Tab>(() => { try { return (localStorage.getItem('pc-acc-tab') as Tab) || 'overview'; } catch { return 'overview'; } });
  const [period, setPeriod] = useState<Period>('month');
  const [custom, setCustom] = useState<{ from: string; to: string }>({ from: localISO().slice(0, 8) + '01', to: localISO() });
  const [repCur, setRepCur] = useState<Currency>(financeSettings?.reportingCurrency || Currency.TRY);
  useEffect(() => { if (financeSettings?.reportingCurrency) setRepCur(financeSettings.reportingCurrency); }, [financeSettings?.reportingCurrency]);
  useEffect(() => { try { localStorage.setItem('pc-acc-tab', tab); } catch {} }, [tab]);

  // filtreler
  const [search, setSearch] = useState('');
  const [typeF, setTypeF] = useState<'All' | 'Income' | 'Expense'>('All');
  const [catF, setCatF] = useState('all');
  const [projF, setProjF] = useState('all');
  const [docOnly, setDocOnly] = useState(false);
  const [sortBy, setSortBy] = useState<{ key: 'date' | 'amount'; dir: 1 | -1 }>({ key: 'date', dir: -1 });
  const [page, setPage] = useState(1);
  const PAGE = 15;
  const [debtF, setDebtF] = useState<'open' | 'Borrowed' | 'Lent' | 'closed'>('open');
  const [salaryMonth, setSalaryMonth] = useState(localISO().slice(0, 7));
  const [confirmDel, setConfirmDel] = useState<string | null>(null);

  // formlar
  const [sheet, setSheet] = useState<Sheet>(null);
  const [touched, setTouched] = useState(false);
  const [saving, setSaving] = useState(false);
  const [editingTx, setEditingTx] = useState<Transaction | null>(null);
  const [editingDebt, setEditingDebt] = useState<Debt | null>(null);
  const [newTx, setNewTx] = useState<Partial<Transaction>>({});
  const [newDebt, setNewDebt] = useState<Partial<Debt>>({});
  const [newSalary, setNewSalary] = useState<Partial<SalaryPayment>>({});
  const [payDebt, setPayDebt] = useState<{ debt: Debt; amount: number; note: string } | null>(null);
  const [localDate, setLocalDate] = useState(localISO());
  const [uploading, setUploading] = useState(false);
  const [analyzing, setAnalyzing] = useState(false);
  const [pendingFile, setPendingFile] = useState<File | null>(null);
  const [zipping, setZipping] = useState(false);

  // ---------- Para birimi ----------
  const rateOf = (c?: Currency | string) => (c === Currency.TRY ? rates.TRY || 1 : c === Currency.EUR ? rates.EUR || 1 : 1);
  const conv = (amount: number, c?: Currency | string) => (Number(amount) || 0) / rateOf(c || Currency.USD) * rateOf(repCur);
  const money = (n: number) => (showFinancials ? fmt(n, repCur) : '••••');

  // ---------- Dönem ----------
  const range = useMemo(() => {
    const now = new Date();
    const iso = (d: Date) => localISO(d);
    const y = now.getFullYear(), m = now.getMonth();
    switch (period) {
      case 'month': return { from: iso(new Date(y, m, 1)), to: iso(new Date(y, m + 1, 0)) };
      case 'lastMonth': return { from: iso(new Date(y, m - 1, 1)), to: iso(new Date(y, m, 0)) };
      case 'quarter': { const q = Math.floor(m / 3) * 3; return { from: iso(new Date(y, q, 1)), to: iso(new Date(y, q + 3, 0)) }; }
      case 'year': return { from: `${y}-01-01`, to: `${y}-12-31` };
      case 'custom': return custom;
      default: return { from: '0000-01-01', to: '9999-12-31' };
    }
  }, [period, custom]);
  const prevRange = useMemo(() => {
    if (period === 'all') return null;
    const f = new Date(range.from), t = new Date(range.to);
    const span = t.getTime() - f.getTime() + 86400000;
    return { from: localISO(new Date(f.getTime() - span)), to: localISO(new Date(f.getTime() - 86400000)) };
  }, [range, period]);
  const inRange = (d: string, r: { from: string; to: string }) => !!d && d >= r.from && d <= r.to;

  // ---------- Hesaplamalar ----------
  const periodTx = useMemo(() => transactions.filter(t => inRange(t.date, range)), [transactions, range]);
  const sums = (list: Transaction[]) => {
    let income = 0, expense = 0, vatOut = 0, vatIn = 0;
    list.forEach(t => {
      const v = conv(t.amount, t.currency);
      const vat = conv(t.taxAmount || 0, t.currency);
      if (t.type === 'Income') { income += v; vatOut += vat; } else { expense += v; vatIn += vat; }
    });
    return { income, expense, net: income - expense, vatOut, vatIn, vatDue: vatOut - vatIn };
  };
  const cur = useMemo(() => sums(periodTx), [periodTx, repCur, rates]);
  const prev = useMemo(() => (prevRange ? sums(transactions.filter(t => inRange(t.date, prevRange))) : null), [transactions, prevRange, repCur, rates]);
  const delta = (a: number, b?: number) => (b && b !== 0 ? Math.round(((a - b) / Math.abs(b)) * 100) : null);

  const debtStats = useMemo(() => {
    const open = debts.filter(d => !d.isPaid);
    const borrowed = open.filter(d => d.type === 'Borrowed');
    const lent = open.filter(d => d.type === 'Lent');
    const overdue = (l: Debt[]) => l.filter(d => (dayDiff(d.dueDate) ?? 1) < 0).length;
    return {
      borrowed: borrowed.reduce((s, d) => s + conv(d.remainingAmount, d.currency), 0),
      lent: lent.reduce((s, d) => s + conv(d.remainingAmount, d.currency), 0),
      borrowedOverdue: overdue(borrowed), lentOverdue: overdue(lent),
    };
  }, [debts, repCur, rates]);

  const monthly = useMemo(() => {
    const out = [];
    const now = new Date();
    for (let i = 11; i >= 0; i--) {
      const d = new Date(now.getFullYear(), now.getMonth() - i, 1);
      const ym = `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}`;
      const s = sums(transactions.filter(t => t.date?.startsWith(ym)));
      out.push({ ym, name: d.toLocaleString(tr ? 'tr-TR' : 'en-US', { month: 'short' }), income: Math.round(s.income), expense: Math.round(s.expense), net: Math.round(s.net) });
    }
    return out;
  }, [transactions, repCur, rates, tr]);

  const catBreakdown = (type: 'Income' | 'Expense') => {
    const m: Record<string, number> = {};
    periodTx.filter(t => t.type === type).forEach(t => { const c = t.category || (tr ? 'Diğer' : 'Other'); m[c] = (m[c] || 0) + conv(t.amount, t.currency); });
    return Object.entries(m).map(([name, value]) => ({ name, value: Math.round(value) })).sort((a, b) => b.value - a.value);
  };
  const expenseCatsData = useMemo(() => catBreakdown('Expense'), [periodTx, repCur, rates]);
  const incomeCatsData = useMemo(() => catBreakdown('Income'), [periodTx, repCur, rates]);

  const upcoming = useMemo(() => {
    const items: { id: string; date: string; label: string; amount: number; kind: 'debt' | 'lent' | 'sub' | 'salary'; overdue: boolean }[] = [];
    debts.filter(d => !d.isPaid && d.dueDate && (dayDiff(d.dueDate) ?? 99) <= 30).forEach(d => items.push({ id: d.id, date: d.dueDate!, label: d.personName, amount: conv(d.remainingAmount, d.currency), kind: d.type === 'Borrowed' ? 'debt' : 'lent', overdue: (dayDiff(d.dueDate) ?? 0) < 0 }));
    subscriptions.filter(s => s.status === 'Active' && (dayDiff(s.nextBillingDate) ?? 99) <= 30).forEach(s => items.push({ id: s.id, date: s.nextBillingDate, label: s.name, amount: conv(s.amount, s.currency), kind: 'sub', overdue: (dayDiff(s.nextBillingDate) ?? 0) < 0 }));
    const thisMonth = localISO().slice(0, 7);
    staffList.filter(u => u.monthlySalary && !salaryPayments.some(p => p.userId === u.id && p.month === thisMonth)).forEach(u => items.push({ id: `sal-${u.id}`, date: `${thisMonth}-28`, label: `${tr ? 'Maaş' : 'Salary'}: ${u.name}`, amount: conv(u.monthlySalary || 0, u.salaryCurrency), kind: 'salary', overdue: false }));
    return items.sort((a, b) => a.date.localeCompare(b.date));
  }, [debts, subscriptions, staffList, salaryPayments, repCur, rates, tr]);

  // ---------- İşlem listesi ----------
  const allCats = useMemo(() => [...new Set(transactions.map(t => t.category).filter(Boolean))].sort((a, b) => a.localeCompare(b, 'tr')), [transactions]);
  const filteredTx = useMemo(() => {
    const q = search.trim().toLocaleLowerCase('tr-TR');
    return periodTx.filter(t =>
      (typeF === 'All' || t.type === typeF) &&
      (catF === 'all' || t.category === catF) &&
      (projF === 'all' || t.projectId === projF) &&
      (!docOnly || !!t.documentUrl) &&
      (!q || [t.description, t.category, projects.find(p => p.id === t.projectId)?.name].join(' ').toLocaleLowerCase('tr-TR').includes(q))
    ).sort((a, b) => sortBy.key === 'date' ? sortBy.dir * a.date.localeCompare(b.date) : sortBy.dir * (conv(a.amount, a.currency) - conv(b.amount, b.currency)));
  }, [periodTx, search, typeF, catF, projF, docOnly, sortBy, projects, repCur, rates]);
  useEffect(() => setPage(1), [search, typeF, catF, projF, docOnly, period, custom]);
  const pages = Math.max(1, Math.ceil(filteredTx.length / PAGE));
  const filteredSums = useMemo(() => sums(filteredTx), [filteredTx, repCur, rates]);

  // ---------- Dosya & AI ----------
  const handleFileUpload = async (file: File, folder: 'transactions' | 'debts') => {
    setUploading(true); setPendingFile(file);
    try {
      const storageRef = ref(storage, `${folder}/${Date.now()}_${file.name}`);
      await uploadBytes(storageRef, file);
      const url = await getDownloadURL(storageRef);
      return { url, name: file.name };
    } catch (error: any) {
      toast.error((tr ? 'Yükleme başarısız: ' : 'Upload failed: ') + (error.message || ''));
      return null;
    } finally { setUploading(false); }
  };
  const handleAIAnalyze = async () => {
    if (!pendingFile) return;
    setAnalyzing(true);
    try {
      const base64 = await new Promise<string>(resolve => { const r = new FileReader(); r.onload = () => resolve((r.result as string).split(',')[1]); r.readAsDataURL(pendingFile); });
      const result = await AIService.analyzeFinancialDocument(`Belge Analizi: ${pendingFile.name}`, language, { data: base64, mimeType: pendingFile.type });
      if (result) {
        if (sheet === 'tx') {
          setNewTx(prev => recalcTx({ ...prev, amount: result.amount, currency: result.currency, category: result.category, description: result.description, type: result.type }));
        } else if (sheet === 'debt') {
          setNewDebt(prev => ({ ...prev, amount: result.amount, remainingAmount: result.amount, currency: result.currency, description: result.description, type: result.type === 'Expense' ? 'Borrowed' : 'Lent' }));
        }
        if (result.date) setLocalDate(result.date);
        toast.success(tr ? 'Belge yapay zekayla okundu, alanları kontrol edin' : 'Document read by AI — please review');
      }
    } catch (error: any) {
      toast.error((tr ? 'Analiz başarısız: ' : 'Analysis failed: ') + error.message);
    } finally { setAnalyzing(false); }
  };

  // ---------- Form açma / kaydetme ----------
  const recalcTx = (t: Partial<Transaction>): Partial<Transaction> => {
    const amt = Number(t.amount || 0), rate = Number(t.taxRate || 0);
    const tax = round2((amt * rate) / 100);
    return { ...t, taxAmount: tax, totalAmountWithTax: round2(amt + tax) };
  };
  const openTx = (t?: Transaction, preset?: Partial<Transaction>) => {
    setEditingTx(t || null); setTouched(false); setPendingFile(null);
    setNewTx(t ? { ...t, taxRate: t.taxRate ?? 0 } : recalcTx({ type: 'Expense', currency: defaultCur, amount: 0, category: '', description: '', taxRate: defaultTax, ...preset }));
    setLocalDate(t?.date || localISO()); setSheet('tx');
  };
  const openDebt = (d?: Debt) => {
    setEditingDebt(d || null); setTouched(false); setPendingFile(null);
    setNewDebt(d ? { ...d } : { type: 'Borrowed', currency: defaultCur, amount: 0, personName: '', description: '', isPaid: false, remainingAmount: 0 });
    setLocalDate(d?.date || localISO()); setSheet('debt');
  };
  const openSalary = (u: User) => {
    setTouched(false);
    setNewSalary({ userId: u.id, amount: u.monthlySalary || 0, currency: u.salaryCurrency || defaultCur, month: salaryMonth, description: '' });
    setLocalDate(localISO()); setSheet('salary');
  };
  const closeSheet = () => { setSheet(null); setPayDebt(null); };

  const txErrors = useMemo(() => {
    const e: Record<string, string> = {};
    if (!(Number(newTx.amount) > 0)) e.amount = tr ? 'Tutar sıfırdan büyük olmalı.' : 'Amount must be > 0.';
    if (!newTx.category) e.category = tr ? 'Kategori seçin.' : 'Pick a category.';
    if (!localDate) e.date = tr ? 'Tarih zorunlu.' : 'Date required.';
    return e;
  }, [newTx, localDate, tr]);
  const debtErrors = useMemo(() => {
    const e: Record<string, string> = {};
    if (!newDebt.personName?.trim()) e.person = tr ? 'Kişi / kurum adı zorunlu.' : 'Name required.';
    if (!(Number(newDebt.amount) > 0)) e.amount = tr ? 'Tutar sıfırdan büyük olmalı.' : 'Amount must be > 0.';
    if (newDebt.dueDate && newDebt.dueDate < localDate) e.due = tr ? 'Vade, kayıt tarihinden önce olamaz.' : 'Due date before record date.';
    return e;
  }, [newDebt, localDate, tr]);

  const withSave = async (fn: () => Promise<void>) => { setSaving(true); try { await fn(); } catch (e: any) { toast.error((tr ? 'Kaydedilemedi: ' : 'Save failed: ') + (e?.message || '')); } finally { setSaving(false); } };

  const saveTransaction = () => {
    setTouched(true);
    if (Object.keys(txErrors).length) return;
    withSave(async () => {
      const t = recalcTx(newTx);
      const tx: Transaction = { ...(t as Transaction), id: editingTx ? editingTx.id : `tr${Date.now()}`, date: localDate, amount: Number(t.amount), taxRate: Number(t.taxRate || 0) };
      Object.keys(tx).forEach(k => (tx as any)[k] === undefined && delete (tx as any)[k]);
      await onUpsertTransaction(tx);
      toast.success(editingTx ? (tr ? 'Kayıt güncellendi' : 'Updated') : (tr ? 'Kayıt eklendi' : 'Added'));
      closeSheet();
    });
  };
  const saveDebt = () => {
    setTouched(true);
    if (Object.keys(debtErrors).length) return;
    withSave(async () => {
      const isNew = !editingDebt;
      const amount = Number(newDebt.amount);
      const paidSoFar = (editingDebt?.payments || []).reduce((s, p) => s + p.amount, 0);
      const remaining = newDebt.isPaid ? 0 : Math.max(0, isNew ? amount : amount - paidSoFar);
      const d: Debt = { ...(newDebt as Debt), id: editingDebt ? editingDebt.id : `debt${Date.now()}`, date: localDate, amount, remainingAmount: remaining, isPaid: !!newDebt.isPaid || remaining <= 0, payments: editingDebt?.payments || [] };
      Object.keys(d).forEach(k => (d as any)[k] === undefined && delete (d as any)[k]);
      await onUpsertDebt(d);
      toast.success(tr ? 'Borç/alacak kaydedildi' : 'Saved');
      closeSheet();
    });
  };
  const saveSalary = () => {
    setTouched(true);
    if (!(Number(newSalary.amount) > 0) || !newSalary.month) return;
    withSave(async () => {
      const staff = staffList.find(s => s.id === newSalary.userId);
      const p: SalaryPayment = { ...(newSalary as SalaryPayment), id: `sal${Date.now()}`, date: localDate, amount: Number(newSalary.amount), userName: staff?.name || '—', description: newSalary.description || '' };
      await onUpsertSalaryPayment(p);
      await onUpsertTransaction({ id: `tr_sal_${p.id}`, type: 'Expense', amount: p.amount, currency: p.currency, category: 'Personel Maaşları', date: p.date, description: `Maaş Ödemesi: ${p.userName} (${p.month})`, taxRate: 0, taxAmount: 0, totalAmountWithTax: p.amount });
      toast.success(tr ? `${p.userName} maaşı ödendi ve gidere işlendi` : 'Salary paid and recorded');
      closeSheet();
    });
  };
  const recordDebtPayment = () => {
    if (!payDebt || payDebt.amount <= 0) return;
    withSave(async () => {
      const debt = payDebt.debt;
      const amount = Math.min(payDebt.amount, debt.remainingAmount);
      const pay: DebtPayment = { id: `dp_${Date.now()}`, amount, date: localISO(), note: payDebt.note };
      const remaining = round2(debt.remainingAmount - amount);
      await onUpsertDebt({ ...debt, remainingAmount: remaining, isPaid: remaining <= 0, payments: [...(debt.payments || []), pay] });
      await onAddMainTransaction({
        id: `tr_pay_${pay.id}`, type: debt.type === 'Borrowed' ? 'Expense' : 'Income', amount, currency: debt.currency,
        category: debt.type === 'Borrowed' ? 'Borç Ödemesi' : 'Alacak Tahsilatı', date: pay.date,
        description: `${debt.type === 'Borrowed' ? 'Borç Ödemesi' : 'Alacak Tahsilatı'}: ${debt.personName}${payDebt.note ? ` (${payDebt.note})` : ''}`, taxRate: 0, taxAmount: 0, totalAmountWithTax: amount,
      });
      toast.success(remaining <= 0 ? (tr ? 'Borç kapandı 🎉' : 'Debt closed') : (tr ? 'Ödeme kaydedildi' : 'Payment recorded'));
      closeSheet();
    });
  };

  // ---------- Dışa aktarma ----------
  const exportFilteredExcel = () => {
    const rows = filteredTx.map(t => ({
      Tarih: t.date, Tip: t.type === 'Income' ? 'Gelir' : 'Gider', Kategori: t.category, Aciklama: t.description,
      Proje: projects.find(p => p.id === t.projectId)?.name || '', Tutar: t.amount, KDV_Orani: t.taxRate || 0, KDV: t.taxAmount || 0,
      Toplam: t.totalAmountWithTax || t.amount, Para_Birimi: t.currency, [`Tutar_${repCur}`]: round2(conv(t.amount, t.currency)), Belge: t.documentUrl || '',
    }));
    const ws = XLSX.utils.json_to_sheet(rows.length ? rows : [{ Mesaj: tr ? 'Kayıt yok' : 'No records' }]);
    ws['!cols'] = [{ wch: 12 }, { wch: 8 }, { wch: 24 }, { wch: 40 }, { wch: 22 }, { wch: 12 }, { wch: 9 }, { wch: 10 }, { wch: 12 }, { wch: 8 }, { wch: 12 }, { wch: 30 }];
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, tr ? 'Islemler' : 'Transactions');
    XLSX.writeFile(wb, `Muhasebe_${range.from}_${range.to}.xlsx`.replace('0000-01-01', 'tum').replace('9999-12-31', 'kayitlar'));
    toast.success(tr ? `${rows.length} kayıt Excel'e aktarıldı` : `${rows.length} rows exported`);
  };
  const exportMonthExcel = (ym: string, label: string) => {
    const tx = transactions.filter(t => t.date.startsWith(ym));
    const db = debts.filter(d => d.date.startsWith(ym));
    const sal = salaryPayments.filter(s => s.month === ym || s.date.startsWith(ym));
    const wb = XLSX.utils.book_new();
    const add = (name: string, data: object[]) => XLSX.utils.book_append_sheet(wb, XLSX.utils.json_to_sheet(data.length ? data : [{ Mesaj: 'Kayıt yok' }]), name);
    add('Islemler', tx.map(t => ({ Tarih: t.date, Tip: t.type === 'Income' ? 'Gelir' : 'Gider', Kategori: t.category, Aciklama: t.description, Tutar: t.amount, KDV: t.taxAmount || 0, Toplam: t.totalAmountWithTax || t.amount, Para_Birimi: t.currency, Belge: t.documentUrl || '' })));
    add('Borclar', db.map(d => ({ Tarih: d.date, Vade: d.dueDate || '', Tip: d.type === 'Borrowed' ? 'Alınan' : 'Verilen', Kisi: d.personName, Tutar: d.amount, Kalan: d.remainingAmount, Durum: d.isPaid ? 'Kapandı' : 'Açık', Para_Birimi: d.currency })));
    add('Maaslar', sal.map(s => ({ Tarih: s.date, Ay: s.month, Personel: s.userName, Tutar: s.amount, Para_Birimi: s.currency })));
    XLSX.writeFile(wb, `Muhasebe_Raporu_${label}_${ym}.xlsx`);
  };
  const downloadDocsZip = async (ym: string, label: string) => {
    const docs = [
      ...transactions.filter(t => t.date.startsWith(ym) && t.documentUrl).map(t => ({ name: t.documentName || `belge_${t.id}.pdf`, url: t.documentUrl! })),
      ...debts.filter(d => d.date.startsWith(ym) && d.documentUrl).map(d => ({ name: d.documentName || `borc_${d.id}.pdf`, url: d.documentUrl! })),
    ];
    if (!docs.length) { toast.info(tr ? 'Bu aya ait belge yok' : 'No documents this month'); return; }
    setZipping(true);
    try {
      const zip = new JSZip();
      await Promise.all(docs.map(async (d, i) => { try { const r = await fetch(d.url); if (r.ok) zip.file(`${i + 1}_${d.name}`, await r.blob()); } catch {} }));
      saveAs(await zip.generateAsync({ type: 'blob' }), `Belgeler_${label}_${ym}.zip`);
    } catch { toast.error(tr ? 'Zip oluşturulamadı' : 'Zip failed'); } finally { setZipping(false); }
  };

  // ---------- Ortak parçalar ----------
  const delButtons = (id: string, onYes: () => void) => confirmDel === id ? (
    <span className="inline-flex items-center gap-1 animate-in fade-in zoom-in-95 duration-150" onClick={e => e.stopPropagation()}>
      <button onClick={() => setConfirmDel(null)} className="h-7 px-2 rounded-lg text-[11px] font-semibold text-slate-500 hover:bg-slate-100 dark:hover:bg-white/5">{tr ? 'Vazgeç' : 'Cancel'}</button>
      <button onClick={async () => { await onYes(); setConfirmDel(null); toast(tr ? 'Silindi' : 'Deleted', 'info', 2000); }} className="h-7 px-2 rounded-lg text-[11px] font-semibold text-white bg-rose-600 hover:bg-rose-500">{tr ? 'Sil' : 'Delete'}</button>
    </span>
  ) : (
    <button onClick={e => { e.stopPropagation(); setConfirmDel(id); }} title={tr ? 'Sil' : 'Delete'} className="p-1.5 rounded-lg text-slate-400 hover:text-rose-600 hover:bg-rose-50 dark:hover:bg-white/5"><Trash2 size={14} /></button>
  );

  const periodLabel: Record<Period, string> = { month: tr ? 'Bu ay' : 'This month', lastMonth: tr ? 'Geçen ay' : 'Last month', quarter: tr ? 'Bu çeyrek' : 'Quarter', year: tr ? 'Bu yıl' : 'Year', all: tr ? 'Tümü' : 'All', custom: tr ? 'Özel' : 'Custom' };
  const DeltaBadge: React.FC<{ v: number | null; inverse?: boolean }> = ({ v, inverse }) => v === null ? null : (
    <span className={`inline-flex items-center gap-0.5 text-[10px] font-bold px-1.5 py-0.5 rounded-md ${(v >= 0) !== !!inverse ? 'bg-emerald-50 text-emerald-700 dark:bg-emerald-500/10 dark:text-emerald-300' : 'bg-rose-50 text-rose-700 dark:bg-rose-500/10 dark:text-rose-300'}`}>
      {v >= 0 ? <ArrowUpRight size={10} /> : <ArrowDownRight size={10} />}%{Math.abs(v)}
    </span>
  );

  const kpis = [
    { label: tr ? 'Gelir' : 'Income', value: cur.income, icon: TrendingUp, grad: 'from-emerald-500 to-teal-600', d: delta(cur.income, prev?.income), sub: `${periodTx.filter(t => t.type === 'Income').length} ${tr ? 'kayıt' : 'records'}` },
    { label: tr ? 'Gider' : 'Expense', value: cur.expense, icon: TrendingDown, grad: 'from-rose-500 to-orange-500', d: delta(cur.expense, prev?.expense), inverse: true, sub: `${periodTx.filter(t => t.type === 'Expense').length} ${tr ? 'kayıt' : 'records'}` },
    { label: tr ? 'Net kâr' : 'Net profit', value: cur.net, icon: Scale, grad: cur.net >= 0 ? 'from-indigo-500 to-violet-600' : 'from-rose-600 to-red-600', d: delta(cur.net, prev?.net), sub: cur.income ? `${tr ? 'Marj' : 'Margin'} %${Math.round((cur.net / cur.income) * 100)}` : '—' },
    { label: cur.vatDue >= 0 ? (tr ? 'Ödenecek KDV' : 'VAT payable') : (tr ? 'Devreden KDV' : 'VAT carryover'), value: Math.abs(cur.vatDue), icon: Receipt, grad: 'from-amber-500 to-orange-600', sub: `${tr ? 'Hesaplanan' : 'Out'} ${money(cur.vatOut)} · ${tr ? 'İndirilecek' : 'In'} ${money(cur.vatIn)}` },
    { label: tr ? 'Alacaklar' : 'Receivables', value: debtStats.lent, icon: ArrowUpRight, grad: 'from-sky-500 to-blue-600', sub: debtStats.lentOverdue ? `${debtStats.lentOverdue} ${tr ? 'vadesi geçmiş' : 'overdue'}` : (tr ? 'Vadesi geçen yok' : 'None overdue'), onClick: () => { setTab('debts'); setDebtF('Lent'); } },
    { label: tr ? 'Borçlar' : 'Payables', value: debtStats.borrowed, icon: ArrowDownRight, grad: 'from-slate-600 to-slate-800', sub: debtStats.borrowedOverdue ? `${debtStats.borrowedOverdue} ${tr ? 'vadesi geçmiş' : 'overdue'}` : (tr ? 'Vadesi geçen yok' : 'None overdue'), onClick: () => { setTab('debts'); setDebtF('Borrowed'); } },
  ];

  const tabs: { key: Tab; label: string; icon: React.ElementType; badge?: number }[] = [
    { key: 'overview', label: tr ? 'Genel Bakış' : 'Overview', icon: LayoutDashboard },
    { key: 'transactions', label: tr ? 'Gelir & Gider' : 'Transactions', icon: History, badge: periodTx.length },
    { key: 'debts', label: tr ? 'Borç & Alacak' : 'Debts', icon: CircleDollarSign, badge: debts.filter(d => !d.isPaid).length },
    { key: 'salaries', label: tr ? 'Maaşlar' : 'Salaries', icon: Users },
    { key: 'subscriptions', label: tr ? 'Abonelikler' : 'Subscriptions', icon: CreditCard },
  ];
  const newLabel = tab === 'debts' ? (tr ? 'Yeni borç / alacak' : 'New debt') : (tr ? 'Yeni kayıt' : 'New entry');

  // ---------- Sekmeler ----------
  const overview = () => {
    const expTotal = expenseCatsData.reduce((s, c) => s + c.value, 0);
    const months6 = monthly.slice(-6).reverse();
    return (
      <div className="space-y-5">
        <div className="grid grid-cols-1 xl:grid-cols-3 gap-5">
          <div className="xl:col-span-2 bg-white dark:bg-slate-900 border border-slate-100 dark:border-slate-800 rounded-[24px] p-5">
            <div className="flex items-center justify-between mb-4">
              <h3 className="font-bold text-slate-900 dark:text-white">{tr ? 'Nakit akışı (12 ay)' : 'Cash flow (12 months)'}</h3>
              <div className="flex items-center gap-3 text-[11px] text-slate-500">
                <span className="inline-flex items-center gap-1"><span className="w-2.5 h-2.5 rounded-sm bg-emerald-500" />{tr ? 'Gelir' : 'Income'}</span>
                <span className="inline-flex items-center gap-1"><span className="w-2.5 h-2.5 rounded-sm bg-rose-400" />{tr ? 'Gider' : 'Expense'}</span>
                <span className="inline-flex items-center gap-1"><span className="w-3 h-0.5 bg-indigo-500" />Net</span>
              </div>
            </div>
            <div className="h-72">
              {showFinancials ? (
                <ResponsiveContainer width="100%" height="100%">
                  <ComposedChart data={monthly} margin={{ top: 5, right: 5, left: 0, bottom: 0 }}>
                    <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="var(--chart-grid)" />
                    <XAxis dataKey="name" fontSize={11} axisLine={false} tickLine={false} tick={{ fill: 'var(--chart-text)' }} />
                    <YAxis fontSize={11} axisLine={false} tickLine={false} tick={{ fill: 'var(--chart-text)' }} tickFormatter={v => `${sym(repCur)}${Math.abs(v) >= 1000 ? Math.round(v / 1000) + 'K' : v}`} width={56} />
                    <Tooltip formatter={(v: any) => fmt(Number(v), repCur)} contentStyle={{ borderRadius: 14, border: 'none', backgroundColor: 'var(--tooltip-bg)', boxShadow: '0 20px 40px -12px rgba(0,0,0,.2)' }} />
                    <Bar dataKey="income" name={tr ? 'Gelir' : 'Income'} fill="#10b981" radius={[6, 6, 0, 0]} maxBarSize={22} animationDuration={900} />
                    <Bar dataKey="expense" name={tr ? 'Gider' : 'Expense'} fill="#fb7185" radius={[6, 6, 0, 0]} maxBarSize={22} animationDuration={900} />
                    <Line type="monotone" dataKey="net" name="Net" stroke="#6366f1" strokeWidth={3} dot={{ r: 3 }} animationDuration={1200} />
                  </ComposedChart>
                </ResponsiveContainer>
              ) : <div className="h-full flex items-center justify-center text-sm text-slate-400">{tr ? 'Finansal veriler gizli' : 'Hidden'}</div>}
            </div>
          </div>

          <div className="bg-white dark:bg-slate-900 border border-slate-100 dark:border-slate-800 rounded-[24px] p-5 flex flex-col">
            <h3 className="font-bold text-slate-900 dark:text-white">{tr ? 'Gider dağılımı' : 'Expense breakdown'}</h3>
            <p className="text-xs text-slate-400 mb-2">{periodLabel[period]}</p>
            {expenseCatsData.length === 0 ? <div className="flex-1 flex items-center justify-center text-sm text-slate-400 py-10">{tr ? 'Bu dönemde gider yok' : 'No expenses'}</div> : (
              <>
                <div className="h-44 relative">
                  <ResponsiveContainer width="100%" height="100%">
                    <PieChart><Pie data={expenseCatsData} dataKey="value" innerRadius={52} outerRadius={78} paddingAngle={3} stroke="none" animationDuration={900}>
                      {expenseCatsData.map((_, i) => <Cell key={i} fill={COLORS[i % COLORS.length]} />)}
                    </Pie><Tooltip formatter={(v: any) => fmt(Number(v), repCur)} contentStyle={{ borderRadius: 14, border: 'none' }} /></PieChart>
                  </ResponsiveContainer>
                  <div className="absolute inset-0 flex flex-col items-center justify-center pointer-events-none"><span className="text-[10px] text-slate-400">{tr ? 'Toplam' : 'Total'}</span><span className="text-sm font-black text-slate-900 dark:text-white">{money(expTotal)}</span></div>
                </div>
                <div className="space-y-2 mt-3">
                  {expenseCatsData.slice(0, 6).map((c, i) => (
                    <div key={c.name} className="text-xs">
                      <div className="flex items-center justify-between mb-1"><span className="flex items-center gap-1.5 text-slate-600 dark:text-slate-300 truncate"><span className="w-2 h-2 rounded-full shrink-0" style={{ background: COLORS[i % COLORS.length] }} />{c.name}</span><span className="font-semibold text-slate-900 dark:text-white">{money(c.value)}</span></div>
                      <GrowBar value={expTotal ? (c.value / expTotal) * 100 : 0} className={['bg-indigo-500', 'bg-orange-500', 'bg-emerald-500', 'bg-rose-500', 'bg-sky-500', 'bg-purple-500', 'bg-yellow-500', 'bg-slate-500'][i % 8]} delay={i * 80} />
                    </div>
                  ))}
                </div>
              </>
            )}
          </div>
        </div>

        <div className="grid grid-cols-1 xl:grid-cols-3 gap-5">
          <div className="bg-white dark:bg-slate-900 border border-slate-100 dark:border-slate-800 rounded-[24px] p-5">
            <h3 className="font-bold text-slate-900 dark:text-white flex items-center gap-2 mb-3"><CalendarClock size={17} className="text-indigo-500" /> {tr ? 'Yaklaşan ödemeler (30 gün)' : 'Upcoming (30 days)'}</h3>
            {upcoming.length === 0 ? <p className="text-sm text-slate-400 py-6 text-center">{tr ? 'Yaklaşan ödeme yok 🎉' : 'Nothing due'}</p> : (
              <ul className="space-y-1.5 max-h-72 overflow-y-auto custom-scrollbar pc-stagger">
                {upcoming.map(u => (
                  <li key={u.id} className="flex items-center gap-3 p-2.5 rounded-xl hover:bg-slate-50 dark:hover:bg-white/[0.03]">
                    <span className={`w-8 h-8 shrink-0 rounded-lg flex items-center justify-center ${u.kind === 'lent' ? 'bg-sky-50 text-sky-600 dark:bg-sky-500/10' : u.kind === 'sub' ? 'bg-violet-50 text-violet-600 dark:bg-violet-500/10' : u.kind === 'salary' ? 'bg-amber-50 text-amber-600 dark:bg-amber-500/10' : 'bg-rose-50 text-rose-600 dark:bg-rose-500/10'}`}>
                      {u.kind === 'lent' ? <ArrowUpRight size={15} /> : u.kind === 'sub' ? <CreditCard size={15} /> : u.kind === 'salary' ? <Users size={15} /> : <ArrowDownRight size={15} />}
                    </span>
                    <div className="flex-1 min-w-0"><p className="text-sm font-semibold text-slate-800 dark:text-slate-100 truncate">{u.label}</p><p className={`text-[11px] ${u.overdue ? 'text-rose-600 font-semibold' : 'text-slate-400'}`}>{u.kind === 'salary' ? (tr ? 'Bu ay ödenmedi' : 'Unpaid this month') : u.date}{u.overdue ? (tr ? ' · gecikti' : ' · overdue') : ''}</p></div>
                    <span className={`text-sm font-bold ${u.kind === 'lent' ? 'text-emerald-600' : 'text-slate-900 dark:text-white'}`}>{u.kind === 'lent' ? '+' : '−'}{money(u.amount)}</span>
                  </li>
                ))}
              </ul>
            )}
          </div>

          <div className="bg-white dark:bg-slate-900 border border-slate-100 dark:border-slate-800 rounded-[24px] p-5">
            <h3 className="font-bold text-slate-900 dark:text-white mb-3">{tr ? 'Gelir kaynakları' : 'Income sources'}</h3>
            {incomeCatsData.length === 0 ? <p className="text-sm text-slate-400 py-6 text-center">{tr ? 'Bu dönemde gelir yok' : 'No income'}</p> : (
              <div className="space-y-3">{incomeCatsData.slice(0, 6).map((c, i) => {
                const max = incomeCatsData[0].value || 1;
                return (<div key={c.name}><div className="flex justify-between text-xs mb-1"><span className="text-slate-600 dark:text-slate-300 truncate">{c.name}</span><span className="font-semibold text-slate-900 dark:text-white">{money(c.value)}</span></div><GrowBar value={(c.value / max) * 100} className="bg-gradient-to-r from-emerald-400 to-teal-500" delay={i * 80} /></div>);
              })}</div>
            )}
          </div>

          <div className="bg-white dark:bg-slate-900 border border-slate-100 dark:border-slate-800 rounded-[24px] p-5">
            <h3 className="font-bold text-slate-900 dark:text-white flex items-center gap-2 mb-1"><FileSpreadsheet size={17} className="text-indigo-500" /> {tr ? 'Muhasebeci paketi' : 'Accountant pack'}</h3>
            <p className="text-xs text-slate-400 mb-3">{tr ? 'Aylık Excel raporu ve belge arşivi (ZIP).' : 'Monthly Excel and document ZIP.'}</p>
            <ul className="space-y-1.5">
              {months6.map(m => {
                const label = new Date(`${m.ym}-01`).toLocaleDateString(tr ? 'tr-TR' : 'en-US', { month: 'long', year: 'numeric' });
                const docCount = transactions.filter(t => t.date.startsWith(m.ym) && t.documentUrl).length + debts.filter(d => d.date.startsWith(m.ym) && d.documentUrl).length;
                return (
                  <li key={m.ym} className="flex items-center gap-2 p-2 rounded-xl hover:bg-slate-50 dark:hover:bg-white/[0.03]">
                    <span className="flex-1 text-sm font-semibold text-slate-700 dark:text-slate-200 capitalize">{label}</span>
                    <button onClick={() => exportMonthExcel(m.ym, label)} title="Excel" className="h-8 px-2 rounded-lg text-xs font-semibold text-emerald-700 bg-emerald-50 hover:bg-emerald-100 dark:bg-emerald-500/10 dark:text-emerald-300 inline-flex items-center gap-1"><Download size={13} /> Excel</button>
                    <button onClick={() => downloadDocsZip(m.ym, label)} disabled={zipping || !docCount} title="ZIP" className="h-8 px-2 rounded-lg text-xs font-semibold text-indigo-700 bg-indigo-50 hover:bg-indigo-100 dark:bg-indigo-500/10 dark:text-indigo-300 disabled:opacity-40 inline-flex items-center gap-1">{zipping ? <Loader2 size={13} className="animate-spin" /> : <Paperclip size={13} />} {docCount}</button>
                  </li>
                );
              })}
            </ul>
            <button onClick={() => {
              const ym = localISO().slice(0, 7);
              const links = transactions.filter(t => t.date.startsWith(ym) && t.documentUrl).map(t => `${t.date} - ${t.documentName || t.description}: ${t.documentUrl}`).join('\n');
              if (!links) { toast.info(tr ? 'Bu ay belge yok' : 'No documents'); return; }
              navigator.clipboard.writeText(links); toast.success(tr ? 'Bu ayın belge linkleri kopyalandı' : 'Links copied');
            }} className="mt-3 w-full h-9 rounded-xl text-xs font-semibold border border-slate-200 dark:border-slate-700 text-slate-600 dark:text-slate-300 hover:text-indigo-600 inline-flex items-center justify-center gap-1.5"><Copy size={13} /> {tr ? 'Bu ayın belge linklerini kopyala' : 'Copy this month\'s links'}</button>
          </div>
        </div>

        <div className="bg-white dark:bg-slate-900 border border-slate-100 dark:border-slate-800 rounded-[24px] p-5">
          <div className="flex items-center justify-between mb-3"><h3 className="font-bold text-slate-900 dark:text-white">{tr ? 'Son hareketler' : 'Recent activity'}</h3><button onClick={() => setTab('transactions')} className="text-xs font-semibold text-indigo-600 hover:underline">{tr ? 'Tümü' : 'All'}</button></div>
          <div className="divide-y divide-slate-100 dark:divide-slate-800">{[...transactions].sort((a, b) => b.date.localeCompare(a.date)).slice(0, 6).map(t => txRow(t, true))}</div>
        </div>
      </div>
    );
  };

  const txRow = (t: Transaction, compact = false) => {
    const income = t.type === 'Income';
    const proj = projects.find(p => p.id === t.projectId);
    return (
      <div key={t.id} onClick={() => openTx(t)} className="group flex items-center gap-3 py-3 px-1 sm:px-3 cursor-pointer hover:bg-slate-50/80 dark:hover:bg-white/[0.02] rounded-xl transition-colors">
        <span className={`w-9 h-9 shrink-0 rounded-xl flex items-center justify-center ${income ? 'bg-emerald-50 text-emerald-600 dark:bg-emerald-500/10' : 'bg-rose-50 text-rose-600 dark:bg-rose-500/10'}`}>{income ? <ArrowUpRight size={16} /> : <ArrowDownRight size={16} />}</span>
        <div className="flex-1 min-w-0">
          <p className="text-sm font-semibold text-slate-800 dark:text-slate-100 truncate">{t.description || t.category}</p>
          <p className="text-[11px] text-slate-400 truncate">{new Date(t.date).toLocaleDateString(tr ? 'tr-TR' : 'en-US', { day: 'numeric', month: 'short', year: compact ? undefined : 'numeric' })} · {t.category}{proj ? ` · ${proj.name}` : ''}</p>
        </div>
        {!compact && t.taxRate ? <span className="hidden md:inline text-[10px] font-semibold px-1.5 py-0.5 rounded-md bg-slate-100 dark:bg-white/5 text-slate-500">%{t.taxRate} KDV</span> : null}
        {t.documentUrl && <a href={t.documentUrl} target="_blank" rel="noreferrer" onClick={e => e.stopPropagation()} title={t.documentName} className="p-1.5 rounded-lg text-indigo-500 hover:bg-indigo-50 dark:hover:bg-white/5"><Eye size={14} /></a>}
        <div className="text-right shrink-0">
          <p className={`text-sm font-bold ${income ? 'text-emerald-600' : 'text-rose-600'}`}>{showFinancials ? `${income ? '+' : '−'}${fmt(t.amount, t.currency, 2)}` : '••••'}</p>
          {!compact && t.currency !== repCur && showFinancials && <p className="text-[10px] text-slate-400">≈ {fmt(conv(t.amount, t.currency), repCur)}</p>}
        </div>
        {!compact && <div className="flex items-center opacity-100 lg:opacity-0 lg:group-hover:opacity-100 transition-opacity" onClick={e => e.stopPropagation()}>
          <button onClick={() => openTx(t)} title={tr ? 'Düzenle' : 'Edit'} className="p-1.5 rounded-lg text-slate-400 hover:text-indigo-600 hover:bg-indigo-50 dark:hover:bg-white/5"><Edit2 size={14} /></button>
          {delButtons(t.id, () => onDeleteTransaction(t.id))}
        </div>}
      </div>
    );
  };

  const transactionsTab = () => (
    <div className="space-y-4">
      <div className="bg-white dark:bg-slate-900 border border-slate-100 dark:border-slate-800 rounded-[20px] p-3 flex flex-col lg:flex-row gap-2">
        <div className="relative flex-1"><Search size={16} className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
          <input value={search} onChange={e => setSearch(e.target.value)} placeholder={tr ? 'Açıklama, kategori, proje ara…' : 'Search…'} className="w-full h-10 pl-9 pr-3 rounded-xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700 text-sm outline-none focus:border-indigo-500" /></div>
        <div className="flex flex-wrap gap-2">
          <div className="flex p-1 rounded-xl bg-slate-100 dark:bg-slate-800/60">
            {(['All', 'Income', 'Expense'] as const).map(k => <button key={k} onClick={() => setTypeF(k)} className={`h-8 px-3 rounded-lg text-xs font-semibold ${typeF === k ? 'bg-white dark:bg-slate-900 shadow-sm text-indigo-600' : 'text-slate-500'}`}>{k === 'All' ? (tr ? 'Tümü' : 'All') : k === 'Income' ? (tr ? 'Gelir' : 'Income') : (tr ? 'Gider' : 'Expense')}</button>)}
          </div>
          <select value={catF} onChange={e => setCatF(e.target.value)} className="h-10 px-3 rounded-xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700 text-xs font-semibold outline-none max-w-[180px]"><option value="all">{tr ? 'Tüm kategoriler' : 'All categories'}</option>{allCats.map(c => <option key={c} value={c}>{c}</option>)}</select>
          <select value={projF} onChange={e => setProjF(e.target.value)} className="h-10 px-3 rounded-xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700 text-xs font-semibold outline-none max-w-[180px]"><option value="all">{tr ? 'Tüm projeler' : 'All projects'}</option>{projects.map(p => <option key={p.id} value={p.id}>{p.name}</option>)}</select>
          <button onClick={() => setDocOnly(v => !v)} className={`h-10 px-3 rounded-xl border text-xs font-semibold inline-flex items-center gap-1.5 ${docOnly ? 'border-indigo-300 bg-indigo-50 text-indigo-600 dark:bg-indigo-500/10' : 'border-slate-200 dark:border-slate-700 text-slate-600 dark:text-slate-300'}`}><Paperclip size={13} /> {tr ? 'Belgeli' : 'With doc'}</button>
          <button onClick={() => setSortBy(s => ({ key: s.key === 'date' ? 'amount' : 'date', dir: -1 }))} className="h-10 px-3 rounded-xl border border-slate-200 dark:border-slate-700 text-xs font-semibold text-slate-600 dark:text-slate-300 inline-flex items-center gap-1.5"><ArrowUpDown size={13} /> {sortBy.key === 'date' ? (tr ? 'Tarih' : 'Date') : (tr ? 'Tutar' : 'Amount')}</button>
          <button onClick={() => setSortBy(s => ({ ...s, dir: s.dir === 1 ? -1 : 1 }))} className="h-10 w-10 rounded-xl border border-slate-200 dark:border-slate-700 text-slate-500 inline-flex items-center justify-center" title={tr ? 'Yönü değiştir' : 'Toggle'}>{sortBy.dir === -1 ? '↓' : '↑'}</button>
          <button onClick={exportFilteredExcel} className="h-10 px-3 rounded-xl text-xs font-semibold text-emerald-700 bg-emerald-50 hover:bg-emerald-100 dark:bg-emerald-500/10 dark:text-emerald-300 inline-flex items-center gap-1.5"><Download size={13} /> Excel</button>
        </div>
      </div>

      <div className="grid grid-cols-3 gap-2">
        {[[tr ? 'Gelir' : 'Income', filteredSums.income, 'text-emerald-600'], [tr ? 'Gider' : 'Expense', filteredSums.expense, 'text-rose-600'], ['Net', filteredSums.net, filteredSums.net >= 0 ? 'text-indigo-600' : 'text-rose-600']].map(([l, v, c]) => (
          <div key={l as string} className="rounded-2xl bg-white dark:bg-slate-900 border border-slate-100 dark:border-slate-800 px-4 py-3"><p className="text-[11px] text-slate-400">{l} · {filteredTx.length} {tr ? 'kayıt' : 'rows'}</p><p className={`text-base sm:text-lg font-black ${c}`}>{money(v as number)}</p></div>
        ))}
      </div>

      <div className="bg-white dark:bg-slate-900 border border-slate-100 dark:border-slate-800 rounded-[20px] p-2 sm:p-3">
        {filteredTx.length === 0 ? (
          <div className="py-14 text-center text-slate-400 animate-in fade-in"><Receipt size={36} className="mx-auto mb-2 opacity-40 pc-float" /><p className="text-sm font-semibold">{tr ? 'Bu filtrelerde kayıt yok' : 'No records'}</p><button onClick={() => openTx()} className="mt-2 text-xs font-semibold text-indigo-600 hover:underline">{tr ? 'Yeni kayıt ekle' : 'Add entry'}</button></div>
        ) : (
          <div className="divide-y divide-slate-100 dark:divide-slate-800 pc-stagger" key={`${page}-${typeF}-${catF}`}>{filteredTx.slice((page - 1) * PAGE, page * PAGE).map(t => txRow(t))}</div>
        )}
        {pages > 1 && (
          <div className="flex items-center justify-between px-2 pt-3">
            <span className="text-xs text-slate-400">{tr ? `Sayfa ${page} / ${pages}` : `Page ${page} of ${pages}`}</span>
            <div className="flex gap-1">
              <button disabled={page === 1} onClick={() => setPage(p => p - 1)} className="h-8 w-8 rounded-lg border border-slate-200 dark:border-slate-700 disabled:opacity-40 inline-flex items-center justify-center"><ChevronLeft size={15} /></button>
              <button disabled={page === pages} onClick={() => setPage(p => p + 1)} className="h-8 w-8 rounded-lg border border-slate-200 dark:border-slate-700 disabled:opacity-40 inline-flex items-center justify-center"><ChevronRight size={15} /></button>
            </div>
          </div>
        )}
      </div>
    </div>
  );

  const debtsTab = () => {
    const list = debts.filter(d => debtF === 'open' ? !d.isPaid : debtF === 'closed' ? d.isPaid : (d.type === debtF && !d.isPaid))
      .filter(d => !search || [d.personName, d.description].join(' ').toLocaleLowerCase('tr-TR').includes(search.toLocaleLowerCase('tr-TR')))
      .sort((a, b) => (a.dueDate || '9999').localeCompare(b.dueDate || '9999'));
    return (
      <div className="space-y-4">
        <div className="bg-white dark:bg-slate-900 border border-slate-100 dark:border-slate-800 rounded-[20px] p-3 flex flex-col sm:flex-row gap-2">
          <div className="relative flex-1"><Search size={16} className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" /><input value={search} onChange={e => setSearch(e.target.value)} placeholder={tr ? 'Kişi / kurum ara…' : 'Search…'} className="w-full h-10 pl-9 pr-3 rounded-xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700 text-sm outline-none focus:border-indigo-500" /></div>
          <div className="flex p-1 rounded-xl bg-slate-100 dark:bg-slate-800/60 overflow-x-auto">
            {([['open', tr ? 'Açık' : 'Open'], ['Borrowed', tr ? 'Borçlarım' : 'Payables'], ['Lent', tr ? 'Alacaklarım' : 'Receivables'], ['closed', tr ? 'Kapanan' : 'Closed']] as const).map(([k, l]) => <button key={k} onClick={() => setDebtF(k)} className={`shrink-0 h-8 px-3 rounded-lg text-xs font-semibold ${debtF === k ? 'bg-white dark:bg-slate-900 shadow-sm text-indigo-600' : 'text-slate-500'}`}>{l}</button>)}
          </div>
        </div>
        {list.length === 0 ? (
          <div className="py-14 text-center text-slate-400 rounded-[20px] border border-dashed border-slate-200 dark:border-slate-700"><Landmark size={36} className="mx-auto mb-2 opacity-40 pc-float" /><p className="text-sm font-semibold">{tr ? 'Kayıt yok' : 'No records'}</p></div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-4 pc-stagger">
            {list.map(d => {
              const paidPct = d.amount ? Math.min(100, ((d.amount - d.remainingAmount) / d.amount) * 100) : 0;
              const dd = dayDiff(d.dueDate);
              const borrowed = d.type === 'Borrowed';
              return (
                <div key={d.id} className={`group bg-white dark:bg-slate-900 border rounded-[20px] p-4 transition-all hover:shadow-lg hover:shadow-slate-200/50 dark:hover:shadow-none ${!d.isPaid && dd !== null && dd < 0 ? 'border-rose-200 dark:border-rose-500/30' : 'border-slate-100 dark:border-slate-800'}`}>
                  <div className="flex items-start justify-between gap-2">
                    <span className={`text-[11px] font-semibold px-2 py-0.5 rounded-md ${borrowed ? 'bg-amber-50 text-amber-700 dark:bg-amber-500/10 dark:text-amber-300' : 'bg-sky-50 text-sky-700 dark:bg-sky-500/10 dark:text-sky-300'}`}>{borrowed ? (tr ? 'Borç (alınan)' : 'Payable') : (tr ? 'Alacak (verilen)' : 'Receivable')}</span>
                    <div className="flex items-center">
                      {d.documentUrl && <a href={d.documentUrl} target="_blank" rel="noreferrer" className="p-1.5 rounded-lg text-indigo-500 hover:bg-indigo-50 dark:hover:bg-white/5"><Eye size={14} /></a>}
                      <button onClick={() => openDebt(d)} className="p-1.5 rounded-lg text-slate-400 hover:text-indigo-600 hover:bg-indigo-50 dark:hover:bg-white/5"><Edit2 size={14} /></button>
                      {delButtons(d.id, () => onDeleteDebt(d.id))}
                    </div>
                  </div>
                  <h3 className="mt-2 font-bold text-slate-900 dark:text-white truncate">{d.personName}</h3>
                  {d.description && <p className="text-xs text-slate-500 dark:text-slate-400 line-clamp-1">{d.description}</p>}
                  <div className="mt-3 flex items-end justify-between">
                    <div><p className="text-[11px] text-slate-400">{d.isPaid ? (tr ? 'Kapandı' : 'Closed') : (tr ? 'Kalan' : 'Remaining')}</p><p className={`text-xl font-black ${d.isPaid ? 'text-emerald-600' : borrowed ? 'text-rose-600' : 'text-sky-600'}`}>{showFinancials ? fmt(d.isPaid ? d.amount : d.remainingAmount, d.currency, 2) : '••••'}</p></div>
                    <p className="text-[11px] text-slate-400 text-right">{tr ? 'Toplam' : 'Total'}<br /><b className="text-slate-700 dark:text-slate-200">{showFinancials ? fmt(d.amount, d.currency) : '••'}</b></p>
                  </div>
                  <div className="mt-2 h-1.5 rounded-full bg-slate-100 dark:bg-white/5"><div className="h-full rounded-full bg-gradient-to-r from-emerald-400 to-teal-500 pc-grow-x" style={{ width: `${d.isPaid ? 100 : paidPct}%` }} /></div>
                  <div className="flex items-center justify-between mt-3">
                    <span className={`text-[11px] font-semibold ${!d.isPaid && dd !== null && dd < 0 ? 'text-rose-600' : 'text-slate-500'}`}>{d.dueDate ? (d.isPaid ? `${tr ? 'Vade' : 'Due'} ${d.dueDate}` : dd! < 0 ? (tr ? `${Math.abs(dd!)} gün gecikti` : `${Math.abs(dd!)}d overdue`) : dd === 0 ? (tr ? 'Bugün vadeli' : 'Due today') : (tr ? `${dd} gün kaldı` : `${dd}d left`)) : (tr ? 'Vade yok' : 'No due date')}</span>
                    {!d.isPaid && <button onClick={() => { setPayDebt({ debt: d, amount: d.remainingAmount, note: '' }); setSheet('payDebt'); }} className="h-8 px-3 rounded-lg text-xs font-semibold text-white bg-slate-900 dark:bg-indigo-600 hover:bg-indigo-600 inline-flex items-center gap-1">{borrowed ? (tr ? 'Ödeme yap' : 'Pay') : (tr ? 'Tahsil et' : 'Collect')}</button>}
                  </div>
                  {d.payments && d.payments.length > 0 && (
                    <details className="mt-3 group/d">
                      <summary className="text-[11px] font-semibold text-slate-500 cursor-pointer list-none flex items-center gap-1"><History size={12} /> {d.payments.length} {tr ? 'ödeme' : 'payments'} <ChevronRight size={12} className="transition-transform group-open/d:rotate-90" /></summary>
                      <ul className="mt-2 space-y-1">{d.payments.map(p => <li key={p.id} className="flex justify-between text-[11px] text-slate-500"><span>{p.date}{p.note ? ` · ${p.note}` : ''}</span><span className="font-semibold text-slate-700 dark:text-slate-200">{showFinancials ? fmt(p.amount, d.currency, 2) : '••'}</span></li>)}</ul>
                    </details>
                  )}
                </div>
              );
            })}
          </div>
        )}
      </div>
    );
  };

  const salariesTab = () => {
    const paidMap = new Map(salaryPayments.filter(p => p.month === salaryMonth).map(p => [p.userId, p]));
    const payroll = staffList.filter(s => s.monthlySalary);
    const expected = payroll.reduce((s, u) => s + conv(u.monthlySalary || 0, u.salaryCurrency), 0);
    const paid = salaryPayments.filter(p => p.month === salaryMonth).reduce((s, p) => s + conv(p.amount, p.currency), 0);
    const history = salaryPayments.filter(p => p.month === salaryMonth).sort((a, b) => b.date.localeCompare(a.date));
    return (
      <div className="space-y-4">
        <div className="bg-white dark:bg-slate-900 border border-slate-100 dark:border-slate-800 rounded-[20px] p-4 flex flex-col md:flex-row md:items-center gap-4">
          <div className="flex items-center gap-2"><span className="text-xs font-semibold text-slate-500">{tr ? 'Dönem' : 'Month'}</span><input type="month" value={salaryMonth} onChange={e => setSalaryMonth(e.target.value)} className="h-10 px-3 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-sm font-semibold" /></div>
          <div className="flex-1">
            <div className="flex justify-between text-xs mb-1"><span className="text-slate-500">{tr ? 'Ödenen' : 'Paid'} <b className="text-slate-900 dark:text-white">{money(paid)}</b> / {money(expected)}</span><span className="font-bold text-indigo-600">{paidMap.size}/{payroll.length} {tr ? 'personel' : 'staff'}</span></div>
            <GrowBar value={expected ? (paid / expected) * 100 : 0} className="bg-gradient-to-r from-indigo-500 to-violet-500" />
          </div>
        </div>
        <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-3 gap-4 pc-stagger">
          {staffList.map(s => {
            const p = paidMap.get(s.id);
            return (
              <div key={s.id} className={`bg-white dark:bg-slate-900 border rounded-[20px] p-4 ${p ? 'border-emerald-200 dark:border-emerald-500/20' : 'border-slate-100 dark:border-slate-800'}`}>
                <div className="flex items-center gap-3">
                  {s.avatar ? <img src={s.avatar} alt="" className="w-11 h-11 rounded-xl object-cover" /> : <span className="w-11 h-11 rounded-xl bg-gradient-to-br from-indigo-500 to-violet-500 text-white font-bold flex items-center justify-center">{s.name?.[0]}</span>}
                  <div className="flex-1 min-w-0"><p className="font-bold text-slate-900 dark:text-white truncate">{s.name}</p><p className="text-[11px] text-slate-400 truncate">{s.jobTitle || s.role}</p></div>
                  {p ? <span className="text-[11px] font-semibold px-2 py-0.5 rounded-md bg-emerald-50 text-emerald-700 dark:bg-emerald-500/10 dark:text-emerald-300 inline-flex items-center gap-1"><Check size={11} />{tr ? 'Ödendi' : 'Paid'}</span>
                    : <span className="text-[11px] font-semibold px-2 py-0.5 rounded-md bg-amber-50 text-amber-700 dark:bg-amber-500/10 dark:text-amber-300">{tr ? 'Bekliyor' : 'Pending'}</span>}
                </div>
                <div className="flex items-end justify-between mt-4">
                  <div><p className="text-[11px] text-slate-400">{tr ? 'Aylık maaş' : 'Monthly salary'}</p><p className="text-lg font-black text-slate-900 dark:text-white">{showFinancials ? (s.monthlySalary ? fmt(s.monthlySalary, s.salaryCurrency || Currency.USD) : '—') : '••••'}</p>{p && <p className="text-[11px] text-emerald-600">{p.date} · {showFinancials ? fmt(p.amount, p.currency) : ''}</p>}</div>
                  <button onClick={() => openSalary(s)} className={`h-9 px-3 rounded-xl text-xs font-semibold inline-flex items-center gap-1 ${p ? 'border border-slate-200 dark:border-slate-700 text-slate-600 dark:text-slate-300 hover:text-indigo-600' : 'text-white bg-indigo-600 hover:bg-indigo-500 shadow-md shadow-indigo-500/20'}`}>{p ? (tr ? 'Ek ödeme' : 'Extra') : (tr ? 'Maaşı öde' : 'Pay')}</button>
                </div>
              </div>
            );
          })}
        </div>
        <div className="bg-white dark:bg-slate-900 border border-slate-100 dark:border-slate-800 rounded-[20px] p-4">
          <h3 className="font-bold text-slate-900 dark:text-white mb-2 flex items-center gap-2"><History size={16} className="text-indigo-500" /> {tr ? 'Bu dönemin ödemeleri' : 'Payments this month'}</h3>
          {history.length === 0 ? <p className="text-sm text-slate-400 py-4 text-center">{tr ? 'Ödeme yok' : 'No payments'}</p> : (
            <div className="divide-y divide-slate-100 dark:divide-slate-800">{history.map(p => (
              <div key={p.id} className="group flex items-center gap-3 py-2.5">
                <span className="flex-1 text-sm font-semibold text-slate-800 dark:text-slate-100">{p.userName}</span>
                <span className="text-xs text-slate-400">{p.date}</span>
                <span className="text-sm font-bold text-rose-600">{showFinancials ? `−${fmt(p.amount, p.currency)}` : '••'}</span>
                {delButtons(p.id, async () => { await onDeleteSalaryPayment(p.id); await onDeleteTransaction(`tr_sal_${p.id}`); })}
              </div>
            ))}</div>
          )}
        </div>
      </div>
    );
  };

  // ---------- Formlar ----------
  const err = (m: Record<string, string>, k: string) => (touched ? m[k] : undefined);
  const txSheet = () => {
    const isInc = newTx.type === 'Income';
    const cats = isInc ? incomeCats : expenseCats;
    return (
      <SheetShell title={editingTx ? (tr ? 'Kaydı düzenle' : 'Edit entry') : (tr ? 'Yeni gelir / gider' : 'New entry')} subtitle={tr ? 'Gelir veya gider kaydı' : 'Income or expense'} icon={isInc ? TrendingUp : TrendingDown} tone={isInc ? 'from-emerald-500 to-teal-600' : 'from-rose-500 to-orange-500'}
        onClose={closeSheet} onSubmit={saveTransaction} saving={saving} submitLabel={editingTx ? (tr ? 'Güncelle' : 'Update') : (tr ? 'Kaydet' : 'Save')}
        footerLeft={<span className="text-slate-400">{tr ? 'Toplam' : 'Total'} <b className={isInc ? 'text-emerald-600' : 'text-rose-600'}>{fmt(newTx.totalAmountWithTax || 0, newTx.currency, 2)}</b></span>}>
        <div className="grid grid-cols-2 gap-1 p-1 rounded-xl bg-slate-100 dark:bg-slate-800">
          <button onClick={() => setNewTx(p => ({ ...p, type: 'Income', category: '' }))} className={`h-10 rounded-lg text-sm font-semibold inline-flex items-center justify-center gap-1.5 transition-all ${isInc ? 'bg-white dark:bg-slate-900 shadow-sm text-emerald-600' : 'text-slate-500'}`}><TrendingUp size={15} /> {tr ? 'Gelir' : 'Income'}</button>
          <button onClick={() => setNewTx(p => ({ ...p, type: 'Expense', category: '' }))} className={`h-10 rounded-lg text-sm font-semibold inline-flex items-center justify-center gap-1.5 transition-all ${!isInc ? 'bg-white dark:bg-slate-900 shadow-sm text-rose-600' : 'text-slate-500'}`}><TrendingDown size={15} /> {tr ? 'Gider' : 'Expense'}</button>
        </div>
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
          <Field label={tr ? 'Tutar (KDV hariç)' : 'Amount (excl. VAT)'} required error={err(txErrors, 'amount')} className="sm:col-span-2">
            <div className="relative"><span className="absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-400 font-bold">{sym(newTx.currency)}</span>
              <input autoFocus type="number" min={0} step="0.01" className={inputCls(err(txErrors, 'amount')) + ' pl-9 h-12 text-lg font-bold'} value={newTx.amount || ''} onChange={e => setNewTx(p => recalcTx({ ...p, amount: Number(e.target.value) }))} /></div>
          </Field>
          <Field label={tr ? 'Para birimi' : 'Currency'} required>
            <div className="grid grid-cols-3 gap-1 p-1 rounded-xl bg-slate-100 dark:bg-slate-800 h-12">
              {[Currency.TRY, Currency.USD, Currency.EUR].map(c => <button key={c} onClick={() => setNewTx(p => ({ ...p, currency: c }))} className={`rounded-lg text-xs font-bold ${newTx.currency === c ? 'bg-white dark:bg-slate-900 shadow-sm text-indigo-600' : 'text-slate-500'}`}>{sym(c)}</button>)}
            </div>
          </Field>
        </div>
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <Field label={tr ? 'KDV oranı (%)' : 'VAT rate (%)'}>
            <div className="flex gap-1">{[0, 1, 10, 20].map(r => <button key={r} onClick={() => setNewTx(p => recalcTx({ ...p, taxRate: r }))} className={`flex-1 h-11 rounded-xl text-xs font-bold border ${Number(newTx.taxRate) === r ? 'border-indigo-500 text-indigo-600 bg-indigo-50 dark:bg-indigo-500/10' : 'border-slate-200 dark:border-slate-700 text-slate-500'}`}>%{r}</button>)}</div>
          </Field>
          <Field label={tr ? 'Tarih' : 'Date'} required error={err(txErrors, 'date')}><input type="date" className={inputCls(err(txErrors, 'date'))} value={localDate} onChange={e => setLocalDate(e.target.value)} /></Field>
        </div>
        <Field label={tr ? 'Kategori' : 'Category'} required error={err(txErrors, 'category')}>
          <div className="flex flex-wrap gap-1.5">
            {cats.map(c => <button key={c} onClick={() => setNewTx(p => ({ ...p, category: c }))} className={`h-8 px-3 rounded-lg text-xs font-semibold border transition-all ${newTx.category === c ? (isInc ? 'border-emerald-500 bg-emerald-50 text-emerald-700 dark:bg-emerald-500/10 dark:text-emerald-300' : 'border-rose-500 bg-rose-50 text-rose-700 dark:bg-rose-500/10 dark:text-rose-300') : 'border-slate-200 dark:border-slate-700 text-slate-600 dark:text-slate-300 hover:border-slate-300'}`}>{c}</button>)}
            {newTx.category && !cats.includes(newTx.category) && <span className="h-8 px-3 rounded-lg text-xs font-semibold border border-indigo-500 bg-indigo-50 text-indigo-700 inline-flex items-center">{newTx.category}</span>}
          </div>
        </Field>
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <Field label={tr ? 'Proje' : 'Project'} hint={tr ? 'İsteğe bağlı; proje kârlılığı için' : 'Optional'}>
            <select className={inputCls()} value={newTx.projectId || ''} onChange={e => setNewTx(p => ({ ...p, projectId: e.target.value || undefined }))}><option value="">—</option>{projects.map(p => <option key={p.id} value={p.id}>{p.name}</option>)}</select>
          </Field>
          <Field label={tr ? 'Açıklama' : 'Description'}><input className={inputCls()} value={newTx.description || ''} onChange={e => setNewTx(p => ({ ...p, description: e.target.value }))} placeholder={tr ? 'Örn: AWS Ekim faturası' : 'e.g. AWS invoice'} /></Field>
        </div>
        <Field label={tr ? 'Belge / fiş / fatura' : 'Document'}>
          <div className="flex gap-2">
            <label className={`flex-1 flex items-center gap-2 h-12 px-3.5 rounded-xl border-2 border-dashed cursor-pointer transition-colors ${newTx.documentUrl ? 'border-emerald-300 bg-emerald-50/50 dark:bg-emerald-500/5' : 'border-slate-200 dark:border-slate-700 hover:border-indigo-400'}`}>
              <input type="file" className="hidden" onChange={async e => { const f = e.target.files?.[0]; if (f) { const d = await handleFileUpload(f, 'transactions'); if (d) setNewTx(p => ({ ...p, documentUrl: d.url, documentName: d.name })); } }} />
              {uploading ? <RefreshCw size={16} className="animate-spin text-indigo-500" /> : newTx.documentUrl ? <Check size={16} className="text-emerald-600" /> : <CloudUpload size={16} className="text-slate-400" />}
              <span className="text-sm text-slate-600 dark:text-slate-300 truncate">{newTx.documentName || (tr ? 'Dosya seç (PDF, görsel)' : 'Choose file')}</span>
            </label>
            {pendingFile && <button onClick={handleAIAnalyze} disabled={analyzing} title={tr ? 'Yapay zekayla doldur' : 'Fill with AI'} className="h-12 px-3 rounded-xl text-sm font-semibold text-indigo-700 bg-indigo-50 hover:bg-indigo-100 dark:bg-indigo-500/10 dark:text-indigo-300 inline-flex items-center gap-1.5">{analyzing ? <RefreshCw size={15} className="animate-spin" /> : <Zap size={15} />} AI</button>}
          </div>
        </Field>
        <div className="grid grid-cols-3 gap-2 text-sm">
          {[[tr ? 'Ara toplam' : 'Subtotal', newTx.amount || 0], ['KDV', newTx.taxAmount || 0], [tr ? 'Toplam' : 'Total', newTx.totalAmountWithTax || 0]].map(([l, v], i) => (
            <div key={l as string} className={`rounded-xl p-3 ${i === 2 ? (isInc ? 'bg-emerald-600 text-white' : 'bg-rose-600 text-white') : 'bg-slate-50 dark:bg-white/[0.03]'}`}><p className={`text-[11px] ${i === 2 ? 'text-white/80' : 'text-slate-400'}`}>{l}</p><p className="font-bold">{fmt(v as number, newTx.currency, 2)}</p></div>
          ))}
        </div>
      </SheetShell>
    );
  };

  const debtSheet = () => {
    const borrowed = newDebt.type === 'Borrowed';
    return (
      <SheetShell title={editingDebt ? (tr ? 'Borç / alacak düzenle' : 'Edit debt') : (tr ? 'Yeni borç / alacak' : 'New debt')} subtitle={tr ? 'Ödemeler ayrıca kaydedilir ve finansa işlenir' : 'Payments are recorded separately'} icon={Landmark} tone={borrowed ? 'from-amber-500 to-orange-600' : 'from-sky-500 to-blue-600'}
        onClose={closeSheet} onSubmit={saveDebt} saving={saving} submitLabel={tr ? 'Kaydet' : 'Save'}>
        <div className="grid grid-cols-2 gap-1 p-1 rounded-xl bg-slate-100 dark:bg-slate-800">
          <button onClick={() => setNewDebt(p => ({ ...p, type: 'Borrowed' }))} className={`h-10 rounded-lg text-sm font-semibold ${borrowed ? 'bg-white dark:bg-slate-900 shadow-sm text-amber-600' : 'text-slate-500'}`}>{tr ? 'Borç aldım' : 'I borrowed'}</button>
          <button onClick={() => setNewDebt(p => ({ ...p, type: 'Lent' }))} className={`h-10 rounded-lg text-sm font-semibold ${!borrowed ? 'bg-white dark:bg-slate-900 shadow-sm text-sky-600' : 'text-slate-500'}`}>{tr ? 'Borç verdim' : 'I lent'}</button>
        </div>
        <Field label={tr ? 'Kişi / kurum' : 'Person / company'} required error={err(debtErrors, 'person')}><input autoFocus className={inputCls(err(debtErrors, 'person'))} value={newDebt.personName || ''} onChange={e => setNewDebt(p => ({ ...p, personName: e.target.value }))} /></Field>
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
          <Field label={tr ? 'Tutar' : 'Amount'} required error={err(debtErrors, 'amount')} className="sm:col-span-2">
            <div className="relative"><span className="absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-400 font-bold">{sym(newDebt.currency)}</span><input type="number" min={0} className={inputCls(err(debtErrors, 'amount')) + ' pl-9 font-bold'} value={newDebt.amount || ''} onChange={e => setNewDebt(p => ({ ...p, amount: Number(e.target.value), remainingAmount: Number(e.target.value) }))} /></div>
          </Field>
          <Field label={tr ? 'Para birimi' : 'Currency'}>
            <div className="grid grid-cols-3 gap-1 p-1 rounded-xl bg-slate-100 dark:bg-slate-800 h-11">{[Currency.TRY, Currency.USD, Currency.EUR].map(c => <button key={c} onClick={() => setNewDebt(p => ({ ...p, currency: c }))} className={`rounded-lg text-xs font-bold ${newDebt.currency === c ? 'bg-white dark:bg-slate-900 shadow-sm text-indigo-600' : 'text-slate-500'}`}>{sym(c)}</button>)}</div>
          </Field>
        </div>
        <div className="grid grid-cols-2 gap-4">
          <Field label={tr ? 'Kayıt tarihi' : 'Date'}><input type="date" className={inputCls()} value={localDate} onChange={e => setLocalDate(e.target.value)} /></Field>
          <Field label={tr ? 'Vade tarihi' : 'Due date'} error={err(debtErrors, 'due')}><input type="date" min={localDate} className={inputCls(err(debtErrors, 'due'))} value={newDebt.dueDate || ''} onChange={e => setNewDebt(p => ({ ...p, dueDate: e.target.value || undefined }))} /></Field>
        </div>
        <Field label={tr ? 'Açıklama' : 'Description'}><textarea rows={2} className={inputCls() + ' h-auto py-2.5 resize-none'} value={newDebt.description || ''} onChange={e => setNewDebt(p => ({ ...p, description: e.target.value }))} /></Field>
        <Field label={tr ? 'Sözleşme / dekont' : 'Document'}>
          <label className={`flex items-center gap-2 h-12 px-3.5 rounded-xl border-2 border-dashed cursor-pointer ${newDebt.documentUrl ? 'border-emerald-300 bg-emerald-50/50 dark:bg-emerald-500/5' : 'border-slate-200 dark:border-slate-700 hover:border-indigo-400'}`}>
            <input type="file" className="hidden" onChange={async e => { const f = e.target.files?.[0]; if (f) { const d = await handleFileUpload(f, 'debts'); if (d) setNewDebt(p => ({ ...p, documentUrl: d.url, documentName: d.name })); } }} />
            {uploading ? <RefreshCw size={16} className="animate-spin text-indigo-500" /> : newDebt.documentUrl ? <Check size={16} className="text-emerald-600" /> : <CloudUpload size={16} className="text-slate-400" />}
            <span className="text-sm text-slate-600 dark:text-slate-300 truncate">{newDebt.documentName || (tr ? 'Dosya seç' : 'Choose file')}</span>
          </label>
        </Field>
        {editingDebt && (
          <label className="flex items-center gap-2 text-sm text-slate-600 dark:text-slate-300"><input type="checkbox" className="w-4 h-4 accent-indigo-600" checked={!!newDebt.isPaid} onChange={e => setNewDebt(p => ({ ...p, isPaid: e.target.checked }))} /> {tr ? 'Tamamen kapandı olarak işaretle (finansa kayıt oluşturmaz)' : 'Mark as closed (no finance entry)'}</label>
        )}
      </SheetShell>
    );
  };

  const salarySheet = () => {
    const staff = staffList.find(s => s.id === newSalary.userId);
    const already = salaryPayments.filter(p => p.userId === newSalary.userId && p.month === newSalary.month);
    return (
      <SheetShell title={tr ? 'Maaş ödemesi' : 'Salary payment'} subtitle={staff?.name} icon={Users} tone="from-indigo-500 to-violet-600" onClose={closeSheet} onSubmit={saveSalary} saving={saving} submitLabel={tr ? 'Öde ve kaydet' : 'Pay & save'} width="max-w-md">
        {already.length > 0 && <div className="flex items-start gap-2 p-3 rounded-xl bg-amber-50 dark:bg-amber-500/10 text-xs text-amber-800 dark:text-amber-200"><AlertTriangle size={14} className="shrink-0 mt-0.5" />{tr ? `${newSalary.month} dönemi için zaten ${already.length} ödeme var. Bu ek ödeme olarak kaydedilecek.` : 'A payment for this month already exists.'}</div>}
        <div className="grid grid-cols-2 gap-4">
          <Field label={tr ? 'Maaş dönemi' : 'Month'} required><input type="month" className={inputCls()} value={newSalary.month || ''} onChange={e => setNewSalary(p => ({ ...p, month: e.target.value }))} /></Field>
          <Field label={tr ? 'Ödeme tarihi' : 'Paid on'} required><input type="date" className={inputCls()} value={localDate} onChange={e => setLocalDate(e.target.value)} /></Field>
        </div>
        <Field label={tr ? 'Tutar' : 'Amount'} required error={touched && !(Number(newSalary.amount) > 0) ? (tr ? 'Tutar girin' : 'Enter amount') : undefined} hint={staff?.monthlySalary ? `${tr ? 'Tanımlı maaş' : 'Defined'}: ${fmt(staff.monthlySalary, staff.salaryCurrency || Currency.USD)}` : undefined}>
          <div className="relative"><span className="absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-400 font-bold">{sym(newSalary.currency)}</span><input autoFocus type="number" className={inputCls() + ' pl-9 h-12 text-lg font-bold'} value={newSalary.amount || ''} onChange={e => setNewSalary(p => ({ ...p, amount: Number(e.target.value) }))} /></div>
        </Field>
        <Field label={tr ? 'Not' : 'Note'}><input className={inputCls()} value={newSalary.description || ''} onChange={e => setNewSalary(p => ({ ...p, description: e.target.value }))} /></Field>
        <p className="text-[11px] text-slate-400">{tr ? 'Ödeme "Personel Maaşları" kategorisinde gider olarak da işlenir.' : 'Also recorded as an expense.'}</p>
      </SheetShell>
    );
  };

  const payDebtSheet = () => payDebt && (
    <SheetShell title={payDebt.debt.type === 'Borrowed' ? (tr ? 'Borç ödemesi' : 'Pay debt') : (tr ? 'Alacak tahsilatı' : 'Collect receivable')} subtitle={payDebt.debt.personName} icon={Wallet} tone="from-emerald-500 to-teal-600" onClose={closeSheet} onSubmit={recordDebtPayment} saving={saving} submitLabel={tr ? 'Kaydet' : 'Record'} width="max-w-md">
      <Field label={tr ? 'Tutar' : 'Amount'} required hint={`${tr ? 'Kalan' : 'Remaining'}: ${fmt(payDebt.debt.remainingAmount, payDebt.debt.currency, 2)}`}>
        <div className="relative"><span className="absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-400 font-bold">{sym(payDebt.debt.currency)}</span><input autoFocus type="number" className={inputCls() + ' pl-9 h-12 text-lg font-bold'} value={payDebt.amount || ''} onChange={e => setPayDebt({ ...payDebt, amount: Math.min(Number(e.target.value), payDebt.debt.remainingAmount) })} /></div>
      </Field>
      <div className="flex gap-1.5">{[25, 50, 100].map(pct => <button key={pct} onClick={() => setPayDebt({ ...payDebt, amount: round2(payDebt.debt.remainingAmount * pct / 100) })} className="flex-1 h-8 rounded-lg text-xs font-semibold border border-slate-200 dark:border-slate-700 text-slate-600 dark:text-slate-300 hover:text-indigo-600">%{pct}</button>)}</div>
      <Field label={tr ? 'Not' : 'Note'}><input className={inputCls()} value={payDebt.note} onChange={e => setPayDebt({ ...payDebt, note: e.target.value })} placeholder={tr ? 'Havale, nakit…' : 'Transfer, cash…'} /></Field>
      <p className="text-[11px] text-slate-400">{tr ? 'Ödeme finansa otomatik işlenir.' : 'Posted to finance automatically.'}</p>
    </SheetShell>
  );

  // ---------- Sayfa ----------
  return (
    <div className="space-y-5 pb-10">
      <div className="flex flex-col xl:flex-row xl:items-end justify-between gap-4">
        <div>
          <h2 className="text-2xl lg:text-3xl font-black text-slate-900 dark:text-white tracking-tight">{tr ? 'Ön Muhasebe' : 'Accounting'}</h2>
          <p className="text-sm text-slate-500 dark:text-slate-400">{tr ? 'Gelir-gider, KDV, borç-alacak, maaş ve abonelik takibi.' : 'Income, VAT, debts, payroll and subscriptions.'}</p>
        </div>
        <div className="flex flex-wrap items-center gap-2">
          <div className="h-10 px-3 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-900 inline-flex items-center gap-2 text-xs text-slate-500">
            <span>USD <b className="text-slate-800 dark:text-slate-100">₺{rates.TRY?.toFixed(2)}</b></span>
            <span>EUR <b className="text-slate-800 dark:text-slate-100">₺{(rates.TRY / (rates.EUR || 1)).toFixed(2)}</b></span>
            <button onClick={() => onRefreshRates()} title={tr ? 'Kurları yenile' : 'Refresh rates'} className="p-1 rounded-md hover:bg-slate-100 dark:hover:bg-white/5"><RefreshCw size={13} className={loadingRates ? 'animate-spin' : ''} /></button>
          </div>
          <div className="flex p-1 rounded-xl bg-slate-100 dark:bg-slate-800/60" title={tr ? 'Raporlama para birimi' : 'Reporting currency'}>
            {[Currency.TRY, Currency.USD, Currency.EUR].map(c => <button key={c} onClick={() => setRepCur(c)} className={`h-8 w-9 rounded-lg text-xs font-bold ${repCur === c ? 'bg-white dark:bg-slate-900 shadow-sm text-indigo-600' : 'text-slate-500'}`}>{sym(c)}</button>)}
          </div>
          {onOpenSettings && <button onClick={onOpenSettings} title={tr ? 'Finans ayarları' : 'Finance settings'} className="h-10 w-10 rounded-xl border border-slate-200 dark:border-slate-700 text-slate-500 hover:text-indigo-600 inline-flex items-center justify-center"><Settings size={16} /></button>}
          {tab !== 'subscriptions' && (
            <button onClick={() => (tab === 'debts' ? openDebt() : openTx())} className="h-10 px-4 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white text-sm font-semibold inline-flex items-center gap-2 shadow-lg shadow-indigo-500/25"><Plus size={16} /> {newLabel}</button>
          )}
        </div>
      </div>

      {/* Dönem */}
      <div className="flex flex-wrap items-center gap-2">
        <div className="flex p-1 rounded-xl bg-slate-100 dark:bg-slate-800/60 overflow-x-auto">
          {(Object.keys(periodLabel) as Period[]).map(p => <button key={p} onClick={() => setPeriod(p)} className={`shrink-0 h-8 px-3 rounded-lg text-xs font-semibold ${period === p ? 'bg-white dark:bg-slate-900 shadow-sm text-indigo-600' : 'text-slate-500'}`}>{periodLabel[p]}</button>)}
        </div>
        {period === 'custom' && (
          <div className="flex items-center gap-1.5 animate-in fade-in slide-in-from-left-2 duration-200">
            <input type="date" value={custom.from} onChange={e => setCustom({ ...custom, from: e.target.value })} className="h-9 px-2 rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-xs" />
            <span className="text-slate-400">→</span>
            <input type="date" value={custom.to} min={custom.from} onChange={e => setCustom({ ...custom, to: e.target.value })} className="h-9 px-2 rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-xs" />
          </div>
        )}
        {period !== 'all' && <span className="text-xs text-slate-400">{range.from} → {range.to}{prev ? (tr ? ' · önceki döneme göre' : ' · vs previous') : ''}</span>}
      </div>

      {/* KPI */}
      <div className="grid grid-cols-2 lg:grid-cols-3 2xl:grid-cols-6 gap-3 pc-stagger">
        {kpis.map((k: any) => {
          const Icon = k.icon;
          return (
            <button key={k.label} onClick={k.onClick} className={`text-left bg-white dark:bg-slate-900 border border-slate-100 dark:border-slate-800 rounded-[20px] p-4 min-w-0 ${k.onClick ? 'pc-lift' : 'cursor-default'}`}>
              <div className="flex items-center justify-between gap-2"><span className={`p-2 rounded-xl bg-gradient-to-br ${k.grad} text-white shadow-md`}><Icon size={16} /></span>{k.d !== undefined && <DeltaBadge v={k.d} inverse={k.inverse} />}</div>
              <p className="text-[11px] font-semibold text-slate-500 dark:text-slate-400 mt-2.5 truncate">{k.label}</p>
              <p className="text-xl font-black text-slate-900 dark:text-white truncate">{showFinancials ? <AnimatedNumber value={k.value} format={n => fmt(n, repCur)} /> : '••••'}</p>
              <p className="text-[11px] text-slate-400 truncate">{k.sub}</p>
            </button>
          );
        })}
      </div>

      {/* Sekmeler */}
      <div className="flex gap-1 p-1 rounded-2xl bg-white dark:bg-slate-900 border border-slate-100 dark:border-slate-800 overflow-x-auto">
        {tabs.map(t => {
          const Icon = t.icon;
          return (
            <button key={t.key} onClick={() => { setTab(t.key); setSearch(''); }} className={`shrink-0 flex-1 min-w-fit px-3 whitespace-nowrap h-10 rounded-xl text-sm font-semibold inline-flex items-center justify-center gap-2 transition-all ${tab === t.key ? 'bg-indigo-600 text-white shadow-md shadow-indigo-500/25' : 'text-slate-500 hover:bg-slate-50 dark:hover:bg-white/5'}`}>
              <Icon size={15} /> {t.label}{t.badge ? <span className={`text-[10px] px-1.5 rounded-full ${tab === t.key ? 'bg-white/20' : 'bg-slate-100 dark:bg-white/10'}`}>{t.badge}</span> : null}
            </button>
          );
        })}
      </div>

      <div key={tab} className="animate-in fade-in slide-in-from-bottom-2 duration-300">
        {tab === 'overview' && overview()}
        {tab === 'transactions' && transactionsTab()}
        {tab === 'debts' && debtsTab()}
        {tab === 'salaries' && salariesTab()}
        {tab === 'subscriptions' && <SubscriptionsView subscriptions={subscriptions} onUpsertSubscription={onUpsertSubscription} onDeleteSubscription={onDeleteSubscription} language={language} rates={rates} showFinancials={showFinancials} onAddTransaction={onUpsertTransaction} transactions={transactions} defaultCurrency={defaultCur} expenseCategories={expenseCats} />}
      </div>

      {sheet === 'tx' && txSheet()}
      {sheet === 'debt' && debtSheet()}
      {sheet === 'salary' && salarySheet()}
      {sheet === 'payDebt' && payDebtSheet()}
    </div>
  );
};

export default AccountingView;
