import React, { useState, useRef, useEffect } from 'react';
import { Bot, User, Send, X, Loader2, Sparkles, MinusCircle } from 'lucide-react';
import { askCopilot } from '../services/aiService';

interface Message {
  id: string;
  sender: 'ai' | 'user';
  text: string;
  timestamp: number;
}

interface Props {
  contextData: any;
  language: 'tr' | 'en';
}

const CopilotPanel: React.FC<Props> = ({ contextData, language }) => {
  const [isOpen, setIsOpen] = useState(false);
  const [messages, setMessages] = useState<Message[]>([
    {
      id: 'welcome',
      sender: 'ai',
      text: language === 'tr' ? 'Merhaba! Ben Panimo Copilot. Size nasıl yardımcı olabilirim?' : 'Hello! I am Panimo Copilot. How can I help you?',
      timestamp: Date.now()
    }
  ]);
  const [input, setInput] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const scrollToBottom = () => {
    { const box = messagesEndRef.current?.parentElement; if (box) box.scrollTo({ top: box.scrollHeight, behavior: "smooth" }); }
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages, isOpen]);

  const handleSend = async () => {
    if (!input.trim() || isLoading) return;

    const userMsg: Message = { id: Date.now().toString(), sender: 'user', text: input, timestamp: Date.now() };
    setMessages(prev => [...prev, userMsg]);
    setInput('');
    setIsLoading(true);

    try {
      const response = await askCopilot(userMsg.text, contextData, language);
      const aiMsg: Message = { id: (Date.now() + 1).toString(), sender: 'ai', text: response, timestamp: Date.now() };
      setMessages(prev => [...prev, aiMsg]);
    } catch (error) {
      console.error(error);
      const errorMsg: Message = { id: (Date.now() + 1).toString(), sender: 'ai', text: 'Error connecting to Copilot.', timestamp: Date.now() };
      setMessages(prev => [...prev, errorMsg]);
    }

    setIsLoading(false);
  };

  if (!isOpen) {
    return (
      <button
        onClick={() => setIsOpen(true)}
        className="fixed bottom-6 right-6 z-[9999] p-4 bg-indigo-600 text-white rounded-full shadow-2xl hover:bg-indigo-700 transition-all hover:scale-110 flex items-center justify-center animate-bounce"
        style={{ animationDuration: '3s' }}
      >
        <Sparkles size={28} />
      </button>
    );
  }

  return (
    <div className="fixed bottom-6 right-6 z-[9999] w-80 sm:w-[400px] h-[550px] bg-slate-900 border border-indigo-500/30 shadow-2xl rounded-2xl flex flex-col overflow-hidden animate-in fade-in slide-in-from-bottom-5 duration-300">
      {/* Header */}
      <div className="bg-indigo-600 p-4 flex justify-between items-center text-white">
        <div className="flex items-center gap-3">
          <Bot size={24} />
          <div>
            <h3 className="font-bold text-sm">Panimo Copilot</h3>
            <p className="text-[10px] text-indigo-200">AI Assistant</p>
          </div>
        </div>
        <button onClick={() => setIsOpen(false)} className="text-indigo-200 hover:text-white transition-colors">
          <MinusCircle size={20} />
        </button>
      </div>

      {/* Messages */}
      <div className="flex-1 overflow-y-auto p-4 space-y-4 bg-slate-900/50">
        {messages.map(msg => (
          <div key={msg.id} className={`flex ${msg.sender === 'user' ? 'justify-end' : 'justify-start'}`}>
            <div className={`p-3 rounded-2xl max-w-[85%] text-sm ${msg.sender === 'user' ? 'bg-indigo-500 text-white rounded-br-none' : 'bg-slate-800 border border-slate-700 text-slate-200 rounded-bl-none'}`}>
              <div className="whitespace-pre-wrap">{msg.text}</div>
              <div className={`text-[9px] mt-1 text-right ${msg.sender === 'user' ? 'text-indigo-200' : 'text-slate-400'}`}>
                {new Date(msg.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
              </div>
            </div>
          </div>
        ))}
        {isLoading && (
          <div className="flex justify-start">
            <div className="bg-slate-800 border border-slate-700 p-3 rounded-2xl rounded-bl-none">
              <Loader2 size={16} className="text-indigo-400 animate-spin" />
            </div>
          </div>
        )}
        <div ref={messagesEndRef} />
      </div>

      {/* Input */}
      <div className="p-3 bg-slate-800 border-t border-slate-700">
        <div className="flex items-end gap-2 bg-slate-900 border border-slate-700 rounded-xl p-1 focus-within:border-indigo-500 transition-colors">
          <textarea
            value={input}
            onChange={(e) => setInput(e.target.value)}
            onKeyDown={(e) => {
              if (e.key === 'Enter' && !e.shiftKey) {
                e.preventDefault();
                handleSend();
              }
            }}
            placeholder={language === 'tr' ? 'Bir şeyler sorun...' : 'Ask something...'}
            className="flex-1 bg-transparent border-none text-white text-sm outline-none px-3 py-2 resize-none max-h-24 min-h-[40px] placeholder:text-slate-500"
            rows={1}
          />
          <button
            onClick={handleSend}
            disabled={!input.trim() || isLoading}
            className="p-3 bg-indigo-600 text-white rounded-lg hover:bg-indigo-500 disabled:opacity-50 disabled:hover:bg-indigo-600 transition-colors disabled:cursor-not-allowed m-1"
          >
            <Send size={16} />
          </button>
        </div>
      </div>
    </div>
  );
};

export default CopilotPanel;
