import React, { useEffect, useState } from 'react';
import { Search, Bell, Gauge, ChevronRight, Command, Menu } from 'lucide-react';
import { User } from '../types';

interface Props {
  language: 'tr' | 'en';
  section?: string;
  title: string;
  icon?: React.ReactNode;
  currentUser: User;
  alertCount: number;
  criticalCount: number;
  canSeeOps: boolean;
  onOpenPalette: () => void;
  onOpenNotifications: () => void;
  onOpenOps: () => void;
  onOpenMenu?: () => void;
}

const TopBar: React.FC<Props> = ({ language, section, title, icon, currentUser, alertCount, criticalCount, canSeeOps, onOpenPalette, onOpenNotifications, onOpenOps, onOpenMenu }) => {
  const tr = language === 'tr';
  const [now, setNow] = useState(new Date());
  const isMac = typeof navigator !== 'undefined' && /Mac|iPhone|iPad/.test(navigator.platform);

  useEffect(() => {
    const t = setInterval(() => setNow(new Date()), 15000);
    return () => clearInterval(t);
  }, []);

  return (
    <header
      className="relative z-30 -mx-4 lg:-mx-8 -mt-4 lg:-mt-8 mb-4 lg:mb-6 px-3 sm:px-4 lg:px-8 pb-3 bg-white/80 dark:bg-[#020617]/80 backdrop-blur-xl border-b border-slate-200/60 dark:border-white/5 animate-in fade-in slide-in-from-top-2 duration-500"
      style={{ paddingTop: 'max(env(safe-area-inset-top, 0px) + 0.75rem, 0.75rem)' }}
    >
      <div className="flex items-center gap-2 sm:gap-3">
        {/* Mobil menü */}
        {onOpenMenu && (
          <button onClick={onOpenMenu} className="lg:hidden shrink-0 p-2.5 rounded-xl bg-[#020617] text-white dark:bg-white/10 shadow-lg" aria-label="Menu">
            <Menu size={18} />
          </button>
        )}
        {/* Breadcrumb */}
        <div className="flex items-center gap-2 min-w-0 flex-1" key={title}>
          {icon && <span className="hidden sm:flex shrink-0 p-2 rounded-xl bg-indigo-600 text-white shadow-lg shadow-indigo-500/30 animate-in zoom-in spin-in duration-500">{icon}</span>}
          <div className="min-w-0 animate-in fade-in slide-in-from-left-2 duration-500">
            {section && (
              <p className="hidden sm:flex items-center gap-1 text-[9px] font-black uppercase tracking-[0.25em] text-slate-400">
                PanimoCloud <ChevronRight size={10} /> {section}
              </p>
            )}
            <h2 className="text-base lg:text-lg font-black text-slate-900 dark:text-white truncate leading-tight">{title}</h2>
          </div>
        </div>

        {/* Search */}
        <button
          onClick={onOpenPalette}
          className="group hidden md:flex items-center gap-2 w-64 lg:w-80 px-3 py-2 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 text-slate-400 hover:border-indigo-300 dark:hover:border-indigo-500/40 hover:shadow-lg hover:shadow-indigo-500/10"
        >
          <Search size={16} className="text-slate-400 group-hover:text-indigo-500 transition-colors" />
          <span className="text-sm font-medium flex-1 text-left">{tr ? 'Ara veya komut…' : 'Search or command…'}</span>
          <kbd className="flex items-center gap-0.5 text-[10px] font-black border border-slate-200 dark:border-slate-700 rounded-md px-1.5 py-0.5">
            {isMac ? <Command size={10} /> : 'Ctrl'} K
          </kbd>
        </button>
        <button onClick={onOpenPalette} className="md:hidden shrink-0 p-2.5 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 text-slate-500" aria-label="Search">
          <Search size={18} />
        </button>

        {/* Ops health */}
        {canSeeOps && (
          <button
            onClick={onOpenOps}
            title={tr ? 'Yönetim Merkezi' : 'Operations Center'}
            className={`relative shrink-0 flex items-center gap-1.5 sm:gap-2 px-2.5 sm:px-3 py-2 rounded-xl sm:rounded-2xl border text-xs font-black ${criticalCount > 0 ? 'bg-rose-500/10 border-rose-500/20 text-rose-600 dark:text-rose-400' : 'bg-emerald-500/10 border-emerald-500/20 text-emerald-600 dark:text-emerald-400'}`}
          >
            <Gauge size={16} className={criticalCount > 0 ? 'animate-pulse' : ''} />
            <span className="sm:hidden">{criticalCount > 0 ? criticalCount : '✓'}</span>
            <span className="hidden sm:inline">{criticalCount > 0 ? `${criticalCount} ${tr ? 'kritik' : 'critical'}` : (tr ? 'Stabil' : 'Stable')}</span>
          </button>
        )}

        {/* Notifications */}
        <button onClick={onOpenNotifications} className="relative shrink-0 p-2.5 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 text-slate-500 hover:text-indigo-600" aria-label="Notifications">
          <Bell size={18} className={alertCount > 0 ? 'origin-top animate-[pc-bell_2.4s_ease-in-out_infinite]' : ''} />
          {alertCount > 0 && (
            <span key={alertCount} className="absolute -top-1.5 -right-1.5 min-w-[20px] h-5 px-1 rounded-full bg-rose-500 text-white text-[10px] font-black flex items-center justify-center ring-2 ring-slate-50 dark:ring-[#020617] animate-in zoom-in-50 duration-300">
              {alertCount > 99 ? '99+' : alertCount}
            </span>
          )}
        </button>

        {/* User */}
        <div className="hidden lg:flex items-center gap-3 pl-3 border-l border-slate-200 dark:border-slate-800">
          <div className="text-right">
            <p className="text-sm font-black text-slate-800 dark:text-white leading-tight">{currentUser.name}</p>
            <p className="text-[10px] font-bold text-slate-400 tabular-nums">
              {currentUser.jobTitle || currentUser.role} · {now.toLocaleTimeString(tr ? 'tr-TR' : 'en-US', { hour: '2-digit', minute: '2-digit' })}
            </p>
          </div>
          <div className="relative">
            {currentUser.avatar
              ? <img src={currentUser.avatar} alt="" className="w-10 h-10 rounded-2xl object-cover ring-2 ring-indigo-500/30" />
              : <div className="w-10 h-10 rounded-2xl bg-gradient-to-br from-indigo-500 to-orange-500 text-white flex items-center justify-center font-black">{currentUser.name?.[0]}</div>}
            <span className="absolute -bottom-0.5 -right-0.5 w-3 h-3 rounded-full bg-emerald-500 border-2 border-slate-50 dark:border-[#020617]" />
          </div>
        </div>
      </div>
    </header>
  );
};

export default TopBar;
