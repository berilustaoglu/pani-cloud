import React, { useEffect, useMemo, useState } from 'react';
import {
  Plus, Search, X, Edit2, Trash2, Brain, List, Columns3, AlertTriangle, Clock, ListTodo, CheckSquare, Ban, Users as UsersIcon,
  SlidersHorizontal, ArrowUpDown, ChevronRight, CheckCircle2, UserX, Layers, Link2
} from 'lucide-react';
import { Task, TaskStatus, Project, User } from '../types';
import TaskModal, { TASK_STATUS_META } from './TaskModal';
import AutoAssignAssistant from './AutoAssignAssistant';
import ModalPortal from './ModalPortal';
import { AnimatedNumber, GrowBar } from './ui/Motion';
import { dayDiff, isProjectSuspended } from '../services/insights';
import { daysLeftText } from '../services/projectMetrics';
import { toast } from '../services/toast';

interface Props {
  tasks: Task[];
  setTasks: (task: Task | any) => Promise<void>;
  projects: Project[];
  users: User[];
  language: 'tr' | 'en';
  onUpdateProject?: (project: Project) => Promise<void>;
  onDeleteTask?: (id: string) => Promise<void>;
  initialView?: 'list' | 'board';
}

type Sort = 'deadline' | 'project' | 'status' | 'title' | 'progress';
type Group = 'none' | 'project' | 'assignee' | 'status';
const COLS = [TaskStatus.TODO, TaskStatus.DOING, TaskStatus.BLOCKED, TaskStatus.DONE];
const STATUS_ORDER: Record<string, number> = { [TaskStatus.BLOCKED]: 0, [TaskStatus.DOING]: 1, [TaskStatus.TODO]: 2, [TaskStatus.DONE]: 3 };
const pref = <T,>(k: string, d: T): T => { try { const v = localStorage.getItem(k); return v ? JSON.parse(v) : d; } catch { return d; } };

const TasksView: React.FC<Props> = ({ tasks, setTasks, projects, users, language, onUpdateProject, onDeleteTask, initialView }) => {
  const tr = language === 'tr';
  const [view, setView] = useState<'list' | 'board'>(() => initialView || pref('pc-tasks-view', 'list'));
  useEffect(() => { if (initialView) setView(initialView); }, [initialView]);
  const [sort, setSort] = useState<Sort>(() => pref('pc-tasks-sort', 'deadline'));
  const [group, setGroup] = useState<Group>(() => pref('pc-tasks-group', 'none'));
  const [search, setSearch] = useState('');
  const [projectF, setProjectF] = useState('all');
  const [userF, setUserF] = useState('all');
  const [statusF, setStatusF] = useState<TaskStatus[]>([TaskStatus.TODO, TaskStatus.DOING, TaskStatus.BLOCKED]);
  const [quick, setQuick] = useState<'none' | 'overdue' | 'soon' | 'unassigned'>('none');
  const [showFilters, setShowFilters] = useState(false);
  const [selected, setSelected] = useState<string[]>([]);
  const [confirmBulkDelete, setConfirmBulkDelete] = useState(false);
  const [confirmDel, setConfirmDel] = useState<string | null>(null);
  const [modal, setModal] = useState<{ open: boolean; task: Task | null; defaults?: Partial<Task> }>({ open: false, task: null });
  const [aiTask, setAiTask] = useState<Task | null>(null);
  const [dragId, setDragId] = useState<string | null>(null);
  const [dropCol, setDropCol] = useState<TaskStatus | null>(null);
  const [expanded, setExpanded] = useState<string[]>([]);
  const BOARD_LIMIT = 5;

  useEffect(() => { try { if (!initialView) localStorage.setItem('pc-tasks-view', JSON.stringify(view)); localStorage.setItem('pc-tasks-sort', JSON.stringify(sort)); localStorage.setItem('pc-tasks-group', JSON.stringify(group)); } catch {} }, [view, sort, group, initialView]);

  const projectById = useMemo(() => new Map(projects.map(p => [p.id, p])), [projects]);
  const userById = useMemo(() => new Map(users.map(u => [u.id, u])), [users]);
  // Askıdaki projelerin görevleri askı süresince gecikmiş sayılmaz
  const isOverdue = (t: Task) => t.status !== TaskStatus.DONE && (dayDiff(t.deadline) ?? 1) < 0 && !isProjectSuspended(projectById.get(t.projectId));
  const isSoon = (t: Task) => { const d = dayDiff(t.deadline); return t.status !== TaskStatus.DONE && d !== null && d >= 0 && d <= 2; };

  // ---------- Kaydetme + proje ilerlemesi ----------
  const updateProjectProgress = async (projectId: string, list: Task[]) => {
    if (!onUpdateProject) return;
    const project = projectById.get(projectId);
    if (!project) return;
    const progress = Math.min(100, list.filter(t => t.projectId === projectId && t.status === TaskStatus.DONE).reduce((s, t) => s + (t.progress || 0), 0));
    const allPaid = project.installments.length === 0 || project.installments.every(i => i.isPaid);
    await onUpdateProject({ ...project, progress, status: progress === 100 && allPaid ? 'Completed' : project.status });
  };
  const saveTask = async (task: Task) => {
    await setTasks(task);
    const next = tasks.some(t => t.id === task.id) ? tasks.map(t => (t.id === task.id ? task : t)) : [...tasks, task];
    await updateProjectProgress(task.projectId, next);
  };
  const changeStatus = async (task: Task, status: TaskStatus) => {
    if (task.status === status) return;
    if (status === TaskStatus.BLOCKED && !task.blockedReason) { setModal({ open: true, task: { ...task, status } }); return; }
    if (task.dependencyId && status !== TaskStatus.TODO) {
      const dep = tasks.find(t => t.id === task.dependencyId);
      if (dep && dep.status !== TaskStatus.DONE) toast.warning(tr ? `Uyarı: bağlı olduğu "${dep.title}" görevi henüz bitmedi` : `Dependency "${dep.title}" not done yet`);
    }
    await saveTask({ ...task, status });
    toast(tr ? `"${task.title}" → ${TASK_STATUS_META[status].tr}` : `"${task.title}" → ${TASK_STATUS_META[status].en}`, status === TaskStatus.DONE ? 'success' : 'info', 2200);
  };

  // ---------- Filtreleme ----------
  const filtered = useMemo(() => {
    const q = search.trim().toLocaleLowerCase('tr-TR');
    const list = tasks.filter(t => {
      if (view === 'list' && !statusF.includes(t.status)) return false;
      if (projectF !== 'all' && t.projectId !== projectF) return false;
      if (userF === 'none' ? (t.assignedTo || []).length > 0 : userF !== 'all' && !(t.assignedTo || []).includes(userF)) return false;
      if (quick === 'overdue' && !isOverdue(t)) return false;
      if (quick === 'soon' && !isSoon(t)) return false;
      if (quick === 'unassigned' && (t.assignedTo || []).length > 0) return false;
      if (q && ![t.title, t.notes, t.managerNotes, projectById.get(t.projectId)?.name].join(' ').toLocaleLowerCase('tr-TR').includes(q)) return false;
      return true;
    });
    return list.sort((a, b) => {
      switch (sort) {
        case 'deadline': return (a.deadline || '9999').localeCompare(b.deadline || '9999');
        case 'project': return (projectById.get(a.projectId)?.name || '').localeCompare(projectById.get(b.projectId)?.name || '', 'tr');
        case 'status': return STATUS_ORDER[a.status] - STATUS_ORDER[b.status];
        case 'title': return a.title.localeCompare(b.title, 'tr');
        case 'progress': return (b.progress || 0) - (a.progress || 0);
      }
    });
  }, [tasks, view, statusF, projectF, userF, quick, search, sort, projectById]);

  const stats = useMemo(() => {
    const open = tasks.filter(t => t.status !== TaskStatus.DONE);
    return {
      open: open.length,
      overdue: open.filter(isOverdue).length,
      soon: open.filter(isSoon).length,
      blocked: open.filter(t => t.status === TaskStatus.BLOCKED).length,
      unassigned: open.filter(t => !(t.assignedTo || []).length).length,
      doneRate: tasks.length ? Math.round(((tasks.length - open.length) / tasks.length) * 100) : 0,
    };
  }, [tasks]);

  const filterCount = [projectF !== 'all', userF !== 'all', quick !== 'none', view === 'list' && statusF.length !== 3].filter(Boolean).length;
  const clearFilters = () => { setProjectF('all'); setUserF('all'); setQuick('none'); setStatusF([TaskStatus.TODO, TaskStatus.DOING, TaskStatus.BLOCKED]); setSearch(''); };
  useEffect(() => { setSelected(s => s.filter(id => filtered.some(t => t.id === id))); }, [filtered]);

  // ---------- Toplu işlemler ----------
  const bulk = async (fn: (t: Task) => Task | null, msg: string) => {
    const items = tasks.filter(t => selected.includes(t.id));
    for (const t of items) { const n = fn(t); if (n) await setTasks(n); }
    const touched = new Set(items.map(t => t.projectId));
    const next = tasks.map(t => (selected.includes(t.id) ? fn(t) || t : t));
    for (const pid of touched) await updateProjectProgress(pid, next);
    toast.success(msg);
    setSelected([]);
  };
  const bulkDelete = async () => {
    if (!onDeleteTask) return;
    for (const id of selected) await onDeleteTask(id);
    toast(tr ? `${selected.length} görev silindi` : `${selected.length} tasks deleted`, 'info');
    setSelected([]); setConfirmBulkDelete(false);
  };

  // ---------- Parçalar ----------
  const avatars = (ids: string[], size = 'w-7 h-7') => {
    const people = ids.map(id => userById.get(id)).filter(Boolean) as User[];
    if (!people.length) return <span className="text-[11px] text-amber-600 dark:text-amber-400 inline-flex items-center gap-1"><UserX size={12} />{tr ? 'Atanmadı' : 'Unassigned'}</span>;
    return (
      <div className="flex -space-x-1.5">
        {people.slice(0, 3).map(u => u.avatar
          ? <img key={u.id} src={u.avatar} alt={u.name} title={u.name} className={`${size} rounded-full object-cover ring-2 ring-white dark:ring-slate-900`} />
          : <span key={u.id} title={u.name} className={`${size} rounded-full ring-2 ring-white dark:ring-slate-900 bg-gradient-to-br from-indigo-500 to-violet-500 text-white text-[10px] font-bold flex items-center justify-center`}>{u.name?.[0]}</span>)}
        {people.length > 3 && <span className={`${size} rounded-full ring-2 ring-white dark:ring-slate-900 bg-slate-100 dark:bg-slate-800 text-[10px] font-bold flex items-center justify-center`}>+{people.length - 3}</span>}
      </div>
    );
  };
  const deadline = (t: Task) => {
    const d = dayDiff(t.deadline);
    if (t.status === TaskStatus.DONE) return <span className="text-slate-400">{new Date(t.deadline).toLocaleDateString(tr ? 'tr-TR' : 'en-US', { day: 'numeric', month: 'short' })}</span>;
    const cls = d === null ? 'text-slate-400' : d < 0 ? 'text-rose-600 dark:text-rose-400' : d <= 2 ? 'text-amber-600 dark:text-amber-400' : 'text-slate-600 dark:text-slate-300';
    return <span className={cls}>{daysLeftText(d, language)}</span>;
  };
  const checklist = (t: Task) => {
    const total = t.checklist?.length || 0;
    if (!total) return null;
    const done = t.checklist!.filter(c => c.isCompleted).length;
    return <span className={`inline-flex items-center gap-1 text-[11px] font-semibold ${done === total ? 'text-emerald-600' : 'text-slate-500'}`}><ListTodo size={12} />{done}/{total}</span>;
  };
  const statusPicker = (t: Task) => (
    <select value={t.status} onClick={e => e.stopPropagation()} onChange={e => changeStatus(t, e.target.value as TaskStatus)}
      className={`h-7 pl-2 pr-6 rounded-lg text-[11px] font-semibold border-0 outline-none cursor-pointer appearance-none bg-no-repeat ${TASK_STATUS_META[t.status].chip}`}
      style={{ backgroundImage: 'url("data:image/svg+xml,%3Csvg xmlns=\'http://www.w3.org/2000/svg\' width=\'10\' height=\'10\' viewBox=\'0 0 24 24\' fill=\'none\' stroke=\'%2394a3b8\' stroke-width=\'3\'%3E%3Cpath d=\'m6 9 6 6 6-6\'/%3E%3C/svg%3E")', backgroundPosition: 'right 6px center' }}>
      {Object.values(TaskStatus).map(s => <option key={s} value={s}>{tr ? TASK_STATUS_META[s].tr : TASK_STATUS_META[s].en}</option>)}
    </select>
  );
  const rowActions = (t: Task) => confirmDel === t.id ? (
    <span className="inline-flex items-center gap-1 animate-in fade-in zoom-in-95 duration-150" onClick={e => e.stopPropagation()}>
      <button onClick={() => setConfirmDel(null)} className="h-7 px-2 rounded-lg text-[11px] font-semibold text-slate-500 hover:bg-slate-100 dark:hover:bg-white/5">{tr ? 'Vazgeç' : 'Cancel'}</button>
      <button onClick={async () => { await onDeleteTask?.(t.id); setConfirmDel(null); toast(tr ? 'Görev silindi' : 'Deleted', 'info', 2000); }} className="h-7 px-2 rounded-lg text-[11px] font-semibold text-white bg-rose-600">{tr ? 'Sil' : 'Delete'}</button>
    </span>
  ) : (
    <span className="inline-flex items-center opacity-100 lg:opacity-0 lg:group-hover:opacity-100 transition-opacity" onClick={e => e.stopPropagation()}>
      <button onClick={() => setAiTask(t)} title={tr ? 'Yapay zeka ile ata' : 'AI assign'} className="p-1.5 rounded-lg text-slate-400 hover:text-violet-600 hover:bg-violet-50 dark:hover:bg-white/5"><Brain size={14} /></button>
      <button onClick={() => setModal({ open: true, task: t })} title={tr ? 'Düzenle' : 'Edit'} className="p-1.5 rounded-lg text-slate-400 hover:text-indigo-600 hover:bg-indigo-50 dark:hover:bg-white/5"><Edit2 size={14} /></button>
      {onDeleteTask && <button onClick={() => setConfirmDel(t.id)} title={tr ? 'Sil' : 'Delete'} className="p-1.5 rounded-lg text-slate-400 hover:text-rose-600 hover:bg-rose-50 dark:hover:bg-white/5"><Trash2 size={14} /></button>}
    </span>
  );

  const row = (t: Task) => {
    const sel = selected.includes(t.id);
    const p = projectById.get(t.projectId);
    const dep = t.dependencyId ? tasks.find(x => x.id === t.dependencyId) : undefined;
    return (
      <div key={t.id} onClick={() => setModal({ open: true, task: t })}
        className={`group grid grid-cols-12 items-center gap-3 px-3 py-2.5 rounded-xl cursor-pointer transition-colors ${sel ? 'bg-indigo-50/70 dark:bg-indigo-500/10' : 'hover:bg-slate-50 dark:hover:bg-white/[0.03]'} ${isOverdue(t) ? 'border-l-2 border-rose-400' : ''}`}>
        <div className="col-span-12 md:col-span-5 flex items-center gap-3 min-w-0">
          <button onClick={e => { e.stopPropagation(); setSelected(s => (s.includes(t.id) ? s.filter(x => x !== t.id) : [...s, t.id])); }}
            className={`w-[18px] h-[18px] shrink-0 rounded-md border-2 flex items-center justify-center transition-all ${sel ? 'bg-indigo-600 border-indigo-600' : 'border-slate-300 dark:border-slate-600 hover:border-indigo-400'}`}>{sel && <CheckCircle2 size={12} className="text-white" />}</button>
          <button onClick={e => { e.stopPropagation(); changeStatus(t, t.status === TaskStatus.DONE ? TaskStatus.TODO : TaskStatus.DONE); }} title={tr ? 'Tamamlandı olarak işaretle' : 'Toggle done'}
            className={`w-5 h-5 shrink-0 rounded-full border-2 flex items-center justify-center transition-all ${t.status === TaskStatus.DONE ? 'bg-emerald-500 border-emerald-500 text-white' : 'border-slate-300 dark:border-slate-600 text-transparent hover:border-emerald-400 hover:text-emerald-400'}`}><CheckCircle2 size={12} /></button>
          <div className="min-w-0">
            <p className={`text-sm font-semibold truncate ${t.status === TaskStatus.DONE ? 'line-through text-slate-400' : 'text-slate-800 dark:text-slate-100'}`}>{t.title}</p>
            <p className="text-[11px] text-slate-400 truncate flex items-center gap-1.5">
              <span className="truncate">{p?.name || '—'}</span>
              {t.status === TaskStatus.BLOCKED && t.blockedReason && <span className="text-rose-500 truncate">· {t.blockedReason}</span>}
              {dep && <span className={`inline-flex items-center gap-0.5 ${dep.status === TaskStatus.DONE ? 'text-emerald-500' : 'text-amber-500'}`}><Link2 size={10} />{dep.title}</span>}
            </p>
          </div>
        </div>
        <div className="col-span-4 md:col-span-2">{statusPicker(t)}</div>
        <div className="col-span-4 md:col-span-2 text-xs font-semibold flex items-center gap-1"><Clock size={12} className="text-slate-400" />{deadline(t)}</div>
        <div className="hidden md:flex md:col-span-1 items-center gap-2">{checklist(t)}{t.progress ? <span className="text-[10px] font-semibold text-slate-400">%{t.progress}</span> : null}</div>
        <div className="col-span-4 md:col-span-2 flex items-center justify-end gap-2">{avatars(t.assignedTo || [], 'w-6 h-6')}{rowActions(t)}</div>
      </div>
    );
  };

  const groups = useMemo(() => {
    if (group === 'none') return [{ key: 'all', label: '', items: filtered }];
    const map = new Map<string, { label: string; items: Task[] }>();
    filtered.forEach(t => {
      const keys = group === 'project' ? [t.projectId] : group === 'status' ? [t.status] : ((t.assignedTo || []).length ? t.assignedTo : ['__none']);
      keys.forEach(k => {
        const label = group === 'project' ? (projectById.get(k)?.name || '—') : group === 'status' ? (tr ? TASK_STATUS_META[k as TaskStatus].tr : TASK_STATUS_META[k as TaskStatus].en) : (k === '__none' ? (tr ? 'Atanmamış' : 'Unassigned') : userById.get(k)?.name || '—');
        if (!map.has(k)) map.set(k, { label, items: [] });
        map.get(k)!.items.push(t);
      });
    });
    return [...map.entries()].map(([key, v]) => ({ key, ...v })).sort((a, b) => b.items.length - a.items.length);
  }, [filtered, group, projectById, userById, tr]);

  const listView = () => (
    <div className="bg-white dark:bg-slate-900 border border-slate-100 dark:border-slate-800 rounded-[20px] p-2 sm:p-3">
      {filtered.length === 0 ? (
        <div className="py-14 text-center text-slate-400 animate-in fade-in"><CheckSquare size={36} className="mx-auto mb-2 opacity-40 pc-float" /><p className="text-sm font-semibold">{filterCount || search ? (tr ? 'Filtrelere uyan görev yok' : 'No tasks match') : (tr ? 'Henüz görev yok' : 'No tasks yet')}</p>
          {(filterCount > 0 || search) ? <button onClick={clearFilters} className="mt-2 text-xs font-semibold text-indigo-600 hover:underline">{tr ? 'Filtreleri temizle' : 'Clear filters'}</button> : <button onClick={() => setModal({ open: true, task: null })} className="mt-2 text-xs font-semibold text-indigo-600 hover:underline">{tr ? 'İlk görevi oluştur' : 'Create first task'}</button>}</div>
      ) : (
        <>
          <div className="hidden md:grid grid-cols-12 gap-3 px-3 pb-2 text-[10px] font-black uppercase tracking-widest text-slate-400 border-b border-slate-100 dark:border-slate-800">
            <span className="col-span-5 flex items-center gap-3">
              <button onClick={() => setSelected(selected.length === filtered.length ? [] : filtered.map(t => t.id))} className={`w-[18px] h-[18px] rounded-md border-2 flex items-center justify-center ${selected.length && selected.length === filtered.length ? 'bg-indigo-600 border-indigo-600' : 'border-slate-300 dark:border-slate-600'}`}>{selected.length > 0 && <span className={`w-2 h-0.5 ${selected.length === filtered.length ? 'bg-white' : 'bg-indigo-600'}`} />}</button>
              {tr ? 'Görev' : 'Task'}
            </span>
            <span className="col-span-2">{tr ? 'Durum' : 'Status'}</span><span className="col-span-2">{tr ? 'Son tarih' : 'Deadline'}</span><span className="col-span-1">{tr ? 'Liste' : 'List'}</span><span className="col-span-2 text-right">{tr ? 'Atanan' : 'Assignee'}</span>
          </div>
          <div className="space-y-4 pt-2" key={`${group}-${sort}`}>
            {groups.map(g => (
              <div key={g.key}>
                {group !== 'none' && <p className="px-3 py-1.5 text-xs font-bold text-slate-700 dark:text-slate-200 flex items-center gap-2"><Layers size={13} className="text-indigo-500" />{g.label}<span className="text-[10px] font-semibold px-1.5 rounded-md bg-slate-100 dark:bg-white/5 text-slate-500">{g.items.length}</span></p>}
                <div className="pc-stagger">{g.items.map(row)}</div>
              </div>
            ))}
          </div>
        </>
      )}
    </div>
  );

  const card = (t: Task) => {
    const p = projectById.get(t.projectId);
    const overdue = isOverdue(t);
    const total = t.checklist?.length || 0;
    const done = t.checklist?.filter(c => c.isCompleted).length || 0;
    return (
      <div key={t.id} draggable onDragStart={e => { setDragId(t.id); e.dataTransfer.effectAllowed = 'move'; }} onDragEnd={() => { setDragId(null); setDropCol(null); }}
        onClick={() => setModal({ open: true, task: t })}
        className={`group relative bg-white dark:bg-slate-900 border rounded-2xl p-3.5 cursor-grab active:cursor-grabbing transition-all hover:shadow-lg hover:shadow-slate-200/60 dark:hover:shadow-none ${overdue ? 'border-rose-200 dark:border-rose-500/30' : 'border-slate-100 dark:border-slate-800 hover:border-indigo-200 dark:hover:border-indigo-500/30'} ${dragId === t.id ? 'opacity-40 scale-95' : ''}`}>
        <div className="absolute top-2.5 right-2.5">{rowActions(t)}</div>
        <div className="flex flex-wrap gap-1 pr-20 mb-1.5">
          <span className="text-[10px] font-semibold px-1.5 py-0.5 rounded-md bg-indigo-50 dark:bg-indigo-500/10 text-indigo-600 dark:text-indigo-300 truncate max-w-[160px]">{p?.name || '—'}</span>
          {overdue && <span className="text-[10px] font-semibold px-1.5 py-0.5 rounded-md bg-rose-50 text-rose-700 dark:bg-rose-500/10 dark:text-rose-300 inline-flex items-center gap-0.5"><AlertTriangle size={10} />{tr ? 'Gecikti' : 'Late'}</span>}
        </div>
        <h4 className="text-sm font-semibold text-slate-800 dark:text-slate-100 leading-snug line-clamp-3">{t.title}</h4>
        {t.status === TaskStatus.BLOCKED && t.blockedReason && <p className="mt-1 text-[11px] text-rose-600 dark:text-rose-400 line-clamp-2 flex items-start gap-1"><Ban size={11} className="mt-0.5 shrink-0" />{t.blockedReason}</p>}
        {total > 0 && <div className="mt-2.5"><div className="h-1 rounded-full bg-slate-100 dark:bg-white/5"><div className="h-full rounded-full bg-gradient-to-r from-emerald-400 to-teal-500" style={{ width: `${(done / total) * 100}%` }} /></div></div>}
        <div className="flex items-center justify-between mt-3 text-[11px] font-semibold">
          <span className="inline-flex items-center gap-2"><span className="inline-flex items-center gap-1"><Clock size={11} className="text-slate-400" />{deadline(t)}</span>{checklist(t)}</span>
          {avatars(t.assignedTo || [], 'w-6 h-6')}
        </div>
      </div>
    );
  };

  const boardView = () => (
    <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-4 gap-4 items-start">
      {COLS.map(s => {
        const items = filtered.filter(t => t.status === s);
        const isDrop = dropCol === s && dragId && tasks.find(x => x.id === dragId)?.status !== s;
        const shown = expanded.includes(s) ? items : items.slice(0, BOARD_LIMIT);
        return (
          <div key={s} onDragOver={e => { if (dragId) { e.preventDefault(); setDropCol(s); } }} onDragLeave={() => setDropCol(c => (c === s ? null : c))}
            onDrop={e => { e.preventDefault(); const t = tasks.find(x => x.id === dragId); if (t) changeStatus(t, s); setDragId(null); setDropCol(null); }}
            className={`rounded-[20px] p-3 transition-all duration-200 ${isDrop ? 'bg-indigo-50 dark:bg-indigo-500/10 ring-2 ring-indigo-400 scale-[1.01]' : 'bg-slate-100/70 dark:bg-white/[0.03]'}`}>
            <div className="flex items-center justify-between px-1 mb-3">
              <div className="flex items-center gap-2">
                <span className={`w-2.5 h-2.5 rounded-full bg-gradient-to-br ${TASK_STATUS_META[s].col}`} />
                <p className="text-sm font-bold text-slate-800 dark:text-slate-100">{tr ? TASK_STATUS_META[s].tr : TASK_STATUS_META[s].en}</p>
                <span className="text-[11px] font-semibold px-1.5 rounded-md bg-white dark:bg-slate-800 text-slate-500">{items.length}</span>
              </div>
              {s !== TaskStatus.DONE && <button onClick={() => setModal({ open: true, task: null, defaults: { status: s, projectId: projectF !== 'all' ? projectF : undefined } })} title={tr ? 'Bu sütuna görev ekle' : 'Add here'} className="p-1 rounded-md text-slate-400 hover:text-indigo-600 hover:bg-white dark:hover:bg-slate-800"><Plus size={15} /></button>}
            </div>
            <div className="space-y-2.5 min-h-[80px] pc-stagger">
              {shown.map(card)}
              {items.length > BOARD_LIMIT && (
                <button onClick={() => setExpanded(c => (c.includes(s) ? c.filter(x => x !== s) : [...c, s]))} className="w-full h-9 rounded-xl text-xs font-semibold text-slate-500 hover:text-indigo-600 bg-white/70 dark:bg-slate-800/60 border border-dashed border-slate-200 dark:border-slate-700 inline-flex items-center justify-center gap-1">
                  {expanded.includes(s) ? (tr ? 'Daha az göster' : 'Show less') : (tr ? `+${items.length - BOARD_LIMIT} görev daha` : `Show ${items.length - BOARD_LIMIT} more`)}
                  <ChevronRight size={12} className={expanded.includes(s) ? '-rotate-90' : 'rotate-90'} />
                </button>
              )}
              {!items.length && <div className="h-20 rounded-xl border-2 border-dashed border-slate-200 dark:border-slate-700 flex items-center justify-center text-[11px] text-slate-400">{dragId ? (tr ? 'Buraya bırak' : 'Drop here') : (tr ? 'Boş' : 'Empty')}</div>}
            </div>
          </div>
        );
      })}
    </div>
  );

  const kpis = [
    { label: tr ? 'Açık görev' : 'Open', value: stats.open, sub: `${tr ? 'Tamamlanma' : 'Done'} %${stats.doneRate}`, icon: CheckSquare, grad: 'from-indigo-500 to-violet-600', bar: stats.doneRate, onClick: () => { setQuick('none'); } },
    { label: tr ? 'Gecikmiş' : 'Overdue', value: stats.overdue, sub: tr ? 'Son tarihi geçenler' : 'Past deadline', icon: AlertTriangle, grad: 'from-rose-500 to-orange-500', bar: stats.open ? (stats.overdue / stats.open) * 100 : 0, onClick: () => setQuick(q => (q === 'overdue' ? 'none' : 'overdue')), active: quick === 'overdue' },
    { label: tr ? '48 saat içinde' : 'Due in 48h', value: stats.soon, sub: tr ? 'Yaklaşan teslimler' : 'Upcoming', icon: Clock, grad: 'from-amber-500 to-orange-600', bar: stats.open ? (stats.soon / stats.open) * 100 : 0, onClick: () => setQuick(q => (q === 'soon' ? 'none' : 'soon')), active: quick === 'soon' },
    { label: tr ? 'Engellenen' : 'Blocked', value: stats.blocked, sub: tr ? 'Çözüm bekleyenler' : 'Need attention', icon: Ban, grad: 'from-slate-600 to-slate-800', bar: stats.open ? (stats.blocked / stats.open) * 100 : 0, onClick: () => { setStatusF([TaskStatus.BLOCKED]); setView('list'); } },
    { label: tr ? 'Atanmamış' : 'Unassigned', value: stats.unassigned, sub: tr ? 'Sorumlusu olmayanlar' : 'No owner', icon: UserX, grad: 'from-sky-500 to-blue-600', bar: stats.open ? (stats.unassigned / stats.open) * 100 : 0, onClick: () => setQuick(q => (q === 'unassigned' ? 'none' : 'unassigned')), active: quick === 'unassigned' },
  ];
  const selectCls = 'h-10 px-3 rounded-xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700 text-xs font-semibold text-slate-700 dark:text-slate-200 outline-none focus:border-indigo-500 cursor-pointer max-w-[200px]';

  return (
    <div className="space-y-5 pb-24">
      <div className="flex flex-col lg:flex-row lg:items-end justify-between gap-4">
        <div>
          <h2 className="text-2xl lg:text-3xl font-black text-slate-900 dark:text-white tracking-tight">{view === 'board' ? (tr ? 'Görev Panosu' : 'Task Board') : (tr ? 'Görev Yönetimi' : 'Task Management')}</h2>
          <p className="text-sm text-slate-500 dark:text-slate-400">{view === 'board' ? (tr ? 'Kartları sürükleyerek durumlarını güncelleyin.' : 'Drag cards to update status.') : (tr ? 'Tüm projelerin görevleri; filtreleyin, toplu güncelleyin.' : 'All tasks across projects.')}</p>
        </div>
        <button onClick={() => setModal({ open: true, task: null, defaults: projectF !== 'all' ? { projectId: projectF } : undefined })} className="h-10 px-4 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white text-sm font-semibold inline-flex items-center gap-2 shadow-lg shadow-indigo-500/25 self-start lg:self-auto"><Plus size={16} /> {tr ? 'Yeni görev' : 'New task'}</button>
      </div>

      <div className="grid grid-cols-2 lg:grid-cols-5 gap-3 pc-stagger">
        {kpis.map((k: any, i) => {
          const Icon = k.icon;
          return (
            <button key={k.label} onClick={k.onClick} className={`text-left bg-white dark:bg-slate-900 border rounded-[20px] p-4 pc-lift min-w-0 ${k.active ? 'border-indigo-400 ring-4 ring-indigo-500/10' : 'border-slate-100 dark:border-slate-800'} ${i === 4 ? 'col-span-2 lg:col-span-1' : ''}`}>
              <div className="flex items-center gap-2.5"><span className={`p-2 rounded-xl bg-gradient-to-br ${k.grad} text-white shadow-md`}><Icon size={16} /></span><span className="text-[11px] font-semibold text-slate-500 dark:text-slate-400 truncate">{k.label}</span></div>
              <p className="text-2xl font-black text-slate-900 dark:text-white mt-2"><AnimatedNumber value={k.value} /></p>
              <p className="text-[11px] text-slate-400 truncate">{k.sub}</p>
              <div className="mt-2.5"><GrowBar value={k.bar} className={`bg-gradient-to-r ${k.grad}`} /></div>
            </button>
          );
        })}
      </div>

      <div className="bg-white dark:bg-slate-900 border border-slate-100 dark:border-slate-800 rounded-[20px] p-3 space-y-3">
        <div className="flex flex-col xl:flex-row xl:items-center gap-2">
          <div className="relative flex-1"><Search size={16} className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
            <input value={search} onChange={e => setSearch(e.target.value)} placeholder={tr ? 'Görev, proje veya not ara…' : 'Search tasks…'} className="w-full h-10 pl-9 pr-8 rounded-xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700 text-sm outline-none focus:border-indigo-500" />
            {search && <button onClick={() => setSearch('')} className="absolute right-2 top-1/2 -translate-y-1/2 p-1 text-slate-400"><X size={14} /></button>}</div>
          <div className="flex flex-wrap items-center gap-2">
            <select value={projectF} onChange={e => setProjectF(e.target.value)} className={selectCls}><option value="all">{tr ? 'Tüm projeler' : 'All projects'}</option>{projects.filter(p => p.status !== 'Completed').map(p => <option key={p.id} value={p.id}>{p.name}</option>)}</select>
            <select value={userF} onChange={e => setUserF(e.target.value)} className={selectCls}><option value="all">{tr ? 'Herkes' : 'Everyone'}</option><option value="none">{tr ? 'Atanmamış' : 'Unassigned'}</option>{users.map(u => <option key={u.id} value={u.id}>{u.name}</option>)}</select>
            <button onClick={() => setShowFilters(v => !v)} className={`h-10 px-3 rounded-xl border text-xs font-semibold inline-flex items-center gap-2 ${showFilters || filterCount ? 'border-indigo-300 text-indigo-600 bg-indigo-50/60 dark:bg-indigo-500/10' : 'border-slate-200 dark:border-slate-700 text-slate-600 dark:text-slate-300'}`}><SlidersHorizontal size={15} /> {tr ? 'Daha fazla' : 'More'}{filterCount > 0 && <span className="w-5 h-5 rounded-full bg-indigo-600 text-white text-[10px] flex items-center justify-center">{filterCount}</span>}</button>
            <div className="flex p-1 rounded-xl bg-slate-100 dark:bg-slate-800/60">
              <button title={tr ? 'Liste' : 'List'} onClick={() => setView('list')} className={`p-2 rounded-lg ${view === 'list' ? 'bg-white dark:bg-slate-900 text-indigo-600 shadow-sm' : 'text-slate-400'}`}><List size={16} /></button>
              <button title={tr ? 'Pano' : 'Board'} onClick={() => setView('board')} className={`p-2 rounded-lg ${view === 'board' ? 'bg-white dark:bg-slate-900 text-indigo-600 shadow-sm' : 'text-slate-400'}`}><Columns3 size={16} /></button>
            </div>
          </div>
        </div>
        {showFilters && (
          <div className="flex flex-wrap items-center gap-2 pt-3 border-t border-slate-100 dark:border-slate-800 animate-in fade-in slide-in-from-top-2 duration-300">
            {view === 'list' && (
              <div className="flex flex-wrap gap-1">
                {Object.values(TaskStatus).map(s => {
                  const on = statusF.includes(s);
                  return <button key={s} onClick={() => setStatusF(f => (on ? f.filter(x => x !== s) : [...f, s]))} className={`h-8 px-2.5 rounded-lg text-xs font-semibold border inline-flex items-center gap-1.5 ${on ? 'border-indigo-300 bg-indigo-50 text-indigo-700 dark:bg-indigo-500/10 dark:text-indigo-200' : 'border-slate-200 dark:border-slate-700 text-slate-500'}`}><span className={`w-1.5 h-1.5 rounded-full ${TASK_STATUS_META[s].dot}`} />{tr ? TASK_STATUS_META[s].tr : TASK_STATUS_META[s].en}</button>;
                })}
              </div>
            )}
            <div className="relative"><ArrowUpDown size={14} className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400 pointer-events-none" />
              <select value={sort} onChange={e => setSort(e.target.value as Sort)} className={selectCls + ' pl-8'}>
                <option value="deadline">{tr ? 'Son tarihe göre' : 'By deadline'}</option><option value="status">{tr ? 'Duruma göre' : 'By status'}</option><option value="project">{tr ? 'Projeye göre' : 'By project'}</option><option value="progress">{tr ? 'Katkıya göre' : 'By weight'}</option><option value="title">{tr ? 'Ada göre' : 'By title'}</option>
              </select></div>
            {view === 'list' && (
              <div className="relative"><Layers size={14} className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400 pointer-events-none" />
                <select value={group} onChange={e => setGroup(e.target.value as Group)} className={selectCls + ' pl-8'}>
                  <option value="none">{tr ? 'Gruplama yok' : 'No grouping'}</option><option value="project">{tr ? 'Projeye göre grupla' : 'Group by project'}</option><option value="assignee">{tr ? 'Kişiye göre grupla' : 'Group by assignee'}</option><option value="status">{tr ? 'Duruma göre grupla' : 'Group by status'}</option>
                </select></div>
            )}
            {(filterCount > 0 || search) && <button onClick={clearFilters} className="ml-auto text-xs font-semibold text-slate-500 hover:text-rose-600 inline-flex items-center gap-1"><X size={13} /> {tr ? 'Temizle' : 'Clear'}</button>}
          </div>
        )}
      </div>

      <div className="flex items-center justify-between text-xs text-slate-400 px-1">
        <span>{filtered.length} {tr ? 'görev' : 'tasks'}{quick !== 'none' && <button onClick={() => setQuick('none')} className="ml-2 inline-flex items-center gap-1 px-2 py-0.5 rounded-md bg-indigo-50 dark:bg-indigo-500/10 text-indigo-600 font-semibold">{quick === 'overdue' ? (tr ? 'Gecikmiş' : 'Overdue') : quick === 'soon' ? (tr ? '48 saat' : '48h') : (tr ? 'Atanmamış' : 'Unassigned')} <X size={11} /></button>}</span>
      </div>

      <div key={view} className="animate-in fade-in duration-300">{view === 'list' ? listView() : boardView()}</div>

      {/* Toplu işlem çubuğu */}
      <div className={`fixed bottom-4 left-1/2 -translate-x-1/2 z-40 transition-all duration-300 ${selected.length ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-6 pointer-events-none'}`}>
        <div className="flex flex-wrap items-center gap-2 pl-4 pr-2 py-2 rounded-2xl bg-slate-900 text-white shadow-2xl shadow-slate-900/30 border border-white/10 max-w-[calc(100vw-2rem)]">
          <span className="text-sm font-semibold whitespace-nowrap">{selected.length} {tr ? 'seçili' : 'selected'}</span>
          <select value="" onChange={e => { const s = e.target.value as TaskStatus; if (s) bulk(t => (s === TaskStatus.BLOCKED && !t.blockedReason ? { ...t, status: s, blockedReason: tr ? 'Toplu işlemle engellendi' : 'Blocked in bulk' } : { ...t, status: s }), tr ? 'Durumlar güncellendi' : 'Status updated'); }} className="h-9 px-2 rounded-xl bg-white/10 text-sm font-semibold outline-none cursor-pointer">
            <option value="" className="text-slate-900">{tr ? 'Durum değiştir…' : 'Set status…'}</option>
            {Object.values(TaskStatus).map(s => <option key={s} value={s} className="text-slate-900">{tr ? TASK_STATUS_META[s].tr : TASK_STATUS_META[s].en}</option>)}
          </select>
          <select value="" onChange={e => { const u = e.target.value; if (u) bulk(t => ({ ...t, assignedTo: [...new Set([...(t.assignedTo || []), u])] }), tr ? 'Görevler atandı' : 'Assigned'); }} className="h-9 px-2 rounded-xl bg-white/10 text-sm font-semibold outline-none cursor-pointer">
            <option value="" className="text-slate-900">{tr ? 'Kişiye ata…' : 'Assign to…'}</option>
            {users.map(u => <option key={u.id} value={u.id} className="text-slate-900">{u.name}</option>)}
          </select>
          {onDeleteTask && (confirmBulkDelete
            ? <><button onClick={() => setConfirmBulkDelete(false)} className="h-9 px-3 rounded-xl text-sm font-semibold text-slate-300 hover:bg-white/10">{tr ? 'Vazgeç' : 'Cancel'}</button><button onClick={bulkDelete} className="h-9 px-3 rounded-xl text-sm font-semibold bg-rose-600 hover:bg-rose-500">{tr ? `${selected.length} görevi sil` : 'Delete'}</button></>
            : <button onClick={() => setConfirmBulkDelete(true)} className="h-9 px-3 rounded-xl text-sm font-semibold text-rose-300 hover:bg-white/10 inline-flex items-center gap-1"><Trash2 size={14} /> {tr ? 'Sil' : 'Delete'}</button>)}
          <button onClick={() => { setSelected([]); setConfirmBulkDelete(false); }} className="p-2 rounded-xl text-slate-400 hover:bg-white/10"><X size={16} /></button>
        </div>
      </div>

      <TaskModal show={modal.open} onClose={() => setModal({ open: false, task: null })} task={modal.task && tasks.some(t => t.id === modal.task!.id) ? modal.task : null}
        defaults={modal.task && !tasks.some(t => t.id === modal.task!.id) ? modal.task : modal.defaults} projects={projects} users={users} language={language} onSave={saveTask} onDelete={onDeleteTask} tasks={tasks} />

      {aiTask && (
        <ModalPortal>
          <div className="fixed inset-0 z-[1100] flex items-center justify-center p-4">
            <div className="absolute inset-0 bg-slate-950/70 backdrop-blur-md pc-backdrop" onClick={() => setAiTask(null)} />
            <div className="relative pc-pop">
              <button onClick={() => setAiTask(null)} className="absolute -top-11 right-0 p-2 text-white/70 hover:text-white"><X size={26} /></button>
              <AutoAssignAssistant task={aiTask} users={users} allTasks={tasks} language={language}
                onAssign={async (userId) => { await saveTask({ ...aiTask, assignedTo: [userId] }); toast.success(tr ? 'Görev atandı' : 'Assigned'); setAiTask(null); }} />
            </div>
          </div>
        </ModalPortal>
      )}
    </div>
  );
};

export default TasksView;
