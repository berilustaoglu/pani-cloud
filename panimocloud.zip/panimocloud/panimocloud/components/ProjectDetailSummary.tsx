import React from 'react';
import { CalendarRange, UserCog, Users, Mail, Phone, Link2, Contact, Timer, AlertTriangle, CheckCircle2, ListChecks } from 'lucide-react';
import { Project, Task, User, ProjectType } from '../types';
import { computeProjectMetrics, PRIORITY_META, RISK_META, TYPE_META, daysLeftText } from '../services/projectMetrics';

interface Props {
  project: Project;
  tasks: Task[];
  users: User[];
  language: 'tr' | 'en';
}

const fmt = (d: string | undefined, tr: boolean) => {
  if (!d) return '—';
  const [y, m, day] = d.slice(0, 10).split('-').map(Number);
  return new Date(y, m - 1, day).toLocaleDateString(tr ? 'tr-TR' : 'en-US', { day: 'numeric', month: 'short', year: 'numeric' });
};

/** Proje detay panelinin üstündeki özet: risk, takvim, ekip, etiketler, iletişim. */
const ProjectDetailSummary: React.FC<Props> = ({ project: p, tasks, users, language }) => {
  const tr = language === 'tr';
  const m = computeProjectMetrics(p, tasks, language);
  const risk = RISK_META[m.risk];
  const type = TYPE_META[p.projectType] || TYPE_META[ProjectType.OTHER];
  const pm = users.find(u => u.id === p.projectManagerId);
  const team = (p.teamMemberIds || []).map(id => users.find(u => u.id === id)).filter(Boolean) as User[];
  const active = p.status !== 'Completed' && p.status !== 'On Hold';

  return (
    <div className="mb-10 space-y-4 animate-in fade-in slide-in-from-bottom-4 duration-500">
      {/* Rozetler */}
      <div className="flex flex-wrap items-center gap-2">
        <span className="text-xs font-semibold px-2.5 py-1 rounded-lg bg-slate-100 dark:bg-white/5 text-slate-600 dark:text-slate-300">{type.emoji} {tr ? type.tr : type.en}</span>
        {p.priority && (
          <span className={`inline-flex items-center gap-1.5 text-xs font-semibold px-2.5 py-1 rounded-lg ${PRIORITY_META[p.priority].chip}`}>
            <span className={`w-1.5 h-1.5 rounded-full ${PRIORITY_META[p.priority].dot}`} /> {tr ? 'Öncelik' : 'Priority'}: {tr ? PRIORITY_META[p.priority].tr : PRIORITY_META[p.priority].en}
          </span>
        )}
        {active && <span className={`text-xs font-semibold px-2.5 py-1 rounded-lg ${risk.chip}`}>{tr ? risk.tr : risk.en}</span>}
        {(p.tags || []).map(t => <span key={t} className="text-xs font-semibold px-2 py-1 rounded-lg bg-indigo-50 dark:bg-indigo-500/10 text-indigo-600 dark:text-indigo-300">#{t}</span>)}
      </div>

      {/* Risk nedenleri */}
      {active && m.riskReasons.length > 0 && (
        <div className="flex items-start gap-3 p-4 rounded-2xl bg-amber-50/70 dark:bg-amber-500/10 border border-amber-100 dark:border-amber-500/20">
          <AlertTriangle size={18} className="text-amber-500 shrink-0 mt-0.5" />
          <div className="text-sm text-amber-900 dark:text-amber-200">
            <p className="font-semibold mb-1">{tr ? 'Dikkat gerektiren konular' : 'Needs attention'}</p>
            <ul className="list-disc ml-4 space-y-0.5 text-xs">{m.riskReasons.map(r => <li key={r}>{r}</li>)}</ul>
          </div>
        </div>
      )}
      {active && m.riskReasons.length === 0 && (
        <div className="flex items-center gap-2 p-3 rounded-2xl bg-emerald-50/70 dark:bg-emerald-500/10 text-sm font-semibold text-emerald-700 dark:text-emerald-300">
          <CheckCircle2 size={16} /> {tr ? 'Proje planlandığı gibi ilerliyor.' : 'Project is on track.'}
        </div>
      )}

      {p.description && <p className="text-sm text-slate-600 dark:text-slate-300 leading-relaxed whitespace-pre-wrap">{p.description}</p>}

      {/* Takvim + görev */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
        <div className="rounded-2xl bg-slate-50 dark:bg-white/[0.03] p-3">
          <p className="text-[11px] text-slate-400 flex items-center gap-1"><CalendarRange size={12} /> {tr ? 'Başlangıç' : 'Start'}</p>
          <p className="text-sm font-semibold text-slate-800 dark:text-slate-100 mt-0.5">{fmt(p.startDate, tr)}</p>
        </div>
        <div className="rounded-2xl bg-slate-50 dark:bg-white/[0.03] p-3">
          <p className="text-[11px] text-slate-400 flex items-center gap-1"><Timer size={12} /> {tr ? 'Teslim' : 'Delivery'}</p>
          <p className="text-sm font-semibold text-slate-800 dark:text-slate-100 mt-0.5">{fmt(p.deliveryDate, tr)}</p>
          {active && <p className={`text-[11px] font-semibold ${m.daysLeft !== null && m.daysLeft < 0 ? 'text-rose-600' : 'text-slate-400'}`}>{daysLeftText(m.daysLeft, language)}</p>}
        </div>
        <div className="rounded-2xl bg-slate-50 dark:bg-white/[0.03] p-3">
          <p className="text-[11px] text-slate-400">{tr ? 'Plan / Gerçek' : 'Plan / Actual'}</p>
          <p className="text-sm font-semibold text-slate-800 dark:text-slate-100 mt-0.5">{m.plannedProgress !== null ? `%${m.plannedProgress}` : '—'} / %{p.progress || 0}</p>
          {m.scheduleGap !== null && active && <p className={`text-[11px] font-semibold ${m.scheduleGap < -9 ? 'text-rose-600' : m.scheduleGap >= 5 ? 'text-emerald-600' : 'text-slate-400'}`}>{m.scheduleGap >= 0 ? (tr ? `${m.scheduleGap} puan ileride` : `${m.scheduleGap} pts ahead`) : (tr ? `${Math.abs(m.scheduleGap)} puan geride` : `${Math.abs(m.scheduleGap)} pts behind`)}</p>}
        </div>
        <div className="rounded-2xl bg-slate-50 dark:bg-white/[0.03] p-3">
          <p className="text-[11px] text-slate-400 flex items-center gap-1"><ListChecks size={12} /> {tr ? 'Görevler' : 'Tasks'}</p>
          <p className="text-sm font-semibold text-slate-800 dark:text-slate-100 mt-0.5">{m.tasksDone}/{m.tasksTotal}</p>
          {(m.tasksOverdue > 0 || m.tasksBlocked > 0) && <p className="text-[11px] font-semibold text-rose-600">{m.tasksOverdue} {tr ? 'gecikmiş' : 'late'} · {m.tasksBlocked} {tr ? 'engelli' : 'blocked'}</p>}
          {p.estimatedHours ? <p className="text-[11px] text-slate-400">~{p.estimatedHours} {tr ? 'saat' : 'h'}</p> : null}
        </div>
      </div>

      {/* Ekip + İletişim */}
      {(pm || team.length > 0 || p.clientContactName || p.clientEmail || p.clientPhone || p.repoUrl) && (
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
          {(pm || team.length > 0) && (
            <div className="rounded-2xl border border-slate-100 dark:border-slate-800 p-4">
              {pm && (
                <div className="flex items-center gap-2 mb-3">
                  <UserCog size={15} className="text-indigo-500" />
                  <span className="text-xs text-slate-400">{tr ? 'Proje Yöneticisi' : 'Project Manager'}:</span>
                  <span className="text-sm font-semibold text-slate-800 dark:text-slate-100">{pm.name}</span>
                </div>
              )}
              {team.length > 0 && (
                <>
                  <p className="text-xs text-slate-400 flex items-center gap-1.5 mb-2"><Users size={13} /> {tr ? 'Ekip' : 'Team'} ({team.length})</p>
                  <div className="flex flex-wrap gap-1.5">
                    {team.map(u => (
                      <span key={u.id} className="inline-flex items-center gap-1.5 pl-0.5 pr-2 py-0.5 rounded-full bg-slate-100 dark:bg-white/5 text-xs font-semibold text-slate-700 dark:text-slate-200">
                        {u.avatar ? <img src={u.avatar} alt="" className="w-5 h-5 rounded-full object-cover" /> : <span className="w-5 h-5 rounded-full bg-indigo-500 text-white text-[9px] flex items-center justify-center">{u.name?.[0]}</span>}
                        {u.name}
                      </span>
                    ))}
                  </div>
                </>
              )}
            </div>
          )}
          {(p.clientContactName || p.clientEmail || p.clientPhone || p.repoUrl) && (
            <div className="rounded-2xl border border-slate-100 dark:border-slate-800 p-4 space-y-2 text-sm">
              {p.clientContactName && <p className="flex items-center gap-2 text-slate-700 dark:text-slate-200"><Contact size={14} className="text-indigo-500" /> {p.clientContactName}</p>}
              {p.clientEmail && <a href={`mailto:${p.clientEmail}`} className="flex items-center gap-2 text-indigo-600 dark:text-indigo-300 hover:underline"><Mail size={14} /> {p.clientEmail}</a>}
              {p.clientPhone && <a href={`tel:${p.clientPhone.replace(/\s/g, '')}`} className="flex items-center gap-2 text-indigo-600 dark:text-indigo-300 hover:underline"><Phone size={14} /> {p.clientPhone}</a>}
              {p.repoUrl && <a href={p.repoUrl} target="_blank" rel="noopener noreferrer" className="flex items-center gap-2 text-indigo-600 dark:text-indigo-300 hover:underline truncate"><Link2 size={14} className="shrink-0" /> <span className="truncate">{p.repoUrl}</span></a>}
            </div>
          )}
        </div>
      )}
    </div>
  );
};

export default ProjectDetailSummary;
