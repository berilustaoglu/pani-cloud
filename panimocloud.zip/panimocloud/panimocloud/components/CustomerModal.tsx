
import React, { useState, useEffect } from 'react';
import { Customer } from '../types';
import { translations } from '../translations';
import { 
  User as UserIcon, 
  Smartphone, 
  X, 
  Mail, 
  Building2, 
  Hash, 
  MapPin, 
  StickyNote,
  UserPlus,
  Venus,
  Mars,
  ShieldCheck
} from 'lucide-react';

interface Props {
  show: boolean;
  customer: Customer | null;
  language: 'tr' | 'en';
  onClose: () => void;
  onSave: (customer: Customer) => Promise<void>;
}

import ModalPortal from './ModalPortal';

const InputField = ({ label, icon: Icon, value, onChange, placeholder, type = "text", colSpan = "col-span-1" }: any) => (
  <div className={colSpan}>
    <label className="block text-[10px] font-black text-slate-400 uppercase tracking-[0.2em] mb-2 ml-1">
      {label}
    </label>
    <div className="relative group">
      <div className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-300 group-focus-within:text-indigo-500 transition-colors">
        <Icon size={18} />
      </div>
      <input 
        type={type} 
        className="w-full bg-slate-50 dark:bg-slate-800/50 border-2 border-slate-100 dark:border-slate-800 rounded-[20px] py-4 pl-12 pr-4 focus:border-indigo-500 focus:bg-white dark:focus:bg-slate-800 outline-none font-bold text-sm dark:text-white transition-all shadow-sm group-hover:border-slate-200 dark:group-hover:border-slate-700" 
        value={value || ''} 
        placeholder={placeholder}
        onChange={(e) => onChange(e.target.value)} 
      />
    </div>
  </div>
);

const CustomerModal: React.FC<Props> = ({ show, customer, language, onClose, onSave }) => {
  const t = translations[language];
  const [formData, setFormData] = useState<Partial<Customer>>({});

  useEffect(() => {
    if (customer) {
      setFormData({ ...customer });
    } else {
      setFormData({});
    }
  }, [customer, show]);

  if (!show) return null;

  const handleSubmit = async () => {
    if (formData.name && formData.phone) {
      const updatedCustomer: Customer = {
        ...(formData as Customer),
        id: customer ? customer.id : `c${Date.now()}`
      };
      await onSave(updatedCustomer);
      onClose();
    }
  };


  return (
    <ModalPortal>
      <div className="fixed inset-0 bg-slate-900/40 z-[9999] flex items-center justify-center p-4 backdrop-blur-xl animate-in fade-in duration-300">
        <div className="bg-white dark:bg-slate-900 rounded-[40px] w-full max-w-2xl shadow-[0_32px_64px_-12px_rgba(0,0,0,0.2)] animate-in zoom-in duration-300 relative overflow-hidden flex flex-col md:flex-row border border-white/20 dark:border-slate-800">
          
          {/* Decorative Side Panel (Visible on Desktop) */}
          <div className="hidden md:flex md:w-1/3 bg-indigo-600 p-10 flex-col justify-between text-white relative overflow-hidden">
              <div className="absolute top-0 left-0 w-full h-full opacity-10">
                  <div className="absolute -top-20 -left-20 w-64 h-64 bg-white rounded-full blur-3xl"></div>
                  <div className="absolute -bottom-20 -right-20 w-64 h-64 bg-indigo-400 rounded-full blur-3xl"></div>
              </div>
              
              <div className="relative z-10">
                  <div className="w-12 h-12 bg-white/20 backdrop-blur-md rounded-2xl flex items-center justify-center mb-6">
                      <UserPlus size={24} />
                  </div>
                  <h2 className="text-3xl font-black leading-tight tracking-tighter uppercase italic">
                      {customer ? (language === 'tr' ? 'Müşteri Güncelle' : 'Update Client') : (language === 'tr' ? 'Yeni Müşteri' : 'New Client')}
                  </h2>
                  <p className="text-indigo-100 text-xs font-bold mt-4 leading-relaxed">
                      {language === 'tr' 
                          ? 'Müşteri bilgilerini eksiksiz doldurarak CRM veritabanınızı güncel tutun.' 
                          : 'Keep your CRM database up to date by filling in client information completely.'}
                  </p>
              </div>

              <div className="relative z-10 pt-10 border-t border-white/10 flex items-center gap-3">
                  <ShieldCheck size={16} className="text-indigo-300" />
                  <span className="text-[10px] font-black uppercase tracking-widest text-indigo-200">Secure Database Access</span>
              </div>
          </div>

          {/* Form Panel */}
          <div className="flex-1 p-8 md:p-12 max-h-[90vh] overflow-y-auto custom-scrollbar">
              <button 
                onClick={onClose}
                className="absolute top-8 right-8 p-3 text-slate-300 hover:text-slate-600 dark:hover:text-white hover:bg-slate-50 dark:hover:bg-slate-800 rounded-2xl transition-all z-20"
              >
                <X size={20} />
              </button>

              <div className="space-y-8">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                      <InputField 
                          label={language === 'tr' ? 'Müşteri Adı' : 'Customer Name'}
                          icon={UserIcon}
                          value={formData.name}
                          onChange={(val: string) => setFormData({ ...formData, name: val })}
                          colSpan="col-span-1 md:col-span-2"
                          placeholder="Örn: Ahmet Yılmaz"
                      />
                      
                      <InputField 
                          label={t.phone}
                          icon={Smartphone}
                          value={formData.phone}
                          onChange={(val: string) => setFormData({ ...formData, phone: val })}
                          placeholder="05xxxxxxxxx"
                      />

                      <InputField 
                          label={t.email}
                          icon={Mail}
                          value={formData.email}
                          onChange={(val: string) => setFormData({ ...formData, email: val })}
                          placeholder="mail@example.com"
                          type="email"
                      />

                      <InputField 
                          label={t.company}
                          icon={Building2}
                          value={formData.company}
                          onChange={(val: string) => setFormData({ ...formData, company: val })}
                          placeholder="Şirket Adı (Opsiyonel)"
                      />

                      <InputField 
                          label={t.tax_office}
                          icon={Building2}
                          value={formData.taxOffice}
                          onChange={(val: string) => setFormData({ ...formData, taxOffice: val })}
                          placeholder="Vergi Dairesi"
                      />

                      <InputField 
                          label={t.tax_no}
                          icon={Hash}
                          value={formData.taxNumber}
                          onChange={(val: string) => setFormData({ ...formData, taxNumber: val })}
                          placeholder="Vergi No"
                          colSpan="col-span-1 md:col-span-2"
                      />

                      <div className="col-span-1 md:col-span-2">
                          <label className="block text-[10px] font-black text-slate-400 uppercase tracking-[0.2em] mb-3 ml-1">
                              {language === 'tr' ? 'Cinsiyet' : 'Gender'}
                          </label>
                          <div className="flex gap-4">
                              <button 
                                  type="button"
                                  onClick={() => setFormData({ ...formData, gender: 'Male' })}
                                  className={`flex-1 flex items-center justify-center gap-3 py-4 rounded-[20px] font-black text-xs transition-all border-2 ${
                                      formData.gender === 'Male' 
                                          ? 'bg-indigo-600 border-indigo-600 text-white shadow-lg shadow-indigo-100' 
                                          : 'bg-slate-50 border-slate-50 text-slate-400 hover:bg-slate-100 dark:bg-slate-800/50 dark:border-slate-800'
                                  }`}
                              >
                                  <Mars size={16} /> {language === 'tr' ? 'ERKEK' : 'MALE'}
                              </button>
                              <button 
                                  type="button"
                                  onClick={() => setFormData({ ...formData, gender: 'Female' })}
                                  className={`flex-1 flex items-center justify-center gap-3 py-4 rounded-[20px] font-black text-xs transition-all border-2 ${
                                      formData.gender === 'Female' 
                                          ? 'bg-pink-600 border-pink-600 text-white shadow-lg shadow-pink-100' 
                                          : 'bg-slate-50 border-slate-50 text-slate-400 hover:bg-slate-100 dark:bg-slate-800/50 dark:border-slate-800'
                                  }`}
                              >
                                  <Venus size={16} /> {language === 'tr' ? 'KADIN' : 'FEMALE'}
                              </button>
                          </div>
                      </div>

                      <div className="col-span-1 md:col-span-2">
                          <label className="block text-[10px] font-black text-slate-400 uppercase tracking-[0.2em] mb-2 ml-1">{t.address}</label>
                          <div className="relative group">
                              <div className="absolute left-4 top-4 text-slate-300 group-focus-within:text-indigo-500">
                                  <MapPin size={18} />
                              </div>
                              <textarea 
                                  className="w-full bg-slate-50 dark:bg-slate-800/50 border-2 border-slate-100 dark:border-slate-800 rounded-[20px] py-4 pl-12 pr-4 focus:border-indigo-500 outline-none font-bold text-sm min-h-[100px] dark:text-white transition-all resize-none shadow-sm" 
                                  value={formData.address || ''} 
                                  placeholder={language === 'tr' ? 'Açık adres...' : 'Full address...'}
                                  onChange={(e) => setFormData({ ...formData, address: e.target.value })} 
                              />
                          </div>
                      </div>
                      
                      <div className="col-span-1 md:col-span-2">
                          <label className="block text-[10px] font-black text-slate-400 uppercase tracking-[0.2em] mb-2 ml-1">{t.notes}</label>
                          <div className="relative group">
                              <div className="absolute left-4 top-4 text-slate-300 group-focus-within:text-indigo-500">
                                  <StickyNote size={18} />
                              </div>
                              <textarea 
                                  className="w-full bg-slate-50 dark:bg-slate-800/50 border-2 border-slate-100 dark:border-slate-800 rounded-[20px] py-4 pl-12 pr-4 focus:border-indigo-500 outline-none font-bold text-sm min-h-[100px] dark:text-white transition-all resize-none shadow-sm" 
                                  value={formData.notes || ''} 
                                  placeholder={language === 'tr' ? 'Müşteri hakkında notlar...' : 'Notes about the client...'}
                                  onChange={(e) => setFormData({ ...formData, notes: e.target.value })} 
                              />
                          </div>
                      </div>
                  </div>
                  
                  <div className="flex flex-col sm:flex-row gap-4 pt-6 border-t border-slate-50 dark:border-slate-800">
                      <button 
                          onClick={onClose} 
                          className="flex-1 px-8 py-5 border-2 border-slate-100 dark:border-slate-800 rounded-3xl font-black text-slate-400 uppercase tracking-widest text-[11px] hover:bg-slate-50 dark:hover:bg-slate-800 transition-all"
                      >
                          {t.cancel}
                      </button>
                      <button 
                          onClick={handleSubmit} 
                          disabled={!formData.name || !formData.phone}
                          className="flex-1 px-8 py-5 bg-indigo-600 text-white rounded-3xl font-black hover:bg-indigo-700 shadow-2xl shadow-indigo-100 dark:shadow-none uppercase tracking-widest text-[11px] disabled:opacity-50 transition-all transform active:scale-95"
                      >
                          {customer ? (language === 'tr' ? 'GÜNCELLE' : 'UPDATE') : (language === 'tr' ? 'MÜŞTERİ EKLE' : 'ADD CUSTOMER')}
                      </button>
                  </div>
              </div>
          </div>
        </div>
      </div>
    </ModalPortal>
  );
};

export default CustomerModal;
