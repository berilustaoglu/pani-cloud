
import React, { useState, useEffect, useMemo } from 'react';
import { Project, PaymentType, Installment, ProjectDocument, Currency, Transaction, Task, TaskStatus, ProjectType, User, UserRole, ProjectFormSettings, Customer } from '../types';
import ProjectsBoard from './ProjectsBoard';
import ProjectDetailSummary from './ProjectDetailSummary';
import ProjectFormPanel from './ProjectFormPanel';
import ProjectDetailPanel from './ProjectDetailPanel';
import { translations } from '../translations';
import { generateSubTasks } from '../services/aiService';
import {
  Plus,
  Briefcase,
  CheckSquare,
  CreditCard,
  FileText,
  FilePlus,
  X,
  CheckCircle2,
  Paperclip,
  Download,
  Clock,
  ArrowRight,
  AlertCircle,
  Calendar,
  DollarSign,
  Edit,
  CheckCircle,
  Timer,
  AlertTriangle,
  Zap,
  ChevronRight,
  Archive,
  LayoutGrid,
  PauseCircle,
  Trash2,
  Shield,
  ExternalLink,
  List,
  Search,
  FileSpreadsheet,
  TrendingUp,
  Filter,
  Settings as SettingsIcon
} from 'lucide-react';
import ModalPortal from './ModalPortal';
import { toast } from '../services/toast';

interface Props {
  projects: Project[];
  tasks: Task[];
  setProjects: (project: Project) => Promise<void>;
  language: 'tr' | 'en';
  onAddTransaction: (transaction: Transaction) => Promise<void>;
  onDeleteProject?: (id: string) => Promise<void>;
  onAddTask?: (task: Task) => Promise<void>;
  users?: User[];
  showFinancials: boolean;
  onOpenArchive?: () => void;
  financeSettings?: any;
  currentUser?: User | null;
  projectFormSettings?: ProjectFormSettings;
  customers?: Customer[];
  onOpenSettings?: () => void;
  rates?: { TRY: number; EUR: number };
  onDeleteTransaction?: (id: string) => Promise<void>;
  onOpenTasks?: () => void;
}

const ProjectsView: React.FC<Props> = ({ projects, tasks, setProjects, language, onAddTransaction, onDeleteProject, onAddTask, users, showFinancials, onOpenArchive, financeSettings, currentUser, projectFormSettings, customers = [], onOpenSettings, rates, onDeleteTransaction, onOpenTasks }) => {
  const t = translations[language];
  const [showModal, setShowModal] = useState(false);
  const [showDetails, setShowDetails] = useState<Project | null>(null);
  const detail = showDetails ? (projects.find(p => p.id === showDetails.id) || showDetails) : null;
  const [isEditing, setIsEditing] = useState(false);
  const [isAnalyzingGDD, setIsAnalyzingGDD] = useState(false);
  const [analysisLogs, setAnalysisLogs] = useState<string[]>([]);
  const [analysisStep, setAnalysisStep] = useState(0);
  const [showTaskManagement, setShowTaskManagement] = useState<Project | null>(null);
  const [showPortalSettings, setShowPortalSettings] = useState<Project | null>(null);

  // View Mode State: 'active', 'completed', 'on_hold'

  const d0 = new Date(); const todayStr = `${d0.getFullYear()}-${String(d0.getMonth() + 1).padStart(2, '0')}-${String(d0.getDate()).padStart(2, '0')}`;

  const getCurrencySymbol = (c: Currency) => {
    switch (c) {
      case Currency.TRY: return '₺';
      case Currency.EUR: return '€';
      default: return '$';
    }
  };

  const getOverdueStatus = (project: Project) => {
    const overdueInstallments = project.installments.filter(inst =>
      !inst.isPaid && inst.dueDate < todayStr
    );
    return {
      isOverdue: overdueInstallments.length > 0,
      count: overdueInstallments.length,
      totalAmount: overdueInstallments.reduce((sum, inst) => sum + inst.amount, 0)
    };
  };

  const isApproaching = (dateStr?: string) => {
    if (!dateStr) return false;
    const deliveryDate = new Date(dateStr);
    const now = new Date();
    const diffTime = deliveryDate.getTime() - now.getTime();
    const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
    return diffDays <= 3;
  };


  const handleDownloadDocument = (doc: ProjectDocument) => {
    if (doc.url) {
      const a = document.createElement('a');
      a.href = doc.url;
      a.download = doc.name;
      a.target = '_blank';
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
    } else {
      const blob = new Blob([`PanimoCloud Doküman: ${doc.name}\nYükleme Tarihi: ${doc.uploadDate}\nTip: ${doc.type}`], { type: 'text/plain;charset=utf-8' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `${doc.name}.txt`;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
    }
  };

  const exportProjectsToCSV = () => {
    const q = (v: unknown) => `"${String(v ?? '').replace(/"/g, '""')}"`;
    const userName = (id?: string) => users?.find(u => u.id === id)?.name || '';
    const headers = ['Proje Adı', 'Müşteri', 'Yetkili', 'E-posta', 'Telefon', 'Tip', 'Öncelik', 'Durum', 'İlerleme (%)', 'Başlangıç', 'Teslim', 'Proje Yöneticisi', 'Ekip', 'Etiketler', 'Tahmini Saat', 'Bütçe', 'KDV Dahil', 'Para Birimi', 'Ödeme Tipi', 'Ödenen Taksit', 'Toplam Taksit'];
    const rows = projects.map(p => [
      p.name, p.client, p.clientContactName, p.clientEmail, p.clientPhone, p.projectType, p.priority, p.status, p.progress,
      p.startDate, p.deliveryDate, userName(p.projectManagerId), (p.teamMemberIds || []).map(userName).join(' / '), (p.tags || []).join(' '),
      p.estimatedHours, showFinancials ? p.budget : '', showFinancials ? (p.totalAmountWithTax || p.budget) : '', p.currency, p.paymentType,
      (p.installments || []).filter(i => i.isPaid).length, (p.installments || []).length
    ].map(q));
    const csv = [headers.map(q).join(';'), ...rows.map(e => e.join(';'))].join('\n');
    const url = URL.createObjectURL(new Blob(['\uFEFF' + csv], { type: 'text/csv;charset=utf-8' }));
    const link = document.createElement('a');
    link.href = url;
    link.download = `PanimoCloud_Projeler_${new Date().toISOString().split('T')[0]}.csv`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
    toast(language === 'tr' ? `${projects.length} proje d\u0131\u015Fa aktar\u0131ld\u0131` : `${projects.length} projects exported`, 'success');
  };

  const initialProjectState: Partial<Project> = {
    name: '',
    client: '',
    budget: 0,
    currency: Currency.USD,
    status: 'Active',
    progress: 0,
    paymentType: PaymentType.CASH,
    projectType: ProjectType.OTHER,
    installments: [],
    documents: [],
    contracts: [],
    deliveryDate: '',
    gddUrl: '',
    taxRate: financeSettings?.defaultTaxRate || 20,
    taxAmount: 0,
    totalAmountWithTax: 0
  };

  const [newProject, setNewProject] = useState<Partial<Project>>(initialProjectState);
  const handleQuickProgressUpdate = async (project: Project, newProgress: number) => {
    let newStatus = project.status;

    // Check if everything is paid (or no installments exist/cash)
    const allPaid = project.installments.length === 0 || project.installments.every(i => i.isPaid);

    // If progress hits 100 and everything is paid, move to Completed
    if (newProgress === 100 && allPaid) {
      newStatus = 'Completed';
    } else if (project.status === 'Completed' && newProgress < 100) {
      // Optional: If manually dragging back from 100, reopen project
      newStatus = 'Active';
    }

    const updatedProject = { ...project, progress: newProgress, status: newStatus };
    await setProjects(updatedProject);
    if (showDetails?.id === project.id) {
      setShowDetails(updatedProject);
    }
  };

  const syncProgressWithTasks = async (project: Project) => {
    const projectTasks = tasks.filter(t => t.projectId === project.id);
    if (projectTasks.length === 0) {
      toast(language === 'tr' ? 'Bu projeye atanmış görev bulunamadı.' : 'No tasks assigned to this project.');
      return;
    }
    const completed = projectTasks.filter(t => t.status === TaskStatus.DONE).length;
    const calculatedProgress = Math.round((completed / projectTasks.length) * 100);
    await handleQuickProgressUpdate(project, calculatedProgress);
  };

  const autoGenerateTasks = async (project: Project) => {
    if (project.gddTasksGenerated || !onAddTask) return;

    setIsAnalyzingGDD(true);
    setAnalysisLogs([]);
    setAnalysisStep(0);

    const steps = [
      { msg: language === 'tr' ? 'GDD Dosyası Okunuyor...' : 'Reading GDD File...', delay: 1000 },
      { msg: language === 'tr' ? 'AI Asistanına Bağlanılıyor...' : 'Connecting to AI Assistant...', delay: 1500 },
      { msg: language === 'tr' ? 'Proje Gereksinimleri Analiz Ediliyor...' : 'Analyzing Project Requirements...', delay: 2000 },
      { msg: language === 'tr' ? 'Görev Dağılımı ve Atamalar Yapılıyor...' : 'Assigning Tasks...', delay: 1500 }
    ];

    for (let i = 0; i < steps.length; i++) {
        setAnalysisStep(i + 1);
        setAnalysisLogs(prev => [...prev.slice(-4), `> ${steps[i].msg}`]);
        await new Promise(resolve => setTimeout(resolve, steps[i].delay));
    }

    try {
      const generated = await generateSubTasks(`${project.name} - ${project.projectType}`, users || [], language);
      
      for (let i = 0; i < generated.length; i++) {
        const task: Task = {
            id: `t_${project.id}_${Date.now()}_${i}`,
            projectId: project.id,
            title: generated[i].title || 'Unnamed Task',
            assignedTo: [],
            status: TaskStatus.TODO,
            deadline: new Date(new Date().setDate(new Date().getDate() + (i + 1) * 7)).toISOString().split('T')[0],
            progress: 0,
            checklist: [] // Add empty checklist to fix typing issue if present later
        };
        
        // Find assigned users if AI returned names
        if (generated[i].assignedTo && Array.isArray(generated[i].assignedTo) && users) {
           const assignedIds = generated[i].assignedTo.reduce<string[]>((acc, name) => {
              const user = users.find(u => u.name.toLowerCase().includes((name as string).toLowerCase()));
              if (user && !acc.includes(user.id)) acc.push(user.id);
              return acc;
           }, []);
           task.assignedTo = assignedIds;
        }

        await onAddTask(task);
      }
    } catch (e) {
      console.error(e);
      toast(language === 'tr' ? 'AI görev üretirken bir hata oluştu.' : 'Error generating tasks with AI.');
    }
    
    setIsAnalyzingGDD(false);
  };


  const saveProject = async (input: Partial<Project>) => {
    const newProject = input;
    const p: Project = {
      ...newProject as Project,
      id: newProject.id || `p${Date.now()}`,
      budget: Number(newProject.budget || 0),
      currency: newProject.currency || Currency.USD,
      taxRate: Number(newProject.taxRate || 0),
      taxAmount: Number(newProject.taxAmount || 0),
      totalAmountWithTax: Number(newProject.totalAmountWithTax || newProject.budget || 0),
      progress: newProject.progress || 0,
      status: (newProject.status as any) || 'Active',
      paymentType: newProject.paymentType || PaymentType.CASH,
      projectType: newProject.projectType || ProjectType.OTHER,
      installments: newProject.paymentType === PaymentType.CASH ? [] : (newProject.installments || []),
      documents: newProject.documents || [],
      contracts: newProject.contracts || [],
      deliveryDate: newProject.deliveryDate || '',
      gddUrl: newProject.gddUrl || '',
      gddTasksGenerated: newProject.gddTasksGenerated || false,
      tags: newProject.tags || [],
      teamMemberIds: newProject.teamMemberIds || []
    };
    Object.keys(p).forEach(k => (p as any)[k] === undefined && delete (p as any)[k]);
    await setProjects(p);
    if (!isEditing && p.gddUrl) {
      await autoGenerateTasks(p);
      // Update with generated flag
      await setProjects({ ...p, gddTasksGenerated: true });
    }
    setShowModal(false);
    setIsEditing(false);
    setNewProject(initialProjectState);
    if (showDetails?.id === p.id) setShowDetails(p);
  };

  const handleEditProject = (p: Project) => {
    // Kayıtlı KDV değerlerini koru; eski kayıtlarda oran yoksa toplamdan türet (yoksa 0)
    const derivedRate = p.taxRate ?? (p.totalAmountWithTax && p.budget ? Math.round(((p.totalAmountWithTax - p.budget) / p.budget) * 100) : 0);
    setNewProject({ ...p, taxRate: derivedRate, taxAmount: p.taxAmount ?? Math.max(0, (p.totalAmountWithTax || p.budget) - p.budget), totalAmountWithTax: p.totalAmountWithTax || p.budget });
    setIsEditing(true);
   
    setShowModal(true);
  };

  const handleDelete = async (id: string) => {
    if (onDeleteProject) {
      await onDeleteProject(id);
      setShowDetails(null);
    }
  };

  const handlePayInstallment = async (project: Project, instIndex: number) => {
    const inst = project.installments[instIndex];
    const isNowPaid = !inst.isPaid;

    const updatedInstallments = [...project.installments];
    updatedInstallments[instIndex] = { ...inst, isPaid: isNowPaid };

    // Check for auto-completion
    let newStatus = project.status;
    const allPaid = updatedInstallments.every(i => i.isPaid);
    if (allPaid && project.progress === 100) {
      newStatus = 'Completed';
    } else if (!isNowPaid && project.status === 'Completed') {
      newStatus = 'Active'; // Revert to active if unpaid
    }

    const updatedProject = { ...project, installments: updatedInstallments, status: newStatus };
    await setProjects(updatedProject);

    if (showDetails?.id === project.id) {
      setShowDetails(updatedProject);
    }

    if (isNowPaid) {
      const transaction: Transaction = {
        id: `tr_inst_${Date.now()}`,
        type: 'Income',
        amount: inst.amount,
        currency: project.currency,
        category: language === 'tr' ? 'Proje Taksit Ödemesi' : 'Project Installment Payment',
        date: new Date().toISOString().split('T')[0],
        description: `${project.name} - ${inst.label} tahsilatı.`,
        projectId: project.id
      };
      await onAddTransaction(transaction);
    }
  };

  return (
    <>
      <ProjectsBoard
        projects={projects}
        tasks={tasks}
        users={users || []}
        language={language}
        showFinancials={showFinancials}
        rates={rates || { TRY: 34, EUR: 0.92 }}
        onOpen={(p) => setShowDetails(p)}
        onEdit={handleEditProject}
        onNew={() => { setNewProject(initialProjectState); setIsEditing(false); setShowModal(true); }}
        onExport={exportProjectsToCSV}
        onOpenArchive={onOpenArchive}
      />

      <ProjectFormPanel
        open={showModal}
        initial={newProject}
        isEditing={isEditing}
        users={users || []}
        customers={customers}
        settings={projectFormSettings}
        language={language}
        showFinancials={showFinancials}
        onClose={() => { setShowModal(false); setIsEditing(false); }}
        onSubmit={saveProject}
        onOpenSettings={onOpenSettings}
      />

      {detail && (
        <ProjectDetailPanel
          project={detail}
          tasks={tasks}
          users={users || []}
          language={language}
          showFinancials={showFinancials}
          canManage={currentUser?.role === 'Admin' || currentUser?.role === 'Manager'}
          onClose={() => setShowDetails(null)}
          onEdit={handleEditProject}
          onDelete={onDeleteProject}
          onUpdateProject={setProjects}
          onUpsertTask={onAddTask}
          onAddTransaction={onAddTransaction}
          onDeleteTransaction={onDeleteTransaction}
          onOpenTasks={onOpenTasks}
        />
      )}

      {/* GDD'den görev üretilirken gösterge (yeni proje kaydında; panel kapalıyken de görünür) */}
      {isAnalyzingGDD && (
        <ModalPortal>
          <div className="fixed inset-0 z-[2000] flex items-center justify-center bg-slate-950/80 backdrop-blur-md pc-backdrop">
            <div className="bg-white dark:bg-slate-900 rounded-[24px] p-6 w-[min(92vw,380px)] text-center shadow-2xl pc-pop">
              <div className="w-14 h-14 mx-auto rounded-2xl bg-gradient-to-br from-indigo-500 to-violet-600 text-white flex items-center justify-center mb-3"><Zap size={24} className="animate-pulse" /></div>
              <p className="font-bold text-slate-900 dark:text-white">{language === 'tr' ? 'Yapay zekâ görevleri hazırlıyor…' : 'AI is drafting tasks…'}</p>
              <p className="text-xs text-slate-500 mt-1">{analysisLogs[analysisLogs.length - 1]?.replace(/^> /, '') || ''}</p>
              <div className="mt-4 h-1.5 rounded-full bg-slate-100 dark:bg-slate-800 overflow-hidden"><div className="h-full bg-indigo-500 rounded-full transition-all duration-700" style={{ width: `${Math.min(95, analysisStep * 22)}%` }} /></div>
            </div>
          </div>
        </ModalPortal>
      )}
    </>
  );
};

export default ProjectsView;
