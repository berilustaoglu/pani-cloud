import React, { useMemo, useState } from 'react';
import QRCode from 'react-qr-code';
import { FileText, Plus, Printer, CheckCircle2, Clock, AlertTriangle, Ban, Wallet, Receipt, Building2, Trash2, Copy, ExternalLink, Eye, Edit2, Percent } from 'lucide-react';
import { Invoice, InvoiceItem, Customer, Transaction, Currency, CompanySettings } from '../types';
import { PageHeader, KpiGrid, SearchBox, Segmented, Field, EmptyState, DeleteButton, Sheet, Avatar, inputCls, selectSm, cardCls, btnPrimary, btnGhost, money } from './ui/Kit';
import { toTRY, formatTRY, dayDiff, localISO } from '../services/insights';
import { toast } from '../services/toast';

interface Props {
  language: 'tr' | 'en';
  customers: Customer[];
  invoices: Invoice[];
  onAddInvoice: (invoice: Invoice) => Promise<void>;
  onDeleteInvoice: (id: string) => Promise<void>;
  onAddTransaction: (transaction: Transaction) => Promise<void>;
  onDeleteTransaction?: (id: string) => Promise<void>;
  showFinancials: boolean;
  rates?: { TRY: number; EUR: number };
  company?: CompanySettings;
}

const uuid = () => 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, c => { const r = Math.random() * 16 | 0; return (c === 'x' ? r : (r & 0x3 | 0x8)).toString(16); }).toUpperCase();
const totalsOf = (items: InvoiceItem[], wh = 0) => {
  const subtotal = items.reduce((a, i) => a + (Number(i.quantity) || 0) * (Number(i.unitPrice) || 0), 0);
  const taxTotal = items.reduce((a, i) => a + (Number(i.quantity) || 0) * (Number(i.unitPrice) || 0) * ((Number(i.taxRate) || 0) / 100), 0);
  const withholdingTotal = subtotal * (wh / 100);
  return { subtotal, taxTotal, withholdingTotal, totalAmount: subtotal + taxTotal - withholdingTotal };
};
const CUR_NAME: Record<string, string> = { TRY: 'Türk Lirası', USD: 'Amerikan Doları', EUR: 'Euro' };

type View = 'all' | 'open' | 'overdue' | 'paid' | 'draft' | 'cancelled';

const InvoicesView: React.FC<Props> = ({ language, customers, invoices, onAddInvoice, onDeleteInvoice, onAddTransaction, onDeleteTransaction, showFinancials, rates = { TRY: 1, EUR: 1 }, company = {} }) => {
  const tr = language === 'tr';
  const [view, setView] = useState<View>('all');
  const [search, setSearch] = useState('');
  const [month, setMonth] = useState('all');
  const [form, setForm] = useState<(Partial<Invoice> & { wh: number; record: boolean }) | null>(null);
  const [touched, setTouched] = useState(false);
  const [saving, setSaving] = useState(false);
  const [preview, setPreview] = useState<Invoice | null>(null);
  const [eInv, setEInv] = useState<{ id: string; url: string } | null>(null);
  const show = (n: number, c?: string) => (showFinancials ? money(n, c || 'TRY', 2) : '••••');

  const stateOf = (i: Invoice): Exclude<View, 'all' | 'open'> | 'sent' => {
    if (i.status === 'Paid') return 'paid';
    if (i.status === 'Cancelled') return 'cancelled';
    if (i.status === 'Draft') return 'draft';
    const d = dayDiff(i.dueDate);
    return d !== null && d < 0 ? 'overdue' : 'sent';
  };

  const nextNumber = () => {
    const y = new Date().getFullYear();
    const prefix = `PAN${y}`;
    const max = invoices.filter(i => i.invoiceNumber?.startsWith(prefix)).reduce((m, i) => Math.max(m, Number(i.invoiceNumber.slice(prefix.length)) || 0), 0);
    return `${prefix}${String(max + 1).padStart(9, '0')}`;
  };

  const stats = useMemo(() => {
    const T = (i: Invoice, n: number) => toTRY(n, i.currency || Currency.TRY, rates);
    const thisMonth = localISO().slice(0, 7);
    const live = invoices.filter(i => i.status !== 'Cancelled' && i.status !== 'Draft');
    return {
      month: live.filter(i => i.date?.startsWith(thisMonth)).reduce((a, i) => a + T(i, i.totalAmount), 0),
      monthCount: live.filter(i => i.date?.startsWith(thisMonth)).length,
      open: live.filter(i => i.status === 'Sent').reduce((a, i) => a + T(i, i.totalAmount), 0),
      openCount: live.filter(i => i.status === 'Sent').length,
      overdue: invoices.filter(i => stateOf(i) === 'overdue').reduce((a, i) => a + T(i, i.totalAmount), 0),
      overdueCount: invoices.filter(i => stateOf(i) === 'overdue').length,
      vat: live.filter(i => i.date?.startsWith(thisMonth)).reduce((a, i) => a + T(i, i.taxTotal || 0), 0),
    };
  }, [invoices, rates]);

  const months = useMemo(() => [...new Set(invoices.map(i => (i.date || '').slice(0, 7)).filter(Boolean))].sort().reverse(), [invoices]);
  const q = search.trim().toLocaleLowerCase('tr-TR');
  const list = useMemo(() => invoices.filter(i => {
    const s = stateOf(i);
    if (view === 'open' && !(s === 'sent' || s === 'overdue')) return false;
    if (view !== 'all' && view !== 'open' && s !== view) return false;
    if (month !== 'all' && !(i.date || '').startsWith(month)) return false;
    return !q || [i.invoiceNumber, i.customerName, i.customerTaxNo, i.ettn, ...i.items.map(x => x.description)].join(' ').toLocaleLowerCase('tr-TR').includes(q);
  }).sort((a, b) => (b.date || '').localeCompare(a.date || '') || (b.invoiceNumber || '').localeCompare(a.invoiceNumber || '')), [invoices, view, month, q]);

  // ---------- Form ----------
  const openNew = () => {
    setTouched(false);
    const due = new Date(); due.setDate(due.getDate() + 30);
    setForm({ invoiceNumber: nextNumber(), ettn: uuid(), date: localISO(), dueDate: localISO(due), items: [{ description: '', quantity: 1, unitPrice: 0, taxRate: 20 }], currency: Currency.TRY, paymentMethod: 'EFT/Havale', notes: company.iban ? `${tr ? 'Ödeme hesabı' : 'Pay to'}: ${company.iban}` : '', customerName: '', customerTaxNo: '', customerTaxOffice: '', customerAddress: '', wh: 0, record: true });
  };
  const openEdit = (i: Invoice) => { setTouched(false); setForm({ ...i, items: i.items.map(x => ({ ...x })), wh: i.subtotal ? Math.round(((i.withholdingTotal || 0) / i.subtotal) * 100) : 0, record: false }); };
  const pickCustomer = (id: string) => {
    const c = customers.find(x => x.id === id); if (!c || !form) return;
    setForm({ ...form, customerId: c.id, customerName: c.company || c.name, customerTaxNo: c.taxNumber || '', customerTaxOffice: c.taxOffice || '', customerAddress: c.address || '' });
  };
  const setItem = (idx: number, patch: Partial<InvoiceItem>) => form && setForm({ ...form, items: form.items!.map((x, i) => i === idx ? { ...x, ...patch } : x) });
  const ft = form ? totalsOf(form.items || [], form.wh) : null;

  const errs: Record<string, string> = {};
  if (form) {
    if (!form.customerName?.trim()) errs.customer = tr ? 'Alıcı unvanı zorunlu.' : 'Required.';
    if (!/^\d{10,11}$/.test((form.customerTaxNo || '').trim())) errs.tax = tr ? 'VKN 10, TCKN 11 haneli olmalı.' : '10–11 digits.';
    if (!(form.items || []).some(x => x.description.trim() && Number(x.quantity) > 0 && Number(x.unitPrice) > 0)) errs.items = tr ? 'En az bir geçerli kalem girin.' : 'Add an item.';
    if (form.dueDate && form.date && form.dueDate < form.date) errs.due = tr ? 'Vade, fatura tarihinden önce olamaz.' : 'Invalid due date.';
  }
  const e = (k: string) => (touched ? errs[k] : undefined);

  const save = async (status: Invoice['status']) => {
    setTouched(true);
    if (!form || Object.keys(errs).length) return;
    setSaving(true);
    try {
      const items = (form.items || []).filter(x => x.description.trim()).map(x => ({ ...x, quantity: Number(x.quantity), unitPrice: Number(x.unitPrice), taxRate: Number(x.taxRate) }));
      const t = totalsOf(items, form.wh);
      const isNew = !form.id;
      const { wh, record, ...rest } = form;
      const inv: Invoice = { ...(rest as Invoice), id: form.id || `inv${Date.now()}`, customerId: form.customerId || `manual_${Date.now()}`, items, ...t, status, currency: form.currency || Currency.TRY };
      await onAddInvoice(inv);
      const wasIssued = !isNew && invoices.find(x => x.id === inv.id)?.status !== 'Draft';
      if (status !== 'Draft' && record && !wasIssued) {
        await onAddTransaction({ id: `tr_inv_${inv.id}`, type: 'Income', amount: t.subtotal - t.withholdingTotal, currency: inv.currency!, category: 'E-Arşiv Fatura Satışı', date: inv.date, description: `${inv.invoiceNumber} nolu fatura (${inv.customerName})`, taxRate: t.subtotal ? Math.round((t.taxTotal / t.subtotal) * 100) : 0, taxAmount: t.taxTotal, totalAmountWithTax: t.totalAmount });
      }
      toast.success(status === 'Draft' ? (tr ? 'Taslak kaydedildi' : 'Draft saved') : isNew ? (tr ? `${inv.invoiceNumber} düzenlendi${record ? ' · gelire işlendi' : ''}` : 'Issued') : (tr ? 'Fatura güncellendi' : 'Updated'));
      setForm(null);
    } catch (err: any) { toast.error(err?.message || 'Hata'); } finally { setSaving(false); }
  };

  const setStatus = async (i: Invoice, status: Invoice['status']) => {
    const upd: Invoice = { ...i, status, paidDate: status === 'Paid' ? localISO() : i.paidDate };
    await onAddInvoice(upd);
    if (status === 'Cancelled' && onDeleteTransaction) { try { await onDeleteTransaction(`tr_inv_${i.id}`); } catch { /* kayıt yoksa sorun değil */ } }
    if (preview?.id === i.id) setPreview(upd);
    toast(status === 'Paid' ? (tr ? `${i.invoiceNumber} tahsil edildi` : 'Marked paid') : status === 'Cancelled' ? (tr ? `${i.invoiceNumber} iptal edildi${onDeleteTransaction ? ' · gelir kaydı geri alındı' : ''}` : 'Cancelled') : (tr ? 'Durum güncellendi' : 'Updated'), status === 'Paid' ? 'success' : 'info');
  };

  const chip = (i: Invoice) => {
    const s = stateOf(i); const d = dayDiff(i.dueDate);
    const C = 'text-[11px] font-semibold px-2 py-0.5 rounded-md whitespace-nowrap inline-flex items-center gap-1';
    if (s === 'paid') return <span className={`${C} bg-emerald-50 text-emerald-700 dark:bg-emerald-500/10 dark:text-emerald-300`}><CheckCircle2 size={11} />{tr ? 'Tahsil edildi' : 'Paid'}</span>;
    if (s === 'cancelled') return <span className={`${C} bg-slate-100 text-slate-500 dark:bg-white/5`}><Ban size={11} />{tr ? 'İptal' : 'Cancelled'}</span>;
    if (s === 'draft') return <span className={`${C} bg-slate-100 text-slate-600 dark:bg-white/5 dark:text-slate-300`}>{tr ? 'Taslak' : 'Draft'}</span>;
    if (s === 'overdue') return <span className={`${C} bg-rose-50 text-rose-700 dark:bg-rose-500/10 dark:text-rose-300`}><AlertTriangle size={11} />{tr ? `${Math.abs(d!)} gün gecikti` : 'Overdue'}</span>;
    return <span className={`${C} bg-amber-50 text-amber-700 dark:bg-amber-500/10 dark:text-amber-300`}><Clock size={11} />{d !== null ? (d === 0 ? (tr ? 'Vade bugün' : 'Due today') : (tr ? `Vadeye ${d} gün` : `Due in ${d}d`)) : (tr ? 'Bekliyor' : 'Open')}</span>;
  };

  const P = preview; const pc = P?.currency || Currency.TRY;

  return (
    <div className="space-y-5 pb-10">
      <PageHeader title={tr ? 'Faturalar' : 'Invoices'} subtitle={tr ? 'Satış faturaları, vade ve tahsilat takibi.' : 'Sales invoices, due dates and collections.'}
        actions={<button onClick={openNew} className={btnPrimary}><Plus size={16} />{tr ? 'Yeni fatura' : 'New invoice'}</button>} />

      <KpiGrid items={[
        { label: tr ? 'Bu ay faturalanan' : 'Invoiced this month', value: showFinancials ? stats.month : 0, format: formatTRY, icon: Receipt, grad: 'from-indigo-500 to-violet-600', sub: `${stats.monthCount} ${tr ? 'fatura' : 'invoices'}` },
        { label: tr ? 'Tahsil edilecek' : 'Receivable', value: showFinancials ? stats.open : 0, format: formatTRY, icon: Wallet, grad: 'from-amber-500 to-orange-600', sub: `${stats.openCount} ${tr ? 'açık fatura' : 'open'}`, onClick: () => setView(view === 'open' ? 'all' : 'open'), active: view === 'open' },
        { label: tr ? 'Vadesi geçen' : 'Overdue', value: showFinancials ? stats.overdue : 0, format: formatTRY, icon: AlertTriangle, grad: 'from-rose-500 to-red-600', sub: `${stats.overdueCount} ${tr ? 'fatura' : 'invoices'}`, onClick: () => setView(view === 'overdue' ? 'all' : 'overdue'), active: view === 'overdue' },
        { label: tr ? 'Bu ay hesaplanan KDV' : 'VAT this month', value: showFinancials ? stats.vat : 0, format: formatTRY, icon: Percent, grad: 'from-sky-500 to-blue-600', sub: tr ? 'Beyan için' : 'For filing' },
      ]} />

      <div className={`${cardCls} p-3 flex flex-col lg:flex-row gap-2`}>
        <Segmented<View> value={view} onChange={setView} options={[
          { value: 'all', label: tr ? 'Tümü' : 'All' }, { value: 'open', label: tr ? 'Açık' : 'Open' }, { value: 'overdue', label: tr ? 'Geciken' : 'Overdue' },
          { value: 'paid', label: tr ? 'Ödenen' : 'Paid' }, { value: 'draft', label: tr ? 'Taslak' : 'Draft' }, { value: 'cancelled', label: tr ? 'İptal' : 'Void' },
        ]} />
        <SearchBox value={search} onChange={setSearch} placeholder={tr ? 'No, alıcı, VKN veya kalem ara…' : 'Search…'} />
        <select value={month} onChange={ev => setMonth(ev.target.value)} className={selectSm}><option value="all">{tr ? 'Tüm dönemler' : 'All periods'}</option>{months.map(m => <option key={m} value={m}>{m}</option>)}</select>
      </div>

      <div key={view} className={`${cardCls} overflow-hidden animate-in fade-in duration-300`}>
        {list.length === 0 ? <EmptyState icon={FileText} text={tr ? 'Fatura bulunamadı' : 'No invoices'} action={<button onClick={openNew} className={btnPrimary}><Plus size={15} />{tr ? 'Fatura oluştur' : 'Create'}</button>} /> : (
          <div className="divide-y divide-slate-100 dark:divide-slate-800 pc-stagger">
            {list.map(i => {
              const s = stateOf(i);
              return (
                <div key={i.id} className={`grid grid-cols-12 gap-3 items-center px-4 py-3 hover:bg-slate-50/70 dark:hover:bg-white/[0.02] ${s === 'cancelled' ? 'opacity-60' : ''}`}>
                  <div className="col-span-12 md:col-span-4 flex items-center gap-3 min-w-0">
                    <Avatar name={i.customerName} />
                    <div className="min-w-0"><p className="text-sm font-semibold text-slate-800 dark:text-slate-100 truncate">{i.customerName}</p><p className="text-[11px] text-slate-400 font-mono truncate">{i.invoiceNumber}{i.eInvoiceId ? ' · e-Arşiv' : ''}</p></div>
                  </div>
                  <div className="col-span-6 md:col-span-2 text-xs text-slate-500"><p>{i.date}</p>{i.dueDate && <p className="text-[10px] text-slate-400">{tr ? 'Vade' : 'Due'} {i.dueDate}</p>}</div>
                  <div className="col-span-6 md:col-span-2">{chip(i)}</div>
                  <div className={`col-span-6 md:col-span-2 text-right text-sm font-bold ${s === 'cancelled' ? 'line-through text-slate-400' : 'text-slate-900 dark:text-white'}`}>{show(i.totalAmount, i.currency)}</div>
                  <div className="col-span-6 md:col-span-2 flex justify-end items-center gap-1">
                    {(s === 'sent' || s === 'overdue') && <button onClick={() => setStatus(i, 'Paid')} title={tr ? 'Tahsil edildi' : 'Mark paid'} className="h-8 px-2.5 rounded-lg text-[11px] font-semibold text-emerald-700 bg-emerald-50 hover:bg-emerald-100 dark:bg-emerald-500/10 dark:text-emerald-300 inline-flex items-center gap-1"><CheckCircle2 size={12} />{tr ? 'Tahsil' : 'Paid'}</button>}
                    <button onClick={() => setPreview(i)} title={tr ? 'Görüntüle' : 'View'} className="p-1.5 rounded-lg text-slate-400 hover:text-indigo-600 hover:bg-indigo-50 dark:hover:bg-white/5"><Eye size={15} /></button>
                    {(s === 'draft') && <button onClick={() => openEdit(i)} className="p-1.5 rounded-lg text-slate-400 hover:text-indigo-600 hover:bg-indigo-50 dark:hover:bg-white/5"><Edit2 size={14} /></button>}
                    {s === 'draft' && <DeleteButton language={language} onConfirm={async () => { await onDeleteInvoice(i.id); toast(tr ? 'Taslak silindi' : 'Deleted', 'info'); }} />}
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>

      {/* Fatura formu */}
      <Sheet open={!!form} language={language} width="max-w-3xl" title={form?.id ? (tr ? 'Taslağı düzenle' : 'Edit draft') : (tr ? 'Yeni fatura' : 'New invoice')} subtitle={form?.invoiceNumber} icon={FileText} onClose={() => setForm(null)} onSubmit={() => save('Sent')} saving={saving} submitLabel={tr ? 'Faturayı düzenle' : 'Issue'}
        footerLeft={form ? <button onClick={() => save('Draft')} disabled={saving} className={btnGhost + ' !h-9'}>{tr ? 'Taslak olarak kaydet' : 'Save draft'}</button> : undefined}>
        {form && ft && <>
          <div className="rounded-2xl border border-slate-100 dark:border-slate-800 p-4 space-y-4">
            <div className="flex items-center gap-2"><Building2 size={15} className="text-indigo-500" /><p className="text-sm font-bold text-slate-800 dark:text-slate-100 flex-1">{tr ? 'Alıcı' : 'Buyer'}</p>
              {customers.length > 0 && <select className={selectSm} value={form.customerId || ''} onChange={ev => pickCustomer(ev.target.value)}><option value="">{tr ? 'Kayıtlı müşteriden seç…' : 'Pick customer…'}</option>{customers.map(c => <option key={c.id} value={c.id}>{c.company || c.name}</option>)}</select>}
            </div>
            <Field label={tr ? 'Unvan / ad soyad' : 'Name'} required error={e('customer')}><input className={inputCls(e('customer'))} value={form.customerName || ''} onChange={ev => setForm({ ...form, customerName: ev.target.value })} /></Field>
            <div className="grid grid-cols-2 gap-4">
              <Field label="VKN / TCKN" required error={e('tax')}><input inputMode="numeric" maxLength={11} className={inputCls(e('tax')) + ' font-mono'} value={form.customerTaxNo || ''} onChange={ev => setForm({ ...form, customerTaxNo: ev.target.value.replace(/\D/g, '') })} /></Field>
              <Field label={tr ? 'Vergi dairesi' : 'Tax office'}><input className={inputCls()} value={form.customerTaxOffice || ''} onChange={ev => setForm({ ...form, customerTaxOffice: ev.target.value })} /></Field>
            </div>
            <Field label={tr ? 'Adres' : 'Address'}><input className={inputCls()} value={form.customerAddress || ''} onChange={ev => setForm({ ...form, customerAddress: ev.target.value })} /></Field>
          </div>

          <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
            <Field label={tr ? 'Fatura tarihi' : 'Date'}><input type="date" className={inputCls()} value={form.date || ''} onChange={ev => setForm({ ...form, date: ev.target.value })} /></Field>
            <Field label={tr ? 'Vade' : 'Due'} error={e('due')}><input type="date" className={inputCls(e('due'))} value={form.dueDate || ''} onChange={ev => setForm({ ...form, dueDate: ev.target.value })} /></Field>
            <Field label={tr ? 'Para birimi' : 'Currency'}><select className={inputCls()} value={form.currency} onChange={ev => setForm({ ...form, currency: ev.target.value as Currency })}>{Object.values(Currency).map(c => <option key={c} value={c}>{c}</option>)}</select></Field>
            <Field label={tr ? 'Ödeme şekli' : 'Payment'}><select className={inputCls()} value={form.paymentMethod} onChange={ev => setForm({ ...form, paymentMethod: ev.target.value })}>{['EFT/Havale', 'Kredi Kartı', 'Nakit', 'Çek'].map(m => <option key={m}>{m}</option>)}</select></Field>
          </div>

          <div>
            <div className="flex items-center justify-between mb-2"><p className="text-xs font-semibold text-slate-500">{tr ? 'Mal / hizmet kalemleri' : 'Line items'}</p><button type="button" onClick={() => setForm({ ...form, items: [...form.items!, { description: '', quantity: 1, unitPrice: 0, taxRate: 20 }] })} className="text-xs font-semibold text-indigo-600 hover:underline inline-flex items-center gap-1"><Plus size={12} />{tr ? 'Satır ekle' : 'Add line'}</button></div>
            {e('items') && <p className="text-xs text-rose-500 mb-2">{e('items')}</p>}
            <div className="space-y-2">
              {form.items!.map((it, idx) => (
                <div key={idx} className="grid grid-cols-12 gap-2 items-center p-2 rounded-xl bg-slate-50 dark:bg-white/[0.03] animate-in fade-in slide-in-from-top-1 duration-200">
                  <input placeholder={tr ? 'Açıklama' : 'Description'} className={inputCls() + ' col-span-12 sm:col-span-5 !h-10'} value={it.description} onChange={ev => setItem(idx, { description: ev.target.value })} />
                  <input type="number" min={0} title={tr ? 'Miktar' : 'Qty'} className={inputCls() + ' col-span-3 sm:col-span-2 !h-10'} value={it.quantity} onChange={ev => setItem(idx, { quantity: Number(ev.target.value) })} />
                  <input type="number" min={0} title={tr ? 'Birim fiyat' : 'Unit price'} className={inputCls() + ' col-span-4 sm:col-span-2 !h-10'} value={it.unitPrice || ''} placeholder="0" onChange={ev => setItem(idx, { unitPrice: Number(ev.target.value) })} />
                  <select title={tr ? 'KDV' : 'VAT'} className={inputCls() + ' col-span-3 sm:col-span-2 !h-10'} value={it.taxRate} onChange={ev => setItem(idx, { taxRate: Number(ev.target.value) })}>{[0, 1, 10, 20].map(v => <option key={v} value={v}>%{v}</option>)}</select>
                  <button type="button" disabled={form.items!.length === 1} onClick={() => setForm({ ...form, items: form.items!.filter((_, i) => i !== idx) })} className="col-span-2 sm:col-span-1 p-2 rounded-lg text-slate-400 hover:text-rose-500 disabled:opacity-30 justify-self-center"><Trash2 size={15} /></button>
                </div>
              ))}
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div className="space-y-4">
              <Field label={tr ? 'Tevkifat / stopaj' : 'Withholding'}><Segmented<string> value={String(form.wh)} onChange={v => setForm({ ...form, wh: Number(v) })} options={['0', '10', '20'].map(v => ({ value: v, label: `%${v}` }))} /></Field>
              <Field label={tr ? 'Fatura notu' : 'Note'}><input className={inputCls()} value={form.notes || ''} onChange={ev => setForm({ ...form, notes: ev.target.value })} /></Field>
              {!form.id && <label className="flex items-center gap-2 text-sm text-slate-700 dark:text-slate-200 cursor-pointer"><input type="checkbox" className="w-4 h-4 accent-indigo-600" checked={form.record} onChange={ev => setForm({ ...form, record: ev.target.checked })} />{tr ? 'Muhasebeye gelir olarak işle' : 'Record income'}</label>}
            </div>
            <div className="rounded-2xl bg-slate-900 text-white p-4 space-y-2 text-sm">
              <div className="flex justify-between text-slate-400"><span>{tr ? 'Ara toplam' : 'Subtotal'}</span><span>{show(ft.subtotal, form.currency)}</span></div>
              <div className="flex justify-between text-slate-400"><span>KDV</span><span>+{show(ft.taxTotal, form.currency)}</span></div>
              {ft.withholdingTotal > 0 && <div className="flex justify-between text-rose-300"><span>{tr ? 'Tevkifat' : 'Withholding'}</span><span>−{show(ft.withholdingTotal, form.currency)}</span></div>}
              <div className="flex justify-between items-end pt-2 border-t border-white/10"><span className="text-slate-300">{tr ? 'Ödenecek' : 'Total'}</span><span className="text-2xl font-black">{show(ft.totalAmount, form.currency)}</span></div>
            </div>
          </div>
        </>}
      </Sheet>

      {/* Önizleme */}
      <Sheet open={!!P} language={language} width="max-w-4xl" title={P?.invoiceNumber || ''} subtitle={P ? `${P.customerName} · ${P.date}` : ''} icon={Receipt} onClose={() => { setPreview(null); setEInv(null); }}
        footerLeft={P ? <div className="flex flex-wrap gap-2">
          <button onClick={() => window.print()} className={btnGhost + ' !h-9'}><Printer size={14} />{tr ? 'Yazdır / PDF' : 'Print'}</button>
          {(stateOf(P) === 'sent' || stateOf(P) === 'overdue') && <button onClick={() => setStatus(P, 'Paid')} className={btnGhost + ' !h-9 !text-emerald-700'}><CheckCircle2 size={14} />{tr ? 'Tahsil edildi' : 'Mark paid'}</button>}
          {P.status === 'Paid' && <button onClick={() => setStatus(P, 'Sent')} className={btnGhost + ' !h-9'}>{tr ? 'Ödenmedi yap' : 'Mark unpaid'}</button>}
          {P.status !== 'Cancelled' && P.status !== 'Draft' && <DeleteButton language={language} label text={tr ? 'İptal et' : 'Void'} confirmText={tr ? 'Faturayı iptal et' : 'Void invoice'} onConfirm={() => setStatus(P, 'Cancelled')} />}
        </div> : undefined}>
        {P && <>
          <div className="rounded-2xl border border-slate-100 dark:border-slate-800 p-3 flex flex-wrap items-center gap-2 text-xs">
            {chip(P)}
            {P.eInvoiceId ? <span className="text-slate-500">e-Arşiv: <b className="font-mono">{P.eInvoiceId}</b>{P.eInvoiceUrl && <a href={P.eInvoiceUrl} target="_blank" rel="noreferrer" className="ml-1 text-indigo-600 inline-flex items-center gap-0.5">{tr ? 'aç' : 'open'}<ExternalLink size={10} /></a>}</span>
              : P.status !== 'Draft' && P.status !== 'Cancelled' && (eInv
                ? <span className="flex flex-wrap items-center gap-1.5 w-full"><input placeholder={tr ? 'Entegratör belge no' : 'Provider doc no'} className={inputCls() + ' !h-8 !w-44'} value={eInv.id} onChange={ev => setEInv({ ...eInv, id: ev.target.value })} /><input placeholder={tr ? 'Belge bağlantısı (ops.)' : 'URL (optional)'} className={inputCls() + ' !h-8 flex-1 min-w-[140px]'} value={eInv.url} onChange={ev => setEInv({ ...eInv, url: ev.target.value })} /><button disabled={!eInv.id.trim()} onClick={async () => { const u = { ...P, isEInvoice: true, eInvoiceId: eInv.id.trim(), eInvoiceUrl: eInv.url.trim() || undefined }; await onAddInvoice(u); setPreview(u); setEInv(null); toast.success(tr ? 'e-Arşiv bilgisi kaydedildi' : 'Saved'); }} className={btnPrimary + ' !h-8 !text-xs'}>{tr ? 'Kaydet' : 'Save'}</button></span>
                : <button onClick={() => setEInv({ id: '', url: '' })} className="text-indigo-600 font-semibold hover:underline">{tr ? '+ Entegratörde kesilen e-Arşiv numarasını ekle' : '+ Add e-invoice number'}</button>)}
            {P.paidDate && <span className="text-slate-400 ml-auto">{tr ? 'Tahsil' : 'Paid'}: {P.paidDate}</span>}
          </div>

          <div id="invoice-print-area" className="bg-white text-slate-900 rounded-2xl border border-slate-100 p-6 sm:p-8 space-y-6">
            <div className="flex flex-col sm:flex-row justify-between gap-4 pb-4 border-b-2 border-slate-900">
              <div className="flex gap-3">
                {company.logoUrl && <img src={company.logoUrl} alt="" className="w-14 h-14 object-contain" />}
                <div><p className="text-lg font-black">{company.legalName || company.name || 'Panimo Soft'}</p><div className="text-[11px] text-slate-500 leading-relaxed">{company.address && <p>{company.address}</p>}<p>{[company.phone, company.email, company.website].filter(Boolean).join(' · ')}</p>{(company.taxOffice || company.taxNumber) && <p>{company.taxOffice} {company.taxNumber && `· VKN ${company.taxNumber}`}</p>}</div></div>
              </div>
              <div className="sm:text-right text-xs space-y-0.5"><p className="text-xl font-black text-slate-300">{P.isEInvoice ? 'e-ARŞİV FATURA' : (tr ? 'FATURA' : 'INVOICE')}</p><p>{tr ? 'No' : 'No'}: <b>{P.invoiceNumber}</b></p><p>{tr ? 'Tarih' : 'Date'}: <b>{P.date}</b></p>{P.dueDate && <p>{tr ? 'Vade' : 'Due'}: <b>{P.dueDate}</b></p>}<p className="font-mono text-[10px] text-slate-400">ETTN {P.ettn}</p></div>
            </div>
            <div className="flex flex-col sm:flex-row justify-between gap-4">
              <div className="text-xs"><p className="text-[10px] font-bold text-slate-400 mb-1">{tr ? 'SAYIN' : 'BILL TO'}</p><p className="text-base font-bold">{P.customerName}</p><p className="text-slate-500">{P.customerAddress}</p><p className="text-slate-500">{P.customerTaxOffice} · {P.customerTaxNo?.length === 11 ? 'TCKN' : 'VKN'} {P.customerTaxNo}</p></div>
              <div className="w-24 h-24 shrink-0"><QRCode value={`${company.taxNumber || ''}|${P.invoiceNumber}|${P.ettn}|${P.date}|${P.totalAmount.toFixed(2)} ${pc}`} size={96} style={{ width: '100%', height: '100%' }} /></div>
            </div>
            <table className="w-full text-xs">
              <thead><tr className="border-y border-slate-900 text-left"><th className="py-2 pr-2">#</th><th className="py-2 pr-2">{tr ? 'Mal / hizmet' : 'Item'}</th><th className="py-2 pr-2 text-right">{tr ? 'Miktar' : 'Qty'}</th><th className="py-2 pr-2 text-right">{tr ? 'Birim fiyat' : 'Price'}</th><th className="py-2 pr-2 text-right">KDV</th><th className="py-2 text-right">{tr ? 'Tutar' : 'Amount'}</th></tr></thead>
              <tbody className="divide-y divide-slate-100">{P.items.map((it, idx) => <tr key={idx}><td className="py-2 pr-2">{idx + 1}</td><td className="py-2 pr-2 font-semibold">{it.description}</td><td className="py-2 pr-2 text-right">{it.quantity}</td><td className="py-2 pr-2 text-right">{show(it.unitPrice, pc)}</td><td className="py-2 pr-2 text-right">%{it.taxRate}</td><td className="py-2 text-right font-semibold">{show(it.quantity * it.unitPrice, pc)}</td></tr>)}</tbody>
            </table>
            <div className="flex flex-col sm:flex-row justify-between gap-4">
              <div className="text-[11px] text-slate-500 space-y-1 max-w-sm">{P.paymentMethod && <p>{tr ? 'Ödeme şekli' : 'Payment'}: <b className="text-slate-700">{P.paymentMethod}</b></p>}{company.iban && <p>IBAN: <b className="text-slate-700 font-mono">{company.iban}</b></p>}{P.notes && <p>{P.notes}</p>}<p className="font-semibold text-slate-700">{tr ? 'Yalnız' : 'Total'} {showFinancials ? P.totalAmount.toLocaleString('tr-TR', { minimumFractionDigits: 2 }) : '••••'} {CUR_NAME[pc] || pc}</p></div>
              <div className="w-full sm:w-64 text-xs space-y-1.5"><div className="flex justify-between"><span className="text-slate-500">{tr ? 'Mal hizmet toplamı' : 'Subtotal'}</span><span>{show(P.subtotal, pc)}</span></div><div className="flex justify-between"><span className="text-slate-500">{tr ? 'Hesaplanan KDV' : 'VAT'}</span><span>{show(P.taxTotal, pc)}</span></div>{!!P.withholdingTotal && <div className="flex justify-between"><span className="text-slate-500">{tr ? 'Tevkifat' : 'Withholding'}</span><span>−{show(P.withholdingTotal, pc)}</span></div>}<div className="flex justify-between pt-2 border-t-2 border-slate-900 text-base font-black"><span>{tr ? 'Ödenecek' : 'Total'}</span><span>{show(P.totalAmount, pc)}</span></div></div>
            </div>
          </div>
          {!P.eInvoiceId && <p className="text-[11px] text-slate-400">{tr ? 'Bu belge sistem içi fatura kaydıdır. Resmi e-Arşiv/e-Fatura, özel entegratörünüz üzerinden düzenlenmeli ve belge numarası buraya eklenmelidir.' : 'Internal record; issue the official e-invoice via your provider.'}</p>}
        </>}
      </Sheet>
    </div>
  );
};

export default InvoicesView;
