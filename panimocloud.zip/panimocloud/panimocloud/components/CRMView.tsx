import React, { useMemo, useState } from 'react';
import { Target, TrendingUp, Plus, Phone, Mail, Building2, CheckCircle2, Clock, Trash2, Sparkles, Loader2, FileText, Upload, LayoutGrid, List, CalendarClock, MessageSquare, Users as UsersIcon, StickyNote, Bell, ChevronRight, Trophy, XCircle, UserPlus } from 'lucide-react';
import { Deal, DealStatus, Currency, Project, ProjectType, PaymentType, TaskStatus, CRMActivity, CRMActivityType, Customer } from '../types';
import { predictDealSuccess } from '../services/aiService';
import { pushNotification } from '../services/notificationService';
import { ref, uploadBytes, getDownloadURL } from 'firebase/storage';
import { storage } from '../firebase';
import { PageHeader, KpiGrid, SearchBox, Segmented, Field, EmptyState, DeleteButton, Sheet, Avatar, inputCls, selectSm, cardCls, btnPrimary, btnGhost, money } from './ui/Kit';
import { toTRY, formatTRY, dayDiff, localISO } from '../services/insights';
import { toast } from '../services/toast';

interface Props {
  deals: Deal[];
  language: 'tr' | 'en';
  onUpsertDeal: (deal: Deal) => Promise<void>;
  onDeleteDeal: (id: string) => Promise<void>;
  showFinancials: boolean;
  currentUser: any;
  rates?: { TRY: number; EUR: number };
  onUpsertProject?: (project: Project) => Promise<void>;
  onAddTask?: (task: any) => Promise<void>;
  financeSettings?: any;
  crmActivities?: CRMActivity[];
  onUpsertCrmActivity?: (activity: CRMActivity) => Promise<void>;
  onDeleteCrmActivity?: (id: string) => Promise<void>;
  customers?: Customer[];
  onUpsertCustomer?: (customer: Customer) => Promise<void>;
}

const STAGES: { id: DealStatus; tr: string; en: string; dot: string; prob: number }[] = [
  { id: DealStatus.LEAD, tr: 'Potansiyel', en: 'Lead', dot: 'bg-slate-400', prob: 0.1 },
  { id: DealStatus.PROPOSAL, tr: 'Teklif', en: 'Proposal', dot: 'bg-indigo-500', prob: 0.35 },
  { id: DealStatus.NEGOTIATION, tr: 'Pazarlık', en: 'Negotiation', dot: 'bg-amber-500', prob: 0.65 },
  { id: DealStatus.WON, tr: 'Kazanıldı', en: 'Won', dot: 'bg-emerald-500', prob: 1 },
  { id: DealStatus.LOST, tr: 'Kaybedildi', en: 'Lost', dot: 'bg-rose-500', prob: 0 },
];
const ACT: Record<CRMActivityType, { tr: string; en: string; icon: React.ElementType; tone: string }> = {
  Call: { tr: 'Arama', en: 'Call', icon: Phone, tone: 'bg-sky-500' },
  Email: { tr: 'E-posta', en: 'Email', icon: Mail, tone: 'bg-indigo-500' },
  Meeting: { tr: 'Toplantı', en: 'Meeting', icon: UsersIcon, tone: 'bg-violet-500' },
  Note: { tr: 'Not', en: 'Note', icon: StickyNote, tone: 'bg-amber-500' },
};

const CRMView: React.FC<Props> = ({ deals, language, onUpsertDeal, onDeleteDeal, showFinancials, currentUser, rates = { TRY: 1, EUR: 1 }, onUpsertProject, onAddTask, financeSettings, crmActivities = [], onUpsertCrmActivity, onDeleteCrmActivity, customers = [], onUpsertCustomer }) => {
  const tr = language === 'tr';
  const [layout, setLayout] = useState<'board' | 'list'>(() => { try { return (localStorage.getItem('panimo-crm-layout') as any) || 'board'; } catch { return 'board'; } });
  const [search, setSearch] = useState('');
  const [onlyMine, setOnlyMine] = useState(false);
  const [form, setForm] = useState<Partial<Deal> | null>(null);
  const [tab, setTab] = useState<'details' | 'activity'>('details');
  const [touched, setTouched] = useState(false);
  const [saving, setSaving] = useState(false);
  const [uploading, setUploading] = useState(false);
  const [ai, setAi] = useState<{ score: number; reason: string } | null>(null);
  const [aiBusy, setAiBusy] = useState(false);
  const [act, setAct] = useState<Partial<CRMActivity>>({ type: 'Call', description: '', status: 'Completed' });
  const [dragId, setDragId] = useState<string | null>(null);
  const [overStage, setOverStage] = useState<DealStatus | null>(null);
  const show = (n: number, c?: string) => (showFinancials ? money(n, c) : '••••');
  const T = (d: Deal) => toTRY(d.value || 0, d.currency, rates);

  const q = search.trim().toLocaleLowerCase('tr-TR');
  const list = useMemo(() => deals.filter(d => (!onlyMine || d.assignedAdminId === currentUser?.id) && (!q || [d.contactName, d.companyName, d.email, d.phone, d.notes].join(' ').toLocaleLowerCase('tr-TR').includes(q))), [deals, q, onlyMine, currentUser?.id]);

  const followUps = useMemo(() => crmActivities.filter(a => a.status === 'Pending' && a.reminderDate).sort((a, b) => (a.reminderDate || '').localeCompare(b.reminderDate || '')), [crmActivities]);
  const overdueFollow = followUps.filter(a => (dayDiff((a.reminderDate || '').slice(0, 10)) ?? 1) <= 0);

  const stats = useMemo(() => {
    const open = deals.filter(d => d.status !== DealStatus.WON && d.status !== DealStatus.LOST);
    const year = String(new Date().getFullYear());
    const closed = deals.filter(d => d.status === DealStatus.WON || d.status === DealStatus.LOST);
    return {
      pipeline: open.reduce((a, d) => a + T(d), 0),
      weighted: open.reduce((a, d) => a + T(d) * (STAGES.find(s => s.id === d.status)?.prob || 0), 0),
      openCount: open.length,
      wonYear: deals.filter(d => d.status === DealStatus.WON && (d.updatedAt || '').startsWith(year)).reduce((a, d) => a + T(d), 0),
      wonCount: deals.filter(d => d.status === DealStatus.WON && (d.updatedAt || '').startsWith(year)).length,
      winRate: closed.length ? Math.round((deals.filter(d => d.status === DealStatus.WON).length / closed.length) * 100) : 0,
      closingSoon: open.filter(d => { const x = dayDiff(d.expectedCloseDate); return x !== null && x <= 14; }).length,
    };
  }, [deals, rates]);

  // ---------- Kazanılınca proje ----------
  const createProjectFromDeal = async (deal: Deal) => {
    if (!onUpsertProject || !onAddTask) return;
    const projectId = `proj_${Date.now()}`;
    await onUpsertProject({
      id: projectId, name: `${deal.companyName || deal.contactName} - ${tr ? 'Proje' : 'Project'}`, client: deal.companyName || deal.contactName, status: 'Active',
      budget: deal.value, currency: deal.currency, taxRate: deal.taxRate, taxAmount: deal.taxAmount, totalAmountWithTax: deal.totalAmountWithTax, progress: 0, paymentType: PaymentType.MILESTONE, projectType: ProjectType.OTHER,
      installments: [], documents: [], contracts: [], startDate: localISO(), clientContactName: deal.contactName, clientEmail: deal.email, clientPhone: deal.phone, description: deal.notes,
      portalSettings: { showFinancials: true, showTeam: true, showTasks: true, isPublic: false },
    });
    const due = new Date(Date.now() + 7 * 86400000).toISOString().split('T')[0];
    for (const title of tr ? ['Müşteri ile başlangıç toplantısı', 'İhtiyaç analizi', 'Sözleşme ve ön ödeme'] : ['Kick-off meeting', 'Requirement analysis', 'Contract & advance payment']) {
      await onAddTask({ projectId, title, status: TaskStatus.TODO, assignedTo: [], progress: 0, deadline: due });
    }
    pushNotification(tr ? 'Fırsat kazanıldı' : 'Deal won', tr ? `${deal.contactName} fırsatı için proje açıldı.` : `Project started for ${deal.contactName}.`, 'success', 'projects');
    toast.success(tr ? 'Fırsat kazanıldı · proje ve başlangıç görevleri oluşturuldu 🎉' : 'Won · project created');
  };

  const moveTo = async (d: Deal, status: DealStatus) => {
    if (d.status === status) return;
    const upd = { ...d, status, updatedAt: new Date().toISOString() };
    await onUpsertDeal(upd);
    if (status === DealStatus.WON) await createProjectFromDeal(upd);
    else toast(tr ? `${d.companyName || d.contactName} → ${STAGES.find(s => s.id === status)!.tr}` : 'Moved', status === DealStatus.LOST ? 'warning' : 'info', 2200);
  };

  // ---------- Form ----------
  const openNew = (status = DealStatus.LEAD) => { setTouched(false); setAi(null); setTab('details'); setForm({ status, currency: financeSettings?.defaultCurrency || Currency.TRY, value: 0, taxRate: financeSettings?.defaultTaxRate ?? 20, notes: '' }); };
  const openEdit = (d: Deal) => { setTouched(false); setAi(null); setTab('details'); setForm({ ...d, taxRate: d.taxRate ?? financeSettings?.defaultTaxRate ?? 20 }); setAct({ type: 'Call', description: '', status: 'Completed' }); };
  const errs: Record<string, string> = {};
  if (form) {
    if (!form.contactName?.trim()) errs.contact = tr ? 'İlgili kişi zorunlu.' : 'Required.';
    if (form.email && !/^\S+@\S+\.\S+$/.test(form.email)) errs.email = tr ? 'Geçersiz e-posta.' : 'Invalid email.';
    if (Number(form.value) < 0) errs.value = tr ? 'Tutar negatif olamaz.' : 'Invalid.';
  }
  const fe = (k: string) => (touched ? errs[k] : undefined);
  const save = async () => {
    setTouched(true);
    if (!form || Object.keys(errs).length) return;
    setSaving(true);
    try {
      const value = Number(form.value) || 0; const rate = Number(form.taxRate || 0);
      const prev = form.id ? deals.find(d => d.id === form.id) : undefined;
      const deal: Deal = { ...(form as Deal), id: form.id || `deal_${Date.now()}`, contactName: form.contactName!.trim(), value, taxRate: rate, taxAmount: value * rate / 100, totalAmountWithTax: value * (1 + rate / 100), notes: form.notes || '', createdAt: form.createdAt || new Date().toISOString(), updatedAt: new Date().toISOString(), assignedAdminId: form.assignedAdminId || currentUser?.id || 'unknown', aiScore: ai ? ai.score : (form.aiScore || 0) };
      await onUpsertDeal(deal);
      if (deal.status === DealStatus.WON && prev?.status !== DealStatus.WON) await createProjectFromDeal(deal);
      else toast.success(prev ? (tr ? 'Fırsat güncellendi' : 'Updated') : (tr ? 'Fırsat eklendi' : 'Deal added'));
      setForm(null);
    } catch (e: any) { toast.error(e?.message || 'Hata'); } finally { setSaving(false); }
  };
  const upload = async (file?: File) => {
    if (!file || !form) return;
    setUploading(true);
    try { const r = ref(storage, `proposals/${Date.now()}_${file.name}`); await uploadBytes(r, file); setForm({ ...form, proposalUrl: await getDownloadURL(r) }); toast.success(tr ? 'Teklif dosyası yüklendi' : 'Uploaded'); }
    catch { toast.error(tr ? 'Dosya yüklenemedi' : 'Upload failed'); } finally { setUploading(false); }
  };
  const analyze = async () => {
    if (!form?.value) { toast.warning(tr ? 'Analiz için önce tutar girin' : 'Enter a value first'); return; }
    setAiBusy(true);
    try { setAi(await predictDealSuccess(form as Deal, language)); } catch { toast.error(tr ? 'Analiz yapılamadı' : 'Failed'); } finally { setAiBusy(false); }
  };
  const makeCustomer = async () => {
    if (!form || !onUpsertCustomer) return;
    await onUpsertCustomer({ id: `cust_${Date.now()}`, name: form.contactName || '', company: form.companyName, phone: form.phone || '', email: form.email });
    toast.success(tr ? 'Müşteri kaydı oluşturuldu' : 'Customer created');
  };
  const knownCustomer = form && customers.some(c => (form.companyName && c.company === form.companyName) || (form.phone && c.phone === form.phone));

  const dealActs = form?.id ? crmActivities.filter(a => a.dealId === form.id).sort((a, b) => (b.date || '').localeCompare(a.date || '')) : [];
  const saveAct = async () => {
    if (!form?.id || !onUpsertCrmActivity) return;
    if (!act.description?.trim()) { toast.warning(tr ? 'Açıklama girin' : 'Enter a description'); return; }
    await onUpsertCrmActivity({ ...(act as CRMActivity), id: `act_${Date.now()}`, dealId: form.id, userId: currentUser.id, userName: currentUser.name, date: new Date().toISOString(), status: act.reminderDate ? 'Pending' : 'Completed', description: act.description.trim() });
    setAct({ type: act.type, description: '', status: 'Completed', reminderDate: '' });
    toast.success(act.reminderDate ? (tr ? 'Takip hatırlatması eklendi' : 'Follow-up added') : (tr ? 'Aktivite kaydedildi' : 'Logged'));
  };

  // ---------- Parçalar ----------
  const closeChip = (d: Deal) => {
    if (!d.expectedCloseDate || d.status === DealStatus.WON || d.status === DealStatus.LOST) return null;
    const x = dayDiff(d.expectedCloseDate)!;
    return <span className={`text-[10px] font-semibold px-1.5 py-0.5 rounded inline-flex items-center gap-1 ${x < 0 ? 'bg-rose-50 text-rose-700 dark:bg-rose-500/10 dark:text-rose-300' : x <= 14 ? 'bg-amber-50 text-amber-700 dark:bg-amber-500/10 dark:text-amber-300' : 'bg-slate-100 text-slate-500 dark:bg-white/5'}`}><CalendarClock size={10} />{x < 0 ? (tr ? `${-x} gün geçti` : 'overdue') : x === 0 ? (tr ? 'bugün' : 'today') : (tr ? `${x} gün` : `${x}d`)}</span>;
  };
  const nextFollow = (d: Deal) => followUps.find(a => a.dealId === d.id);
  const card = (d: Deal) => {
    const f = nextFollow(d); const fd = f ? dayDiff((f.reminderDate || '').slice(0, 10)) : null;
    return (
      <div key={d.id} draggable onDragStart={e => { setDragId(d.id); e.dataTransfer.effectAllowed = 'move'; }} onDragEnd={() => { setDragId(null); setOverStage(null); }} onClick={() => openEdit(d)}
        className={`${cardCls} p-3 cursor-pointer pc-lift space-y-2 ${dragId === d.id ? 'opacity-40 scale-95' : ''}`}>
        <div className="flex items-start gap-2">
          <Avatar name={d.companyName || d.contactName} size="w-8 h-8" />
          <div className="min-w-0 flex-1"><p className="text-sm font-semibold text-slate-800 dark:text-slate-100 truncate">{d.companyName || d.contactName}</p><p className="text-[11px] text-slate-400 truncate">{d.companyName ? d.contactName : (d.email || d.phone || '—')}</p></div>
          {!!d.aiScore && <span title="AI" className={`text-[10px] font-bold px-1.5 py-0.5 rounded ${d.aiScore >= 60 ? 'bg-emerald-50 text-emerald-700 dark:bg-emerald-500/10 dark:text-emerald-300' : 'bg-amber-50 text-amber-700 dark:bg-amber-500/10 dark:text-amber-300'}`}>%{d.aiScore}</span>}
        </div>
        <div className="flex items-center gap-1.5 flex-wrap">
          <span className="text-sm font-black text-slate-900 dark:text-white mr-auto">{show(d.value, d.currency)}</span>
          {closeChip(d)}
          {f && <span className={`text-[10px] font-semibold px-1.5 py-0.5 rounded inline-flex items-center gap-1 ${fd !== null && fd <= 0 ? 'bg-rose-600 text-white' : 'bg-sky-50 text-sky-700 dark:bg-sky-500/10 dark:text-sky-300'}`}><Bell size={10} />{fd !== null && fd < 0 ? (tr ? 'takip gecikti' : 'late') : fd === 0 ? (tr ? 'bugün ara' : 'today') : (f.reminderDate || '').slice(5, 10)}</span>}
        </div>
      </div>
    );
  };

  return (
    <div className="space-y-5 pb-10">
      <PageHeader title={tr ? 'CRM ve Satış Hunisi' : 'CRM & Pipeline'} subtitle={tr ? 'Fırsatlar, teklifler ve müşteri takipleri.' : 'Deals, proposals and follow-ups.'}
        actions={<button onClick={() => openNew()} className={btnPrimary}><Plus size={16} />{tr ? 'Yeni fırsat' : 'New deal'}</button>} />

      <KpiGrid items={[
        { label: tr ? 'Açık huni değeri' : 'Open pipeline', value: showFinancials ? stats.pipeline : 0, format: formatTRY, icon: Target, grad: 'from-indigo-500 to-violet-600', sub: `${stats.openCount} ${tr ? 'fırsat' : 'deals'} · ${tr ? 'ağırlıklı' : 'weighted'} ${showFinancials ? formatTRY(stats.weighted) : '••'}` },
        { label: tr ? 'Bu yıl kazanılan' : 'Won this year', value: showFinancials ? stats.wonYear : 0, format: formatTRY, icon: Trophy, grad: 'from-emerald-500 to-teal-600', sub: `${stats.wonCount} ${tr ? 'fırsat' : 'deals'}` },
        { label: tr ? 'Kazanma oranı' : 'Win rate', value: stats.winRate, format: n => `%${n}`, icon: TrendingUp, grad: 'from-sky-500 to-blue-600', bar: stats.winRate, sub: tr ? `${stats.closingSoon} fırsat 14 gün içinde kapanmalı` : `${stats.closingSoon} closing soon` },
        { label: tr ? 'Bekleyen takip' : 'Follow-ups', value: followUps.length, icon: Bell, grad: overdueFollow.length ? 'from-rose-500 to-red-600' : 'from-amber-500 to-orange-600', sub: overdueFollow.length ? (tr ? `${overdueFollow.length} tanesi bugün/gecikmiş` : `${overdueFollow.length} due`) : (tr ? 'Gecikme yok' : 'None due') },
      ]} />

      {overdueFollow.length > 0 && (
        <div className={`${cardCls} p-3 flex flex-col gap-2 border-rose-200 dark:border-rose-500/30 animate-in fade-in duration-300`}>
          <p className="text-xs font-semibold text-rose-600 flex items-center gap-1.5"><Bell size={13} className="pc-bell" />{tr ? 'Bugün yapılması gereken takipler' : 'Follow-ups due'}</p>
          <div className="flex gap-2 overflow-x-auto custom-scrollbar pb-1">
            {overdueFollow.slice(0, 8).map(a => { const d = deals.find(x => x.id === a.dealId); const I = ACT[a.type]?.icon || Phone; return (
              <button key={a.id} onClick={() => { if (d) { openEdit(d); setTab('activity'); } }} className="shrink-0 max-w-[260px] text-left px-3 py-2 rounded-xl bg-rose-50/70 dark:bg-rose-500/10 hover:bg-rose-100 dark:hover:bg-rose-500/20">
                <p className="text-xs font-semibold text-slate-800 dark:text-slate-100 truncate flex items-center gap-1.5"><I size={12} />{d?.companyName || d?.contactName || '—'}</p>
                <p className="text-[11px] text-slate-500 truncate">{a.description}</p>
              </button>); })}
          </div>
        </div>
      )}

      <div className={`${cardCls} p-3 flex flex-col lg:flex-row gap-2`}>
        <SearchBox value={search} onChange={setSearch} placeholder={tr ? 'Kişi, firma, e-posta, telefon ara…' : 'Search…'} />
        <button onClick={() => setOnlyMine(!onlyMine)} className={`h-10 px-3 rounded-xl text-xs font-semibold border ${onlyMine ? 'bg-indigo-600 border-indigo-600 text-white' : 'border-slate-200 dark:border-slate-700 text-slate-600 dark:text-slate-300'}`}>{tr ? 'Yalnızca benimkiler' : 'Mine only'}</button>
        <div className="flex bg-slate-100 dark:bg-slate-800 rounded-xl p-1 shrink-0">
          {(['board', 'list'] as const).map(l => <button key={l} onClick={() => { setLayout(l); try { localStorage.setItem('panimo-crm-layout', l); } catch { /* yok say */ } }} className={`p-1.5 rounded-lg ${layout === l ? 'bg-white dark:bg-slate-900 text-indigo-600 shadow-sm' : 'text-slate-400'}`}>{l === 'board' ? <LayoutGrid size={15} /> : <List size={15} />}</button>)}
        </div>
      </div>

      {layout === 'board' ? (
        <div className="flex gap-3 overflow-x-auto custom-scrollbar pb-3 items-start">
          {STAGES.map(s => {
            const items = list.filter(d => d.status === s.id).sort((a, b) => (b.updatedAt || '').localeCompare(a.updatedAt || ''));
            const sum = items.reduce((a, d) => a + T(d), 0);
            return (
              <div key={s.id} onDragOver={e => { e.preventDefault(); setOverStage(s.id); }} onDragLeave={() => setOverStage(o => o === s.id ? null : o)}
                onDrop={async e => { e.preventDefault(); const d = deals.find(x => x.id === dragId); setOverStage(null); setDragId(null); if (d) await moveTo(d, s.id); }}
                className={`shrink-0 w-[280px] rounded-[20px] p-2 transition-colors ${overStage === s.id ? 'bg-indigo-50 dark:bg-indigo-500/10 ring-2 ring-indigo-300' : 'bg-slate-100/60 dark:bg-white/[0.02]'}`}>
                <div className="flex items-center gap-2 px-2 py-1.5">
                  <span className={`w-2 h-2 rounded-full ${s.dot}`} /><span className="text-sm font-bold text-slate-800 dark:text-slate-100">{tr ? s.tr : s.en}</span><span className="text-[11px] text-slate-400">{items.length}</span>
                  <span className="ml-auto text-[11px] font-semibold text-slate-500">{showFinancials ? formatTRY(sum) : ''}</span>
                </div>
                <div className="space-y-2 min-h-[80px] max-h-[62vh] overflow-y-auto custom-scrollbar p-0.5">
                  {items.map(card)}
                  {s.id !== DealStatus.WON && s.id !== DealStatus.LOST && <button onClick={() => openNew(s.id)} className="w-full h-9 rounded-xl border border-dashed border-slate-300 dark:border-slate-700 text-xs font-semibold text-slate-400 hover:text-indigo-600 hover:border-indigo-300 inline-flex items-center justify-center gap-1"><Plus size={13} />{tr ? 'Ekle' : 'Add'}</button>}
                </div>
              </div>
            );
          })}
        </div>
      ) : (
        <div className={`${cardCls} overflow-hidden`}>
          {list.length === 0 ? <EmptyState icon={Target} text={tr ? 'Fırsat yok' : 'No deals'} /> : (
            <div className="divide-y divide-slate-100 dark:divide-slate-800 pc-stagger">
              {[...list].sort((a, b) => STAGES.findIndex(s => s.id === a.status) - STAGES.findIndex(s => s.id === b.status) || (a.expectedCloseDate || '9').localeCompare(b.expectedCloseDate || '9')).map(d => { const s = STAGES.find(x => x.id === d.status)!; return (
                <button key={d.id} onClick={() => openEdit(d)} className="w-full text-left grid grid-cols-12 gap-3 items-center px-4 py-3 hover:bg-slate-50/70 dark:hover:bg-white/[0.02] group">
                  <div className="col-span-12 sm:col-span-4 flex items-center gap-3 min-w-0"><Avatar name={d.companyName || d.contactName} /><div className="min-w-0"><p className="text-sm font-semibold text-slate-800 dark:text-slate-100 truncate">{d.companyName || d.contactName}</p><p className="text-[11px] text-slate-400 truncate">{d.contactName}{d.phone ? ` · ${d.phone}` : ''}</p></div></div>
                  <div className="col-span-4 sm:col-span-2"><span className="text-[11px] font-semibold inline-flex items-center gap-1.5 text-slate-600 dark:text-slate-300"><span className={`w-2 h-2 rounded-full ${s.dot}`} />{tr ? s.tr : s.en}</span></div>
                  <div className="col-span-4 sm:col-span-2">{closeChip(d) || <span className="text-[11px] text-slate-400">{d.expectedCloseDate || '—'}</span>}</div>
                  <div className="col-span-4 sm:col-span-3 text-right text-sm font-bold text-slate-900 dark:text-white">{show(d.value, d.currency)}</div>
                  <ChevronRight size={16} className="hidden sm:block col-span-1 justify-self-end text-slate-300 group-hover:text-indigo-500" />
                </button>); })}
            </div>
          )}
        </div>
      )}

      <Sheet open={!!form} language={language} width="max-w-2xl" title={form?.id ? (form.companyName || form.contactName || '') : (tr ? 'Yeni fırsat' : 'New deal')} subtitle={form?.id ? `${tr ? 'Oluşturuldu' : 'Created'} ${(form.createdAt || '').slice(0, 10)}` : undefined} icon={Target} onClose={() => setForm(null)} onSubmit={tab === 'details' ? save : undefined} saving={saving}
        footerLeft={form?.id ? <DeleteButton language={language} label onConfirm={async () => { await onDeleteDeal(form.id!); toast(tr ? 'Fırsat silindi' : 'Deleted', 'info'); setForm(null); }} /> : undefined}>
        {form && <>
          {form.id && <Segmented<'details' | 'activity'> value={tab} onChange={setTab} options={[{ value: 'details', label: tr ? 'Detaylar' : 'Details' }, { value: 'activity', label: <>{tr ? 'Aktiviteler' : 'Activity'} <span className="text-[10px] opacity-60">{dealActs.length}</span></> }]} />}

          {tab === 'details' ? <>
            <Field label={tr ? 'Aşama' : 'Stage'}>
              <div className="flex flex-wrap gap-1.5">{STAGES.map(s => <button key={s.id} type="button" onClick={() => setForm({ ...form, status: s.id })} className={`h-9 px-3 rounded-xl text-xs font-semibold inline-flex items-center gap-1.5 border transition-all ${form.status === s.id ? 'bg-slate-900 dark:bg-white text-white dark:text-slate-900 border-transparent' : 'border-slate-200 dark:border-slate-700 text-slate-600 dark:text-slate-300 hover:border-indigo-300'}`}>{s.id === DealStatus.WON ? <Trophy size={12} /> : s.id === DealStatus.LOST ? <XCircle size={12} /> : <span className={`w-2 h-2 rounded-full ${s.dot}`} />}{tr ? s.tr : s.en}</button>)}</div>
              {form.status === DealStatus.WON && !deals.find(d => d.id === form.id && d.status === DealStatus.WON) && onUpsertProject && <p className="text-[11px] text-emerald-600 mt-1.5">{tr ? 'Kaydedince bu fırsat için otomatik proje ve başlangıç görevleri açılır.' : 'A project will be created on save.'}</p>}
            </Field>
            <div className="grid grid-cols-2 gap-4">
              <Field label={tr ? 'İlgili kişi' : 'Contact'} required error={fe('contact')}><input autoFocus className={inputCls(fe('contact'))} value={form.contactName || ''} onChange={e => setForm({ ...form, contactName: e.target.value })} /></Field>
              <Field label={tr ? 'Firma' : 'Company'}><input list="crm-companies" className={inputCls()} value={form.companyName || ''} onChange={e => { const c = customers.find(x => (x.company || x.name) === e.target.value); setForm({ ...form, companyName: e.target.value, ...(c ? { phone: form.phone || c.phone, email: form.email || c.email } : {}) }); }} /><datalist id="crm-companies">{customers.map(c => <option key={c.id} value={c.company || c.name} />)}</datalist></Field>
              <Field label={tr ? 'E-posta' : 'Email'} error={fe('email')}><input type="email" className={inputCls(fe('email'))} value={form.email || ''} onChange={e => setForm({ ...form, email: e.target.value })} /></Field>
              <Field label={tr ? 'Telefon' : 'Phone'}><input type="tel" className={inputCls()} value={form.phone || ''} onChange={e => setForm({ ...form, phone: e.target.value })} /></Field>
            </div>
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
              <Field label={tr ? 'Tutar (KDV hariç)' : 'Value'} error={fe('value')} className="col-span-2"><input type="number" min={0} className={inputCls(fe('value')) + ' font-bold'} value={form.value || ''} onChange={e => setForm({ ...form, value: Number(e.target.value) })} /></Field>
              <Field label={tr ? 'Para birimi' : 'Currency'}><select className={inputCls()} value={form.currency} onChange={e => setForm({ ...form, currency: e.target.value as Currency })}>{Object.values(Currency).map(c => <option key={c} value={c}>{c}</option>)}</select></Field>
              <Field label="KDV"><select className={inputCls()} value={form.taxRate} onChange={e => setForm({ ...form, taxRate: Number(e.target.value) })}>{[0, 1, 10, 20].map(v => <option key={v} value={v}>%{v}</option>)}</select></Field>
            </div>
            <div className="grid grid-cols-2 gap-4">
              <Field label={tr ? 'Beklenen kapanış' : 'Expected close'}><input type="date" className={inputCls()} value={form.expectedCloseDate || ''} onChange={e => setForm({ ...form, expectedCloseDate: e.target.value })} /></Field>
              <Field label={tr ? 'Teklif dosyası' : 'Proposal'}>
                {form.proposalUrl ? <div className="flex items-center gap-2 h-11"><a href={form.proposalUrl} target="_blank" rel="noreferrer" className="text-sm font-semibold text-indigo-600 hover:underline inline-flex items-center gap-1"><FileText size={14} />{tr ? 'Teklifi aç' : 'Open'}</a><button type="button" onClick={() => setForm({ ...form, proposalUrl: undefined })} className="text-xs text-slate-400 hover:text-rose-500">{tr ? 'kaldır' : 'remove'}</button></div>
                  : <label className={btnGhost + ' w-full cursor-pointer !h-11'}>{uploading ? <Loader2 size={15} className="animate-spin" /> : <Upload size={15} />}{tr ? 'Dosya yükle' : 'Upload'}<input type="file" className="hidden" onChange={e => upload(e.target.files?.[0])} /></label>}
              </Field>
            </div>
            <Field label={tr ? 'Notlar' : 'Notes'}><textarea rows={3} className={inputCls() + ' !h-auto py-2.5 resize-none'} value={form.notes || ''} onChange={e => setForm({ ...form, notes: e.target.value })} /></Field>
            <div className="flex flex-wrap items-center gap-2">
              <button type="button" onClick={analyze} disabled={aiBusy} className={btnGhost}>{aiBusy ? <Loader2 size={15} className="animate-spin" /> : <Sparkles size={15} />}{tr ? 'Kazanma olasılığını analiz et' : 'AI win chance'}</button>
              {onUpsertCustomer && form.contactName && !knownCustomer && <button type="button" onClick={makeCustomer} className={btnGhost}><UserPlus size={15} />{tr ? 'Müşteri kaydı oluştur' : 'Create customer'}</button>}
            </div>
            {(ai || form.aiScore) ? <div className="rounded-2xl bg-indigo-50/60 dark:bg-indigo-500/10 p-3 flex gap-3 items-start animate-in fade-in duration-300"><span className="text-2xl font-black text-indigo-600">%{ai?.score ?? form.aiScore}</span><p className="text-xs text-slate-600 dark:text-slate-300 leading-relaxed">{ai?.reason || (tr ? 'Önceki AI tahmini.' : 'Previous AI estimate.')}</p></div> : null}
          </> : <>
            {onUpsertCrmActivity && <div className="rounded-2xl border border-slate-100 dark:border-slate-800 p-3 space-y-3">
              <Segmented<CRMActivityType> value={act.type as CRMActivityType} onChange={v => setAct({ ...act, type: v })} options={(Object.keys(ACT) as CRMActivityType[]).map(k => { const I = ACT[k].icon; return { value: k, label: <><I size={13} />{tr ? ACT[k].tr : ACT[k].en}</> }; })} />
              <textarea rows={2} className={inputCls() + ' !h-auto py-2.5 resize-none'} placeholder={tr ? 'Ne konuşuldu / ne yapıldı?' : 'What happened?'} value={act.description || ''} onChange={e => setAct({ ...act, description: e.target.value })} onKeyDown={e => { if (e.key === 'Enter' && (e.ctrlKey || e.metaKey)) { e.preventDefault(); e.stopPropagation(); saveAct(); } }} />
              <div className="flex flex-wrap items-center gap-2">
                <label className="text-xs text-slate-500 inline-flex items-center gap-1.5"><Bell size={13} />{tr ? 'Takip hatırlatması' : 'Remind'}<input type="datetime-local" className={inputCls() + ' !h-9 !w-auto'} value={act.reminderDate || ''} onChange={e => setAct({ ...act, reminderDate: e.target.value })} /></label>
                <button onClick={saveAct} className={btnPrimary + ' !h-9 ml-auto'}><Plus size={14} />{tr ? 'Kaydet' : 'Log'}</button>
              </div>
            </div>}
            {dealActs.length === 0 ? <EmptyState icon={MessageSquare} text={tr ? 'Henüz aktivite yok' : 'No activity yet'} /> : (
              <div className="relative pl-5 space-y-3 before:absolute before:left-[9px] before:top-2 before:bottom-2 before:w-px before:bg-slate-200 dark:before:bg-slate-700">
                {dealActs.map(a => { const M = ACT[a.type] || ACT.Note; const I = M.icon; const pending = a.status === 'Pending'; const rd = a.reminderDate ? dayDiff(a.reminderDate.slice(0, 10)) : null; return (
                  <div key={a.id} className="relative animate-in fade-in slide-in-from-left-1 duration-300">
                    <span className={`absolute -left-5 top-1 w-[18px] h-[18px] rounded-full ${M.tone} text-white flex items-center justify-center ring-4 ring-white dark:ring-slate-900`}><I size={10} /></span>
                    <div className={`rounded-xl px-3 py-2 ${pending ? 'bg-sky-50/70 dark:bg-sky-500/10' : 'bg-slate-50 dark:bg-white/[0.03]'}`}>
                      <div className="flex items-center gap-2 text-[11px] text-slate-400"><b className="text-slate-600 dark:text-slate-300">{tr ? M.tr : M.en}</b>· {a.userName} · {new Date(a.date).toLocaleString('tr-TR', { day: 'numeric', month: 'short', hour: '2-digit', minute: '2-digit' })}
                        <span className="ml-auto flex items-center gap-1">
                          {pending && onUpsertCrmActivity && <button onClick={async () => { await onUpsertCrmActivity({ ...a, status: 'Completed' }); toast.success(tr ? 'Takip tamamlandı' : 'Done'); }} title={tr ? 'Tamamlandı' : 'Done'} className="p-1 rounded text-emerald-600 hover:bg-emerald-50 dark:hover:bg-emerald-500/10"><CheckCircle2 size={13} /></button>}
                          {onDeleteCrmActivity && <button onClick={() => onDeleteCrmActivity(a.id)} className="p-1 rounded text-slate-300 hover:text-rose-500"><Trash2 size={12} /></button>}
                        </span>
                      </div>
                      <p className="text-sm text-slate-700 dark:text-slate-200 whitespace-pre-wrap break-words">{a.description}</p>
                      {pending && a.reminderDate && <p className={`text-[11px] font-semibold mt-1 inline-flex items-center gap-1 ${rd !== null && rd <= 0 ? 'text-rose-600' : 'text-sky-600'}`}><Clock size={11} />{tr ? 'Takip' : 'Follow-up'}: {new Date(a.reminderDate).toLocaleString('tr-TR', { day: 'numeric', month: 'short', hour: '2-digit', minute: '2-digit' })}</p>}
                    </div>
                  </div>); })}
              </div>
            )}
          </>}
        </>}
      </Sheet>
    </div>
  );
};

export default CRMView;
