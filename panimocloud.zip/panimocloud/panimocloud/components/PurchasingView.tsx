import React, { useMemo, useState } from 'react';
import { ShoppingCart, Store, Plus, Edit2, Truck, PackageCheck, FileClock, Wallet, Trash2, Mail, Phone, AlertTriangle, CheckCircle2, Clock, FileText, Ban, Sparkles } from 'lucide-react';
import { Vendor, PurchaseOrder, PurchaseOrderItem, Currency, User, InventoryItem, Transaction } from '../types';
import { PageHeader, KpiGrid, SearchBox, Segmented, Field, EmptyState, DeleteButton, Sheet, inputCls, selectSm, cardCls, btnPrimary, btnGhost, money } from './ui/Kit';
import { toTRY, formatTRY, dayDiff, localISO } from '../services/insights';
import { toast } from '../services/toast';

interface Props {
  vendors: Vendor[];
  purchaseOrders: PurchaseOrder[];
  inventory: InventoryItem[];
  onUpsertVendor: (vendor: Vendor) => Promise<void>;
  onDeleteVendor?: (id: string) => Promise<void>;
  onUpsertPO: (po: PurchaseOrder) => Promise<void>;
  onDeletePO?: (id: string) => Promise<void>;
  onUpsertInventory?: (item: InventoryItem) => Promise<void>;
  onAddTransaction?: (tx: Transaction) => Promise<void>;
  currentUser: User;
  language: 'tr' | 'en';
  rates?: { TRY: number; EUR: number };
}

type Status = PurchaseOrder['status'];
const STATUS: Record<Status, { tr: string; en: string; chip: string; icon: React.ElementType }> = {
  Draft: { tr: 'Taslak', en: 'Draft', chip: 'bg-slate-100 text-slate-600 dark:bg-white/5 dark:text-slate-300', icon: FileText },
  Ordered: { tr: 'Sipariş verildi', en: 'Ordered', chip: 'bg-sky-50 text-sky-700 dark:bg-sky-500/10 dark:text-sky-300', icon: Truck },
  Received: { tr: 'Teslim alındı', en: 'Received', chip: 'bg-emerald-50 text-emerald-700 dark:bg-emerald-500/10 dark:text-emerald-300', icon: PackageCheck },
  Cancelled: { tr: 'İptal', en: 'Cancelled', chip: 'bg-rose-50 text-rose-700 dark:bg-rose-500/10 dark:text-rose-300', icon: Ban },
};
const totalOf = (items: PurchaseOrderItem[] = []) => Math.round(items.reduce((s, i) => s + (Number(i.quantity) || 0) * (Number(i.unitPrice) || 0), 0) * 100) / 100;

const PurchasingView: React.FC<Props> = ({ vendors, purchaseOrders, inventory, onUpsertVendor, onDeleteVendor, onUpsertPO, onDeletePO, onUpsertInventory, onAddTransaction, currentUser, language, rates = { TRY: 34, EUR: 0.92 } }) => {
  const tr = language === 'tr';
  const [tab, setTab] = useState<'orders' | 'vendors'>('orders');
  const [search, setSearch] = useState('');
  const [statusF, setStatusF] = useState<'open' | Status | 'all'>('open');
  const [po, setPo] = useState<Partial<PurchaseOrder> | null>(null);
  const [vendor, setVendor] = useState<Partial<Vendor> | null>(null);
  const [receive, setReceive] = useState<{ po: PurchaseOrder; updateStock: boolean; addExpense: boolean } | null>(null);
  const [touched, setTouched] = useState(false);
  const [saving, setSaving] = useState(false);
  const [line, setLine] = useState<PurchaseOrderItem>({ name: '', quantity: 1, unitPrice: 0 });

  const lowStock = inventory.filter(i => i.currentQuantity <= i.minQuantity);
  // Depo fiyatını sipariş para birimine çevir (farklı para birimli ürünler aynı siparişe eklenebilir)
  const convert = (amount: number, from: Currency, to: Currency) => {
    const inTRY = toTRY(amount, from, rates);
    const out = to === Currency.TRY ? inTRY : to === Currency.USD ? inTRY / (rates.TRY || 1) : (inTRY / (rates.TRY || 1)) * (rates.EUR || 1);
    return Math.round(out * 100) / 100;
  };
  const nextNumber = () => {
    const y = new Date().getFullYear();
    const nums = purchaseOrders.map(p => Number((p.orderNumber || '').match(new RegExp(`PO-${y}-(\\d+)`))?.[1] || 0));
    return `PO-${y}-${String(Math.max(0, ...nums) + 1).padStart(3, '0')}`;
  };

  const filteredPOs = useMemo(() => {
    const q = search.trim().toLocaleLowerCase('tr-TR');
    return purchaseOrders.filter(p =>
      (statusF === 'all' || (statusF === 'open' ? p.status === 'Draft' || p.status === 'Ordered' : p.status === statusF)) &&
      (!q || [p.orderNumber, p.vendorName, p.notes, ...(p.items || []).map(i => i.name)].join(' ').toLocaleLowerCase('tr-TR').includes(q))
    ).sort((a, b) => (b.date || '').localeCompare(a.date || ''));
  }, [purchaseOrders, statusF, search]);
  const filteredVendors = useMemo(() => {
    const q = search.trim().toLocaleLowerCase('tr-TR');
    return vendors.filter(v => !q || [v.name, v.contactName, v.email, v.phone].join(' ').toLocaleLowerCase('tr-TR').includes(q)).sort((a, b) => a.name.localeCompare(b.name, 'tr'));
  }, [vendors, search]);

  const stats = useMemo(() => {
    const open = purchaseOrders.filter(p => p.status === 'Ordered');
    const month = localISO().slice(0, 7);
    return {
      drafts: purchaseOrders.filter(p => p.status === 'Draft').length,
      open: open.length,
      late: open.filter(p => (dayDiff(p.expectedDelivery) ?? 1) < 0).length,
      openValue: open.reduce((s, p) => s + toTRY(p.totalAmount, p.currency, rates), 0),
      monthSpend: purchaseOrders.filter(p => p.status === 'Received' && (p.date || '').startsWith(month)).reduce((s, p) => s + toTRY(p.totalAmount, p.currency, rates), 0),
    };
  }, [purchaseOrders, rates]);

  // ---------- Sipariş formu ----------
  const openPO = (p?: PurchaseOrder, preset?: Partial<PurchaseOrder>) => {
    setTouched(false); setLine({ name: '', quantity: 1, unitPrice: 0 });
    setPo(p ? { ...p, items: [...(p.items || [])] } : { orderNumber: nextNumber(), vendorId: '', currency: Currency.TRY, status: 'Draft', date: localISO(), items: [], ...preset });
  };
  const poErrors: Record<string, string> = {};
  if (po) {
    if (!po.vendorId) poErrors.vendor = tr ? 'Tedarikçi seçin.' : 'Pick a vendor.';
    if (!(po.items || []).length) poErrors.items = tr ? 'En az bir kalem ekleyin.' : 'Add at least one item.';
    if (po.expectedDelivery && po.date && po.expectedDelivery < po.date) poErrors.delivery = tr ? 'Teslim tarihi sipariş tarihinden önce olamaz.' : 'Delivery before order date.';
  }
  const pe = (k: string) => (touched ? poErrors[k] : undefined);
  const addLine = () => {
    if (!po || !line.name.trim() || !(line.quantity > 0)) return;
    setPo({ ...po, items: [...(po.items || []), { ...line, name: line.name.trim() }] });
    setLine({ name: '', quantity: 1, unitPrice: 0 });
  };
  const savePO = async (statusOverride?: Status) => {
    setTouched(true);
    if (!po || Object.keys(poErrors).length) return;
    const v = vendors.find(x => x.id === po.vendorId)!;
    const prev = purchaseOrders.find(p => p.id === po.id);
    const next: PurchaseOrder = {
      id: po.id || `po_${Date.now()}`, orderNumber: po.orderNumber || nextNumber(), vendorId: v.id, vendorName: v.name,
      items: (po.items || []).map(i => { const o: PurchaseOrderItem = { name: i.name, quantity: Number(i.quantity), unitPrice: Number(i.unitPrice) }; if (i.itemId) o.itemId = i.itemId; return o; }),
      totalAmount: totalOf(po.items), currency: po.currency || Currency.TRY, status: statusOverride || po.status || 'Draft', date: po.date || localISO(),
      expectedDelivery: po.expectedDelivery || '', notes: po.notes || '',
    };
    // Teslim alındıya geçiş ayrı onay akışından yapılır
    if (next.status === 'Received' && prev?.status !== 'Received') { setPo(null); setReceive({ po: next, updateStock: true, addExpense: !!onAddTransaction }); return; }
    setSaving(true);
    try { await onUpsertPO(next); toast.success(prev ? (tr ? 'Sipariş güncellendi' : 'Order updated') : (tr ? `${next.orderNumber} oluşturuldu` : 'Order created')); setPo(null); }
    catch (e: any) { toast.error(e?.message || 'Hata'); } finally { setSaving(false); }
  };

  const confirmReceive = async () => {
    if (!receive) return;
    const { po: order, updateStock, addExpense } = receive;
    setSaving(true);
    try {
      await onUpsertPO({ ...order, status: 'Received' });
      let updated = 0;
      if (updateStock && onUpsertInventory) {
        for (const it of order.items) {
          const inv = it.itemId && inventory.find(i => i.id === it.itemId);
          if (!inv) continue;
          await onUpsertInventory({
            ...inv, currentQuantity: inv.currentQuantity + Number(it.quantity), unitPrice: Number(it.unitPrice) ? convert(Number(it.unitPrice), order.currency, inv.currency) : inv.unitPrice, lastUpdated: new Date().toISOString(),
            movements: [...(inv.movements || []), { id: `mv_${Date.now()}_${updated}`, type: 'in' as const, quantity: Number(it.quantity), date: new Date().toISOString(), note: `${order.orderNumber} · ${order.vendorName}`, userName: currentUser.name }].slice(-100),
          });
          updated++;
        }
      }
      if (addExpense && onAddTransaction) {
        await onAddTransaction({ id: `tr_po_${order.id}`, type: 'Expense', amount: order.totalAmount, currency: order.currency, category: 'Donanım Alımı', date: localISO(), description: `${order.orderNumber} · ${order.vendorName}`, taxRate: 0, taxAmount: 0, totalAmountWithTax: order.totalAmount });
      }
      toast.success(tr ? `${order.orderNumber} teslim alındı${updated ? ` · ${updated} ürünün stoğu güncellendi` : ''}` : 'Received');
      setReceive(null);
    } catch (e: any) { toast.error(e?.message || 'Hata'); } finally { setSaving(false); }
  };

  const changeStatus = async (p: PurchaseOrder, s: Status) => {
    if (s === 'Received') { setReceive({ po: p, updateStock: true, addExpense: !!onAddTransaction }); return; }
    await onUpsertPO({ ...p, status: s });
    toast(tr ? `${p.orderNumber}: ${STATUS[s].tr}` : `${p.orderNumber}: ${STATUS[s].en}`, 'info', 2000);
  };

  // ---------- Tedarikçi formu ----------
  const vErrors: Record<string, string> = {};
  if (vendor) {
    if (!vendor.name?.trim()) vErrors.name = tr ? 'Firma adı zorunlu.' : 'Name required.';
    if (vendor.email && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(vendor.email)) vErrors.email = tr ? 'Geçersiz e-posta.' : 'Invalid email.';
  }
  const ve = (k: string) => (touched ? vErrors[k] : undefined);
  const saveVendor = async () => {
    setTouched(true);
    if (!vendor || Object.keys(vErrors).length) return;
    setSaving(true);
    try {
      await onUpsertVendor({ id: vendor.id || `ven_${Date.now()}`, name: vendor.name!.trim(), contactName: vendor.contactName || '', phone: vendor.phone || '', email: vendor.email || '', taxOffice: vendor.taxOffice || '', taxNumber: vendor.taxNumber || '', address: vendor.address || '', notes: vendor.notes || '' });
      toast.success(tr ? 'Tedarikçi kaydedildi' : 'Vendor saved'); setVendor(null);
    } catch (e: any) { toast.error(e?.message || 'Hata'); } finally { setSaving(false); }
  };

  // ---------- Parçalar ----------
  const statusChip = (s: Status) => { const m = STATUS[s]; const I = m.icon; return <span className={`text-[11px] font-semibold px-2 py-0.5 rounded-md inline-flex items-center gap-1 ${m.chip}`}><I size={11} />{tr ? m.tr : m.en}</span>; };
  const deliveryText = (p: PurchaseOrder) => {
    if (!p.expectedDelivery) return <span className="text-slate-400">—</span>;
    const d = dayDiff(p.expectedDelivery)!;
    if (p.status !== 'Ordered') return <span className="text-slate-500">{p.expectedDelivery}</span>;
    return <span className={d < 0 ? 'text-rose-600 font-semibold' : d <= 2 ? 'text-amber-600 font-semibold' : 'text-slate-600 dark:text-slate-300'}>{d < 0 ? (tr ? `${-d} gün gecikti` : `${-d}d late`) : d === 0 ? (tr ? 'Bugün' : 'Today') : (tr ? `${d} gün sonra` : `in ${d}d`)}</span>;
  };

  const ordersList = () => (
    <div className={`${cardCls} overflow-hidden`}>
      {filteredPOs.length === 0 ? <EmptyState icon={ShoppingCart} text={tr ? 'Sipariş yok' : 'No orders'} action={<button onClick={() => openPO()} className="text-xs font-semibold text-indigo-600 hover:underline">{tr ? 'Yeni sipariş oluştur' : 'Create order'}</button>} /> : (
        <div className="divide-y divide-slate-100 dark:divide-slate-800 pc-stagger">
          {filteredPOs.map(p => (
            <div key={p.id} onClick={() => openPO(p)} className="group grid grid-cols-12 gap-3 items-center px-4 py-3 cursor-pointer hover:bg-slate-50/70 dark:hover:bg-white/[0.02]">
              <div className="col-span-12 md:col-span-4 min-w-0 flex items-center gap-3">
                <span className="w-10 h-10 shrink-0 rounded-xl bg-emerald-50 dark:bg-emerald-500/10 text-emerald-600 flex items-center justify-center"><ShoppingCart size={17} /></span>
                <div className="min-w-0"><p className="text-sm font-semibold text-slate-800 dark:text-slate-100 truncate"><span className="font-mono text-slate-500 mr-1.5">{p.orderNumber}</span>{p.vendorName}</p><p className="text-[11px] text-slate-400 truncate">{(p.items || []).length} {tr ? 'kalem' : 'items'} · {(p.items || []).map(i => i.name).join(', ')}</p></div>
              </div>
              <div className="col-span-4 md:col-span-2">{statusChip(p.status)}</div>
              <div className="col-span-4 md:col-span-2 text-xs flex items-center gap-1"><Truck size={12} className="text-slate-400" />{deliveryText(p)}</div>
              <div className="col-span-4 md:col-span-2 text-right text-sm font-bold text-slate-900 dark:text-white">{money(p.totalAmount, p.currency, 2)}</div>
              <div className="col-span-12 md:col-span-2 flex justify-end items-center gap-1" onClick={e => e.stopPropagation()}>
                {p.status === 'Draft' && <button onClick={() => changeStatus(p, 'Ordered')} className="h-8 px-2.5 rounded-lg text-[11px] font-semibold text-sky-700 bg-sky-50 hover:bg-sky-100 dark:bg-sky-500/10 dark:text-sky-300">{tr ? 'Siparişi ver' : 'Place'}</button>}
                {p.status === 'Ordered' && <button onClick={() => changeStatus(p, 'Received')} className="h-8 px-2.5 rounded-lg text-[11px] font-semibold text-emerald-700 bg-emerald-50 hover:bg-emerald-100 dark:bg-emerald-500/10 dark:text-emerald-300">{tr ? 'Teslim al' : 'Receive'}</button>}
                {onDeletePO && p.status !== 'Received' && <DeleteButton language={language} onConfirm={async () => { await onDeletePO(p.id); toast(tr ? 'Sipariş silindi' : 'Deleted', 'info'); }} />}
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );

  const vendorsList = () => (
    filteredVendors.length === 0 ? <div className={cardCls}><EmptyState icon={Store} text={tr ? 'Tedarikçi yok' : 'No vendors'} action={<button onClick={() => { setVendor({}); setTouched(false); }} className="text-xs font-semibold text-indigo-600 hover:underline">{tr ? 'Tedarikçi ekle' : 'Add vendor'}</button>} /></div> : (
      <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-3 gap-4 pc-stagger">
        {filteredVendors.map(v => {
          const orders = purchaseOrders.filter(p => p.vendorId === v.id);
          const spent = orders.filter(p => p.status === 'Received').reduce((s, p) => s + toTRY(p.totalAmount, p.currency, rates), 0);
          return (
            <div key={v.id} className={`${cardCls} p-4 pc-lift`}>
              <div className="flex items-start gap-3">
                <span className="w-11 h-11 shrink-0 rounded-xl bg-gradient-to-br from-emerald-500 to-teal-600 text-white font-bold flex items-center justify-center">{v.name[0]}</span>
                <div className="flex-1 min-w-0"><p className="font-bold text-slate-900 dark:text-white truncate">{v.name}</p><p className="text-xs text-slate-500 truncate">{v.contactName || '—'}</p></div>
                <div className="flex">
                  <button onClick={() => { setVendor({ ...v }); setTouched(false); }} className="p-1.5 rounded-lg text-slate-400 hover:text-indigo-600 hover:bg-indigo-50 dark:hover:bg-white/5"><Edit2 size={14} /></button>
                  {onDeleteVendor && !orders.length && <DeleteButton language={language} onConfirm={async () => { await onDeleteVendor(v.id); toast(tr ? 'Tedarikçi silindi' : 'Deleted', 'info'); }} />}
                </div>
              </div>
              <div className="mt-3 space-y-1 text-xs">
                {v.phone && <a href={`tel:${v.phone}`} className="flex items-center gap-1.5 text-slate-600 dark:text-slate-300 hover:text-indigo-600"><Phone size={12} />{v.phone}</a>}
                {v.email && <a href={`mailto:${v.email}`} className="flex items-center gap-1.5 text-slate-600 dark:text-slate-300 hover:text-indigo-600 truncate"><Mail size={12} />{v.email}</a>}
                {v.taxNumber && <p className="text-slate-400">{v.taxOffice} · {v.taxNumber}</p>}
              </div>
              <div className="grid grid-cols-2 gap-2 mt-3 pt-3 border-t border-slate-100 dark:border-slate-800 text-xs">
                <div><p className="text-slate-400">{tr ? 'Sipariş' : 'Orders'}</p><p className="font-bold text-slate-800 dark:text-slate-100">{orders.length}</p></div>
                <div><p className="text-slate-400">{tr ? 'Toplam alım' : 'Spent'}</p><p className="font-bold text-slate-800 dark:text-slate-100">{formatTRY(spent)}</p></div>
              </div>
              <button onClick={() => openPO(undefined, { vendorId: v.id })} className="mt-3 w-full h-9 rounded-xl text-xs font-semibold border border-dashed border-slate-200 dark:border-slate-700 text-slate-500 hover:text-indigo-600 hover:border-indigo-300 inline-flex items-center justify-center gap-1"><Plus size={13} />{tr ? 'Bu tedarikçiden sipariş' : 'New order'}</button>
            </div>
          );
        })}
      </div>
    )
  );

  return (
    <div className="space-y-5 pb-10">
      <PageHeader title={tr ? 'Satın Alma' : 'Purchasing'} subtitle={tr ? 'Siparişler, tedarikçiler ve depo ile otomatik stok entegrasyonu.' : 'Orders, vendors and stock integration.'}
        actions={<>
          <button onClick={() => { setVendor({}); setTouched(false); }} className={btnGhost}><Store size={16} /> {tr ? 'Tedarikçi ekle' : 'Add vendor'}</button>
          <button onClick={() => openPO()} className={btnPrimary}><Plus size={16} /> {tr ? 'Yeni sipariş' : 'New order'}</button>
        </>} />

      <KpiGrid items={[
        { label: tr ? 'Yoldaki siparişler' : 'In transit', value: stats.open, sub: stats.late ? (tr ? `${stats.late} sipariş gecikti` : `${stats.late} late`) : (tr ? 'Gecikme yok' : 'On time'), icon: Truck, grad: 'from-sky-500 to-blue-600', onClick: () => { setTab('orders'); setStatusF('Ordered'); }, active: statusF === 'Ordered' },
        { label: tr ? 'Taslaklar' : 'Drafts', value: stats.drafts, sub: tr ? 'Gönderilmeyi bekliyor' : 'Not yet placed', icon: FileClock, grad: 'from-slate-500 to-slate-700', onClick: () => { setTab('orders'); setStatusF('Draft'); }, active: statusF === 'Draft' },
        { label: tr ? 'Açık sipariş tutarı' : 'Open value', value: stats.openValue, format: formatTRY, sub: tr ? 'Teslim bekleyen' : 'Awaiting delivery', icon: Wallet, grad: 'from-amber-500 to-orange-600' },
        { label: tr ? 'Bu ay teslim alınan' : 'Received this month', value: stats.monthSpend, format: formatTRY, sub: `${vendors.length} ${tr ? 'tedarikçi' : 'vendors'}`, icon: PackageCheck, grad: 'from-emerald-500 to-teal-600' },
      ]} />

      {lowStock.length > 0 && (
        <div className="flex flex-col sm:flex-row sm:items-center gap-3 p-4 rounded-[20px] bg-amber-50/70 dark:bg-amber-500/5 border border-amber-200/70 dark:border-amber-500/20">
          <AlertTriangle size={18} className="text-amber-600 shrink-0" />
          <p className="flex-1 text-sm text-amber-900 dark:text-amber-200">{tr ? `${lowStock.length} ürün kritik stok seviyesinde: ` : `${lowStock.length} items low: `}<b>{lowStock.slice(0, 4).map(i => i.name).join(', ')}{lowStock.length > 4 ? '…' : ''}</b></p>
          <button onClick={() => openPO(undefined, { items: lowStock.map(i => ({ itemId: i.id, name: i.name, quantity: Math.max(1, i.minQuantity * 2 - i.currentQuantity), unitPrice: convert(i.unitPrice || 0, i.currency, Currency.TRY) })), currency: Currency.TRY })}
            className="h-9 px-3 rounded-xl text-xs font-semibold text-white bg-amber-600 hover:bg-amber-500 inline-flex items-center gap-1.5 shrink-0"><Sparkles size={14} />{tr ? 'Tümü için sipariş taslağı oluştur' : 'Draft order for all'}</button>
        </div>
      )}

      <div className={`${cardCls} p-3 flex flex-col lg:flex-row gap-2`}>
        <Segmented<'orders' | 'vendors'> value={tab} onChange={setTab} options={[{ value: 'orders', label: <><ShoppingCart size={14} />{tr ? 'Siparişler' : 'Orders'}</> }, { value: 'vendors', label: <><Store size={14} />{tr ? 'Tedarikçiler' : 'Vendors'}</> }]} />
        <SearchBox value={search} onChange={setSearch} placeholder={tab === 'orders' ? (tr ? 'Sipariş no, tedarikçi, ürün ara…' : 'Search orders…') : (tr ? 'Tedarikçi ara…' : 'Search vendors…')} />
        {tab === 'orders' && <select value={statusF} onChange={e => setStatusF(e.target.value as any)} className={selectSm}><option value="open">{tr ? 'Açık siparişler' : 'Open'}</option><option value="all">{tr ? 'Tümü' : 'All'}</option>{(Object.keys(STATUS) as Status[]).map(s => <option key={s} value={s}>{tr ? STATUS[s].tr : STATUS[s].en}</option>)}</select>}
      </div>

      <div key={tab} className="animate-in fade-in duration-300">{tab === 'orders' ? ordersList() : vendorsList()}</div>

      {/* Sipariş formu */}
      <Sheet open={!!po} language={language} width="max-w-2xl" title={po?.id ? (tr ? `Sipariş ${po.orderNumber}` : `Order ${po.orderNumber}`) : (tr ? 'Yeni satın alma siparişi' : 'New purchase order')} subtitle={po?.orderNumber} icon={ShoppingCart} tone="from-emerald-500 to-teal-600"
        onClose={() => setPo(null)} onSubmit={() => savePO()} saving={saving}
        footerLeft={po && <span className="text-slate-400">{tr ? 'Toplam' : 'Total'} <b className="text-emerald-600 text-base">{money(totalOf(po.items), po.currency, 2)}</b></span>}>
        {po && <>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <Field label={tr ? 'Tedarikçi' : 'Vendor'} required error={pe('vendor')} hint={!vendors.length ? <button onClick={() => { setPo(null); setVendor({}); }} className="text-indigo-600 font-semibold hover:underline">{tr ? 'Önce tedarikçi ekleyin' : 'Add a vendor first'}</button> : undefined}>
              <select className={inputCls(pe('vendor'))} value={po.vendorId || ''} onChange={e => setPo({ ...po, vendorId: e.target.value })}><option value="">{tr ? 'Seçin' : 'Select'}</option>{vendors.map(v => <option key={v.id} value={v.id}>{v.name}</option>)}</select>
            </Field>
            <Field label={tr ? 'Durum' : 'Status'}>
              <select className={inputCls()} value={po.status} onChange={e => setPo({ ...po, status: e.target.value as Status })}>{(Object.keys(STATUS) as Status[]).map(s => <option key={s} value={s}>{tr ? STATUS[s].tr : STATUS[s].en}</option>)}</select>
            </Field>
            <Field label={tr ? 'Sipariş tarihi' : 'Order date'}><input type="date" className={inputCls()} value={po.date || ''} onChange={e => setPo({ ...po, date: e.target.value })} /></Field>
            <Field label={tr ? 'Beklenen teslim' : 'Expected delivery'} error={pe('delivery')}><input type="date" min={po.date} className={inputCls(pe('delivery'))} value={po.expectedDelivery || ''} onChange={e => setPo({ ...po, expectedDelivery: e.target.value })} /></Field>
          </div>
          <div className="rounded-2xl border border-slate-200 dark:border-slate-700 overflow-hidden">
            <div className="flex items-center justify-between px-4 py-3 bg-slate-50 dark:bg-white/[0.03] border-b border-slate-200 dark:border-slate-700">
              <p className="text-sm font-semibold text-slate-800 dark:text-slate-100">{tr ? 'Sipariş kalemleri' : 'Line items'}</p>
              <select value={po.currency} onChange={e => setPo({ ...po, currency: e.target.value as Currency })} className="h-8 px-2 rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-xs font-semibold">{Object.values(Currency).map(c => <option key={c} value={c}>{c}</option>)}</select>
            </div>
            <div className="divide-y divide-slate-100 dark:divide-slate-800">
              {(po.items || []).map((it, idx) => (
                <div key={idx} className="grid grid-cols-12 gap-2 items-center px-4 py-2">
                  <div className="col-span-12 sm:col-span-5 min-w-0"><p className="text-sm font-semibold text-slate-800 dark:text-slate-100 truncate">{it.name}</p>{it.itemId && <p className="text-[10px] text-emerald-600">{tr ? 'Depoya bağlı · teslimde stok artar' : 'Linked to stock'}</p>}</div>
                  <input type="number" min={1} className="col-span-3 sm:col-span-2 h-9 px-2 rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-sm text-center" value={it.quantity} onChange={e => setPo({ ...po, items: po.items!.map((x, i) => (i === idx ? { ...x, quantity: Number(e.target.value) } : x)) })} />
                  <input type="number" min={0} step="0.01" className="col-span-4 sm:col-span-2 h-9 px-2 rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-sm text-right" value={it.unitPrice} onChange={e => setPo({ ...po, items: po.items!.map((x, i) => (i === idx ? { ...x, unitPrice: Number(e.target.value) } : x)) })} />
                  <span className="col-span-4 sm:col-span-2 text-right text-sm font-bold text-slate-900 dark:text-white">{money(it.quantity * it.unitPrice, po.currency, 2)}</span>
                  <button onClick={() => setPo({ ...po, items: po.items!.filter((_, i) => i !== idx) })} className="col-span-1 p-1.5 rounded-lg text-slate-400 hover:text-rose-600 hover:bg-rose-50 justify-self-end"><Trash2 size={14} /></button>
                </div>
              ))}
              {!(po.items || []).length && <p className={`px-4 py-4 text-xs text-center ${pe('items') ? 'text-rose-600 font-semibold' : 'text-slate-400'}`}>{pe('items') || (tr ? 'Henüz kalem yok' : 'No items yet')}</p>}
            </div>
            <div className="grid grid-cols-12 gap-2 p-3 bg-slate-50/60 dark:bg-white/[0.02] border-t border-slate-100 dark:border-slate-800">
              <select className="col-span-12 sm:col-span-4 h-9 px-2 rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-xs" value={line.itemId || ''} onChange={e => { const s = inventory.find(i => i.id === e.target.value); setLine(s ? { itemId: s.id, name: s.name, quantity: Math.max(1, s.minQuantity * 2 - s.currentQuantity), unitPrice: convert(s.unitPrice || 0, s.currency, po.currency || Currency.TRY) } : { ...line, itemId: undefined }); }}>
                <option value="">{tr ? 'Depodan seç (isteğe bağlı)' : 'From inventory'}</option>{inventory.map(i => <option key={i.id} value={i.id}>{i.name} ({i.currentQuantity})</option>)}
              </select>
              <input className="col-span-12 sm:col-span-3 h-9 px-2 rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-xs" placeholder={tr ? 'Ürün / hizmet adı' : 'Item name'} value={line.name} onChange={e => setLine({ ...line, name: e.target.value })} onKeyDown={e => e.key === 'Enter' && addLine()} />
              <input type="number" min={1} className="col-span-4 sm:col-span-1 h-9 px-2 rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-xs text-center" value={line.quantity} onChange={e => setLine({ ...line, quantity: Number(e.target.value) })} />
              <input type="number" min={0} step="0.01" className="col-span-4 sm:col-span-2 h-9 px-2 rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-xs text-right" placeholder={tr ? 'Birim fiyat' : 'Price'} value={line.unitPrice || ''} onChange={e => setLine({ ...line, unitPrice: Number(e.target.value) })} />
              <button onClick={addLine} disabled={!line.name.trim()} className="col-span-4 sm:col-span-2 h-9 rounded-lg text-xs font-semibold text-white bg-emerald-600 hover:bg-emerald-500 disabled:opacity-40 inline-flex items-center justify-center gap-1"><Plus size={13} />{tr ? 'Ekle' : 'Add'}</button>
            </div>
          </div>
          <Field label={tr ? 'Not' : 'Notes'}><textarea rows={2} className={inputCls() + ' h-auto py-2.5 resize-none'} value={po.notes || ''} onChange={e => setPo({ ...po, notes: e.target.value })} /></Field>
          {po.status === 'Draft' && <button onClick={() => savePO('Ordered')} className="w-full h-10 rounded-xl text-sm font-semibold text-sky-700 bg-sky-50 hover:bg-sky-100 dark:bg-sky-500/10 dark:text-sky-300 inline-flex items-center justify-center gap-2"><Truck size={15} />{tr ? 'Kaydet ve siparişi ver' : 'Save & place order'}</button>}
        </>}
      </Sheet>

      {/* Teslim alma onayı */}
      <Sheet open={!!receive} language={language} width="max-w-md" title={tr ? 'Siparişi teslim al' : 'Receive order'} subtitle={receive ? `${receive.po.orderNumber} · ${receive.po.vendorName}` : ''} icon={PackageCheck} tone="from-emerald-500 to-teal-600"
        onClose={() => setReceive(null)} onSubmit={confirmReceive} saving={saving} submitLabel={tr ? 'Teslim alındı' : 'Mark received'}>
        {receive && <>
          <div className="rounded-xl border border-slate-200 dark:border-slate-700 divide-y divide-slate-100 dark:divide-slate-800">
            {receive.po.items.map((it, i) => <div key={i} className="flex justify-between px-3 py-2 text-sm"><span className="text-slate-700 dark:text-slate-200">{it.name}{it.itemId && <CheckCircle2 size={12} className="inline ml-1 text-emerald-500" />}</span><span className="font-semibold">+{it.quantity}</span></div>)}
          </div>
          {onUpsertInventory && <label className="flex items-start gap-2 text-sm text-slate-700 dark:text-slate-200 cursor-pointer"><input type="checkbox" className="mt-0.5 w-4 h-4 accent-emerald-600" checked={receive.updateStock} onChange={e => setReceive({ ...receive, updateStock: e.target.checked })} /><span>{tr ? 'Depoya bağlı ürünlerin stoğunu artır' : 'Increase stock for linked items'}<span className="block text-[11px] text-slate-400">{tr ? `${receive.po.items.filter(i => i.itemId).length} kalem depoya bağlı` : ''}</span></span></label>}
          {onAddTransaction && <label className="flex items-start gap-2 text-sm text-slate-700 dark:text-slate-200 cursor-pointer"><input type="checkbox" className="mt-0.5 w-4 h-4 accent-emerald-600" checked={receive.addExpense} onChange={e => setReceive({ ...receive, addExpense: e.target.checked })} /><span>{tr ? `Muhasebeye ${money(receive.po.totalAmount, receive.po.currency, 2)} gider olarak işle` : 'Record as expense'}</span></label>}
        </>}
      </Sheet>

      {/* Tedarikçi formu */}
      <Sheet open={!!vendor} language={language} title={vendor?.id ? (tr ? 'Tedarikçiyi düzenle' : 'Edit vendor') : (tr ? 'Yeni tedarikçi' : 'New vendor')} subtitle={vendor?.name} icon={Store} tone="from-emerald-500 to-teal-600" onClose={() => setVendor(null)} onSubmit={saveVendor} saving={saving}>
        {vendor && <>
          <Field label={tr ? 'Firma adı' : 'Company'} required error={ve('name')}><input autoFocus className={inputCls(ve('name'))} value={vendor.name || ''} onChange={e => setVendor({ ...vendor, name: e.target.value })} /></Field>
          <div className="grid grid-cols-2 gap-4">
            <Field label={tr ? 'Yetkili kişi' : 'Contact'}><input className={inputCls()} value={vendor.contactName || ''} onChange={e => setVendor({ ...vendor, contactName: e.target.value })} /></Field>
            <Field label={tr ? 'Telefon' : 'Phone'}><input type="tel" className={inputCls()} value={vendor.phone || ''} onChange={e => setVendor({ ...vendor, phone: e.target.value })} /></Field>
          </div>
          <Field label={tr ? 'E-posta' : 'Email'} error={ve('email')}><input type="email" className={inputCls(ve('email'))} value={vendor.email || ''} onChange={e => setVendor({ ...vendor, email: e.target.value })} /></Field>
          <div className="grid grid-cols-2 gap-4">
            <Field label={tr ? 'Vergi dairesi' : 'Tax office'}><input className={inputCls()} value={vendor.taxOffice || ''} onChange={e => setVendor({ ...vendor, taxOffice: e.target.value })} /></Field>
            <Field label={tr ? 'Vergi no' : 'Tax no'}><input inputMode="numeric" className={inputCls()} value={vendor.taxNumber || ''} onChange={e => setVendor({ ...vendor, taxNumber: e.target.value.replace(/[^\d]/g, '').slice(0, 11) })} /></Field>
          </div>
          <Field label={tr ? 'Adres' : 'Address'}><textarea rows={2} className={inputCls() + ' h-auto py-2.5 resize-none'} value={vendor.address || ''} onChange={e => setVendor({ ...vendor, address: e.target.value })} /></Field>
          <Field label={tr ? 'Not' : 'Notes'}><input className={inputCls()} value={vendor.notes || ''} onChange={e => setVendor({ ...vendor, notes: e.target.value })} /></Field>
        </>}
      </Sheet>
    </div>
  );
};

export default PurchasingView;
