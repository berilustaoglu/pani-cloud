import React, { useEffect, useMemo, useState } from 'react';
import {
  CalendarDays, Plus, Search, Check, X, Clock, CheckCircle2, XCircle, ChevronLeft, ChevronRight, List, Palmtree,
  AlertTriangle, Users as UsersIcon, Loader2, Save, AlertCircle, Ban, MessageSquare
} from 'lucide-react';
import { User, LeaveRequest, LeaveType, UserRole, HRSettings } from '../types';
import ModalPortal from './ModalPortal';
import { ProgressRing, AnimatedNumber } from './ui/Motion';
import { localISO, dayDiff } from '../services/insights';
import { toast } from '../services/toast';

interface Props {
  leaves: LeaveRequest[];
  onUpsertLeave: (leave: LeaveRequest) => Promise<void>;
  currentUser: User;
  staffList: User[];
  language: 'tr' | 'en';
  hrSettings?: HRSettings;
}

const TYPE_META: Record<LeaveType, { en: string; emoji: string; color: string; bar: string }> = {
  'Yıllık İzin': { en: 'Annual leave', emoji: '🌴', color: 'bg-emerald-50 text-emerald-700 dark:bg-emerald-500/10 dark:text-emerald-300', bar: 'bg-emerald-500' },
  'Mazeret İzni': { en: 'Excuse leave', emoji: '📝', color: 'bg-sky-50 text-sky-700 dark:bg-sky-500/10 dark:text-sky-300', bar: 'bg-sky-500' },
  'Hastalık/Rapor': { en: 'Sick leave', emoji: '🩺', color: 'bg-rose-50 text-rose-700 dark:bg-rose-500/10 dark:text-rose-300', bar: 'bg-rose-500' },
  'Ücretsiz İzin': { en: 'Unpaid leave', emoji: '⏸️', color: 'bg-amber-50 text-amber-700 dark:bg-amber-500/10 dark:text-amber-300', bar: 'bg-amber-500' },
  'Diğer': { en: 'Other', emoji: '✨', color: 'bg-slate-100 text-slate-600 dark:bg-white/5 dark:text-slate-300', bar: 'bg-slate-400' },
};
const STATUS_META: Record<LeaveRequest['status'], { tr: string; en: string; chip: string; icon: React.ElementType }> = {
  Pending: { tr: 'Onay bekliyor', en: 'Pending', chip: 'bg-amber-50 text-amber-700 dark:bg-amber-500/10 dark:text-amber-300', icon: Clock },
  Approved: { tr: 'Onaylandı', en: 'Approved', chip: 'bg-emerald-50 text-emerald-700 dark:bg-emerald-500/10 dark:text-emerald-300', icon: CheckCircle2 },
  Rejected: { tr: 'Reddedildi', en: 'Rejected', chip: 'bg-rose-50 text-rose-700 dark:bg-rose-500/10 dark:text-rose-300', icon: XCircle },
  Cancelled: { tr: 'İptal edildi', en: 'Cancelled', chip: 'bg-slate-100 text-slate-500 dark:bg-white/5 dark:text-slate-400', icon: Ban },
};
const TYPES = Object.keys(TYPE_META) as LeaveType[];

/** İzin günlerini sayar (hafta sonları isteğe bağlı). */
export const countLeaveDays = (start: string, end: string, includeWeekends = false) => {
  if (!start || !end || end < start) return 0;
  let n = 0;
  const [y, m, d] = start.split('-').map(Number);
  const cur = new Date(y, m - 1, d);
  const [y2, m2, d2] = end.split('-').map(Number);
  const last = new Date(y2, m2 - 1, d2);
  while (cur <= last) { const wd = cur.getDay(); if (includeWeekends || (wd !== 0 && wd !== 6)) n++; cur.setDate(cur.getDate() + 1); }
  return n;
};
const fmt = (iso: string, tr: boolean, opts: Intl.DateTimeFormatOptions = { day: 'numeric', month: 'short' }) => {
  const [y, m, d] = iso.split('-').map(Number);
  return new Date(y, m - 1, d).toLocaleDateString(tr ? 'tr-TR' : 'en-US', opts);
};
const inputCls = 'w-full h-11 px-3.5 rounded-xl bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-sm font-medium text-slate-900 dark:text-white outline-none focus:border-indigo-500 focus:ring-4 focus:ring-indigo-500/10';

const LeaveView: React.FC<Props> = ({ leaves, onUpsertLeave, currentUser, staffList, language, hrSettings }) => {
  const tr = language === 'tr';
  const isManager = currentUser.role === UserRole.ADMIN || currentUser.role === UserRole.MANAGER || currentUser.role === UserRole.ACCOUNTANT;
  const year = new Date().getFullYear();
  const today = localISO();

  const [tab, setTab] = useState<'list' | 'calendar'>('list');
  const [search, setSearch] = useState('');
  const [statusF, setStatusF] = useState<'all' | LeaveRequest['status']>('all');
  const [typeF, setTypeF] = useState<'all' | LeaveType>('all');
  const [mineOnly, setMineOnly] = useState(!isManager);
  const [month, setMonth] = useState(() => { const d = new Date(); return new Date(d.getFullYear(), d.getMonth(), 1); });
  const [decision, setDecision] = useState<{ leave: LeaveRequest; status: 'Approved' | 'Rejected'; note: string } | null>(null);
  const [confirmCancel, setConfirmCancel] = useState<string | null>(null);

  // Talep formu
  const [show, setShow] = useState(false);
  const [form, setForm] = useState<Partial<LeaveRequest>>({ type: 'Yıllık İzin', startDate: '', endDate: '', reason: '', includeWeekends: false });
  const [touched, setTouched] = useState(false);
  const [saving, setSaving] = useState(false);

  const allowanceOf = (u?: User) => u?.annualLeaveAllowance ?? hrSettings?.defaultAnnualLeaveDays ?? 14;
  const usedOf = (uid: string, status: LeaveRequest['status'] = 'Approved') =>
    leaves.filter(l => l.userId === uid && l.status === status && l.type === 'Yıllık İzin' && l.startDate.startsWith(String(year)))
      .reduce((s, l) => s + countLeaveDays(l.startDate, l.endDate, l.includeWeekends), 0);

  const me = staffList.find(u => u.id === currentUser.id) || currentUser;
  const myAllowance = allowanceOf(me);
  const myUsed = usedOf(currentUser.id);
  const myPending = usedOf(currentUser.id, 'Pending');
  const myRemaining = Math.max(0, myAllowance - myUsed);

  const onLeaveToday = leaves.filter(l => l.status === 'Approved' && l.startDate <= today && l.endDate >= today);
  const pending = leaves.filter(l => l.status === 'Pending').sort((a, b) => a.startDate.localeCompare(b.startDate));
  const upcoming = leaves.filter(l => l.status === 'Approved' && l.startDate > today && (dayDiff(l.startDate) ?? 99) <= 30);

  const filtered = useMemo(() => {
    const q = search.trim().toLocaleLowerCase('tr-TR');
    return leaves.filter(l =>
      (!isManager || !mineOnly || l.userId === currentUser.id) && (isManager || l.userId === currentUser.id) &&
      (statusF === 'all' || l.status === statusF) && (typeF === 'all' || l.type === typeF) &&
      (!q || [l.userName, l.type, l.reason].join(' ').toLocaleLowerCase('tr-TR').includes(q))
    ).sort((a, b) => (b.requestDate || '').localeCompare(a.requestDate || ''));
  }, [leaves, search, statusF, typeF, mineOnly, isManager, currentUser.id]);

  // ---------- Form ----------
  const days = countLeaveDays(form.startDate || '', form.endDate || '', !!form.includeWeekends);
  const overlaps = useMemo(() => leaves.filter(l => l.userId === currentUser.id && (l.status === 'Pending' || l.status === 'Approved') && form.startDate && form.endDate && l.startDate <= form.endDate && l.endDate >= form.startDate), [leaves, form, currentUser.id]);
  const exceeds = form.type === 'Yıllık İzin' && days > myRemaining - myPending;
  const errors: Record<string, string> = {};
  if (!form.startDate) errors.start = tr ? 'Başlangıç tarihi seçin.' : 'Pick a start date.';
  if (!form.endDate) errors.end = tr ? 'Bitiş tarihi seçin.' : 'Pick an end date.';
  else if (form.startDate && form.endDate < form.startDate) errors.end = tr ? 'Bitiş, başlangıçtan önce olamaz.' : 'End before start.';
  if (form.startDate && form.endDate && days === 0) errors.end = tr ? 'Seçilen aralıkta iş günü yok.' : 'No working days in range.';
  if (!form.reason?.trim()) errors.reason = tr ? 'Kısa bir açıklama yazın.' : 'Add a short reason.';
  if (overlaps.length) errors.overlap = tr ? 'Bu tarihlerde zaten bir izin talebiniz var.' : 'You already have leave on these dates.';
  const err = (k: string) => (touched ? errors[k] : undefined);

  const openForm = (preset?: Partial<LeaveRequest>) => { setForm({ type: 'Yıllık İzin', startDate: '', endDate: '', reason: '', includeWeekends: false, ...preset }); setTouched(false); setShow(true); };
  const submit = async () => {
    setTouched(true);
    if (Object.keys(errors).length) return;
    setSaving(true);
    try {
      await onUpsertLeave({
        id: `leave_${currentUser.id}_${Date.now()}`, userId: currentUser.id, userName: currentUser.name, type: form.type as LeaveType,
        startDate: form.startDate!, endDate: form.endDate!, reason: form.reason!.trim(), status: 'Pending', requestDate: new Date().toISOString(), includeWeekends: !!form.includeWeekends,
      });
      toast.success(tr ? 'İzin talebiniz gönderildi' : 'Leave request sent');
      setShow(false);
    } catch (e: any) { toast.error(e?.message || 'Hata'); } finally { setSaving(false); }
  };

  useEffect(() => {
    if (!show) return;
    const onKey = (e: KeyboardEvent) => { if (e.key === 'Escape') setShow(false); if ((e.ctrlKey || e.metaKey) && e.key === 'Enter') submit(); };
    window.addEventListener('keydown', onKey); return () => window.removeEventListener('keydown', onKey);
  });

  const decide = async () => {
    if (!decision) return;
    const { leave, status, note } = decision;
    const out: LeaveRequest = { ...leave, status };
    if (note.trim()) out.managerNotes = note.trim();
    await onUpsertLeave(out);
    toast(status === 'Approved' ? (tr ? `${leave.userName} için izin onaylandı` : 'Approved') : (tr ? 'İzin talebi reddedildi' : 'Rejected'), status === 'Approved' ? 'success' : 'info');
    setDecision(null);
  };

  // ---------- Parçalar ----------
  const userAvatar = (uid: string, name: string, size = 'w-9 h-9') => {
    const u = staffList.find(x => x.id === uid);
    return u?.avatar ? <img src={u.avatar} alt="" className={`${size} rounded-xl object-cover shrink-0`} /> : <span className={`${size} shrink-0 rounded-xl bg-gradient-to-br from-indigo-500 to-violet-500 text-white text-xs font-bold flex items-center justify-center`}>{name?.[0]}</span>;
  };
  const range = (l: LeaveRequest) => {
    const n = countLeaveDays(l.startDate, l.endDate, l.includeWeekends);
    return <>{fmt(l.startDate, tr)}{l.endDate !== l.startDate ? ` – ${fmt(l.endDate, tr)}` : ''} · <b>{n} {tr ? 'gün' : 'days'}</b></>;
  };

  const leaveRow = (l: LeaveRequest) => {
    const st = STATUS_META[l.status] || STATUS_META.Pending;
    const SI = st.icon;
    const active = l.status === 'Approved' && l.startDate <= today && l.endDate >= today;
    return (
      <div key={l.id} className="group flex flex-col sm:flex-row sm:items-center gap-3 p-3 rounded-2xl hover:bg-slate-50 dark:hover:bg-white/[0.03] transition-colors">
        <div className="flex items-center gap-3 flex-1 min-w-0">
          {userAvatar(l.userId, l.userName)}
          <div className="min-w-0">
            <p className="text-sm font-semibold text-slate-800 dark:text-slate-100 flex items-center gap-2">{l.userName}{active && <span className="text-[10px] font-semibold px-1.5 py-0.5 rounded-md bg-emerald-500 text-white">{tr ? 'Şu an izinde' : 'On leave now'}</span>}</p>
            <p className="text-xs text-slate-500 dark:text-slate-400">{range(l)}</p>
            {l.reason && <p className="text-[11px] text-slate-400 truncate max-w-md" title={l.reason}>{l.reason}</p>}
            {l.managerNotes && <p className="text-[11px] text-indigo-600 dark:text-indigo-300 flex items-center gap-1 mt-0.5"><MessageSquare size={11} />{l.managerNotes}</p>}
          </div>
        </div>
        <div className="flex items-center gap-2 sm:justify-end">
          <span className={`text-[11px] font-semibold px-2 py-1 rounded-lg ${TYPE_META[l.type]?.color || TYPE_META['Diğer'].color}`}>{TYPE_META[l.type]?.emoji} {tr ? l.type : TYPE_META[l.type]?.en}</span>
          <span className={`text-[11px] font-semibold px-2 py-1 rounded-lg inline-flex items-center gap-1 ${st.chip}`}><SI size={12} />{tr ? st.tr : st.en}</span>
          {isManager && l.status === 'Pending' && (
            <>
              <button onClick={() => setDecision({ leave: l, status: 'Approved', note: '' })} title={tr ? 'Onayla' : 'Approve'} className="p-2 rounded-lg text-emerald-600 bg-emerald-50 hover:bg-emerald-100 dark:bg-emerald-500/10"><Check size={15} /></button>
              <button onClick={() => setDecision({ leave: l, status: 'Rejected', note: '' })} title={tr ? 'Reddet' : 'Reject'} className="p-2 rounded-lg text-rose-600 bg-rose-50 hover:bg-rose-100 dark:bg-rose-500/10"><X size={15} /></button>
            </>
          )}
          {l.userId === currentUser.id && l.status === 'Pending' && (confirmCancel === l.id ? (
            <span className="inline-flex gap-1 animate-in fade-in zoom-in-95 duration-150">
              <button onClick={() => setConfirmCancel(null)} className="h-8 px-2 rounded-lg text-[11px] font-semibold text-slate-500 hover:bg-slate-100 dark:hover:bg-white/5">{tr ? 'Vazgeç' : 'No'}</button>
              <button onClick={async () => { await onUpsertLeave({ ...l, status: 'Cancelled' }); setConfirmCancel(null); toast(tr ? 'Talep iptal edildi' : 'Cancelled', 'info'); }} className="h-8 px-2 rounded-lg text-[11px] font-semibold text-white bg-rose-600">{tr ? 'İptal et' : 'Cancel'}</button>
            </span>
          ) : <button onClick={() => setConfirmCancel(l.id)} className="h-8 px-2.5 rounded-lg text-[11px] font-semibold text-slate-500 hover:text-rose-600 hover:bg-rose-50 dark:hover:bg-white/5">{tr ? 'Talebi iptal et' : 'Cancel request'}</button>)}
        </div>
      </div>
    );
  };

  const calendar = () => {
    const y = month.getFullYear(), m = month.getMonth();
    const first = new Date(y, m, 1);
    const offset = (first.getDay() + 6) % 7; // Pazartesi başlangıç
    const daysIn = new Date(y, m + 1, 0).getDate();
    const cells: (string | null)[] = [...Array(offset).fill(null), ...Array.from({ length: daysIn }, (_, i) => localISO(new Date(y, m, i + 1)))];
    while (cells.length % 7) cells.push(null);
    const visible = leaves.filter(l => (l.status === 'Approved' || l.status === 'Pending') && (isManager || l.userId === currentUser.id));
    const weekdays = tr ? ['Pzt', 'Sal', 'Çar', 'Per', 'Cum', 'Cmt', 'Paz'] : ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'];
    return (
      <div className="bg-white dark:bg-slate-900 border border-slate-100 dark:border-slate-800 rounded-[20px] p-4">
        <div className="flex items-center justify-between mb-3">
          <button onClick={() => setMonth(new Date(y, m - 1, 1))} className="p-2 rounded-lg hover:bg-slate-100 dark:hover:bg-white/5"><ChevronLeft size={16} /></button>
          <p className="font-bold text-slate-900 dark:text-white capitalize">{month.toLocaleDateString(tr ? 'tr-TR' : 'en-US', { month: 'long', year: 'numeric' })}</p>
          <button onClick={() => setMonth(new Date(y, m + 1, 1))} className="p-2 rounded-lg hover:bg-slate-100 dark:hover:bg-white/5"><ChevronRight size={16} /></button>
        </div>
        <div className="grid grid-cols-7 gap-1 text-[10px] font-bold uppercase text-slate-400 text-center mb-1">{weekdays.map(w => <span key={w}>{w}</span>)}</div>
        <div className="grid grid-cols-7 gap-1 pc-stagger" key={month.toISOString()}>
          {cells.map((d, i) => {
            if (!d) return <div key={i} />;
            const on = visible.filter(l => l.startDate <= d && l.endDate >= d);
            const wd = (i % 7);
            return (
              <button key={d} onClick={() => !isManager && d >= today && openForm({ startDate: d, endDate: d })}
                className={`min-h-[72px] sm:min-h-[88px] p-1.5 rounded-xl text-left border transition-colors ${d === today ? 'border-indigo-400 bg-indigo-50/50 dark:bg-indigo-500/10' : wd >= 5 ? 'border-transparent bg-slate-50 dark:bg-white/[0.02]' : 'border-slate-100 dark:border-slate-800 hover:border-slate-200'}`}>
                <span className={`text-xs font-bold ${d === today ? 'text-indigo-600' : 'text-slate-500'}`}>{Number(d.slice(8))}</span>
                <div className="mt-1 space-y-0.5">
                  {on.slice(0, 3).map(l => (
                    <div key={l.id} title={`${l.userName} · ${l.type}`} className={`text-[9px] sm:text-[10px] font-semibold truncate px-1 rounded text-white ${TYPE_META[l.type]?.bar || 'bg-slate-400'} ${l.status === 'Pending' ? 'opacity-50' : ''}`}>{l.userName.split(' ')[0]}</div>
                  ))}
                  {on.length > 3 && <div className="text-[9px] font-semibold text-slate-400">+{on.length - 3}</div>}
                </div>
              </button>
            );
          })}
        </div>
        <div className="flex flex-wrap gap-3 mt-3 text-[11px] text-slate-500">
          {TYPES.map(tp => <span key={tp} className="inline-flex items-center gap-1"><span className={`w-2.5 h-2.5 rounded ${TYPE_META[tp].bar}`} />{tr ? tp : TYPE_META[tp].en}</span>)}
          <span className="inline-flex items-center gap-1"><span className="w-2.5 h-2.5 rounded bg-slate-400 opacity-50" />{tr ? 'Onay bekleyen' : 'Pending'}</span>
        </div>
      </div>
    );
  };

  return (
    <div className="space-y-5 pb-10">
      <div className="flex flex-col lg:flex-row lg:items-end justify-between gap-4">
        <div>
          <h2 className="text-2xl lg:text-3xl font-black text-slate-900 dark:text-white tracking-tight">{tr ? 'İzin Yönetimi' : 'Leave Management'}</h2>
          <p className="text-sm text-slate-500 dark:text-slate-400">{tr ? 'İzin talepleri, onaylar, bakiyeler ve ekip takvimi.' : 'Requests, approvals, balances and team calendar.'}</p>
        </div>
        <button onClick={() => openForm()} className="h-10 px-4 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white text-sm font-semibold inline-flex items-center gap-2 shadow-lg shadow-indigo-500/25 self-start lg:self-auto"><Plus size={16} /> {tr ? 'İzin talep et' : 'Request leave'}</button>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        {/* Bakiye */}
        <div className="bg-white dark:bg-slate-900 border border-slate-100 dark:border-slate-800 rounded-[20px] p-5 flex items-center gap-5">
          <ProgressRing value={myAllowance ? (myRemaining / myAllowance) * 100 : 0} size={110} stroke={10}>
            <span className="text-2xl font-black text-slate-900 dark:text-white"><AnimatedNumber value={myRemaining} /></span>
            <span className="text-[10px] text-slate-400">{tr ? 'gün kaldı' : 'days left'}</span>
          </ProgressRing>
          <div className="space-y-1.5 text-sm">
            <p className="font-bold text-slate-900 dark:text-white flex items-center gap-1.5"><Palmtree size={16} className="text-emerald-500" />{tr ? `${year} yıllık izin hakkım` : `My ${year} annual leave`}</p>
            <p className="text-slate-500">{tr ? 'Toplam hak' : 'Allowance'}: <b className="text-slate-800 dark:text-slate-100">{myAllowance}</b></p>
            <p className="text-slate-500">{tr ? 'Kullanılan' : 'Used'}: <b className="text-slate-800 dark:text-slate-100">{myUsed}</b></p>
            {myPending > 0 && <p className="text-amber-600">{tr ? 'Onay bekleyen' : 'Pending'}: <b>{myPending}</b></p>}
          </div>
        </div>
        {isManager ? (
          <>
            <div className="bg-white dark:bg-slate-900 border border-slate-100 dark:border-slate-800 rounded-[20px] p-5">
              <p className="text-sm font-bold text-slate-900 dark:text-white flex items-center gap-2 mb-3"><UsersIcon size={16} className="text-indigo-500" />{tr ? 'Bugün izinde' : 'On leave today'} <span className="text-xs font-semibold px-1.5 rounded-md bg-slate-100 dark:bg-white/5 text-slate-500">{onLeaveToday.length}</span></p>
              {onLeaveToday.length === 0 ? <p className="text-sm text-slate-400">{tr ? 'Bugün herkes görevde.' : 'Everyone is in.'}</p> : (
                <div className="space-y-2">{onLeaveToday.slice(0, 4).map(l => <div key={l.id} className="flex items-center gap-2">{userAvatar(l.userId, l.userName, 'w-7 h-7')}<span className="text-sm font-semibold text-slate-700 dark:text-slate-200 flex-1 truncate">{l.userName}</span><span className="text-[11px] text-slate-400">{tr ? 'dönüş' : 'back'} {fmt(l.endDate, tr)}</span></div>)}</div>
              )}
            </div>
            <div className="bg-white dark:bg-slate-900 border border-slate-100 dark:border-slate-800 rounded-[20px] p-5">
              <p className="text-sm font-bold text-slate-900 dark:text-white flex items-center gap-2 mb-3"><CalendarDays size={16} className="text-indigo-500" />{tr ? '30 gün içinde başlayacak' : 'Starting within 30 days'}</p>
              {upcoming.length === 0 ? <p className="text-sm text-slate-400">{tr ? 'Planlanmış izin yok.' : 'None planned.'}</p> : (
                <div className="space-y-2">{upcoming.slice(0, 4).map(l => <div key={l.id} className="flex items-center gap-2 text-sm"><span>{TYPE_META[l.type]?.emoji}</span><span className="font-semibold text-slate-700 dark:text-slate-200 flex-1 truncate">{l.userName}</span><span className="text-[11px] text-slate-400">{fmt(l.startDate, tr)}</span></div>)}</div>
              )}
            </div>
          </>
        ) : (
          <div className="lg:col-span-2 bg-white dark:bg-slate-900 border border-slate-100 dark:border-slate-800 rounded-[20px] p-5">
            <p className="text-sm font-bold text-slate-900 dark:text-white mb-3">{tr ? 'Son taleplerim' : 'My recent requests'}</p>
            {leaves.filter(l => l.userId === currentUser.id).slice(0, 3).length === 0 ? <p className="text-sm text-slate-400">{tr ? 'Henüz talebiniz yok.' : 'No requests yet.'}</p> :
              leaves.filter(l => l.userId === currentUser.id).sort((a, b) => (b.requestDate || '').localeCompare(a.requestDate || '')).slice(0, 3).map(l => { const st = STATUS_META[l.status]; return <div key={l.id} className="flex items-center gap-2 py-1.5 text-sm"><span>{TYPE_META[l.type]?.emoji}</span><span className="flex-1 text-slate-700 dark:text-slate-200">{range(l)}</span><span className={`text-[11px] font-semibold px-2 py-0.5 rounded-md ${st.chip}`}>{tr ? st.tr : st.en}</span></div>; })}
          </div>
        )}
      </div>

      {/* Onay kuyruğu */}
      {isManager && pending.length > 0 && (
        <div className="bg-amber-50/60 dark:bg-amber-500/5 border border-amber-200/70 dark:border-amber-500/20 rounded-[20px] p-4">
          <p className="text-sm font-bold text-amber-900 dark:text-amber-200 flex items-center gap-2 mb-2"><Clock size={16} />{tr ? `Onay bekleyen ${pending.length} talep` : `${pending.length} pending`}</p>
          <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-3 pc-stagger">
            {pending.map(l => {
              const n = countLeaveDays(l.startDate, l.endDate, l.includeWeekends);
              const u = staffList.find(x => x.id === l.userId);
              const remaining = allowanceOf(u) - usedOf(l.userId);
              const conflicts = leaves.filter(o => o.id !== l.id && o.status === 'Approved' && o.startDate <= l.endDate && o.endDate >= l.startDate).length;
              return (
                <div key={l.id} className="bg-white dark:bg-slate-900 rounded-2xl p-4 border border-slate-100 dark:border-slate-800">
                  <div className="flex items-center gap-3">{userAvatar(l.userId, l.userName)}<div className="min-w-0"><p className="text-sm font-semibold text-slate-800 dark:text-slate-100 truncate">{l.userName}</p><p className="text-xs text-slate-500">{range(l)}</p></div></div>
                  <p className="text-xs text-slate-500 mt-2 line-clamp-2">{TYPE_META[l.type]?.emoji} {l.type} · {l.reason}</p>
                  <div className="flex flex-wrap gap-1.5 mt-2">
                    {l.type === 'Yıllık İzin' && <span className={`text-[10px] font-semibold px-1.5 py-0.5 rounded-md ${remaining - n < 0 ? 'bg-rose-50 text-rose-600' : 'bg-slate-100 dark:bg-white/5 text-slate-500'}`}>{tr ? `Onaylanırsa kalan: ${remaining - n} gün` : `Remaining after: ${remaining - n}`}</span>}
                    {conflicts > 0 && <span className="text-[10px] font-semibold px-1.5 py-0.5 rounded-md bg-amber-100 text-amber-700 inline-flex items-center gap-1"><AlertTriangle size={10} />{tr ? `${conflicts} kişi aynı tarihte izinli` : `${conflicts} overlap`}</span>}
                    {(dayDiff(l.startDate) ?? 9) <= 2 && <span className="text-[10px] font-semibold px-1.5 py-0.5 rounded-md bg-rose-50 text-rose-600">{tr ? 'Acil' : 'Urgent'}</span>}
                  </div>
                  <div className="flex gap-2 mt-3">
                    <button onClick={() => setDecision({ leave: l, status: 'Rejected', note: '' })} className="flex-1 h-9 rounded-xl text-xs font-semibold border border-slate-200 dark:border-slate-700 text-slate-600 dark:text-slate-300 hover:text-rose-600 hover:border-rose-200">{tr ? 'Reddet' : 'Reject'}</button>
                    <button onClick={() => setDecision({ leave: l, status: 'Approved', note: '' })} className="flex-1 h-9 rounded-xl text-xs font-semibold text-white bg-emerald-600 hover:bg-emerald-500">{tr ? 'Onayla' : 'Approve'}</button>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* Araçlar */}
      <div className="bg-white dark:bg-slate-900 border border-slate-100 dark:border-slate-800 rounded-[20px] p-3 flex flex-col lg:flex-row gap-2">
        <div className="flex p-1 rounded-xl bg-slate-100 dark:bg-slate-800/60">
          <button onClick={() => setTab('list')} className={`h-8 px-3 rounded-lg text-xs font-semibold inline-flex items-center gap-1.5 ${tab === 'list' ? 'bg-white dark:bg-slate-900 shadow-sm text-indigo-600' : 'text-slate-500'}`}><List size={14} />{tr ? 'Talepler' : 'Requests'}</button>
          <button onClick={() => setTab('calendar')} className={`h-8 px-3 rounded-lg text-xs font-semibold inline-flex items-center gap-1.5 ${tab === 'calendar' ? 'bg-white dark:bg-slate-900 shadow-sm text-indigo-600' : 'text-slate-500'}`}><CalendarDays size={14} />{tr ? 'Takvim' : 'Calendar'}</button>
        </div>
        {tab === 'list' && (
          <>
            <div className="relative flex-1"><Search size={16} className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" /><input value={search} onChange={e => setSearch(e.target.value)} placeholder={tr ? 'Kişi, tür veya açıklama ara…' : 'Search…'} className="w-full h-10 pl-9 pr-3 rounded-xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700 text-sm outline-none focus:border-indigo-500" /></div>
            <select value={statusF} onChange={e => setStatusF(e.target.value as any)} className="h-10 px-3 rounded-xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700 text-xs font-semibold outline-none"><option value="all">{tr ? 'Tüm durumlar' : 'All statuses'}</option>{(Object.keys(STATUS_META) as LeaveRequest['status'][]).map(s => <option key={s} value={s}>{tr ? STATUS_META[s].tr : STATUS_META[s].en}</option>)}</select>
            <select value={typeF} onChange={e => setTypeF(e.target.value as any)} className="h-10 px-3 rounded-xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700 text-xs font-semibold outline-none"><option value="all">{tr ? 'Tüm türler' : 'All types'}</option>{TYPES.map(tp => <option key={tp} value={tp}>{tr ? tp : TYPE_META[tp].en}</option>)}</select>
            {isManager && <button onClick={() => setMineOnly(v => !v)} className={`h-10 px-3 rounded-xl border text-xs font-semibold ${mineOnly ? 'border-indigo-300 bg-indigo-50 text-indigo-600 dark:bg-indigo-500/10' : 'border-slate-200 dark:border-slate-700 text-slate-600 dark:text-slate-300'}`}>{tr ? 'Sadece benimkiler' : 'Mine only'}</button>}
          </>
        )}
      </div>

      <div key={tab} className="animate-in fade-in duration-300">
        {tab === 'calendar' ? calendar() : (
          <div className="bg-white dark:bg-slate-900 border border-slate-100 dark:border-slate-800 rounded-[20px] p-2 sm:p-3">
            {filtered.length === 0 ? (
              <div className="py-14 text-center text-slate-400"><Palmtree size={36} className="mx-auto mb-2 opacity-40 pc-float" /><p className="text-sm font-semibold">{tr ? 'İzin kaydı yok' : 'No leave records'}</p></div>
            ) : <div className="divide-y divide-slate-100 dark:divide-slate-800 pc-stagger">{filtered.map(leaveRow)}</div>}
          </div>
        )}
      </div>

      {/* Talep formu */}
      {show && (
        <ModalPortal>
          <div className="fixed inset-0 z-[1100] flex items-center justify-center p-0 sm:p-4" role="dialog" aria-modal="true">
            <div className="absolute inset-0 bg-slate-950/60 backdrop-blur-md pc-backdrop" onClick={() => setShow(false)} />
            <div className="relative w-full max-w-xl h-full sm:h-auto sm:max-h-[92vh] bg-white dark:bg-slate-900 sm:rounded-[28px] shadow-2xl flex flex-col overflow-hidden pc-pop">
              <div className="flex items-center gap-3 px-5 sm:px-6 py-4 border-b border-slate-100 dark:border-slate-800">
                <span className="w-10 h-10 rounded-xl bg-gradient-to-br from-emerald-500 to-teal-600 text-white flex items-center justify-center shadow-md"><Palmtree size={18} /></span>
                <div className="flex-1"><h3 className="text-lg font-bold text-slate-900 dark:text-white">{tr ? 'İzin talebi' : 'Leave request'}</h3><p className="text-xs text-slate-400">{tr ? `Kalan yıllık izin: ${myRemaining} gün` : `Remaining: ${myRemaining} days`}</p></div>
                <button onClick={() => setShow(false)} className="p-2 rounded-xl text-slate-400 hover:bg-slate-100 dark:hover:bg-white/5"><X size={20} /></button>
              </div>
              <div className="flex-1 overflow-y-auto p-5 sm:p-6 space-y-5">
                <div>
                  <p className="text-xs font-semibold text-slate-600 dark:text-slate-300 mb-1.5">{tr ? 'İzin türü' : 'Type'}</p>
                  <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
                    {TYPES.map(tp => <button key={tp} onClick={() => setForm(f => ({ ...f, type: tp }))} className={`p-3 rounded-xl border text-left text-sm font-semibold transition-all ${form.type === tp ? 'border-indigo-500 bg-indigo-50 dark:bg-indigo-500/10 text-indigo-700 dark:text-indigo-200 ring-4 ring-indigo-500/10' : 'border-slate-200 dark:border-slate-700 text-slate-600 dark:text-slate-300 hover:border-slate-300'}`}><span className="mr-1">{TYPE_META[tp].emoji}</span>{tr ? tp : TYPE_META[tp].en}</button>)}
                  </div>
                </div>
                <div className="grid grid-cols-2 gap-3">
                  <div><p className="text-xs font-semibold text-slate-600 dark:text-slate-300 mb-1.5">{tr ? 'Başlangıç' : 'Start'} <span className="text-rose-500">*</span></p><input type="date" min={today} className={inputCls} value={form.startDate} onChange={e => setForm(f => ({ ...f, startDate: e.target.value, endDate: f.endDate && f.endDate < e.target.value ? e.target.value : f.endDate || e.target.value }))} />{err('start') && <p className="mt-1 text-[11px] font-semibold text-rose-600">{err('start')}</p>}</div>
                  <div><p className="text-xs font-semibold text-slate-600 dark:text-slate-300 mb-1.5">{tr ? 'Bitiş' : 'End'} <span className="text-rose-500">*</span></p><input type="date" min={form.startDate || today} className={inputCls} value={form.endDate} onChange={e => setForm(f => ({ ...f, endDate: e.target.value }))} />{err('end') && <p className="mt-1 text-[11px] font-semibold text-rose-600">{err('end')}</p>}</div>
                </div>
                <label className="flex items-center gap-2 text-sm text-slate-600 dark:text-slate-300 cursor-pointer"><input type="checkbox" className="w-4 h-4 accent-indigo-600" checked={!!form.includeWeekends} onChange={e => setForm(f => ({ ...f, includeWeekends: e.target.checked }))} />{tr ? 'Hafta sonlarını izne dahil et' : 'Include weekends'}</label>
                {days > 0 && (
                  <div className={`flex items-center justify-between rounded-2xl px-4 py-3 animate-in fade-in duration-200 ${exceeds ? 'bg-rose-50 dark:bg-rose-500/10' : 'bg-indigo-50 dark:bg-indigo-500/10'}`}>
                    <span className={`text-sm font-semibold ${exceeds ? 'text-rose-700 dark:text-rose-300' : 'text-indigo-700 dark:text-indigo-300'}`}>{exceeds ? (tr ? 'Bakiyenizi aşıyor' : 'Exceeds balance') : (tr ? 'Toplam izin' : 'Total')}</span>
                    <span className={`text-2xl font-black ${exceeds ? 'text-rose-600' : 'text-indigo-600'}`}>{days} <span className="text-sm font-semibold">{tr ? 'gün' : 'days'}</span></span>
                  </div>
                )}
                {err('overlap') && <p className="text-[11px] font-semibold text-rose-600 flex items-center gap-1"><AlertCircle size={12} />{err('overlap')}</p>}
                <div><p className="text-xs font-semibold text-slate-600 dark:text-slate-300 mb-1.5">{tr ? 'Açıklama' : 'Reason'} <span className="text-rose-500">*</span></p><textarea rows={3} className={inputCls + ' h-auto py-2.5 resize-none'} value={form.reason} onChange={e => setForm(f => ({ ...f, reason: e.target.value }))} placeholder={tr ? 'İzin nedeninizi kısaca yazın…' : 'Briefly explain…'} />{err('reason') && <p className="mt-1 text-[11px] font-semibold text-rose-600">{err('reason')}</p>}</div>
              </div>
              <div className="flex items-center gap-2 px-5 sm:px-6 py-3 border-t border-slate-100 dark:border-slate-800">
                <div className="flex-1" />
                <button onClick={() => setShow(false)} className="h-10 px-4 rounded-xl text-sm font-semibold text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-white/5">{tr ? 'Vazgeç' : 'Cancel'}</button>
                <button onClick={submit} disabled={saving} className="h-10 px-5 rounded-xl text-sm font-semibold text-white bg-indigo-600 hover:bg-indigo-500 disabled:opacity-60 inline-flex items-center gap-2 shadow-lg shadow-indigo-500/25">{saving ? <Loader2 size={16} className="animate-spin" /> : <Save size={16} />}{tr ? 'Talebi gönder' : 'Send request'}</button>
              </div>
            </div>
          </div>
        </ModalPortal>
      )}

      {/* Onay / ret */}
      {decision && (
        <ModalPortal>
          <div className="fixed inset-0 z-[1100] flex items-center justify-center p-4" role="dialog" aria-modal="true">
            <div className="absolute inset-0 bg-slate-950/60 backdrop-blur-md pc-backdrop" onClick={() => setDecision(null)} />
            <div className="relative w-full max-w-md bg-white dark:bg-slate-900 rounded-[24px] shadow-2xl p-5 pc-pop">
              <div className="flex items-center gap-3 mb-4">{userAvatar(decision.leave.userId, decision.leave.userName, 'w-11 h-11')}<div><p className="font-bold text-slate-900 dark:text-white">{decision.status === 'Approved' ? (tr ? 'İzni onayla' : 'Approve leave') : (tr ? 'İzni reddet' : 'Reject leave')}</p><p className="text-xs text-slate-500">{decision.leave.userName} · {range(decision.leave)}</p></div></div>
              <textarea autoFocus rows={3} className={inputCls + ' h-auto py-2.5 resize-none'} value={decision.note} onChange={e => setDecision({ ...decision, note: e.target.value })} placeholder={tr ? 'Personele not (isteğe bağlı)' : 'Note to employee (optional)'} />
              <div className="flex gap-2 mt-4">
                <button onClick={() => setDecision(null)} className="flex-1 h-10 rounded-xl text-sm font-semibold text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-white/5">{tr ? 'Vazgeç' : 'Cancel'}</button>
                <button onClick={decide} className={`flex-1 h-10 rounded-xl text-sm font-semibold text-white ${decision.status === 'Approved' ? 'bg-emerald-600 hover:bg-emerald-500' : 'bg-rose-600 hover:bg-rose-500'}`}>{decision.status === 'Approved' ? (tr ? 'Onayla' : 'Approve') : (tr ? 'Reddet' : 'Reject')}</button>
              </div>
            </div>
          </div>
        </ModalPortal>
      )}
    </div>
  );
};

export default LeaveView;
