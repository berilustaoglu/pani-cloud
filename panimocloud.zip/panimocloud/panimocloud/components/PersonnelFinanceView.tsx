import React, { useMemo, useState } from 'react';
import { Wallet, CreditCard, TrendingUp, MinusCircle, Users, History, Banknote, CheckCircle2, Clock, AlertTriangle, Copy, CalendarRange } from 'lucide-react';
import { User, PersonnelTransaction, PersonnelTransactionType, Currency, Transaction } from '../types';
import { PageHeader, KpiGrid, SearchBox, Segmented, Field, EmptyState, DeleteButton, Sheet, Avatar, inputCls, selectSm, cardCls, btnPrimary, btnGhost, money } from './ui/Kit';
import { GrowBar } from './ui/Motion';
import { toTRY, formatTRY, localISO } from '../services/insights';
import { toast } from '../services/toast';

interface Props {
  staffList: User[];
  transactions: PersonnelTransaction[];
  onUpsertTransaction: (tx: PersonnelTransaction) => Promise<void>;
  onDeleteTransaction: (id: string) => Promise<void>;
  language: 'tr' | 'en';
  onAddMainTransaction: (tx: Transaction) => Promise<void>;
  onDeleteMainTransaction?: (id: string) => Promise<void>;
  showFinancials: boolean;
  rates?: { TRY: number; EUR: number };
}

const TYPE_META: Record<PersonnelTransactionType, { tr: string; en: string; icon: React.ElementType; tone: string; chip: string }> = {
  Salary: { tr: 'Maaş', en: 'Salary', icon: Wallet, tone: 'from-indigo-500 to-violet-600', chip: 'bg-indigo-50 text-indigo-700 dark:bg-indigo-500/10 dark:text-indigo-300' },
  Advance: { tr: 'Avans', en: 'Advance', icon: CreditCard, tone: 'from-amber-500 to-orange-600', chip: 'bg-amber-50 text-amber-700 dark:bg-amber-500/10 dark:text-amber-300' },
  Bonus: { tr: 'Prim', en: 'Bonus', icon: TrendingUp, tone: 'from-emerald-500 to-teal-600', chip: 'bg-emerald-50 text-emerald-700 dark:bg-emerald-500/10 dark:text-emerald-300' },
  Deduction: { tr: 'Kesinti', en: 'Deduction', icon: MinusCircle, tone: 'from-rose-500 to-red-600', chip: 'bg-rose-50 text-rose-700 dark:bg-rose-500/10 dark:text-rose-300' },
};
const DEFAULT_RATES = { TRY: 1, EUR: 1 };
const monthOf = (t: PersonnelTransaction) => t.month || (t.date || '').slice(0, 7);

const PersonnelFinanceView: React.FC<Props> = ({ staffList, transactions, onUpsertTransaction, onDeleteTransaction, language, onAddMainTransaction, onDeleteMainTransaction, showFinancials, rates = DEFAULT_RATES }) => {
  const tr = language === 'tr';
  const [month, setMonth] = useState(localISO().slice(0, 7));
  const [search, setSearch] = useState('');
  const [statusF, setStatusF] = useState<'all' | 'pending' | 'partial' | 'paid'>('all');
  const [selectedId, setSelectedId] = useState<string | null>(null);
  const [form, setForm] = useState<Partial<PersonnelTransaction> & { type: PersonnelTransactionType } | null>(null);
  const [bulkOpen, setBulkOpen] = useState(false);
  const [saving, setSaving] = useState(false);
  const [touched, setTouched] = useState(false);

  const conv = (amount: number, from: Currency, to: Currency) => from === to ? amount : toTRY(amount, from, rates) / (toTRY(1, to, rates) || 1);
  const show = (n: number, c?: string) => (showFinancials ? money(n, c, 0) : '••••');

  /** Seçili ay için kişi bazlı bordro özeti (personelin maaş para biriminde) */
  const payroll = useMemo(() => staffList.map(u => {
    const cur = u.salaryCurrency || Currency.TRY;
    const salary = Number(u.monthlySalary) || 0;
    const txs = transactions.filter(t => t.userId === u.id && monthOf(t) === month);
    const sum = (type: PersonnelTransactionType) => txs.filter(t => t.type === type).reduce((a, t) => a + conv(t.amount, t.currency, cur), 0);
    const bonus = sum('Bonus'), deduction = sum('Deduction'), advance = sum('Advance'), salaryPaid = sum('Salary');
    const gross = salary + bonus - deduction;
    const paid = salaryPaid + advance + bonus;
    const remaining = Math.max(0, gross - paid);
    const status: 'nosalary' | 'paid' | 'partial' | 'pending' = !salary ? 'nosalary' : remaining < 1 ? 'paid' : paid > 0 ? 'partial' : 'pending';
    return { user: u, cur, salary, bonus, deduction, advance, salaryPaid, gross, paid, remaining, status, count: txs.length };
  }), [staffList, transactions, month, rates]);

  const totals = useMemo(() => {
    const T = (n: number, c: Currency) => toTRY(n, c, rates);
    return {
      gross: payroll.reduce((a, p) => a + T(p.gross, p.cur), 0),
      paid: payroll.reduce((a, p) => a + T(Math.min(p.paid, p.gross), p.cur), 0),
      remaining: payroll.reduce((a, p) => a + T(p.remaining, p.cur), 0),
      advance: payroll.reduce((a, p) => a + T(p.advance, p.cur), 0),
      paidCount: payroll.filter(p => p.status === 'paid').length,
      withSalary: payroll.filter(p => p.status !== 'nosalary').length,
    };
  }, [payroll, rates]);

  const q = search.trim().toLocaleLowerCase('tr-TR');
  const rows = payroll.filter(p => (statusF === 'all' || p.status === statusF) && (!q || [p.user.name, p.user.jobTitle].join(' ').toLocaleLowerCase('tr-TR').includes(q)))
    .sort((a, b) => ({ pending: 0, partial: 1, paid: 2, nosalary: 3 }[a.status] - { pending: 0, partial: 1, paid: 2, nosalary: 3 }[b.status]) || a.user.name.localeCompare(b.user.name, 'tr'));
  const sel = payroll.find(p => p.user.id === selectedId) || null;
  const history = useMemo(() => transactions.filter(t => t.userId === selectedId).sort((a, b) => (b.date || '').localeCompare(a.date || '')), [transactions, selectedId]);

  const months = useMemo(() => { const s = new Set(transactions.map(monthOf).filter(Boolean)); s.add(localISO().slice(0, 7)); return [...s].sort().reverse(); }, [transactions]);
  const monthLabel = (k: string) => { const [y, m] = k.split('-').map(Number); return new Date(y, m - 1, 1).toLocaleDateString(tr ? 'tr-TR' : 'en-US', { month: 'long', year: 'numeric' }); };

  const record = async (u: User, type: PersonnelTransactionType, amount: number, currency: Currency, date: string, m: string, description: string) => {
    const tx: PersonnelTransaction = { id: `ptx_${Date.now()}_${Math.random().toString(36).slice(2, 6)}`, userId: u.id, userName: u.name, amount, currency, date, type, month: m, description };
    await onUpsertTransaction(tx);
    if (type !== 'Deduction') {
      await onAddMainTransaction({ id: `tr_${tx.id}`, type: 'Expense', amount, currency, category: 'Personel Maaşları', date, description: `${TYPE_META[type].tr}: ${u.name} (${m})${description ? ` · ${description}` : ''}`, taxRate: 0, taxAmount: 0, totalAmountWithTax: amount });
    }
  };

  const openForm = (type: PersonnelTransactionType) => {
    if (!sel) return;
    setTouched(false);
    setForm({ type, currency: sel.cur, date: localISO(), month, description: '', amount: type === 'Salary' ? Math.round(sel.remaining * 100) / 100 || undefined : undefined });
  };
  const formErr = form && !(Number(form.amount) > 0) ? (tr ? 'Tutar girin.' : 'Enter amount.') : undefined;
  const saveForm = async () => {
    setTouched(true);
    if (!form || !sel || formErr) return;
    setSaving(true);
    try {
      await record(sel.user, form.type, Number(form.amount), form.currency || sel.cur, form.date || localISO(), form.month || month, (form.description || '').trim());
      toast.success(tr ? `${TYPE_META[form.type].tr} kaydedildi${form.type !== 'Deduction' ? ' · muhasebeye gider olarak işlendi' : ''}` : 'Saved');
      setForm(null);
    } catch (e: any) { toast.error(e?.message || 'Hata'); } finally { setSaving(false); }
  };

  const bulkList = payroll.filter(p => p.status === 'pending' || p.status === 'partial');
  const bulkPay = async () => {
    setSaving(true);
    try {
      for (const p of bulkList) await record(p.user, 'Salary', Math.round(p.remaining * 100) / 100, p.cur, localISO(), month, tr ? 'Toplu maaş ödemesi' : 'Bulk payroll');
      toast.success(tr ? `${bulkList.length} personelin ${monthLabel(month)} maaşı ödendi` : 'Payroll paid');
      setBulkOpen(false);
    } catch (e: any) { toast.error(e?.message || 'Hata'); } finally { setSaving(false); }
  };

  const del = async (t: PersonnelTransaction) => {
    await onDeleteTransaction(t.id);
    if (onDeleteMainTransaction && t.type !== 'Deduction') { try { await onDeleteMainTransaction(`tr_${t.id}`); } catch { /* muhasebe kaydı yoksa sorun değil */ } }
    toast(tr ? 'İşlem silindi' : 'Deleted', 'info');
  };

  const statusChip = (s: string) => ({
    paid: <span className="inline-flex items-center gap-1 text-[11px] font-semibold px-2 py-0.5 rounded-md bg-emerald-50 text-emerald-700 dark:bg-emerald-500/10 dark:text-emerald-300"><CheckCircle2 size={11} />{tr ? 'Ödendi' : 'Paid'}</span>,
    partial: <span className="inline-flex items-center gap-1 text-[11px] font-semibold px-2 py-0.5 rounded-md bg-amber-50 text-amber-700 dark:bg-amber-500/10 dark:text-amber-300"><Clock size={11} />{tr ? 'Kısmi' : 'Partial'}</span>,
    pending: <span className="inline-flex items-center gap-1 text-[11px] font-semibold px-2 py-0.5 rounded-md bg-rose-50 text-rose-700 dark:bg-rose-500/10 dark:text-rose-300"><AlertTriangle size={11} />{tr ? 'Bekliyor' : 'Pending'}</span>,
    nosalary: <span className="text-[11px] font-semibold px-2 py-0.5 rounded-md bg-slate-100 text-slate-500 dark:bg-white/5">{tr ? 'Maaş tanımsız' : 'No salary'}</span>,
  } as Record<string, React.ReactNode>)[s];

  return (
    <div className="space-y-5 pb-10">
      <PageHeader title={tr ? 'Personel Finans' : 'Personnel Finance'} subtitle={tr ? `Bordro, avans, prim ve kesintiler · ${monthLabel(month)}` : `Payroll · ${monthLabel(month)}`}
        actions={<>
          <select value={month} onChange={e => setMonth(e.target.value)} className={selectSm + ' !h-10'}>{months.map(m => <option key={m} value={m}>{monthLabel(m)}</option>)}</select>
          <button disabled={!bulkList.length} onClick={() => setBulkOpen(true)} className={btnPrimary}><Banknote size={16} />{tr ? 'Toplu maaş öde' : 'Run payroll'}{bulkList.length > 0 && <span className="text-[10px] px-1.5 rounded-full bg-white/20">{bulkList.length}</span>}</button>
        </>} />

      <KpiGrid items={[
        { label: tr ? 'Aylık bordro yükü' : 'Payroll', value: showFinancials ? totals.gross : 0, format: formatTRY, icon: Wallet, grad: 'from-indigo-500 to-violet-600', sub: `${totals.withSalary} ${tr ? 'maaşlı personel' : 'salaried'}` },
        { label: tr ? 'Ödenen' : 'Paid', value: showFinancials ? totals.paid : 0, format: formatTRY, icon: CheckCircle2, grad: 'from-emerald-500 to-teal-600', sub: `${totals.paidCount}/${totals.withSalary} ${tr ? 'kişi tamam' : 'done'}`, bar: totals.gross ? (totals.paid / totals.gross) * 100 : 0, onClick: () => setStatusF(statusF === 'paid' ? 'all' : 'paid'), active: statusF === 'paid' },
        { label: tr ? 'Kalan ödeme' : 'Remaining', value: showFinancials ? totals.remaining : 0, format: formatTRY, icon: Clock, grad: 'from-rose-500 to-red-600', sub: `${bulkList.length} ${tr ? 'kişi bekliyor' : 'pending'}`, onClick: () => setStatusF(statusF === 'pending' ? 'all' : 'pending'), active: statusF === 'pending' },
        { label: tr ? 'Verilen avans' : 'Advances', value: showFinancials ? totals.advance : 0, format: formatTRY, icon: CreditCard, grad: 'from-amber-500 to-orange-600', sub: tr ? 'Maaştan düşülür' : 'Deducted from salary' },
      ]} />

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-4 items-start">
        {/* Bordro listesi */}
        <div className={`${cardCls} lg:col-span-5 overflow-hidden`}>
          <div className="p-3 flex gap-2 border-b border-slate-100 dark:border-slate-800">
            <SearchBox value={search} onChange={setSearch} placeholder={tr ? 'Personel ara…' : 'Search…'} />
            <select value={statusF} onChange={e => setStatusF(e.target.value as any)} className={selectSm}><option value="all">{tr ? 'Tümü' : 'All'}</option><option value="pending">{tr ? 'Bekliyor' : 'Pending'}</option><option value="partial">{tr ? 'Kısmi' : 'Partial'}</option><option value="paid">{tr ? 'Ödendi' : 'Paid'}</option></select>
          </div>
          {rows.length === 0 ? <EmptyState icon={Users} text={tr ? 'Personel bulunamadı' : 'No staff'} /> : (
            <div className="divide-y divide-slate-100 dark:divide-slate-800 max-h-[640px] overflow-y-auto custom-scrollbar pc-stagger">
              {rows.map(p => (
                <button key={p.user.id} onClick={() => setSelectedId(p.user.id)} className={`w-full text-left px-4 py-3 flex items-center gap-3 transition-colors ${selectedId === p.user.id ? 'bg-indigo-50/70 dark:bg-indigo-500/10' : 'hover:bg-slate-50/70 dark:hover:bg-white/[0.02]'}`}>
                  <Avatar name={p.user.name} src={p.user.avatar} />
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2"><p className="text-sm font-semibold text-slate-800 dark:text-slate-100 truncate">{p.user.name}</p>{statusChip(p.status)}</div>
                    {p.status !== 'nosalary' ? <div className="mt-1.5 flex items-center gap-2"><div className="flex-1"><GrowBar value={p.gross ? Math.min(100, (p.paid / p.gross) * 100) : 0} className={p.status === 'paid' ? 'bg-emerald-500' : 'bg-indigo-500'} /></div><span className="text-[10px] text-slate-400 whitespace-nowrap">{show(p.paid, p.cur)} / {show(p.gross, p.cur)}</span></div>
                      : <p className="text-[11px] text-slate-400 truncate">{p.user.jobTitle || '—'}</p>}
                  </div>
                </button>
              ))}
            </div>
          )}
        </div>

        {/* Detay */}
        <div className="lg:col-span-7 space-y-4">
          {!sel ? <div className={cardCls}><EmptyState icon={Wallet} text={tr ? 'Bordro detayı için soldan bir personel seçin' : 'Select a staff member'} /></div> : (
            <div key={sel.user.id} className="space-y-4 animate-in fade-in slide-in-from-right-2 duration-300">
              <div className={`${cardCls} p-5`}>
                <div className="flex items-start gap-4">
                  <Avatar name={sel.user.name} src={sel.user.avatar} size="w-14 h-14" />
                  <div className="flex-1 min-w-0">
                    <h3 className="text-lg font-bold text-slate-900 dark:text-white truncate">{sel.user.name}</h3>
                    <p className="text-xs text-slate-400">{sel.user.jobTitle || sel.user.role} · {tr ? 'Aylık maaş' : 'Salary'} <b className="text-slate-700 dark:text-slate-200">{sel.salary ? show(sel.salary, sel.cur) : '—'}</b></p>
                    {sel.user.iban && <button onClick={() => { navigator.clipboard.writeText(sel.user.iban!); toast.success(tr ? 'IBAN kopyalandı' : 'IBAN copied'); }} className="mt-1 text-[11px] font-mono text-slate-500 hover:text-indigo-600 inline-flex items-center gap-1">{sel.user.bankName ? `${sel.user.bankName} · ` : ''}{sel.user.iban}<Copy size={10} /></button>}
                  </div>
                  {statusChip(sel.status)}
                </div>
                <div className="mt-4 grid grid-cols-2 sm:grid-cols-4 gap-2">
                  {[[tr ? 'Brüt hakediş' : 'Gross', sel.gross, 'text-slate-900 dark:text-white'], [tr ? 'Prim' : 'Bonus', sel.bonus, 'text-emerald-600'], [tr ? 'Avans + kesinti' : 'Adv + ded.', sel.advance + sel.deduction, 'text-amber-600'], [tr ? 'Kalan' : 'Remaining', sel.remaining, sel.remaining > 0 ? 'text-rose-600' : 'text-emerald-600']].map(([l, v, c]) => (
                    <div key={l as string} className="rounded-xl bg-slate-50 dark:bg-white/[0.03] px-3 py-2.5"><p className="text-[10px] text-slate-400">{l}</p><p className={`text-base font-black ${c}`}>{show(v as number, sel.cur)}</p></div>
                  ))}
                </div>
                <div className="mt-4 grid grid-cols-2 sm:grid-cols-4 gap-2">
                  {(Object.keys(TYPE_META) as PersonnelTransactionType[]).map(t => { const M = TYPE_META[t]; const I = M.icon; return (
                    <button key={t} onClick={() => openForm(t)} className="h-10 rounded-xl border border-slate-200 dark:border-slate-700 text-xs font-semibold text-slate-600 dark:text-slate-300 inline-flex items-center justify-center gap-1.5 hover:border-indigo-300 hover:text-indigo-600 pc-lift"><span className={`p-1 rounded-md bg-gradient-to-br ${M.tone} text-white`}><I size={12} /></span>{t === 'Salary' ? (tr ? 'Maaş öde' : 'Pay salary') : tr ? M.tr : M.en}</button>); })}
                </div>
              </div>

              <div className={`${cardCls} overflow-hidden`}>
                <div className="px-4 py-3 border-b border-slate-100 dark:border-slate-800 flex items-center gap-2"><History size={15} className="text-indigo-500" /><h4 className="text-sm font-bold text-slate-800 dark:text-slate-100 flex-1">{tr ? 'İşlem geçmişi' : 'History'}</h4><span className="text-[11px] text-slate-400">{history.length}</span></div>
                {history.length === 0 ? <EmptyState icon={History} text={tr ? 'Henüz işlem yok' : 'No transactions'} /> : (
                  <div className="divide-y divide-slate-100 dark:divide-slate-800 max-h-[420px] overflow-y-auto custom-scrollbar pc-stagger">
                    {history.map(t => { const M = TYPE_META[t.type] || TYPE_META.Salary; return (
                      <div key={t.id} className={`px-4 py-2.5 flex items-center gap-3 ${monthOf(t) === month ? '' : 'opacity-70'}`}>
                        <span className={`text-[11px] font-semibold px-2 py-0.5 rounded-md ${M.chip}`}>{tr ? M.tr : M.en}</span>
                        <div className="flex-1 min-w-0"><p className="text-xs text-slate-600 dark:text-slate-300 truncate">{t.description || '—'}</p><p className="text-[10px] text-slate-400 flex items-center gap-1"><CalendarRange size={10} />{t.date} · {tr ? 'dönem' : 'period'} {monthOf(t)}</p></div>
                        <span className={`text-sm font-bold ${t.type === 'Deduction' ? 'text-rose-500' : 'text-slate-900 dark:text-white'}`}>{t.type === 'Deduction' ? '−' : ''}{show(t.amount, t.currency)}</span>
                        <DeleteButton language={language} onConfirm={() => del(t)} />
                      </div>); })}
                  </div>
                )}
              </div>
            </div>
          )}
        </div>
      </div>

      {/* İşlem formu */}
      <Sheet open={!!form} language={language} title={form ? `${tr ? TYPE_META[form.type].tr : TYPE_META[form.type].en} · ${sel?.user.name || ''}` : ''} subtitle={form?.type !== 'Deduction' ? (tr ? 'Muhasebeye "Personel Maaşları" gideri olarak da işlenir' : 'Also recorded as expense') : (tr ? 'Kesinti yalnızca bordroyu etkiler' : 'Affects payroll only')}
        icon={form ? TYPE_META[form.type].icon : Wallet} tone={form ? TYPE_META[form.type].tone : undefined} onClose={() => setForm(null)} onSubmit={saveForm} saving={saving}
        footerLeft={form?.type === 'Salary' && sel ? <span className="text-slate-400">{tr ? 'Kalan hakediş' : 'Remaining'} <b className="text-slate-800 dark:text-slate-100">{show(sel.remaining, sel.cur)}</b></span> : undefined}>
        {form && <>
          <Field label={tr ? 'İşlem türü' : 'Type'}><Segmented<PersonnelTransactionType> value={form.type} onChange={v => setForm({ ...form, type: v, amount: v === 'Salary' && sel ? Math.round(sel.remaining * 100) / 100 : form.amount })} options={(Object.keys(TYPE_META) as PersonnelTransactionType[]).map(t => ({ value: t, label: tr ? TYPE_META[t].tr : TYPE_META[t].en }))} /></Field>
          <div className="grid grid-cols-3 gap-4">
            <Field label={tr ? 'Tutar' : 'Amount'} required error={touched ? formErr : undefined} className="col-span-2"><input autoFocus type="number" min={0} className={inputCls(touched ? formErr : undefined) + ' font-bold'} value={form.amount ?? ''} onChange={e => setForm({ ...form, amount: Number(e.target.value) })} /></Field>
            <Field label={tr ? 'Para birimi' : 'Currency'}><select className={inputCls()} value={form.currency} onChange={e => setForm({ ...form, currency: e.target.value as Currency })}>{Object.values(Currency).map(c => <option key={c} value={c}>{c}</option>)}</select></Field>
          </div>
          <div className="grid grid-cols-2 gap-4">
            <Field label={tr ? 'İşlem tarihi' : 'Date'}><input type="date" className={inputCls()} value={form.date} onChange={e => setForm({ ...form, date: e.target.value })} /></Field>
            <Field label={tr ? 'Bordro dönemi' : 'Period'}><input type="month" className={inputCls()} value={form.month} onChange={e => setForm({ ...form, month: e.target.value })} /></Field>
          </div>
          <Field label={tr ? 'Açıklama' : 'Description'}><input className={inputCls()} value={form.description || ''} onChange={e => setForm({ ...form, description: e.target.value })} placeholder={tr ? 'Örn: Ekim maaşı, proje primi…' : 'Optional'} /></Field>
        </>}
      </Sheet>

      {/* Toplu ödeme */}
      <Sheet open={bulkOpen} language={language} title={tr ? `${monthLabel(month)} toplu maaş ödemesi` : 'Run payroll'} subtitle={tr ? 'Her personelin kalan hakedişi maaş ödemesi olarak kaydedilir' : 'Pays each remaining balance'} icon={Banknote} tone="from-emerald-500 to-teal-600" onClose={() => setBulkOpen(false)} onSubmit={bulkPay} saving={saving} submitLabel={tr ? `${bulkList.length} ödemeyi onayla` : 'Confirm'}
        footerLeft={<span className="text-slate-400">{tr ? 'Toplam' : 'Total'} <b className="text-slate-800 dark:text-slate-100">{showFinancials ? formatTRY(bulkList.reduce((a, p) => a + toTRY(p.remaining, p.cur, rates), 0)) : '••••'}</b></span>}>
        <div className="divide-y divide-slate-100 dark:divide-slate-800 rounded-2xl border border-slate-100 dark:border-slate-800 overflow-hidden">
          {bulkList.map(p => (
            <div key={p.user.id} className="flex items-center gap-3 px-3 py-2.5">
              <Avatar name={p.user.name} src={p.user.avatar} size="w-8 h-8" />
              <div className="flex-1 min-w-0"><p className="text-sm font-semibold text-slate-800 dark:text-slate-100 truncate">{p.user.name}</p><p className="text-[11px] text-slate-400 truncate">{p.user.iban || (tr ? 'IBAN yok' : 'No IBAN')}</p></div>
              <div className="text-right"><p className="text-sm font-bold text-slate-900 dark:text-white">{show(p.remaining, p.cur)}</p>{(p.advance > 0 || p.deduction > 0) && <p className="text-[10px] text-amber-600">{tr ? 'avans/kesinti düşüldü' : 'net of adv.'}</p>}</div>
            </div>
          ))}
        </div>
        <button onClick={() => {
          const csv = '﻿' + [['Personel', 'Banka', 'IBAN', 'Tutar', 'Para birimi'], ...bulkList.map(p => [p.user.name, p.user.bankName || '', p.user.iban || '', p.remaining.toFixed(2), p.cur])].map(r => r.map(c => `"${c}"`).join(';')).join('\n');
          const a = document.createElement('a'); a.href = URL.createObjectURL(new Blob([csv], { type: 'text/csv;charset=utf-8;' })); a.download = `Bordro_${month}.csv`; a.click();
        }} className={btnGhost + ' w-full'}><Copy size={15} />{tr ? 'Banka talimat listesi indir (CSV)' : 'Download bank list'}</button>
      </Sheet>
    </div>
  );
};

export default PersonnelFinanceView;
