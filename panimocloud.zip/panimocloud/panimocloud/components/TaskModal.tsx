import React, { useEffect, useMemo, useRef, useState } from 'react';
import { X, Plus, Trash2, Check, ListTodo, Save, Loader2, AlertCircle, CheckSquare, GripVertical, Link2, Percent, StickyNote } from 'lucide-react';
import { Task, TaskStatus, Project, User, ChecklistItem } from '../types';
import ModalPortal from './ModalPortal';
import { toast } from '../services/toast';

interface Props {
  show: boolean;
  onClose: () => void;
  task: Task | null;
  projects: Project[];
  users: User[];
  language: 'tr' | 'en';
  onSave: (task: Task) => Promise<void>;
  onDelete?: (id: string) => Promise<void>;
  tasks: Task[];
  defaults?: Partial<Task>;
}

export const TASK_STATUS_META: Record<TaskStatus, { tr: string; en: string; chip: string; dot: string; col: string }> = {
  [TaskStatus.TODO]: { tr: 'Yapılacak', en: 'To do', chip: 'bg-slate-100 text-slate-600 dark:bg-white/5 dark:text-slate-300', dot: 'bg-slate-400', col: 'from-slate-400 to-slate-500' },
  [TaskStatus.DOING]: { tr: 'Devam ediyor', en: 'In progress', chip: 'bg-sky-50 text-sky-700 dark:bg-sky-500/10 dark:text-sky-300', dot: 'bg-sky-500', col: 'from-sky-400 to-indigo-500' },
  [TaskStatus.DONE]: { tr: 'Tamamlandı', en: 'Done', chip: 'bg-emerald-50 text-emerald-700 dark:bg-emerald-500/10 dark:text-emerald-300', dot: 'bg-emerald-500', col: 'from-emerald-400 to-teal-500' },
  [TaskStatus.BLOCKED]: { tr: 'Engellendi', en: 'Blocked', chip: 'bg-rose-50 text-rose-700 dark:bg-rose-500/10 dark:text-rose-300', dot: 'bg-rose-500', col: 'from-rose-400 to-orange-500' },
};

const inputBase = 'w-full h-11 px-3.5 rounded-xl bg-white dark:bg-slate-800 border text-sm font-medium text-slate-900 dark:text-white outline-none transition-all placeholder:text-slate-400 focus:ring-4';
const inputCls = (err?: string) => `${inputBase} ${err ? 'border-rose-300 focus:border-rose-400 focus:ring-rose-500/10' : 'border-slate-200 dark:border-slate-700 focus:border-indigo-500 focus:ring-indigo-500/10'}`;
const Field: React.FC<{ label: string; required?: boolean; error?: string; hint?: React.ReactNode; children: React.ReactNode; className?: string }> = ({ label, required, error, hint, children, className = '' }) => (
  <div className={className}>
    <label className="flex items-center gap-1 text-xs font-semibold text-slate-600 dark:text-slate-300 mb-1.5">{label}{required && <span className="text-rose-500">*</span>}</label>
    {children}
    {error ? <p className="mt-1 text-[11px] font-semibold text-rose-600 flex items-center gap-1 animate-in fade-in slide-in-from-top-2 duration-200"><AlertCircle size={12} /> {error}</p> : hint ? <div className="mt-1 text-[11px] text-slate-400">{hint}</div> : null}
  </div>
);

const addDays = (n: number) => { const d = new Date(); d.setDate(d.getDate() + n); return d.toISOString().split('T')[0]; };

const TaskModal: React.FC<Props> = ({ show, onClose, task: editingTask, projects, users, language, onSave, onDelete, tasks, defaults }) => {
  const tr = language === 'tr';
  const [t, setT] = useState<Partial<Task>>({});
  const [itemInput, setItemInput] = useState('');
  const [touched, setTouched] = useState(false);
  const [saving, setSaving] = useState(false);
  const [confirmDelete, setConfirmDelete] = useState(false);
  const [dragItem, setDragItem] = useState<string | null>(null);
  const initial = useRef('');

  useEffect(() => {
    if (!show) return;
    const start: Partial<Task> = editingTask
      ? { ...editingTask, checklist: editingTask.checklist || [] }
      : { status: TaskStatus.TODO, progress: 0, assignedTo: [], checklist: [], deadline: addDays(7), ...defaults };
    setT(start); initial.current = JSON.stringify(start);
    setItemInput(''); setTouched(false); setSaving(false); setConfirmDelete(false);
  }, [editingTask, show]);

  const set = (patch: Partial<Task>) => setT(prev => ({ ...prev, ...patch }));
  const dirty = show && JSON.stringify(t) !== initial.current;

  const suggestedImpact = useMemo(() => {
    if (!t.projectId) return null;
    const count = tasks.filter(x => x.projectId === t.projectId && x.id !== editingTask?.id).length + 1;
    return Math.round(100 / count);
  }, [t.projectId, tasks, editingTask]);
  const projectImpactUsed = useMemo(() => tasks.filter(x => x.projectId === t.projectId && x.id !== editingTask?.id).reduce((s, x) => s + (x.progress || 0), 0), [t.projectId, tasks, editingTask]);

  const errors = useMemo(() => {
    const e: Record<string, string> = {};
    if (!t.title?.trim()) e.title = tr ? 'Görev başlığı zorunlu.' : 'Title is required.';
    if (!t.projectId) e.project = tr ? 'Bir proje seçin.' : 'Select a project.';
    if (!t.deadline) e.deadline = tr ? 'Son tarih zorunlu.' : 'Deadline required.';
    if ((t.progress || 0) < 0 || (t.progress || 0) > 100) e.progress = tr ? '0-100 arasında olmalı.' : 'Must be 0-100.';
    if (t.status === TaskStatus.BLOCKED && !t.blockedReason?.trim()) e.blocked = tr ? 'Engellenme nedenini yazın.' : 'Explain why it is blocked.';
    return e;
  }, [t, tr]);
  const err = (k: string) => (touched ? errors[k] : undefined);

  const save = async () => {
    setTouched(true);
    if (Object.keys(errors).length) return;
    setSaving(true);
    try {
      const out: Task = {
        ...(editingTask || {}), ...(t as Task),
        id: editingTask ? editingTask.id : `t${Date.now()}`,
        title: t.title!.trim(), assignedTo: t.assignedTo || [], status: t.status || TaskStatus.TODO,
        progress: Number(t.progress || 0), checklist: t.checklist || [],
      };
      if (out.status !== TaskStatus.BLOCKED) delete (out as any).blockedReason;
      Object.keys(out).forEach(k => (out as any)[k] === undefined && delete (out as any)[k]);
      await onSave(out);
      toast.success(editingTask ? (tr ? 'Görev güncellendi' : 'Task updated') : (tr ? 'Görev oluşturuldu' : 'Task created'));
      onClose();
    } catch (e: any) { toast.error((tr ? 'Kaydedilemedi: ' : 'Save failed: ') + (e?.message || '')); }
    finally { setSaving(false); }
  };

  const requestClose = () => { onClose(); if (dirty && !editingTask) toast.info(tr ? 'Kaydedilmeyen görev kapatıldı' : 'Unsaved task discarded', 2000); };

  useEffect(() => {
    if (!show) return;
    const onKey = (e: KeyboardEvent) => {
      if (e.key === 'Escape') { e.preventDefault(); requestClose(); }
      if ((e.ctrlKey || e.metaKey) && e.key === 'Enter') { e.preventDefault(); save(); }
    };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  });

  if (!show) return null;

  const list = t.checklist || [];
  const done = list.filter(i => i.isCompleted).length;
  const addItems = () => {
    // Birden fazla satır yapıştırılırsa her satır ayrı madde olur
    const lines = itemInput.split('\n').map(s => s.trim()).filter(Boolean);
    if (!lines.length) return;
    set({ checklist: [...list, ...lines.map((text, i) => ({ id: `cl_${Date.now()}_${i}`, text, isCompleted: false } as ChecklistItem))] });
    setItemInput('');
  };
  const moveItem = (fromId: string, toId: string) => {
    if (fromId === toId) return;
    const arr = [...list]; const from = arr.findIndex(i => i.id === fromId); const to = arr.findIndex(i => i.id === toId);
    const [m] = arr.splice(from, 1); arr.splice(to, 0, m); set({ checklist: arr });
  };
  const projectTasks = tasks.filter(x => x.projectId === t.projectId && x.id !== editingTask?.id);

  return (
    <ModalPortal>
      <div className="fixed inset-0 z-[1100] flex items-center justify-center p-0 sm:p-4" role="dialog" aria-modal="true">
        <div className="absolute inset-0 bg-slate-950/60 backdrop-blur-md pc-backdrop" onClick={requestClose} />
        <div className="relative w-full max-w-3xl h-full sm:h-auto sm:max-h-[92vh] bg-white dark:bg-slate-900 sm:rounded-[28px] shadow-2xl flex flex-col overflow-hidden pc-pop border border-white/10">
          <div className="flex items-center gap-3 px-5 sm:px-6 py-4 border-b border-slate-100 dark:border-slate-800" style={{ paddingTop: 'max(env(safe-area-inset-top, 0px), 1rem)' }}>
            <span className={`w-10 h-10 shrink-0 rounded-xl bg-gradient-to-br ${TASK_STATUS_META[(t.status || TaskStatus.TODO) as TaskStatus].col} text-white flex items-center justify-center shadow-md`}><CheckSquare size={18} /></span>
            <div className="flex-1 min-w-0">
              <h3 className="text-lg font-bold text-slate-900 dark:text-white truncate">{editingTask ? (tr ? 'Görevi düzenle' : 'Edit task') : (tr ? 'Yeni görev' : 'New task')}{t.title ? <span className="text-slate-400 font-medium"> · {t.title}</span> : null}</h3>
              <p className="text-xs text-slate-400">{projects.find(p => p.id === t.projectId)?.name || (tr ? 'Proje seçilmedi' : 'No project')}</p>
            </div>
            <button onClick={requestClose} className="p-2 rounded-xl text-slate-400 hover:text-slate-700 hover:bg-slate-100 dark:hover:bg-white/5" aria-label="Close"><X size={20} /></button>
          </div>

          <div className="flex-1 overflow-y-auto custom-scrollbar p-5 sm:p-6 space-y-5">
            <Field label={tr ? 'Görev başlığı' : 'Title'} required error={err('title')}>
              <input autoFocus className={inputCls(err('title')) + ' h-12 text-base font-semibold'} value={t.title || ''} onChange={e => set({ title: e.target.value })} placeholder={tr ? 'Örn: Ana menü arayüzünü yenile' : 'e.g. Redesign main menu'} />
            </Field>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <Field label={tr ? 'Proje' : 'Project'} required error={err('project')}>
                <select className={inputCls(err('project'))} value={t.projectId || ''} onChange={e => set({ projectId: e.target.value, dependencyId: undefined })}>
                  <option value="">{tr ? 'Proje seçin' : 'Select project'}</option>
                  {projects.filter(p => p.status !== 'Completed' || p.id === editingTask?.projectId).map(p => <option key={p.id} value={p.id}>{p.name}</option>)}
                </select>
              </Field>
              <Field label={tr ? 'Son tarih' : 'Deadline'} required error={err('deadline')}
                hint={<div className="flex gap-1">{[[0, tr ? 'Bugün' : 'Today'], [1, tr ? 'Yarın' : 'Tomorrow'], [7, tr ? '+1 hafta' : '+1 week'], [14, tr ? '+2 hafta' : '+2 weeks']].map(([n, l]) => <button key={l as string} type="button" onClick={() => set({ deadline: addDays(n as number) })} className="h-6 px-2 rounded-md bg-slate-100 dark:bg-white/5 text-slate-600 dark:text-slate-300 font-semibold hover:bg-indigo-50 hover:text-indigo-600">{l}</button>)}</div>}>
                <input type="date" className={inputCls(err('deadline'))} value={(t.deadline || '').slice(0, 10)} onChange={e => set({ deadline: e.target.value })} />
              </Field>
            </div>

            <Field label={tr ? 'Durum' : 'Status'} required>
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-1 p-1 rounded-xl bg-slate-100 dark:bg-slate-800">
                {Object.values(TaskStatus).map(s => (
                  <button key={s} type="button" onClick={() => set({ status: s })} className={`h-9 rounded-lg text-xs font-semibold inline-flex items-center justify-center gap-1.5 transition-all ${t.status === s ? 'bg-white dark:bg-slate-900 shadow-sm text-slate-900 dark:text-white' : 'text-slate-500 hover:text-slate-700'}`}>
                    <span className={`w-1.5 h-1.5 rounded-full ${TASK_STATUS_META[s].dot}`} />{tr ? TASK_STATUS_META[s].tr : TASK_STATUS_META[s].en}
                  </button>
                ))}
              </div>
            </Field>
            {t.status === TaskStatus.BLOCKED && (
              <Field label={tr ? 'Engellenme nedeni' : 'Blocked reason'} required error={err('blocked')} className="animate-in fade-in slide-in-from-top-2 duration-200">
                <input className={inputCls(err('blocked'))} value={t.blockedReason || ''} onChange={e => set({ blockedReason: e.target.value })} placeholder={tr ? 'Örn: Müşteri onayı bekleniyor' : 'e.g. Waiting for client approval'} />
              </Field>
            )}

            <Field label={`${tr ? 'Atanan kişiler' : 'Assignees'} (${(t.assignedTo || []).length})`}>
              <div className="flex flex-wrap gap-2">
                {users.map(u => {
                  const on = (t.assignedTo || []).includes(u.id);
                  const load = tasks.filter(x => x.status !== TaskStatus.DONE && (x.assignedTo || []).includes(u.id)).length;
                  return (
                    <button key={u.id} type="button" onClick={() => set({ assignedTo: on ? (t.assignedTo || []).filter(x => x !== u.id) : [...(t.assignedTo || []), u.id] })}
                      className={`inline-flex items-center gap-2 pl-1 pr-3 h-9 rounded-full border text-xs font-semibold transition-all ${on ? 'bg-indigo-600 border-indigo-600 text-white shadow-md shadow-indigo-500/20' : 'border-slate-200 dark:border-slate-700 text-slate-600 dark:text-slate-300 hover:border-indigo-300'}`}>
                      {u.avatar ? <img src={u.avatar} alt="" className="w-7 h-7 rounded-full object-cover" /> : <span className={`w-7 h-7 rounded-full flex items-center justify-center text-[11px] font-bold ${on ? 'bg-white/20' : 'bg-indigo-50 text-indigo-600 dark:bg-indigo-500/10'}`}>{u.name?.[0]}</span>}
                      {u.name}
                      <span className={`text-[10px] px-1.5 rounded-full ${on ? 'bg-white/20' : load > 5 ? 'bg-rose-50 text-rose-600' : 'bg-slate-100 dark:bg-white/10 text-slate-500'}`} title={tr ? 'Açık görev sayısı' : 'Open tasks'}>{load}</span>
                      {on && <Check size={13} className="animate-in zoom-in-50 duration-200" />}
                    </button>
                  );
                })}
              </div>
            </Field>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <Field label={tr ? 'Projeye katkı (%)' : 'Project weight (%)'} error={err('progress')}
                hint={t.projectId ? <span>{tr ? 'Diğer görevlerin toplamı' : 'Others total'}: %{projectImpactUsed}{suggestedImpact ? <> · <button type="button" onClick={() => set({ progress: suggestedImpact })} className="font-semibold text-indigo-600 hover:underline">{tr ? `Önerilen %${suggestedImpact}` : `Use %${suggestedImpact}`}</button></> : null}{projectImpactUsed + (t.progress || 0) > 100 ? <span className="text-rose-500"> · {tr ? 'toplam %100\'ü aşıyor' : 'exceeds 100%'}</span> : null}</span> : undefined}>
                <div className="relative"><Percent size={15} className="absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-400" />
                  <input type="number" min={0} max={100} className={inputCls(err('progress')) + ' pl-9 font-bold'} value={t.progress ?? ''} onChange={e => set({ progress: Number(e.target.value) })} /></div>
              </Field>
              <Field label={tr ? 'Bağlı olduğu görev' : 'Depends on'} hint={tr ? 'Bu görev başlamadan önce bitmesi gereken görev' : 'Must finish first'}>
                <div className="relative"><Link2 size={15} className="absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-400 pointer-events-none" />
                  <select className={inputCls() + ' pl-9'} value={t.dependencyId || ''} onChange={e => set({ dependencyId: e.target.value || undefined })} disabled={!t.projectId}>
                    <option value="">—</option>
                    {projectTasks.map(x => <option key={x.id} value={x.id}>{x.status === TaskStatus.DONE ? '✓ ' : ''}{x.title}</option>)}
                  </select></div>
              </Field>
            </div>

            <div className="rounded-2xl border border-slate-200 dark:border-slate-700 overflow-hidden">
              <div className="flex items-center justify-between px-4 py-3 bg-slate-50 dark:bg-white/[0.03] border-b border-slate-200 dark:border-slate-700">
                <p className="text-sm font-semibold text-slate-800 dark:text-slate-100 flex items-center gap-2"><ListTodo size={15} className="text-indigo-500" /> {tr ? 'Yapılacaklar listesi' : 'Checklist'}</p>
                <span className="text-xs font-bold text-indigo-600">{done}/{list.length}</span>
              </div>
              {list.length > 0 && <div className="h-1 bg-slate-100 dark:bg-white/5"><div className="h-full bg-gradient-to-r from-emerald-400 to-teal-500 transition-all duration-500" style={{ width: `${(done / list.length) * 100}%` }} /></div>}
              <div className="divide-y divide-slate-100 dark:divide-slate-800 max-h-56 overflow-y-auto custom-scrollbar">
                {list.map(item => (
                  <div key={item.id} draggable onDragStart={() => setDragItem(item.id)} onDragOver={e => e.preventDefault()} onDrop={() => { if (dragItem) moveItem(dragItem, item.id); setDragItem(null); }}
                    className={`group flex items-center gap-2 px-3 py-2 ${dragItem === item.id ? 'opacity-40' : ''}`}>
                    <GripVertical size={14} className="text-slate-300 cursor-grab shrink-0" />
                    <button type="button" onClick={() => set({ checklist: list.map(i => i.id === item.id ? { ...i, isCompleted: !i.isCompleted } : i) })}
                      className={`w-[18px] h-[18px] shrink-0 rounded-md border-2 flex items-center justify-center transition-all ${item.isCompleted ? 'bg-emerald-500 border-emerald-500' : 'border-slate-300 dark:border-slate-600 hover:border-indigo-400'}`}>
                      {item.isCompleted && <Check size={12} strokeWidth={3} className="text-white" />}
                    </button>
                    <input className={`pc-plain-input flex-1 text-sm outline-none ${item.isCompleted ? 'line-through text-slate-400' : 'text-slate-700 dark:text-slate-200'}`} value={item.text} onChange={e => set({ checklist: list.map(i => i.id === item.id ? { ...i, text: e.target.value } : i) })} />
                    <button type="button" onClick={() => set({ checklist: list.filter(i => i.id !== item.id) })} className="p-1 rounded-md text-slate-300 hover:text-rose-500 opacity-100 lg:opacity-0 lg:group-hover:opacity-100"><Trash2 size={14} /></button>
                  </div>
                ))}
              </div>
              <div className="flex gap-2 p-2 border-t border-slate-100 dark:border-slate-800">
                <textarea rows={1} className="flex-1 min-h-[40px] px-3 py-2 rounded-lg bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-sm outline-none focus:border-indigo-500 resize-none" value={itemInput} onChange={e => setItemInput(e.target.value)}
                  onKeyDown={e => { if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); addItems(); } }} placeholder={tr ? 'Yeni madde (Enter ile ekle, çok satır yapıştırabilirsiniz)' : 'New item (Enter to add)'} />
                <button type="button" onClick={addItems} className="h-10 w-10 shrink-0 rounded-lg bg-indigo-600 text-white hover:bg-indigo-500 inline-flex items-center justify-center"><Plus size={18} /></button>
              </div>
            </div>

            <Field label={tr ? 'Yönetici notu' : 'Manager note'} hint={tr ? 'Personel görev kartında görür' : 'Visible to the assignee'}>
              <div className="relative"><StickyNote size={15} className="absolute left-3.5 top-3.5 text-slate-400" />
                <textarea rows={2} className={inputCls() + ' h-auto py-2.5 pl-9 resize-none'} value={t.managerNotes || ''} onChange={e => set({ managerNotes: e.target.value })} /></div>
            </Field>
          </div>

          <div className="flex items-center gap-2 px-5 sm:px-6 py-3 border-t border-slate-100 dark:border-slate-800" style={{ paddingBottom: 'max(env(safe-area-inset-bottom, 0px), 0.75rem)' }}>
            {editingTask && onDelete && (confirmDelete ? (
              <div className="flex items-center gap-1 animate-in fade-in slide-in-from-left-2 duration-200">
                <button onClick={() => setConfirmDelete(false)} className="h-10 px-3 rounded-xl text-xs font-semibold text-slate-500 hover:bg-slate-100 dark:hover:bg-white/5">{tr ? 'Vazgeç' : 'Cancel'}</button>
                <button onClick={async () => { await onDelete(editingTask.id); toast(tr ? 'Görev silindi' : 'Task deleted', 'info'); onClose(); }} className="h-10 px-3 rounded-xl text-xs font-semibold text-white bg-rose-600 hover:bg-rose-500">{tr ? 'Evet, sil' : 'Delete'}</button>
              </div>
            ) : (
              <button onClick={() => setConfirmDelete(true)} className="h-10 px-3 rounded-xl text-sm font-semibold text-rose-600 hover:bg-rose-50 dark:hover:bg-rose-500/10 inline-flex items-center gap-1.5"><Trash2 size={15} /> <span className="hidden sm:inline">{tr ? 'Sil' : 'Delete'}</span></button>
            ))}
            <div className="flex-1" />
            <button onClick={requestClose} className="h-10 px-4 rounded-xl text-sm font-semibold text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-white/5">{tr ? 'Vazgeç' : 'Cancel'}</button>
            <button onClick={save} disabled={saving} className="h-10 px-5 rounded-xl text-sm font-semibold text-white bg-indigo-600 hover:bg-indigo-500 disabled:opacity-60 shadow-lg shadow-indigo-500/25 inline-flex items-center gap-2">
              {saving ? <Loader2 size={16} className="animate-spin" /> : <Save size={16} />}{editingTask ? (tr ? 'Güncelle' : 'Update') : (tr ? 'Görevi oluştur' : 'Create task')}
            </button>
          </div>
        </div>
      </div>
    </ModalPortal>
  );
};

export default TaskModal;
