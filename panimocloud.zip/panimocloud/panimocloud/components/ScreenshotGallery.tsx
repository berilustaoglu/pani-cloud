
import React, { useEffect, useState } from 'react';
import { ScreenshotLog } from '../types';
import { collection, query, where, orderBy, onSnapshot, limit } from 'firebase/firestore';
import { db } from '../firebase';
import { Calendar, Clock, Image as ImageIcon, X, ChevronRight, ChevronLeft, Maximize2, AlertTriangle } from 'lucide-react';

interface Props {
    userId: string;
    userName: string;
    language: 'tr' | 'en';
    onClose: () => void;
}

const ScreenshotGallery: React.FC<Props> = ({ userId, userName, language, onClose }) => {
    const [logs, setLogs] = useState<ScreenshotLog[]>([]);
    const [selectedImage, setSelectedImage] = useState<string | null>(null);
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState<string | null>(null);

    useEffect(() => {
        let timeoutId: NodeJS.Timeout;

        const q = query(
            collection(db, "screenshot_logs"),
            where("userId", "==", userId),
            orderBy("timestamp", "desc"),
            limit(50)
        );

        const unsubscribe = onSnapshot(q, (snapshot) => {
            setLogs(snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as ScreenshotLog)));
            setLoading(false);
            setError(null);
            if (timeoutId) clearTimeout(timeoutId);
        }, (err) => {
            console.error("Screenshot query error:", err);
            setError(err.message);
            setLoading(false);
        });

        // Set a timeout to help diagnose missing indexes or slow connections
        timeoutId = setTimeout(() => {
            if (loading && logs.length === 0) {
                setError("TIMEOUT_OR_INDEX_MISSING");
            }
        }, 8000);

        return () => {
            unsubscribe();
            if (timeoutId) clearTimeout(timeoutId);
        };
    }, [userId]);

    // Group by date
    const groupedLogs = logs.reduce((acc, log) => {
        const date = log.timestamp.split('T')[0];
        if (!acc[date]) acc[date] = [];
        acc[date].push(log);
        return acc;
    }, {} as Record<string, ScreenshotLog[]>);

    const t = {
        tr: {
            title: 'Ekran Geçmişi',
            noLogs: 'Henüz ekran görüntüsü bulunamadı.',
            today: 'Bugün',
            subtitle: 'Personelin çalışma periyodundaki rastgele kayıtlar.'
        },
        en: {
            title: 'Screen History',
            noLogs: 'No screenshots found yet.',
            today: 'Today',
            subtitle: 'Random captures during staff working period.'
        }
    }[language];

    return (
        <div className="fixed inset-0 z-[10000] bg-slate-950/40 backdrop-blur-2xl flex justify-end">
            <div className="w-full max-w-2xl bg-white h-full shadow-2xl animate-in slide-in-from-right duration-500 flex flex-col">
                {/* Header */}
                <div className="p-8 border-b flex justify-between items-center bg-slate-50">
                    <div>
                        <h2 className="text-2xl font-black text-slate-900 tracking-tight flex items-center gap-3">
                            <ImageIcon className="text-indigo-600" />
                            {userName} - {t.title}
                        </h2>
                        <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest mt-1">
                            {t.subtitle}
                        </p>
                    </div>
                    <button
                        onClick={onClose}
                        className="p-3 hover:bg-slate-100 rounded-2xl text-slate-400 transition-all"
                    >
                        <X size={24} />
                    </button>
                </div>

                {/* Gallery Content */}
                <div className="flex-1 overflow-y-auto p-8 custom-scrollbar">
                    {loading && logs.length === 0 && !error ? (
                        <div className="flex flex-col items-center justify-center h-64 gap-4 opacity-50">
                            <div className="w-12 h-12 border-4 border-slate-200 border-t-indigo-600 rounded-full animate-spin"></div>
                            <p className="text-[10px] font-black uppercase tracking-widest">Yükleniyor...</p>
                        </div>
                    ) : error ? (
                        <div className="flex flex-col items-center justify-center p-8 bg-red-50 rounded-[32px] border border-red-100 text-center">
                            <AlertTriangle size={48} className="text-red-500 mb-4" />
                            {error === "TIMEOUT_OR_INDEX_MISSING" ? (
                                <>
                                    <h3 className="font-black text-red-900 uppercase tracking-tight mb-2">Yükleme Çok Uzun Sürdü</h3>
                                    <p className="text-xs text-red-700 font-medium leading-relaxed max-w-sm">
                                        Veriler çekilemiyor. Bu durum genellikle eksik bir <b>Firestore Index</b>'inden kaynaklanır.
                                        Lütfen tarayıcı konsolunu (F12) kontrol edin ve orada görünen "Index oluşturma" bağlantısına tıklayın.
                                    </p>
                                </>
                            ) : (
                                <>
                                    <h3 className="font-black text-red-900 uppercase tracking-tight mb-2">Hata Oluştu</h3>
                                    <p className="text-xs text-red-700 font-medium">{error}</p>
                                </>
                            )}
                        </div>
                    ) : logs.length === 0 ? (
                        <div className="flex flex-col items-center justify-center h-64 opacity-20">
                            <ImageIcon size={64} className="mb-4" />
                            <p className="text-[10px] font-black uppercase tracking-widest">{t.noLogs}</p>
                        </div>
                    ) : (
                        Object.entries(groupedLogs).map(([date, dateLogs]) => (
                            <div key={date} className="mb-12">
                                <div className="flex items-center gap-4 mb-6">
                                    <div className="p-2 bg-indigo-50 text-indigo-600 rounded-lg">
                                        <Calendar size={16} />
                                    </div>
                                    <h3 className="font-black text-slate-900 uppercase tracking-wider text-sm">
                                        {date === new Date().toISOString().split('T')[0] ? t.today : date}
                                    </h3>
                                    <div className="flex-1 h-px bg-slate-100"></div>
                                </div>

                                <div className="grid grid-cols-2 gap-4">
                                    {(dateLogs as ScreenshotLog[]).map((log) => (
                                        <div
                                            key={log.id}
                                            className="group relative aspect-video bg-slate-100 rounded-2xl overflow-hidden cursor-pointer hover:ring-4 ring-indigo-500/20 transition-all shadow-sm"
                                            onClick={() => setSelectedImage(log.imageUrl)}
                                        >
                                            <img
                                                src={log.imageUrl}
                                                alt="Screenshot"
                                                className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-110"
                                            />
                                            <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity flex flex-col justify-end p-4">
                                                <div className="flex items-center gap-2 text-white">
                                                    <Clock size={12} />
                                                    <span className="text-[10px] font-black">
                                                        {new Date(log.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                                                    </span>
                                                </div>
                                            </div>
                                            <div className="absolute top-4 right-4 p-2 bg-white/20 backdrop-blur-md rounded-lg text-white opacity-0 group-hover:opacity-100 transition-opacity">
                                                <Maximize2 size={16} />
                                            </div>
                                        </div>
                                    ))}
                                </div>
                            </div>
                        ))
                    )}
                </div>
            </div>

            {/* Fullscreen Overlay */}
            {selectedImage && (
                <div
                    className="fixed inset-0 z-[7000] bg-slate-950/98 backdrop-blur-xl flex items-center justify-center p-12 transition-all p-20"
                    onClick={() => setSelectedImage(null)}
                >
                    <button className="absolute top-10 right-10 text-white/50 hover:text-white">
                        <X size={48} />
                    </button>
                    <img
                        src={selectedImage}
                        alt="Full Preview"
                        className="max-w-full max-h-full rounded-2xl shadow-2xl animate-in zoom-in-95 duration-300"
                    />
                </div>
            )}
        </div>
    );
};

export default ScreenshotGallery;
