import React from 'react';
import { Task, User, TaskStatus } from '../types';

interface Props {
  tasks: Task[];
  users: User[];
  language: 'tr' | 'en';
}

const WorkloadHeatmap: React.FC<Props> = ({ tasks, users, language }) => {
  const getWorkload = (userId: string) => {
    const userTasks = tasks.filter(t => t.assignedTo.includes(userId) && t.status !== TaskStatus.DONE);
    return userTasks.length;
  };

  const getMaxWorkload = () => {
    if (users.length === 0) return 1;
    return Math.max(...users.map(u => getWorkload(u.id)), 1);
  };

  const maxWorkload = getMaxWorkload();

  const getHeatColor = (count: number) => {
    const ratio = count / maxWorkload;
    if (count === 0) return 'bg-slate-100 dark:bg-slate-800 text-slate-400';
    if (ratio < 0.3) return 'bg-emerald-100 dark:bg-emerald-900/30 text-emerald-600 border-emerald-200';
    if (ratio < 0.7) return 'bg-amber-100 dark:bg-amber-900/30 text-amber-600 border-amber-200';
    return 'bg-red-100 dark:bg-red-900/30 text-red-600 border-red-200';
  };

  return (
    <div className="bg-white dark:bg-slate-900 p-6 rounded-[40px] border border-slate-100 dark:border-slate-800 shadow-sm">
      <div className="flex items-center justify-between mb-8">
        <h3 className="text-xl font-black text-slate-900 dark:text-white flex items-center gap-3">
          <div className="w-1.5 h-8 bg-indigo-600 rounded-full" />
          {language === 'tr' ? 'Personel İş Yükü Yoğunluğu' : 'Staff Workload Heatmap'}
        </h3>
      </div>

      <div className="max-h-[360px] overflow-y-auto pr-2 custom-scrollbar">
        <div className="grid grid-cols-2 gap-4 pb-2">
          {users.map(user => {
            const count = getWorkload(user.id);
            const colorClass = getHeatColor(count);
            
            return (
              <div key={user.id} className={`p-5 rounded-3xl border transition-all flex flex-col items-center gap-3 shadow-sm ${colorClass}`}>
                <div className="relative">
                  <img src={user.avatar} className="w-14 h-14 rounded-2xl object-cover border-2 border-white dark:border-slate-700 shadow-md" alt={user.name} />
                  <div className={`absolute -bottom-1 -right-1 w-4 h-4 rounded-full border-2 border-white dark:border-slate-900 ${count > 2 ? 'bg-red-500' : 'bg-emerald-500'}`}></div>
                </div>
                <div className="text-center overflow-hidden w-full">
                  <p className="text-[9px] font-black uppercase truncate px-1 text-slate-500 dark:text-slate-400">{user.name}</p>
                  <p className="text-lg font-black tracking-tight">{count} <span className="text-[10px] opacity-50">{language === 'tr' ? 'Görev' : 'Tasks'}</span></p>
                </div>
              </div>
            );
          })}
        </div>
      </div>
      
      <div className="mt-8 flex items-center justify-center gap-6 text-[10px] font-black uppercase tracking-widest text-slate-400">
        <div className="flex items-center gap-2"><div className="w-3 h-3 bg-slate-100 dark:bg-slate-800 rounded"></div> {language === 'tr' ? 'BOŞ' : 'IDLE'}</div>
        <div className="flex items-center gap-2"><div className="w-3 h-3 bg-emerald-100 rounded"></div> {language === 'tr' ? 'NORMAL' : 'NORMAL'}</div>
        <div className="flex items-center gap-2"><div className="w-3 h-3 bg-amber-100 rounded"></div> {language === 'tr' ? 'YOĞUN' : 'BUSY'}</div>
        <div className="flex items-center gap-2"><div className="w-3 h-3 bg-red-100 rounded"></div> {language === 'tr' ? 'KRİTİK' : 'CRITICAL'}</div>
      </div>
    </div>
  );
};

export default WorkloadHeatmap;
