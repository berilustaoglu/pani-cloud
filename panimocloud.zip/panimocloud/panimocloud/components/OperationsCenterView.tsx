import React, { useEffect, useMemo, useState } from 'react';
import {
  Activity, AlertOctagon, AlertTriangle, ArrowRight, Briefcase, CalendarClock, CheckCircle2, Clock, Download,
  Gauge, LifeBuoy, Package, Search, Sparkles, TrendingUp, Users, Wallet, Handshake, ListChecks, EyeOff,
  AlarmClock, RotateCcw, Coffee, ShoppingCart, Video, Plane, Receipt
} from 'lucide-react';
import { collection, onSnapshot, orderBy, query, limit } from 'firebase/firestore';
import { db } from '../firebase';
import { AuditLog, User } from '../types';
import {
  Insight, InsightCategory, InsightInput, Severity, buildInsights, buildKpis, buildTimeline, buildWorkload,
  computeHealth, formatTRY, localISO, dayDiff
} from '../services/insights';
import { AnimatedNumber, ProgressRing, GrowBar } from './ui/Motion';
import { toast } from '../services/toast';

interface Props extends InsightInput {
  currentUser: User;
  onNavigate: (tab: string) => void;
}

const CATEGORY_META: Record<InsightCategory, { tr: string; en: string; icon: React.ElementType; color: string }> = {
  projects: { tr: 'Projeler', en: 'Projects', icon: Briefcase, color: 'from-indigo-500 to-violet-500' },
  tasks: { tr: 'Görevler', en: 'Tasks', icon: ListChecks, color: 'from-sky-500 to-indigo-500' },
  finance: { tr: 'Finans', en: 'Finance', icon: Wallet, color: 'from-emerald-500 to-teal-500' },
  sales: { tr: 'Satış', en: 'Sales', icon: Receipt, color: 'from-orange-500 to-amber-500' },
  crm: { tr: 'CRM', en: 'CRM', icon: Handshake, color: 'from-pink-500 to-rose-500' },
  hr: { tr: 'İK', en: 'HR', icon: Users, color: 'from-cyan-500 to-sky-500' },
  inventory: { tr: 'Depo', en: 'Inventory', icon: Package, color: 'from-amber-500 to-yellow-500' },
  support: { tr: 'Destek', en: 'Support', icon: LifeBuoy, color: 'from-fuchsia-500 to-purple-500' },
};

const SEVERITY_META: Record<Severity, { tr: string; en: string; dot: string; chip: string; stripe: string }> = {
  critical: { tr: 'Kritik', en: 'Critical', dot: 'bg-rose-500', chip: 'bg-rose-500/10 text-rose-600 dark:text-rose-400 border-rose-500/20', stripe: 'bg-rose-500' },
  high: { tr: 'Yüksek', en: 'High', dot: 'bg-orange-500', chip: 'bg-orange-500/10 text-orange-600 dark:text-orange-400 border-orange-500/20', stripe: 'bg-orange-500' },
  medium: { tr: 'Orta', en: 'Medium', dot: 'bg-amber-400', chip: 'bg-amber-400/10 text-amber-600 dark:text-amber-300 border-amber-400/20', stripe: 'bg-amber-400' },
  low: { tr: 'Düşük', en: 'Low', dot: 'bg-slate-400', chip: 'bg-slate-400/10 text-slate-500 dark:text-slate-400 border-slate-400/20', stripe: 'bg-slate-400' },
};

const TIMELINE_ICON: Record<string, React.ElementType> = {
  delivery: Briefcase, installment: Wallet, meeting: Video, billing: Receipt, leave: Plane, task: ListChecks, purchase: ShoppingCart, deal: Handshake,
};

type SnoozeMap = Record<string, string>; // insightId -> until (YYYY-MM-DD) | 'forever'

const OperationsCenterView: React.FC<Props> = (props) => {
  const { language, currentUser, onNavigate, canSeeFinance } = props;
  const tr = language === 'tr';
  const storageKey = `panimo-ops-snooze-${currentUser.id}`;

  const [catFilter, setCatFilter] = useState<InsightCategory | 'all'>('all');
  const [sevFilter, setSevFilter] = useState<Severity | 'all'>('all');
  const [search, setSearch] = useState('');
  const [showSnoozed, setShowSnoozed] = useState(false);
  const [visibleCount, setVisibleCount] = useState(12);
  const [now, setNow] = useState(new Date());
  const [isSmall, setIsSmall] = useState(() => typeof window !== 'undefined' && window.matchMedia('(max-width: 640px)').matches);
  useEffect(() => {
    const mq = window.matchMedia('(max-width: 640px)');
    const onChange = (e: MediaQueryListEvent) => setIsSmall(e.matches);
    mq.addEventListener?.('change', onChange);
    return () => mq.removeEventListener?.('change', onChange);
  }, []);
  const [auditLogs, setAuditLogs] = useState<AuditLog[]>([]);
  const [snoozed, setSnoozed] = useState<SnoozeMap>(() => {
    try { return JSON.parse(localStorage.getItem(storageKey) || '{}'); } catch { return {}; }
  });

  useEffect(() => {
    const t = setInterval(() => setNow(new Date()), 30000);
    return () => clearInterval(t);
  }, []);

  useEffect(() => {
    try { localStorage.setItem(storageKey, JSON.stringify(snoozed)); } catch {}
  }, [snoozed, storageKey]);

  useEffect(() => {
    if (currentUser.role !== 'Admin') return;
    const q = query(collection(db, 'audit_logs'), orderBy('timestamp', 'desc'), limit(12));
    return onSnapshot(q, snap => setAuditLogs(snap.docs.map(d => ({ id: d.id, ...d.data() } as AuditLog))), () => setAuditLogs([]));
  }, [currentUser.role]);

  const insights = useMemo(() => buildInsights(props), [props]);
  const isSnoozedNow = (id: string) => {
    const until = snoozed[id];
    if (!until) return false;
    return until === 'forever' || until >= localISO();
  };
  const activeInsights = useMemo(() => insights.filter(i => !isSnoozedNow(i.id)), [insights, snoozed]);
  const health = useMemo(() => computeHealth(activeInsights), [activeInsights]);
  const kpis = useMemo(() => buildKpis(props, insights), [props, insights]);
  const timeline = useMemo(() => buildTimeline(props, 14), [props]);
  const workload = useMemo(() => buildWorkload(props), [props]);

  const counts = useMemo(() => {
    const c: Record<Severity, number> = { critical: 0, high: 0, medium: 0, low: 0 };
    activeInsights.forEach(i => c[i.severity]++);
    return c;
  }, [activeInsights]);

  const filtered = useMemo(() => {
    const s = search.trim().toLocaleLowerCase('tr-TR');
    return (showSnoozed ? insights.filter(i => isSnoozedNow(i.id)) : activeInsights).filter(i =>
      (catFilter === 'all' || i.category === catFilter) &&
      (sevFilter === 'all' || i.severity === sevFilter) &&
      (!s || `${i.title} ${i.detail}`.toLocaleLowerCase('tr-TR').includes(s))
    );
  }, [insights, activeInsights, catFilter, sevFilter, search, showSnoozed, snoozed]);

  const snooze = (id: string, days: number | 'forever') => {
    const until = days === 'forever' ? 'forever' : localISO(new Date(Date.now() + days * 86400000));
    setSnoozed(prev => ({ ...prev, [id]: until }));
    toast(days === 'forever' ? (tr ? 'Uyarı gizlendi' : 'Alert hidden') : (tr ? `Uyarı ${days} gün ertelendi` : `Alert snoozed for ${days} day(s)`), 'info', 2500);
  };
  const unsnooze = (id: string) => setSnoozed(prev => { const n = { ...prev }; delete n[id]; return n; });

  const exportCsv = () => {
    const rows = [['Önem', 'Kategori', 'Başlık', 'Detay', 'Tarih', 'Tutar (TRY)'],
      ...filtered.map(i => [SEVERITY_META[i.severity].tr, CATEGORY_META[i.category].tr, i.title, i.detail, i.date || '', i.amountTRY ? Math.round(i.amountTRY).toString() : ''])];
    const csv = rows.map(r => r.map(c => `"${String(c).replace(/"/g, '""')}"`).join(';')).join('\n');
    const blob = new Blob(['﻿' + csv], { type: 'text/csv;charset=utf-8' });
    const a = document.createElement('a');
    a.href = URL.createObjectURL(blob);
    a.download = `aksiyon-listesi-${localISO()}.csv`;
    a.click();
    URL.revokeObjectURL(a.href);
    toast.success(tr ? 'Aksiyon listesi dışa aktarıldı' : 'Action list exported');
  };

  const hour = now.getHours();
  const greeting = tr
    ? hour < 6 ? 'İyi geceler' : hour < 12 ? 'Günaydın' : hour < 18 ? 'İyi günler' : 'İyi akşamlar'
    : hour < 12 ? 'Good morning' : hour < 18 ? 'Good afternoon' : 'Good evening';
  const healthLabel = health.overall >= 85 ? (tr ? 'Mükemmel' : 'Excellent') : health.overall >= 65 ? (tr ? 'İyi' : 'Good') : health.overall >= 40 ? (tr ? 'Dikkat' : 'Attention') : (tr ? 'Kritik' : 'Critical');

  const timelineDays = useMemo(() => {
    const days: { date: string; events: typeof timeline }[] = [];
    for (let i = 0; i < 14; i++) {
      const d = localISO(new Date(Date.now() + i * 86400000));
      days.push({ date: d, events: timeline.filter(e => e.date === d) });
    }
    return days;
  }, [timeline]);
  const [selectedDay, setSelectedDay] = useState(localISO());
  const selectedEvents = timelineDays.find(d => d.date === selectedDay)?.events || [];

  const kpiCards = [
    { key: 'projects', icon: Briefcase, label: tr ? 'Aktif Proje' : 'Active Projects', value: kpis.activeProjects, sub: `${tr ? 'Ort. ilerleme' : 'Avg. progress'} %${kpis.avgProjectProgress}`, bar: kpis.avgProjectProgress, tab: 'projects', grad: 'from-indigo-500 to-violet-600' },
    { key: 'tasks', icon: ListChecks, label: tr ? 'Açık Görev' : 'Open Tasks', value: kpis.openTasks, sub: `${kpis.overdueTasks} ${tr ? 'gecikmiş' : 'overdue'} · ${kpis.blockedTasks} ${tr ? 'engelli' : 'blocked'}`, bar: kpis.completionRate, tab: 'tasks', grad: 'from-sky-500 to-blue-600' },
    ...(canSeeFinance ? [
      { key: 'recv', icon: Wallet, label: tr ? 'Bekleyen Tahsilat' : 'Receivables', value: kpis.receivables, money: true, sub: `${formatTRY(kpis.overdueReceivables)} ${tr ? 'vadesi geçmiş' : 'overdue'}`, bar: kpis.receivables ? 100 - (kpis.overdueReceivables / kpis.receivables) * 100 : 100, tab: 'projects', grad: 'from-emerald-500 to-teal-600' },
      { key: 'net', icon: TrendingUp, label: tr ? 'Bu Ay Net' : 'Net This Month', value: kpis.monthNet, money: true, sub: `${tr ? 'Gelir' : 'In'} ${formatTRY(kpis.monthIncome)} · ${tr ? 'Gider' : 'Out'} ${formatTRY(kpis.monthExpense)}`, bar: kpis.monthIncome ? Math.min(100, (kpis.monthNet / kpis.monthIncome) * 100) : 0, tab: 'accounting', grad: 'from-orange-500 to-rose-500' },
      { key: 'pipe', icon: Handshake, label: tr ? 'Ağırlıklı Satış Hattı' : 'Weighted Pipeline', value: kpis.weightedPipeline, money: true, sub: `${kpis.openDeals} ${tr ? 'açık fırsat' : 'open deals'} · ${tr ? 'kazanma' : 'win'} %${kpis.winRate}`, bar: kpis.winRate, tab: 'crm', grad: 'from-pink-500 to-fuchsia-600' },
    ] : [
      { key: 'pipe', icon: Handshake, label: tr ? 'Açık Fırsat' : 'Open Deals', value: kpis.openDeals, sub: `${tr ? 'Kazanma oranı' : 'Win rate'} %${kpis.winRate}`, bar: kpis.winRate, tab: 'crm', grad: 'from-pink-500 to-fuchsia-600' },
    ]),
    { key: 'team', icon: Users, label: tr ? 'Bugün Ekip' : 'Team Today', value: kpis.presentToday, suffix: ` / ${kpis.staffCount}`, sub: `${kpis.onLeaveToday} ${tr ? 'izinde' : 'on leave'} · ${kpis.pendingLeaves} ${tr ? 'onay bekliyor' : 'pending'}`, bar: kpis.staffCount ? (kpis.presentToday / kpis.staffCount) * 100 : 0, tab: 'attendance', grad: 'from-cyan-500 to-sky-600' },
    { key: 'stock', icon: Package, label: tr ? 'Kritik Stok' : 'Low Stock', value: kpis.lowStock, sub: canSeeFinance ? `${tr ? 'Stok değeri' : 'Stock value'} ${formatTRY(kpis.stockValue)} · ${kpis.openPOs} ${tr ? 'sipariş' : 'POs'}` : `${kpis.openPOs} ${tr ? 'açık sipariş' : 'open POs'}`, bar: props.inventoryItems.length ? 100 - (kpis.lowStock / props.inventoryItems.length) * 100 : 100, tab: 'inventory', grad: 'from-amber-500 to-orange-600' },
    { key: 'support', icon: LifeBuoy, label: tr ? 'Açık Talep' : 'Open Tickets', value: kpis.openTickets, sub: `${kpis.criticalTickets} ${tr ? 'yüksek öncelik' : 'high priority'}`, bar: props.tickets.length ? 100 - (kpis.openTickets / props.tickets.length) * 100 : 100, tab: 'tickets', grad: 'from-fuchsia-500 to-purple-600' },
  ];

  const fmtDay = (iso: string, opts: Intl.DateTimeFormatOptions) => {
    const [y, m, d] = iso.split('-').map(Number);
    return new Date(y, m - 1, d).toLocaleDateString(tr ? 'tr-TR' : 'en-US', opts);
  };

  return (
    <div className="space-y-6 pb-8">
      {/* ================= HERO ================= */}
      <section className="relative overflow-hidden rounded-[28px] sm:rounded-[32px] bg-[#0b1024] text-white p-5 sm:p-6 lg:p-8 shadow-2xl shadow-indigo-950/30">
        <div className="pointer-events-none absolute -top-24 -left-16 w-80 h-80 rounded-full bg-indigo-600/40 blur-3xl pc-blob" />
        <div className="pointer-events-none absolute -bottom-32 right-10 w-96 h-96 rounded-full bg-orange-500/25 blur-3xl pc-blob" style={{ animationDelay: '-6s' }} />
        <div className="pointer-events-none absolute top-10 right-1/3 w-56 h-56 rounded-full bg-fuchsia-500/20 blur-3xl pc-blob" style={{ animationDelay: '-11s' }} />
        <div className="pointer-events-none absolute inset-0 opacity-[0.07]" style={{ backgroundImage: 'radial-gradient(circle at 1px 1px, white 1px, transparent 0)', backgroundSize: '22px 22px' }} />

        <div className="relative flex flex-col lg:flex-row lg:items-center gap-8">
          <div className="flex-1 min-w-0">
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-white/10 border border-white/10 text-[10px] font-black uppercase tracking-[0.25em] text-indigo-200 mb-4">
              <span className="w-2 h-2 rounded-full bg-emerald-400 pc-dot-pulse" /> {tr ? 'Canlı Yönetim Merkezi' : 'Live Operations Center'}
            </div>
            <h1 className="text-2xl sm:text-3xl lg:text-4xl font-black tracking-tight">
              {greeting}, <span className="bg-gradient-to-r from-indigo-300 via-fuchsia-300 to-orange-300 bg-clip-text text-transparent">{currentUser.name.split(' ')[0]}</span>
            </h1>
            <p className="mt-2 text-slate-300 text-sm font-medium">
              {now.toLocaleDateString(tr ? 'tr-TR' : 'en-US', { weekday: 'long', day: 'numeric', month: 'long', year: 'numeric' })}
              {' · '}{now.toLocaleTimeString(tr ? 'tr-TR' : 'en-US', { hour: '2-digit', minute: '2-digit' })}
            </p>
            <p className="mt-4 text-slate-300/90 text-sm max-w-xl leading-relaxed">
              {activeInsights.length === 0
                ? (tr ? 'Her şey yolunda görünüyor. Aksiyon gerektiren bir durum yok. ✨' : 'Everything looks great. Nothing needs your attention. ✨')
                : tr
                  ? <>Bugün ilgilenmen gereken <b className="text-white">{activeInsights.length}</b> konu var; bunlardan <b className="text-rose-300">{counts.critical}</b> tanesi kritik.</>
                  : <>There are <b className="text-white">{activeInsights.length}</b> items needing attention, <b className="text-rose-300">{counts.critical}</b> of them critical.</>}
            </p>

            <div className="mt-6 grid grid-cols-2 sm:grid-cols-4 gap-3 pc-stagger">
              {(Object.keys(SEVERITY_META) as Severity[]).map(sev => (
                <button
                  key={sev}
                  onClick={() => { setSevFilter(sevFilter === sev ? 'all' : sev); setShowSnoozed(false); { const el = document.getElementById('pc-actions'); const main = el?.closest('main'); if (el && main) main.scrollTo({ top: el.getBoundingClientRect().top - main.getBoundingClientRect().top + main.scrollTop - 12, behavior: 'smooth' }); } }}
                  className={`text-left rounded-2xl px-4 py-3 border backdrop-blur-sm transition-all hover:bg-white/15 ${sevFilter === sev ? 'bg-white/20 border-white/30' : 'bg-white/5 border-white/10'}`}
                >
                  <div className="flex items-center gap-2 text-[10px] font-black uppercase tracking-widest text-slate-300">
                    <span className={`w-2 h-2 rounded-full ${SEVERITY_META[sev].dot} ${sev === 'critical' && counts.critical > 0 ? 'pc-dot-pulse' : ''}`} />
                    {tr ? SEVERITY_META[sev].tr : SEVERITY_META[sev].en}
                  </div>
                  <div className="text-2xl font-black mt-1"><AnimatedNumber value={counts[sev]} /></div>
                </button>
              ))}
            </div>
          </div>

          <div className="flex flex-col items-center gap-3 shrink-0">
            <ProgressRing value={health.overall} size={isSmall ? 150 : 190} stroke={isSmall ? 12 : 14} track="rgba(255,255,255,.08)">
              <Gauge size={18} className="text-indigo-300 mb-1" />
              <div className="text-4xl sm:text-5xl font-black leading-none"><AnimatedNumber value={health.overall} /></div>
              <div className="text-[8px] sm:text-[10px] font-black uppercase tracking-[0.2em] sm:tracking-[0.25em] text-slate-400 mt-1">{tr ? 'Sağlık Skoru' : 'Health Score'}</div>
            </ProgressRing>
            <span className="px-3 py-1 rounded-full text-[10px] font-black uppercase tracking-widest bg-white/10 border border-white/10">{healthLabel}</span>
          </div>
        </div>
      </section>

      {/* ================= KPI GRID ================= */}
      <section className="grid grid-cols-2 xl:grid-cols-4 gap-3 sm:gap-4 pc-stagger">
        {kpiCards.map((k: any) => {
          const Icon = k.icon;
          return (
            <button
              key={k.key}
              onClick={() => onNavigate(k.tab)}
              className="group pc-lift pc-sheen text-left bg-white dark:bg-slate-900 border border-slate-100 dark:border-slate-800 rounded-[24px] sm:rounded-[28px] p-4 sm:p-5 shadow-sm min-w-0"
            >
              <div className="flex items-start justify-between">
                <div className={`p-2.5 sm:p-3 rounded-xl sm:rounded-2xl bg-gradient-to-br ${k.grad} text-white shadow-lg transition-transform duration-500 group-hover:rotate-[-8deg] group-hover:scale-110`}>
                  <Icon size={20} />
                </div>
                <ArrowRight size={16} className="text-slate-300 dark:text-slate-600 transition-all duration-300 group-hover:translate-x-1 group-hover:text-indigo-500" />
              </div>
              <p className="mt-3 sm:mt-4 text-[9px] sm:text-[10px] font-black uppercase tracking-[0.15em] sm:tracking-[0.2em] text-slate-400 truncate">{k.label}</p>
              <p className="text-xl sm:text-3xl font-black truncate text-slate-900 dark:text-white mt-1">
                <AnimatedNumber value={k.value} format={k.money ? formatTRY : undefined} />
                {k.suffix && <span className="text-sm sm:text-lg text-slate-400 font-bold">{k.suffix}</span>}
              </p>
              <p className="text-[10px] sm:text-xs font-semibold text-slate-500 dark:text-slate-400 mt-1 truncate">{k.sub}</p>
              <div className="mt-3 sm:mt-4"><GrowBar value={k.bar} className={`bg-gradient-to-r ${k.grad}`} /></div>
            </button>
          );
        })}
      </section>

      {/* ================= KATEGORİ SAĞLIĞI ================= */}
      <section className="bg-white dark:bg-slate-900 border border-slate-100 dark:border-slate-800 rounded-[28px] sm:rounded-[32px] p-4 sm:p-6">
        <div className="flex items-center justify-between mb-5">
          <h3 className="font-black text-slate-900 dark:text-white flex items-center gap-2"><Activity size={18} className="text-indigo-500" /> {tr ? 'Modül Sağlığı' : 'Module Health'}</h3>
          <span className="text-[10px] font-black uppercase tracking-widest text-slate-400">{tr ? 'Filtrelemek için tıkla' : 'Click to filter'}</span>
        </div>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-3 pc-stagger">
          {(Object.keys(CATEGORY_META) as InsightCategory[]).filter(c => canSeeFinance || (c !== 'finance' && c !== 'sales')).map(cat => {
            const meta = CATEGORY_META[cat];
            const Icon = meta.icon;
            const score = health.byCat[cat];
            const n = activeInsights.filter(i => i.category === cat).length;
            return (
              <button
                key={cat}
                onClick={() => { setCatFilter(catFilter === cat ? 'all' : cat); setShowSnoozed(false); }}
                className={`text-left p-4 rounded-2xl border transition-all hover:-translate-y-0.5 ${catFilter === cat ? 'border-indigo-400 bg-indigo-50 dark:bg-indigo-500/10' : 'border-slate-100 dark:border-slate-800 hover:border-slate-200 dark:hover:border-slate-700'}`}
              >
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <div className={`p-1.5 rounded-lg bg-gradient-to-br ${meta.color} text-white`}><Icon size={14} /></div>
                    <span className="text-xs font-black text-slate-700 dark:text-slate-200">{tr ? meta.tr : meta.en}</span>
                  </div>
                  <span className={`text-xs font-black ${score >= 80 ? 'text-emerald-500' : score >= 50 ? 'text-amber-500' : 'text-rose-500'}`}>{score}</span>
                </div>
                <div className="mt-3"><GrowBar value={score} className={score >= 80 ? 'bg-emerald-500' : score >= 50 ? 'bg-amber-400' : 'bg-rose-500'} /></div>
                <p className="text-[10px] font-bold text-slate-400 mt-2">{n} {tr ? 'aksiyon' : 'actions'}</p>
              </button>
            );
          })}
        </div>
      </section>

      {/* ================= AKSİYON MERKEZİ + TAKVİM ================= */}
      <section className="grid grid-cols-1 xl:grid-cols-5 gap-6">
        <div id="pc-actions" className="xl:col-span-3 bg-white dark:bg-slate-900 border border-slate-100 dark:border-slate-800 rounded-[28px] sm:rounded-[32px] p-4 sm:p-6 scroll-mt-6">
          <div className="flex flex-col md:flex-row md:items-center justify-between gap-3 mb-4">
            <h3 className="font-black text-slate-900 dark:text-white flex items-center gap-2">
              <AlertOctagon size={18} className="text-rose-500" /> {tr ? 'Aksiyon Merkezi' : 'Action Center'}
              <span className="ml-1 text-[10px] px-2 py-0.5 rounded-full bg-slate-100 dark:bg-white/5 text-slate-500">{filtered.length}</span>
            </h3>
            <div className="flex items-center gap-2">
              <div className="relative flex-1 md:w-56">
                <Search size={14} className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
                <input value={search} onChange={e => setSearch(e.target.value)} placeholder={tr ? 'Ara...' : 'Search...'} className="w-full pl-9 pr-3 py-2 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-100 dark:border-slate-700 text-sm outline-none focus:ring-2 focus:ring-indigo-500/30" />
              </div>
              <button onClick={() => setShowSnoozed(!showSnoozed)} title={tr ? 'Ertelenenler' : 'Snoozed'} className={`p-2 rounded-xl border ${showSnoozed ? 'bg-indigo-600 text-white border-indigo-600' : 'border-slate-100 dark:border-slate-700 text-slate-500 hover:text-indigo-600'}`}><EyeOff size={16} /></button>
              <button onClick={exportCsv} title="CSV" className="p-2 rounded-xl border border-slate-100 dark:border-slate-700 text-slate-500 hover:text-indigo-600"><Download size={16} /></button>
            </div>
          </div>

          <div className="flex flex-wrap gap-2 mb-4">
            {(['all', 'critical', 'high', 'medium', 'low'] as const).map(s => (
              <button key={s} onClick={() => setSevFilter(s)} className={`px-3 py-1.5 rounded-full text-[10px] font-black uppercase tracking-wider border transition-all ${sevFilter === s ? 'bg-slate-900 text-white border-slate-900 dark:bg-white dark:text-slate-900' : 'border-slate-200 dark:border-slate-700 text-slate-500 hover:border-slate-400'}`}>
                {s === 'all' ? (tr ? 'Tümü' : 'All') : (tr ? SEVERITY_META[s].tr : SEVERITY_META[s].en)}
              </button>
            ))}
            {catFilter !== 'all' && (
              <button onClick={() => setCatFilter('all')} className="px-3 py-1.5 rounded-full text-[10px] font-black uppercase tracking-wider bg-indigo-600 text-white flex items-center gap-1">
                {tr ? CATEGORY_META[catFilter].tr : CATEGORY_META[catFilter].en} ✕
              </button>
            )}
          </div>

          {filtered.length === 0 ? (
            <div className="py-16 flex flex-col items-center text-center animate-in fade-in zoom-in-95">
              <div className="w-20 h-20 rounded-full bg-emerald-500/10 flex items-center justify-center mb-4 pc-float"><CheckCircle2 size={40} className="text-emerald-500" /></div>
              <p className="font-black text-slate-800 dark:text-white">{showSnoozed ? (tr ? 'Ertelenmiş uyarı yok' : 'No snoozed alerts') : (tr ? 'Harika! Bekleyen aksiyon yok.' : 'All clear! Nothing pending.')}</p>
              <p className="text-xs text-slate-400 mt-1">{tr ? 'Filtreleri değiştirerek diğer kayıtlara bakabilirsin.' : 'Try changing filters.'}</p>
            </div>
          ) : (
            <ul className="space-y-2 max-h-[620px] overflow-y-auto custom-scrollbar pr-1 pc-stagger" key={`${catFilter}-${sevFilter}-${showSnoozed}`}>
              {filtered.slice(0, visibleCount).map(item => {
                const cat = CATEGORY_META[item.category];
                const sev = SEVERITY_META[item.severity];
                const Icon = cat.icon;
                return (
                  <li key={item.id} className="group relative flex items-center gap-2 sm:gap-3 p-2.5 sm:p-3 pl-3.5 sm:pl-4 rounded-2xl border border-slate-100 dark:border-slate-800 hover:border-slate-200 dark:hover:border-slate-700 hover:bg-slate-50/70 dark:hover:bg-white/[0.03] transition-all overflow-hidden">
                    <span className={`absolute left-0 top-0 bottom-0 w-1 ${sev.stripe}`} />
                    <div className={`shrink-0 p-2 rounded-xl bg-gradient-to-br ${cat.color} text-white shadow-sm`}><Icon size={16} /></div>
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2">
                        <p className="text-sm font-bold text-slate-800 dark:text-slate-100 truncate">{item.title}</p>
                        <span className={`hidden sm:inline shrink-0 text-[9px] font-black uppercase px-2 py-0.5 rounded-full border ${sev.chip}`}>{tr ? sev.tr : sev.en}</span>
                      </div>
                      <p className="text-xs text-slate-500 dark:text-slate-400 truncate">{item.detail}</p>
                    </div>
                    <div className="flex items-center shrink-0 opacity-100 lg:opacity-0 lg:group-hover:opacity-100 transition-opacity">
                      {showSnoozed ? (
                        <button onClick={() => unsnooze(item.id)} title={tr ? 'Geri al' : 'Restore'} className="p-2 rounded-lg text-slate-400 hover:text-indigo-600 hover:bg-indigo-50 dark:hover:bg-white/5"><RotateCcw size={15} /></button>
                      ) : (
                        <>
                          <button onClick={() => snooze(item.id, 1)} title={tr ? '1 gün ertele' : 'Snooze 1 day'} className="p-1.5 sm:p-2 rounded-lg text-slate-400 hover:text-amber-600 hover:bg-amber-50 dark:hover:bg-white/5"><AlarmClock size={15} /></button>
                          <button onClick={() => snooze(item.id, 'forever')} title={tr ? 'Gizle' : 'Hide'} className="p-1.5 sm:p-2 rounded-lg text-slate-400 hover:text-slate-700 hover:bg-slate-100 dark:hover:bg-white/5"><EyeOff size={15} /></button>
                        </>
                      )}
                    </div>
                    <button onClick={() => onNavigate(item.tab)} className="shrink-0 flex items-center gap-1 px-3 py-2 rounded-xl text-[10px] font-black uppercase tracking-wider bg-slate-900 text-white dark:bg-white dark:text-slate-900 hover:bg-indigo-600 dark:hover:bg-indigo-500 dark:hover:text-white">
                      <span className="hidden sm:inline">{tr ? 'Git' : 'Open'}</span> <ArrowRight size={12} className="transition-transform group-hover:translate-x-0.5" />
                    </button>
                  </li>
                );
              })}
            </ul>
          )}
          {filtered.length > visibleCount && (
            <button onClick={() => setVisibleCount(v => v + 20)} className="mt-4 w-full py-3 rounded-2xl border border-dashed border-slate-200 dark:border-slate-700 text-xs font-black uppercase tracking-widest text-slate-500 hover:text-indigo-600 hover:border-indigo-300">
              {tr ? `${filtered.length - visibleCount} kayıt daha göster` : `Show ${filtered.length - visibleCount} more`}
            </button>
          )}
        </div>

        {/* TAKVİM */}
        <div className="xl:col-span-2 bg-white dark:bg-slate-900 border border-slate-100 dark:border-slate-800 rounded-[28px] sm:rounded-[32px] p-4 sm:p-6 flex flex-col">
          <h3 className="font-black text-slate-900 dark:text-white flex items-center gap-2 mb-4"><CalendarClock size={18} className="text-indigo-500" /> {tr ? 'Önümüzdeki 14 Gün' : 'Next 14 Days'}</h3>
          <div className="grid grid-cols-7 gap-1.5 pc-stagger">
            {timelineDays.map(d => {
              const isToday = d.date === localISO();
              const sel = d.date === selectedDay;
              return (
                <button
                  key={d.date}
                  onClick={() => setSelectedDay(d.date)}
                  className={`relative rounded-xl py-2 flex flex-col items-center border transition-all ${sel ? 'bg-indigo-600 border-indigo-600 text-white shadow-lg shadow-indigo-500/30' : isToday ? 'border-indigo-300 dark:border-indigo-500/40 text-indigo-600 dark:text-indigo-300' : 'border-slate-100 dark:border-slate-800 text-slate-600 dark:text-slate-300 hover:border-slate-300'}`}
                >
                  <span className="text-[9px] font-black uppercase opacity-70">{fmtDay(d.date, { weekday: 'short' })}</span>
                  <span className="text-sm font-black">{fmtDay(d.date, { day: 'numeric' })}</span>
                  <span className="flex gap-0.5 h-1.5 mt-1">
                    {d.events.slice(0, 3).map(e => <span key={e.id} className={`w-1.5 h-1.5 rounded-full ${sel ? 'bg-white' : 'bg-indigo-400'}`} />)}
                  </span>
                </button>
              );
            })}
          </div>
          <div className="mt-5 flex-1">
            <p className="text-[10px] font-black uppercase tracking-widest text-slate-400 mb-3">{fmtDay(selectedDay, { weekday: 'long', day: 'numeric', month: 'long' })}</p>
            {selectedEvents.length === 0 ? (
              <div className="py-10 text-center text-slate-400 animate-in fade-in" key={selectedDay}>
                <Coffee size={28} className="mx-auto mb-2 pc-float" />
                <p className="text-xs font-bold">{tr ? 'Planlanmış bir şey yok' : 'Nothing scheduled'}</p>
              </div>
            ) : (
              <ul className="space-y-2 max-h-[420px] overflow-y-auto custom-scrollbar pc-stagger" key={selectedDay}>
                {selectedEvents.map(e => {
                  const Icon = TIMELINE_ICON[e.kind] || Clock;
                  return (
                    <li key={e.id}>
                      <button onClick={() => onNavigate(e.tab)} className="w-full flex items-center gap-3 p-3 rounded-2xl bg-slate-50 dark:bg-white/[0.03] hover:bg-indigo-50 dark:hover:bg-indigo-500/10 text-left transition-colors">
                        <div className="p-2 rounded-xl bg-white dark:bg-slate-800 text-indigo-500 shadow-sm"><Icon size={14} /></div>
                        <span className="text-sm font-semibold text-slate-700 dark:text-slate-200 truncate">{e.label}</span>
                      </button>
                    </li>
                  );
                })}
              </ul>
            )}
          </div>
        </div>
      </section>

      {/* ================= EKİP İŞ YÜKÜ + AKTİVİTE ================= */}
      <section className="grid grid-cols-1 xl:grid-cols-5 gap-6">
        <div className="xl:col-span-3 bg-white dark:bg-slate-900 border border-slate-100 dark:border-slate-800 rounded-[28px] sm:rounded-[32px] p-4 sm:p-6">
          <div className="flex items-center justify-between mb-4">
            <h3 className="font-black text-slate-900 dark:text-white flex items-center gap-2"><Users size={18} className="text-indigo-500" /> {tr ? 'Ekip İş Yükü' : 'Team Workload'}</h3>
            <button onClick={() => onNavigate('team')} className="text-[10px] font-black uppercase tracking-widest text-indigo-500 hover:underline">{tr ? 'Ekibe git' : 'Go to team'}</button>
          </div>
          {workload.length === 0 ? (
            <p className="text-sm text-slate-400 py-8 text-center">{tr ? 'Personel bulunamadı.' : 'No staff found.'}</p>
          ) : (
            <div className="space-y-2 pc-stagger">
              {workload.map(row => {
                const load = Math.min(100, row.open * 12 + row.overdue * 10);
                return (
                  <div key={row.user.id} className="flex items-center gap-3 p-3 rounded-2xl hover:bg-slate-50 dark:hover:bg-white/[0.03] transition-colors">
                    <div className="relative shrink-0">
                      {row.user.avatar
                        ? <img src={row.user.avatar} alt="" className="w-10 h-10 rounded-xl object-cover" />
                        : <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-indigo-500 to-violet-500 text-white flex items-center justify-center font-black">{row.user.name?.[0]}</div>}
                      <span className={`absolute -bottom-0.5 -right-0.5 w-3 h-3 rounded-full border-2 border-white dark:border-slate-900 ${row.onLeave ? 'bg-sky-400' : row.clockedIn ? 'bg-emerald-500 pc-dot-pulse' : 'bg-slate-300 dark:bg-slate-600'}`} />
                    </div>
                    <div className="w-32 sm:w-40 min-w-0">
                      <p className="text-sm font-bold text-slate-800 dark:text-slate-100 truncate">{row.user.name}</p>
                      <p className="text-[10px] font-semibold text-slate-400 truncate">{row.onLeave ? (tr ? 'İzinde' : 'On leave') : row.clockedIn ? (tr ? 'Mesaide' : 'Working') : (tr ? 'Mesai dışı' : 'Off')} · {row.user.jobTitle || row.user.role}</p>
                    </div>
                    <div className="flex-1 hidden sm:block">
                      <GrowBar value={load} className={load > 75 ? 'bg-rose-500' : load > 45 ? 'bg-amber-400' : 'bg-emerald-500'} />
                    </div>
                    <div className="flex items-center gap-1.5 text-[10px] font-black shrink-0">
                      <span className="px-2 py-1 rounded-lg bg-slate-100 dark:bg-white/5 text-slate-600 dark:text-slate-300" title={tr ? 'Açık' : 'Open'}>{row.open}</span>
                      {row.overdue > 0 && <span className="px-2 py-1 rounded-lg bg-rose-500/10 text-rose-500" title={tr ? 'Gecikmiş' : 'Overdue'}>{row.overdue}!</span>}
                      {row.blocked > 0 && <span className="px-2 py-1 rounded-lg bg-orange-500/10 text-orange-500" title={tr ? 'Engelli' : 'Blocked'}>⛔ {row.blocked}</span>}
                      <span className="px-2 py-1 rounded-lg bg-emerald-500/10 text-emerald-600" title={tr ? 'Tamamlanan' : 'Done'}>✓ {row.doneTotal}</span>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>

        <div className="xl:col-span-2 bg-white dark:bg-slate-900 border border-slate-100 dark:border-slate-800 rounded-[28px] sm:rounded-[32px] p-4 sm:p-6">
          <div className="flex items-center justify-between mb-4">
            <h3 className="font-black text-slate-900 dark:text-white flex items-center gap-2"><Sparkles size={18} className="text-indigo-500" /> {tr ? 'Son Aktiviteler' : 'Recent Activity'}</h3>
            {currentUser.role === 'Admin' && <button onClick={() => onNavigate('systemlogs')} className="text-[10px] font-black uppercase tracking-widest text-indigo-500 hover:underline">{tr ? 'Tümü' : 'All'}</button>}
          </div>
          {auditLogs.length === 0 ? (
            <div className="space-y-3">
              {currentUser.role === 'Admin'
                ? [0, 1, 2, 3].map(i => <div key={i} className="h-12 rounded-2xl pc-skeleton" />)
                : <p className="text-sm text-slate-400 py-8 text-center">{tr ? 'Aktivite akışı yalnızca yöneticilere açıktır.' : 'Activity feed is admin-only.'}</p>}
            </div>
          ) : (
            <ol className="relative border-l-2 border-slate-100 dark:border-slate-800 ml-2 space-y-4 pc-stagger">
              {auditLogs.map(log => {
                const color = log.action === 'DELETE' ? 'bg-rose-500' : log.action === 'CREATE' ? 'bg-emerald-500' : log.action === 'LOGIN' ? 'bg-sky-500' : 'bg-indigo-500';
                const ago = dayDiff(log.timestamp);
                return (
                  <li key={log.id} className="ml-4">
                    <span className={`absolute -left-[7px] mt-1.5 w-3 h-3 rounded-full ring-4 ring-white dark:ring-slate-900 ${color}`} />
                    <p className="text-sm font-semibold text-slate-700 dark:text-slate-200 leading-snug">{log.details}</p>
                    <p className="text-[10px] font-bold text-slate-400 mt-0.5">
                      {log.userName} · {ago === 0 ? new Date(log.timestamp).toLocaleTimeString(tr ? 'tr-TR' : 'en-US', { hour: '2-digit', minute: '2-digit' }) : new Date(log.timestamp).toLocaleDateString(tr ? 'tr-TR' : 'en-US')}
                    </p>
                  </li>
                );
              })}
            </ol>
          )}
        </div>
      </section>
    </div>
  );
};

export default OperationsCenterView;
