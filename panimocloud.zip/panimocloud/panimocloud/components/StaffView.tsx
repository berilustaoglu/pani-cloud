import React, { useMemo, useState } from 'react';
import { CheckCircle2, PlayCircle, Clock, AlertTriangle, ListTodo, MessageSquare, FileText, Edit3, Check, ChevronDown, Hand, RotateCcw, CalendarCheck, Ban, ChevronLeft, ChevronRight, Trophy } from 'lucide-react';
import { Task, TaskStatus, Project, User } from '../types';
import { PageHeader, KpiGrid, SearchBox, Segmented, Field, EmptyState, Sheet, inputCls, selectSm, cardCls } from './ui/Kit';
import { GrowBar } from './ui/Motion';
import { localISO, dayDiff, suspendedProjectIds } from '../services/insights';
import { toast } from '../services/toast';
import { pushNotification } from '../services/notificationService';

interface Props {
  tasks: Task[];
  onUpdateTask: (task: Task) => Promise<void>;
  currentUser: User;
  projects: Project[];
  language: 'tr' | 'en';
  onUpdateProject?: (project: Project) => Promise<void>;
}

type Filter = 'active' | 'today' | 'overdue' | 'blocked' | 'done';
const PAGE = 5;

const StaffView: React.FC<Props> = ({ tasks, onUpdateTask, currentUser, projects, language, onUpdateProject }) => {
  const tr = language === 'tr';
  const today = localISO();
  const [filter, setFilter] = useState<Filter>('active');
  const [search, setSearch] = useState('');
  const [projectF, setProjectF] = useState('all');
  const [open, setOpen] = useState<string | null>(null);
  const [editingNotes, setEditingNotes] = useState<string | null>(null);
  const [tempNotes, setTempNotes] = useState('');
  const [blockFor, setBlockFor] = useState<Task | null>(null);
  const [blockReason, setBlockReason] = useState('');
  const [busy, setBusy] = useState<string | null>(null);
  const [donePage, setDonePage] = useState(0);

  const projectName = (id: string) => projects.find(p => p.id === id)?.name || (tr ? 'Genel' : 'General');
  const mine = useMemo(() => tasks.filter(t => t.assignedTo?.includes(currentUser.id)), [tasks, currentUser.id]);
  const held = useMemo(() => suspendedProjectIds(projects), [projects]);
  // Askıdaki projelerin görevleri askı süresince gecikmiş sayılmaz
  const isOverdue = (t: Task) => t.status !== TaskStatus.DONE && !!t.deadline && t.deadline < today && !held.has(t.projectId);
  const active = mine.filter(t => t.status !== TaskStatus.DONE);
  const done = mine.filter(t => t.status === TaskStatus.DONE);
  const month = today.slice(0, 7);

  const stats = {
    open: active.length,
    today: active.filter(t => t.deadline === today).length,
    overdue: active.filter(isOverdue).length,
    blocked: active.filter(t => t.status === TaskStatus.BLOCKED).length,
    doneMonth: done.filter(t => (t.deadline || '').startsWith(month)).length,
    rate: mine.length ? Math.round((done.length / mine.length) * 100) : 0,
  };

  const q = search.trim().toLocaleLowerCase('tr-TR');
  const list = useMemo(() => {
    const base = filter === 'done' ? done
      : filter === 'today' ? active.filter(t => t.deadline === today)
      : filter === 'overdue' ? active.filter(isOverdue)
      : filter === 'blocked' ? active.filter(t => t.status === TaskStatus.BLOCKED)
      : active;
    return base.filter(t => (projectF === 'all' || t.projectId === projectF) && (!q || [t.title, t.notes, t.managerNotes, projectName(t.projectId)].join(' ').toLocaleLowerCase('tr-TR').includes(q)))
      .sort((a, b) => filter === 'done' ? (b.deadline || '').localeCompare(a.deadline || '')
        : (Number(b.status === TaskStatus.DOING) - Number(a.status === TaskStatus.DOING)) || (a.deadline || '9').localeCompare(b.deadline || '9'));
  }, [filter, mine, projectF, q, today]); // eslint-disable-line react-hooks/exhaustive-deps

  const pages = Math.max(1, Math.ceil(list.length / PAGE));
  const curPage = Math.min(donePage, pages - 1);
  const shown = filter === 'done' ? list.slice(curPage * PAGE, curPage * PAGE + PAGE) : list;

  // Proje ilerlemesi: tamamlanan görevlerin katkı yüzdelerinin toplamı (mevcut davranış korunur)
  const syncProject = async (projectId: string, next: Task[]) => {
    if (!onUpdateProject) return;
    const p = projects.find(x => x.id === projectId);
    if (!p) return;
    const progress = Math.min(100, next.filter(t => t.projectId === projectId && t.status === TaskStatus.DONE).reduce((a, t) => a + (t.progress || 0), 0));
    if (progress !== p.progress) await onUpdateProject({ ...p, progress });
  };
  const setStatus = async (t: Task, status: TaskStatus, reason?: string) => {
    setBusy(t.id);
    try {
      const upd: Task = { ...t, status, blockedReason: status === TaskStatus.BLOCKED ? (reason || '') : (status === TaskStatus.DOING ? '' : t.blockedReason || '') };
      await onUpdateTask(upd);
      await syncProject(t.projectId, tasks.map(x => x.id === t.id ? upd : x));
      if (status === TaskStatus.BLOCKED) await pushNotification(`${currentUser.name} bir işte takıldı`, `${t.title}: ${reason || ''}`, 'warning', 'myteam');
      toast(status === TaskStatus.DONE ? (tr ? `"${t.title}" tamamlandı 🎉` : 'Completed 🎉') : status === TaskStatus.DOING ? (tr ? 'Görev başlatıldı' : 'Started') : status === TaskStatus.BLOCKED ? (tr ? 'Takıldığınız bildirildi; yöneticiniz görecek' : 'Marked blocked') : (tr ? 'Güncellendi' : 'Updated'), status === TaskStatus.DONE ? 'success' : 'info', 2600);
    } catch (e: any) { toast.error(e?.message || 'Hata'); } finally { setBusy(null); }
  };
  const toggleItem = async (t: Task, itemId: string) => {
    if (!t.checklist) return;
    await onUpdateTask({ ...t, checklist: t.checklist.map(i => i.id === itemId ? { ...i, isCompleted: !i.isCompleted } : i) });
  };
  const saveNotes = async (t: Task) => { await onUpdateTask({ ...t, notes: tempNotes }); setEditingNotes(null); toast.success(tr ? 'Not kaydedildi' : 'Saved'); };

  const dueLabel = (t: Task) => {
    if (!t.deadline) return { text: tr ? 'Tarih yok' : 'No date', cls: 'text-slate-400' };
    const d = dayDiff(t.deadline)!;
    if (t.status === TaskStatus.DONE) return { text: new Date(t.deadline + 'T00:00').toLocaleDateString(tr ? 'tr-TR' : 'en-US', { day: 'numeric', month: 'short' }), cls: 'text-slate-400' };
    if (d < 0) return { text: tr ? `${-d} gün gecikti` : `${-d}d overdue`, cls: 'text-rose-600 dark:text-rose-400 font-semibold' };
    if (d === 0) return { text: tr ? 'Bugün teslim' : 'Due today', cls: 'text-amber-600 dark:text-amber-400 font-semibold' };
    if (d === 1) return { text: tr ? 'Yarın' : 'Tomorrow', cls: 'text-slate-600 dark:text-slate-300' };
    return { text: tr ? `${d} gün kaldı` : `${d} days left`, cls: 'text-slate-500' };
  };
  const statusChip = (t: Task) => {
    const m = t.status === TaskStatus.DONE ? { l: tr ? 'Tamamlandı' : 'Done', c: 'bg-emerald-50 text-emerald-700 dark:bg-emerald-500/10 dark:text-emerald-300', d: 'bg-emerald-500' }
      : t.status === TaskStatus.DOING ? { l: tr ? 'Devam ediyor' : 'In progress', c: 'bg-sky-50 text-sky-700 dark:bg-sky-500/10 dark:text-sky-300', d: 'bg-sky-500 pc-dot-pulse' }
      : t.status === TaskStatus.BLOCKED ? { l: tr ? 'Takıldı' : 'Blocked', c: 'bg-orange-50 text-orange-700 dark:bg-orange-500/10 dark:text-orange-300', d: 'bg-orange-500' }
      : { l: tr ? 'Başlanmadı' : 'To do', c: 'bg-slate-100 text-slate-600 dark:bg-white/5 dark:text-slate-300', d: 'bg-slate-400' };
    return <span className={`inline-flex items-center gap-1.5 text-[11px] font-semibold px-2 py-0.5 rounded-md ${m.c}`}><span className={`w-1.5 h-1.5 rounded-full ${m.d}`} />{m.l}</span>;
  };

  const card = (t: Task) => {
    const overdue = isOverdue(t);
    const cl = t.checklist || [];
    const clDone = cl.filter(i => i.isCompleted).length;
    const due = dueLabel(t);
    const expanded = open === t.id;
    const accent = t.status === TaskStatus.DONE ? 'bg-emerald-400' : overdue ? 'bg-rose-400' : t.status === TaskStatus.BLOCKED ? 'bg-orange-400' : t.status === TaskStatus.DOING ? 'bg-sky-400' : 'bg-slate-200 dark:bg-slate-700';
    return (
      <div key={t.id} className={`${cardCls} relative overflow-hidden transition-shadow ${expanded ? 'shadow-lg shadow-slate-200/60 dark:shadow-none' : 'hover:shadow-md'} ${overdue ? '!border-rose-200 dark:!border-rose-500/30' : ''}`}>
        <span className={`absolute left-0 inset-y-0 w-1 ${accent}`} />
        <div className="p-4 pl-5 flex flex-col sm:flex-row sm:items-center gap-3">
          <button onClick={() => setOpen(expanded ? null : t.id)} className="flex-1 min-w-0 text-left">
            <div className="flex flex-wrap items-center gap-1.5 mb-1">
              <span className="text-[11px] font-semibold text-indigo-600 dark:text-indigo-300 truncate max-w-[200px]">{projectName(t.projectId)}</span>
              {statusChip(t)}
            </div>
            <p className={`font-semibold leading-snug ${t.status === TaskStatus.DONE ? 'text-slate-400 line-through decoration-slate-300' : 'text-slate-900 dark:text-white'}`}>{t.title}</p>
            <div className="flex flex-wrap items-center gap-x-3 gap-y-1 mt-1 text-xs">
              <span className={`inline-flex items-center gap-1 ${due.cls}`}><Clock size={12} />{due.text}</span>
              {cl.length > 0 && <span className="inline-flex items-center gap-1.5 text-slate-500"><ListTodo size={12} />{clDone}/{cl.length}<span className="w-14"><GrowBar value={(clDone / cl.length) * 100} className="bg-indigo-500" /></span></span>}
              {t.managerNotes && <span className="inline-flex items-center gap-1 text-indigo-600 dark:text-indigo-300"><MessageSquare size={12} />{tr ? 'Yönetici notu' : 'Note'}</span>}
              {t.status === TaskStatus.BLOCKED && t.blockedReason && <span className="text-orange-600 truncate max-w-[220px]">⛔ {t.blockedReason}</span>}
            </div>
          </button>
          <div className="flex items-center gap-1.5 shrink-0">
            {t.status === TaskStatus.TODO && <button disabled={busy === t.id} onClick={() => setStatus(t, TaskStatus.DOING)} className="h-9 px-3 rounded-xl text-xs font-semibold text-indigo-700 bg-indigo-50 hover:bg-indigo-100 dark:bg-indigo-500/10 dark:text-indigo-300 inline-flex items-center gap-1.5 disabled:opacity-50"><PlayCircle size={14} />{tr ? 'Başla' : 'Start'}</button>}
            {t.status === TaskStatus.BLOCKED && <button disabled={busy === t.id} onClick={() => setStatus(t, TaskStatus.DOING)} className="h-9 px-3 rounded-xl text-xs font-semibold text-sky-700 bg-sky-50 hover:bg-sky-100 dark:bg-sky-500/10 dark:text-sky-300 inline-flex items-center gap-1.5 disabled:opacity-50"><PlayCircle size={14} />{tr ? 'Devam et' : 'Resume'}</button>}
            {t.status !== TaskStatus.DONE && <button disabled={busy === t.id} onClick={() => setStatus(t, TaskStatus.DONE)} className="h-9 px-3 rounded-xl text-xs font-semibold text-white bg-emerald-600 hover:bg-emerald-500 inline-flex items-center gap-1.5 shadow-md shadow-emerald-500/20 disabled:opacity-50"><CheckCircle2 size={14} />{tr ? 'Tamamla' : 'Done'}</button>}
            {t.status === TaskStatus.DONE && <button disabled={busy === t.id} onClick={() => setStatus(t, TaskStatus.DOING)} title={tr ? 'Yeniden aç' : 'Reopen'} className="h-9 px-3 rounded-xl text-xs font-semibold text-slate-600 dark:text-slate-300 border border-slate-200 dark:border-slate-700 hover:border-indigo-300 inline-flex items-center gap-1.5"><RotateCcw size={13} />{tr ? 'Geri al' : 'Reopen'}</button>}
            <button onClick={() => setOpen(expanded ? null : t.id)} className="p-2 rounded-xl text-slate-400 hover:bg-slate-100 dark:hover:bg-white/5"><ChevronDown size={16} className={`transition-transform ${expanded ? 'rotate-180' : ''}`} /></button>
          </div>
        </div>

        {expanded && (
          <div className="px-5 pb-5 space-y-3 animate-in fade-in slide-in-from-top-1 duration-200">
            {cl.length > 0 && (
              <div className="rounded-2xl bg-slate-50/70 dark:bg-white/[0.02] p-3">
                <p className="text-xs font-semibold text-slate-500 mb-2 flex items-center gap-1.5"><ListTodo size={13} className="text-indigo-500" />{tr ? 'Yapılacaklar' : 'Checklist'} <span className="text-slate-400">{clDone}/{cl.length}</span></p>
                <div className="space-y-1">
                  {cl.map(i => (
                    <button key={i.id} onClick={() => toggleItem(t, i.id)} className={`w-full flex items-center gap-2.5 px-2.5 py-2 rounded-xl text-left text-sm transition-colors ${i.isCompleted ? 'bg-emerald-50/70 dark:bg-emerald-500/5' : 'hover:bg-white dark:hover:bg-white/5'}`}>
                      <span className={`w-[18px] h-[18px] rounded-md border-2 flex items-center justify-center shrink-0 ${i.isCompleted ? 'bg-emerald-500 border-emerald-500' : 'border-slate-300 dark:border-slate-600'}`}>{i.isCompleted && <Check size={12} className="text-white" strokeWidth={3} />}</span>
                      <span className={i.isCompleted ? 'text-slate-400 line-through' : 'text-slate-700 dark:text-slate-200'}>{i.text}</span>
                    </button>
                  ))}
                </div>
              </div>
            )}
            {t.managerNotes && (
              <div className="flex gap-3 rounded-2xl p-3 bg-indigo-50/70 dark:bg-indigo-500/10">
                <MessageSquare size={16} className="text-indigo-600 shrink-0 mt-0.5" />
                <div><p className="text-xs font-semibold text-indigo-700 dark:text-indigo-300">{tr ? 'Yönetici notu' : 'Manager note'}</p><p className="text-sm text-slate-700 dark:text-slate-200 whitespace-pre-wrap">{t.managerNotes}</p></div>
              </div>
            )}
            <div className="rounded-2xl border border-slate-100 dark:border-slate-800 p-3">
              <div className="flex items-center justify-between mb-1.5">
                <p className="text-xs font-semibold text-slate-500 flex items-center gap-1.5"><FileText size={13} className="text-indigo-500" />{tr ? 'Notlarım' : 'My notes'}</p>
                {editingNotes !== t.id
                  ? <button onClick={() => { setEditingNotes(t.id); setTempNotes(t.notes || ''); }} className="h-7 px-2 rounded-lg text-[11px] font-semibold text-slate-500 hover:text-indigo-600 hover:bg-indigo-50 dark:hover:bg-white/5 inline-flex items-center gap-1"><Edit3 size={12} />{tr ? 'Düzenle' : 'Edit'}</button>
                  : <span className="flex gap-1"><button onClick={() => setEditingNotes(null)} className="h-7 px-2 rounded-lg text-[11px] font-semibold text-slate-500">{tr ? 'Vazgeç' : 'Cancel'}</button><button onClick={() => saveNotes(t)} className="h-7 px-2.5 rounded-lg text-[11px] font-semibold text-white bg-indigo-600">{tr ? 'Kaydet' : 'Save'}</button></span>}
              </div>
              {editingNotes === t.id
                ? <textarea autoFocus rows={3} className={inputCls() + ' !h-auto py-2.5 resize-none'} value={tempNotes} onChange={e => setTempNotes(e.target.value)} placeholder={tr ? 'İlerleme, karşılaştığın sorunlar…' : 'Progress notes…'} />
                : <p className={`text-sm whitespace-pre-wrap ${t.notes ? 'text-slate-700 dark:text-slate-200' : 'text-slate-400 italic'}`}>{t.notes || (tr ? 'Henüz not yok.' : 'No notes yet.')}</p>}
            </div>
            {t.status !== TaskStatus.DONE && t.status !== TaskStatus.BLOCKED && (
              <button onClick={() => { setBlockFor(t); setBlockReason(''); }} className="text-xs font-semibold text-orange-600 hover:underline inline-flex items-center gap-1.5"><Hand size={13} />{tr ? 'Bu işte takıldım — yöneticime bildir' : "I'm blocked — notify my manager"}</button>
            )}
            <p className="text-[11px] text-slate-400">{tr ? 'Projeye katkı' : 'Weight'} %{t.progress || 0}{t.deadline ? ` · ${tr ? 'Teslim' : 'Due'} ${new Date(t.deadline + 'T00:00').toLocaleDateString(tr ? 'tr-TR' : 'en-US', { day: 'numeric', month: 'long', year: 'numeric' })}` : ''}</p>
          </div>
        )}
      </div>
    );
  };

  return (
    <div className="space-y-5 pb-10">
      <PageHeader title={tr ? 'Görevlerim' : 'My tasks'} subtitle={tr ? 'Size atanan işler; başlatın, takıldığınızı bildirin, tamamlayın.' : 'Your assigned work.'} />

      <KpiGrid items={[
        { label: tr ? 'Açık görev' : 'Open', value: stats.open, icon: ListTodo, grad: 'from-indigo-500 to-violet-600', sub: `${active.filter(t => t.status === TaskStatus.DOING).length} ${tr ? 'devam ediyor' : 'in progress'}`, onClick: () => setFilter('active'), active: filter === 'active' },
        { label: tr ? 'Bugün teslim' : 'Due today', value: stats.today, icon: CalendarCheck, grad: 'from-amber-500 to-orange-600', sub: stats.today ? (tr ? 'Öncelik bunlar' : 'Focus here') : (tr ? 'Bugün teslim yok' : 'Nothing due'), onClick: () => setFilter('today'), active: filter === 'today' },
        { label: tr ? 'Geciken' : 'Overdue', value: stats.overdue, icon: AlertTriangle, grad: stats.overdue ? 'from-rose-500 to-red-600' : 'from-emerald-500 to-teal-600', sub: stats.blocked ? (tr ? `${stats.blocked} iş takılı` : `${stats.blocked} blocked`) : (tr ? 'Takılan iş yok' : 'None blocked'), onClick: () => setFilter('overdue'), active: filter === 'overdue' },
        { label: tr ? 'Bu ay tamamlanan' : 'Done this month', value: stats.doneMonth, icon: Trophy, grad: 'from-emerald-500 to-teal-600', sub: `${tr ? 'Genel tamamlama' : 'Completion'} %${stats.rate}`, bar: stats.rate, onClick: () => setFilter('done'), active: filter === 'done' },
      ]} />

      <div className={`${cardCls} p-3 flex flex-col lg:flex-row gap-2`}>
        <Segmented<Filter> value={filter} onChange={v => { setFilter(v); setDonePage(0); }} options={[
          { value: 'active', label: <>{tr ? 'Aktif' : 'Active'} <span className="text-[10px] opacity-60">{stats.open}</span></> },
          { value: 'today', label: tr ? 'Bugün' : 'Today' },
          { value: 'overdue', label: <>{tr ? 'Geciken' : 'Overdue'}{stats.overdue > 0 && <span className="text-[10px] px-1.5 rounded-full bg-rose-500 text-white">{stats.overdue}</span>}</> },
          { value: 'blocked', label: <><Ban size={12} />{tr ? 'Takılan' : 'Blocked'}</> },
          { value: 'done', label: tr ? 'Tamamlanan' : 'Done' },
        ]} />
        <SearchBox value={search} onChange={v => { setSearch(v); setDonePage(0); }} placeholder={tr ? 'Görev veya not ara…' : 'Search…'} />
        <select value={projectF} onChange={e => setProjectF(e.target.value)} className={selectSm}><option value="all">{tr ? 'Tüm projeler' : 'All projects'}</option>{[...new Set(mine.map(t => t.projectId))].map(id => <option key={id} value={id}>{projectName(id)}</option>)}</select>
      </div>

      {shown.length === 0 ? (
        <div className={cardCls}><EmptyState icon={filter === 'done' ? Trophy : CheckCircle2} text={filter === 'active' ? (tr ? 'Açık göreviniz yok — harika! 🎉' : 'No open tasks 🎉') : filter === 'done' ? (tr ? 'Henüz tamamlanan görev yok' : 'Nothing completed yet') : (tr ? 'Bu filtrede görev yok' : 'No tasks here')} /></div>
      ) : (
        <div key={filter + curPage} className="space-y-2.5 pc-stagger">{shown.map(card)}</div>
      )}

      {filter === 'done' && list.length > PAGE && (
        <div className={`${cardCls} px-4 py-2.5 flex items-center gap-2`}>
          <span className="text-[11px] text-slate-400 flex-1">{tr ? `${list.length} görevden ${curPage * PAGE + 1}–${Math.min(list.length, (curPage + 1) * PAGE)}` : `Page ${curPage + 1}/${pages}`}</span>
          <button disabled={curPage === 0} onClick={() => setDonePage(curPage - 1)} className="h-8 w-8 rounded-lg border border-slate-200 dark:border-slate-700 flex items-center justify-center text-slate-500 disabled:opacity-30"><ChevronLeft size={15} /></button>
          <span className="text-xs font-semibold text-slate-600 dark:text-slate-300 min-w-[24px] text-center">{curPage + 1}</span>
          <button disabled={curPage >= pages - 1} onClick={() => setDonePage(curPage + 1)} className="h-8 w-8 rounded-lg border border-slate-200 dark:border-slate-700 flex items-center justify-center text-slate-500 disabled:opacity-30"><ChevronRight size={15} /></button>
        </div>
      )}

      <Sheet open={!!blockFor} language={language} title={tr ? 'İşte takıldım' : 'I am blocked'} subtitle={blockFor?.title} icon={Hand} tone="from-orange-500 to-amber-600" onClose={() => setBlockFor(null)} submitLabel={tr ? 'Bildir' : 'Report'}
        onSubmit={async () => { if (!blockFor || !blockReason.trim()) { toast.warning(tr ? 'Neyin engel olduğunu yazın' : 'Describe the blocker'); return; } await setStatus(blockFor, TaskStatus.BLOCKED, blockReason.trim()); setBlockFor(null); }}>
        <Field label={tr ? 'Ne engel oluyor?' : "What's blocking you?"} required hint={tr ? 'Yöneticiniz bunu Ekibim ekranında görür.' : 'Your manager will see this.'}>
          <textarea autoFocus rows={4} className={inputCls() + ' !h-auto py-2.5 resize-none'} value={blockReason} onChange={e => setBlockReason(e.target.value)} placeholder={tr ? 'Örn: Müşteriden içerik bekleniyor, sunucu erişimi yok…' : 'e.g. waiting for client content'} />
        </Field>
      </Sheet>
    </div>
  );
};

export default StaffView;
