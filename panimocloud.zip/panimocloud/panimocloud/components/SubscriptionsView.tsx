import React, { useMemo, useState } from 'react';
import { Plus, CreditCard, Edit2, RefreshCw, Layers, CalendarClock, CheckCircle2, BellOff, PauseCircle, PlayCircle, FileText, Upload, Loader2, ExternalLink, AlertTriangle, History, TrendingUp } from 'lucide-react';
import { ref, uploadBytes, getDownloadURL } from 'firebase/storage';
import { storage } from '../firebase';
import { Subscription, Currency, BillingCycle, Transaction } from '../types';
import { KpiGrid, SearchBox, Segmented, Field, EmptyState, DeleteButton, Sheet, Avatar, inputCls, selectSm, cardCls, btnPrimary, btnGhost, money } from './ui/Kit';
import { GrowBar } from './ui/Motion';
import { toTRY, formatTRY, dayDiff, localISO } from '../services/insights';
import { toast } from '../services/toast';

interface Props {
  subscriptions: Subscription[];
  onUpsertSubscription: (sub: Subscription) => Promise<void>;
  onDeleteSubscription: (id: string) => Promise<void>;
  language: 'tr' | 'en';
  rates: { TRY: number; EUR: number };
  showFinancials: boolean;
  /** Ödendi işaretlenince muhasebeye gider kaydı */
  onAddTransaction?: (t: Transaction) => Promise<void>;
  transactions?: Transaction[];
  defaultCurrency?: Currency;
  expenseCategories?: string[];
}

const CATS = ['Yazılım', 'Sunucu ve Bulut', 'Tasarım', 'Pazarlama', 'İletişim', 'Ofis', 'Diğer'];
const CAT_COLORS = ['bg-indigo-500', 'bg-sky-500', 'bg-violet-500', 'bg-amber-500', 'bg-emerald-500', 'bg-rose-500', 'bg-slate-400', 'bg-teal-500', 'bg-orange-500'];
const addCycle = (iso: string, c: BillingCycle) => { const [y, m, d] = iso.split('-').map(Number); return localISO(new Date(y, m - 1 + (c === BillingCycle.YEARLY ? 12 : 1), d)); };
/** Abonelik kategorisini muhasebedeki en yakın gider kategorisine eşle */
const expenseCatOf = (cat: string, cats: string[]) => {
  const c = (cat || '').toLocaleLowerCase('tr-TR');
  const find = (k: string) => cats.find(x => x.toLocaleLowerCase('tr-TR').includes(k));
  if (/sunucu|bulut|hosting|server|cloud/.test(c)) return find('sunucu') || cats[0];
  if (/pazarlama|reklam|marketing/.test(c)) return find('reklam') || cats[0];
  if (/ofis|kira|fatura/.test(c)) return find('ofis') || cats[0];
  return cats.find(x => x === cat) || find('yazılım') || find('lisans') || cats[0];
};

const SubscriptionsView: React.FC<Props> = ({ subscriptions, onUpsertSubscription, onDeleteSubscription, language, rates, showFinancials, onAddTransaction, transactions = [], defaultCurrency = Currency.TRY, expenseCategories = ['Yazılım Lisans Giderleri', 'Sunucu ve Bulut Giderleri', 'Diğer'] }) => {
  const tr = language === 'tr';
  const [statusF, setStatusF] = useState<'Active' | 'Cancelled' | 'all'>('Active');
  const [catF, setCatF] = useState('all');
  const [search, setSearch] = useState('');
  const [sort, setSort] = useState<'next' | 'cost' | 'name'>('next');
  const [form, setForm] = useState<Partial<Subscription> | null>(null);
  const [touched, setTouched] = useState(false);
  const [saving, setSaving] = useState(false);
  const [uploading, setUploading] = useState(false);
  const [busyId, setBusyId] = useState<string | null>(null);
  const show = (n: number, c?: string) => (showFinancials ? money(n, c, 2) : '••••');
  const monthlyTRY = (s: Subscription) => toTRY(s.billingCycle === BillingCycle.YEARLY ? s.amount / 12 : s.amount, s.currency, rates);

  const active = subscriptions.filter(s => s.status === 'Active');
  const stats = useMemo(() => {
    const monthly = active.reduce((a, s) => a + monthlyTRY(s), 0);
    const due30 = active.filter(s => (dayDiff(s.nextBillingDate) ?? 99) <= 30);
    const overdue = active.filter(s => (dayDiff(s.nextBillingDate) ?? 0) < 0);
    const byCat = new Map<string, number>();
    active.forEach(s => byCat.set(s.category || (tr ? 'Diğer' : 'Other'), (byCat.get(s.category || (tr ? 'Diğer' : 'Other')) || 0) + monthlyTRY(s)));
    return {
      monthly, yearly: monthly * 12, due30Amount: due30.reduce((a, s) => a + toTRY(s.amount, s.currency, rates), 0), due30: due30.length, overdue: overdue.length,
      cats: [...byCat.entries()].sort((a, b) => b[1] - a[1]),
    };
  }, [subscriptions, rates]);

  const categories = useMemo(() => [...new Set([...CATS, ...subscriptions.map(s => s.category).filter(Boolean)])], [subscriptions]);
  const q = search.trim().toLocaleLowerCase('tr-TR');
  const list = subscriptions
    .filter(s => (statusF === 'all' || s.status === statusF) && (catF === 'all' || s.category === catF) && (!q || [s.name, s.provider, s.category].join(' ').toLocaleLowerCase('tr-TR').includes(q)))
    .sort((a, b) => sort === 'cost' ? monthlyTRY(b) - monthlyTRY(a) : sort === 'name' ? a.name.localeCompare(b.name, 'tr') : (a.status === b.status ? 0 : a.status === 'Active' ? -1 : 1) || (a.nextBillingDate || '').localeCompare(b.nextBillingDate || ''));

  // ---------- İşlemler ----------
  const pay = async (s: Subscription) => {
    setBusyId(s.id);
    try {
      const date = localISO();
      if (onAddTransaction) {
        await onAddTransaction({ id: `tr_sub_${s.id}_${s.nextBillingDate}`, type: 'Expense', amount: s.amount, currency: s.currency, category: expenseCatOf(s.category, expenseCategories), date, description: `${s.name}${s.provider ? ` (${s.provider})` : ''} · ${s.billingCycle} ${tr ? 'abonelik ödemesi' : 'subscription'}`, taxRate: 0, taxAmount: 0, totalAmountWithTax: s.amount });
      }
      const next = addCycle(s.nextBillingDate || date, s.billingCycle);
      await onUpsertSubscription({ ...s, nextBillingDate: next, snoozeUntil: undefined as any });
      toast.success(tr ? `${s.name} ödendi${onAddTransaction ? ' · gidere işlendi' : ''} · sonraki ödeme ${next}` : 'Paid');
    } catch (e: any) { toast.error(e?.message || 'Hata'); } finally { setBusyId(null); }
  };
  const snooze = async (s: Subscription) => {
    const d = new Date(); d.setDate(d.getDate() + 3);
    await onUpsertSubscription({ ...s, snoozeUntil: localISO(d) });
    toast(tr ? `${s.name} hatırlatması 3 gün ertelendi` : 'Snoozed 3 days', 'info', 2200);
  };
  const toggle = async (s: Subscription) => {
    const status = s.status === 'Active' ? 'Cancelled' : 'Active';
    await onUpsertSubscription({ ...s, status });
    toast(status === 'Cancelled' ? (tr ? `${s.name} iptal edildi · aylık ${showFinancials ? formatTRY(monthlyTRY(s)) : ''} tasarruf` : 'Cancelled') : (tr ? `${s.name} yeniden aktif` : 'Reactivated'), status === 'Cancelled' ? 'info' : 'success');
  };

  // ---------- Form ----------
  const openNew = () => { setTouched(false); setForm({ currency: defaultCurrency, billingCycle: BillingCycle.MONTHLY, status: 'Active', category: CATS[0], startDate: localISO(), nextBillingDate: localISO() }); };
  const errs: Record<string, string> = {};
  if (form) {
    if (!form.name?.trim()) errs.name = tr ? 'Hizmet adı zorunlu.' : 'Required.';
    if (!(Number(form.amount) > 0)) errs.amount = tr ? 'Tutar girin.' : 'Enter amount.';
    if (!form.nextBillingDate) errs.next = tr ? 'Sonraki ödeme tarihi zorunlu.' : 'Required.';
    else if (form.startDate && form.nextBillingDate < form.startDate) errs.next = tr ? 'Başlangıçtan önce olamaz.' : 'Before start date.';
  }
  const fe = (k: string) => (touched ? errs[k] : undefined);
  const save = async () => {
    setTouched(true);
    if (!form || Object.keys(errs).length) return;
    setSaving(true);
    try {
      const isNew = !form.id;
      await onUpsertSubscription({ ...(form as Subscription), id: form.id || `sub${Date.now()}`, name: form.name!.trim(), provider: (form.provider || '').trim(), category: (form.category || '').trim() || (tr ? 'Diğer' : 'Other'), amount: Number(form.amount), startDate: form.startDate || localISO(), nextBillingDate: form.nextBillingDate! });
      toast.success(isNew ? (tr ? 'Abonelik eklendi' : 'Added') : (tr ? 'Abonelik güncellendi' : 'Updated'));
      setForm(null);
    } catch (e: any) { toast.error(e?.message || 'Hata'); } finally { setSaving(false); }
  };
  const upload = async (file?: File) => {
    if (!file || !form) return;
    setUploading(true);
    try { const r = ref(storage, `subscriptions/${Date.now()}_${file.name}`); await uploadBytes(r, file); setForm({ ...form, documentUrl: await getDownloadURL(r), documentName: file.name }); toast.success(tr ? 'Belge yüklendi' : 'Uploaded'); }
    catch { toast.error(tr ? 'Belge yüklenemedi' : 'Upload failed'); } finally { setUploading(false); }
  };
  const history = form?.id ? transactions.filter(t => t.id.startsWith(`tr_sub_${form.id}_`)).sort((a, b) => (b.date || '').localeCompare(a.date || '')) : [];
  const formMonthly = form && Number(form.amount) > 0 ? toTRY(form.billingCycle === BillingCycle.YEARLY ? Number(form.amount) / 12 : Number(form.amount), form.currency || Currency.TRY, rates) : 0;

  const dueChip = (s: Subscription) => {
    if (s.status !== 'Active') return <span className="text-[11px] font-semibold px-2 py-0.5 rounded-md bg-slate-100 text-slate-500 dark:bg-white/5">{tr ? 'İptal edildi' : 'Cancelled'}</span>;
    const d = dayDiff(s.nextBillingDate);
    const snoozed = (dayDiff(s.snoozeUntil) ?? -1) >= 0;
    const C = 'text-[11px] font-semibold px-2 py-0.5 rounded-md inline-flex items-center gap-1 whitespace-nowrap';
    if (d === null) return <span className={`${C} bg-slate-100 text-slate-500`}>—</span>;
    if (d < 0) return <span className={`${C} bg-rose-50 text-rose-700 dark:bg-rose-500/10 dark:text-rose-300`}><AlertTriangle size={11} />{tr ? `${-d} gün gecikti` : 'Overdue'}{snoozed && <BellOff size={10} />}</span>;
    if (d <= 7) return <span className={`${C} bg-amber-50 text-amber-700 dark:bg-amber-500/10 dark:text-amber-300`}><CalendarClock size={11} />{d === 0 ? (tr ? 'Bugün' : 'Today') : (tr ? `${d} gün sonra` : `in ${d}d`)}{snoozed && <BellOff size={10} />}</span>;
    return <span className={`${C} bg-slate-100 text-slate-600 dark:bg-white/5 dark:text-slate-300`}><CalendarClock size={11} />{tr ? `${d} gün sonra` : `in ${d}d`}</span>;
  };

  return (
    <div className="space-y-5">
      <KpiGrid items={[
        { label: tr ? 'Aylık abonelik gideri' : 'Monthly cost', value: showFinancials ? stats.monthly : 0, format: formatTRY, icon: RefreshCw, grad: 'from-indigo-500 to-violet-600', sub: `${active.length} ${tr ? 'aktif abonelik' : 'active'}` },
        { label: tr ? 'Yıllık projeksiyon' : 'Yearly', value: showFinancials ? stats.yearly : 0, format: formatTRY, icon: Layers, grad: 'from-slate-600 to-slate-800', sub: tr ? 'Mevcut aboneliklerle' : 'At current plans' },
        { label: tr ? '30 gün içinde ödenecek' : 'Due in 30 days', value: showFinancials ? stats.due30Amount : 0, format: formatTRY, icon: CalendarClock, grad: 'from-amber-500 to-orange-600', sub: `${stats.due30} ${tr ? 'ödeme' : 'payments'}`, onClick: () => { setStatusF('Active'); setSort('next'); } },
        { label: tr ? 'Geciken ödeme' : 'Overdue', value: stats.overdue, icon: AlertTriangle, grad: stats.overdue ? 'from-rose-500 to-red-600' : 'from-emerald-500 to-teal-600', sub: stats.overdue ? (tr ? 'Hemen kontrol edin' : 'Check now') : (tr ? 'Gecikme yok' : 'All good') },
      ]} />

      {stats.cats.length > 0 && showFinancials && (
        <div className={`${cardCls} p-4`}>
          <div className="flex items-center gap-2 mb-3"><TrendingUp size={15} className="text-indigo-500" /><p className="text-sm font-bold text-slate-800 dark:text-slate-100 flex-1">{tr ? 'Kategoriye göre aylık dağılım' : 'Monthly by category'}</p><span className="text-[11px] text-slate-400">{formatTRY(stats.monthly)}</span></div>
          <div className="h-3 rounded-full overflow-hidden flex bg-slate-100 dark:bg-slate-800">
            {stats.cats.map(([c, v], i) => <div key={c} title={`${c}: ${formatTRY(v)}`} className={`${CAT_COLORS[i % CAT_COLORS.length]} h-full transition-all duration-700 first:rounded-l-full last:rounded-r-full`} style={{ width: `${(v / (stats.monthly || 1)) * 100}%` }} />)}
          </div>
          <div className="flex flex-wrap gap-x-4 gap-y-1.5 mt-3">
            {stats.cats.map(([c, v], i) => (
              <button key={c} onClick={() => setCatF(catF === c ? 'all' : c)} className={`text-[11px] inline-flex items-center gap-1.5 rounded-md px-1 -mx-1 ${catF === c ? 'bg-indigo-50 dark:bg-indigo-500/10' : ''}`}>
                <span className={`w-2.5 h-2.5 rounded-sm ${CAT_COLORS[i % CAT_COLORS.length]}`} /><span className="font-semibold text-slate-600 dark:text-slate-300">{c}</span><span className="text-slate-400">{formatTRY(v)} · %{Math.round((v / (stats.monthly || 1)) * 100)}</span>
              </button>
            ))}
          </div>
        </div>
      )}

      <div className={`${cardCls} p-3 flex flex-col lg:flex-row gap-2`}>
        <Segmented<'Active' | 'Cancelled' | 'all'> value={statusF} onChange={setStatusF} options={[{ value: 'Active', label: <>{tr ? 'Aktif' : 'Active'} <span className="text-[10px] opacity-60">{active.length}</span></> }, { value: 'Cancelled', label: tr ? 'İptal' : 'Cancelled' }, { value: 'all', label: tr ? 'Tümü' : 'All' }]} />
        <SearchBox value={search} onChange={setSearch} placeholder={tr ? 'Hizmet, sağlayıcı ara…' : 'Search…'} />
        <select value={catF} onChange={e => setCatF(e.target.value)} className={selectSm}><option value="all">{tr ? 'Tüm kategoriler' : 'All categories'}</option>{categories.map(c => <option key={c} value={c}>{c}</option>)}</select>
        <select value={sort} onChange={e => setSort(e.target.value as any)} className={selectSm}><option value="next">{tr ? 'Ödeme tarihine göre' : 'By due date'}</option><option value="cost">{tr ? 'Maliyete göre' : 'By cost'}</option><option value="name">{tr ? 'Ada göre' : 'By name'}</option></select>
        <button onClick={openNew} className={btnPrimary}><Plus size={16} />{tr ? 'Abonelik ekle' : 'Add'}</button>
      </div>

      <div className={`${cardCls} overflow-hidden`}>
        {list.length === 0 ? <EmptyState icon={CreditCard} text={tr ? 'Abonelik bulunamadı' : 'No subscriptions'} action={<button onClick={openNew} className={btnPrimary}><Plus size={15} />{tr ? 'Abonelik ekle' : 'Add'}</button>} /> : (
          <div key={statusF + catF + sort} className="divide-y divide-slate-100 dark:divide-slate-800 pc-stagger">
            {list.map(s => {
              const share = stats.monthly ? (monthlyTRY(s) / stats.monthly) * 100 : 0;
              const d = dayDiff(s.nextBillingDate);
              return (
                <div key={s.id} className={`grid grid-cols-12 gap-3 items-center px-4 py-3 hover:bg-slate-50/70 dark:hover:bg-white/[0.02] ${s.status !== 'Active' ? 'opacity-60' : ''}`}>
                  <button onClick={() => { setTouched(false); setForm({ ...s }); }} className="col-span-12 md:col-span-4 flex items-center gap-3 min-w-0 text-left group">
                    <Avatar name={s.name} />
                    <div className="min-w-0"><p className="text-sm font-semibold text-slate-800 dark:text-slate-100 truncate group-hover:text-indigo-600">{s.name}</p><p className="text-[11px] text-slate-400 truncate">{[s.provider, s.category].filter(Boolean).join(' · ')}{s.documentUrl ? ' · 📎' : ''}</p></div>
                  </button>
                  <div className="col-span-6 md:col-span-2">{dueChip(s)}<p className="text-[10px] text-slate-400 mt-0.5">{s.nextBillingDate} · {s.billingCycle}</p></div>
                  <div className="col-span-6 md:col-span-2">
                    <p className="text-sm font-bold text-slate-900 dark:text-white text-right md:text-left">{show(s.amount, s.currency)}</p>
                    {s.status === 'Active' && <div className="mt-1 hidden md:block"><GrowBar value={share} className="bg-indigo-400" /><p className="text-[10px] text-slate-400 mt-0.5">{showFinancials ? `${formatTRY(monthlyTRY(s))}/${tr ? 'ay' : 'mo'}` : ''} · %{Math.round(share)}</p></div>}
                  </div>
                  <div className="col-span-12 md:col-span-4 flex justify-end items-center gap-1">
                    {s.status === 'Active' && (d ?? 99) <= 7 && <button disabled={busyId === s.id} onClick={() => pay(s)} className="h-8 px-2.5 rounded-lg text-[11px] font-semibold text-emerald-700 bg-emerald-50 hover:bg-emerald-100 dark:bg-emerald-500/10 dark:text-emerald-300 inline-flex items-center gap-1 disabled:opacity-50">{busyId === s.id ? <Loader2 size={12} className="animate-spin" /> : <CheckCircle2 size={12} />}{tr ? 'Ödendi' : 'Paid'}</button>}
                    {s.status === 'Active' && (d ?? 99) <= 7 && <button onClick={() => snooze(s)} title={tr ? '3 gün ertele' : 'Snooze 3 days'} className="p-1.5 rounded-lg text-slate-400 hover:text-amber-600 hover:bg-amber-50 dark:hover:bg-white/5"><BellOff size={14} /></button>}
                    {s.documentUrl && <a href={s.documentUrl} target="_blank" rel="noreferrer" title={s.documentName || (tr ? 'Belge' : 'Document')} className="p-1.5 rounded-lg text-slate-400 hover:text-indigo-600 hover:bg-indigo-50 dark:hover:bg-white/5"><FileText size={14} /></a>}
                    <button onClick={() => toggle(s)} title={s.status === 'Active' ? (tr ? 'İptal et' : 'Cancel') : (tr ? 'Yeniden başlat' : 'Reactivate')} className="p-1.5 rounded-lg text-slate-400 hover:text-amber-600 hover:bg-amber-50 dark:hover:bg-white/5">{s.status === 'Active' ? <PauseCircle size={15} /> : <PlayCircle size={15} />}</button>
                    <button onClick={() => { setTouched(false); setForm({ ...s }); }} className="p-1.5 rounded-lg text-slate-400 hover:text-indigo-600 hover:bg-indigo-50 dark:hover:bg-white/5"><Edit2 size={14} /></button>
                    <DeleteButton language={language} onConfirm={async () => { await onDeleteSubscription(s.id); toast(tr ? 'Abonelik silindi' : 'Deleted', 'info'); }} />
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>

      <Sheet open={!!form} language={language} title={form?.id ? (tr ? 'Aboneliği düzenle' : 'Edit subscription') : (tr ? 'Yeni abonelik' : 'New subscription')} subtitle={form?.id ? form.provider : undefined} icon={CreditCard} onClose={() => setForm(null)} onSubmit={save} saving={saving}
        footerLeft={formMonthly > 0 && showFinancials ? <span className="text-slate-400">{tr ? 'Aylık' : 'Monthly'} <b className="text-slate-800 dark:text-slate-100">{formatTRY(formMonthly)}</b> · {tr ? 'yıllık' : 'yearly'} <b className="text-slate-800 dark:text-slate-100">{formatTRY(formMonthly * 12)}</b></span> : undefined}>
        {form && <>
          <div className="grid grid-cols-2 gap-4">
            <Field label={tr ? 'Hizmet adı' : 'Service'} required error={fe('name')}><input autoFocus className={inputCls(fe('name'))} value={form.name || ''} onChange={e => setForm({ ...form, name: e.target.value })} placeholder="Örn: Figma Professional" /></Field>
            <Field label={tr ? 'Sağlayıcı' : 'Provider'}><input className={inputCls()} value={form.provider || ''} onChange={e => setForm({ ...form, provider: e.target.value })} placeholder="Figma Inc." /></Field>
          </div>
          <Field label={tr ? 'Kategori' : 'Category'}>
            <div className="flex flex-wrap gap-1.5">
              {categories.map(c => <button key={c} type="button" onClick={() => setForm({ ...form, category: c })} className={`h-8 px-2.5 rounded-lg text-xs font-semibold border transition-all ${form.category === c ? 'bg-indigo-600 border-indigo-600 text-white' : 'border-slate-200 dark:border-slate-700 text-slate-600 dark:text-slate-300 hover:border-indigo-300'}`}>{c}</button>)}
              <input className="pc-plain-input h-8 px-2.5 rounded-lg border border-dashed border-slate-300 dark:border-slate-700 bg-transparent text-xs outline-none focus:border-indigo-400 w-32" placeholder={tr ? '+ yeni kategori' : '+ new'} onKeyDown={e => { const v = (e.target as HTMLInputElement).value.trim(); if (e.key === 'Enter' && v) { e.preventDefault(); setForm({ ...form, category: v }); (e.target as HTMLInputElement).value = ''; } }} />
            </div>
          </Field>
          <div className="grid grid-cols-3 gap-4">
            <Field label={tr ? 'Tutar' : 'Amount'} required error={fe('amount')} className="col-span-2"><input type="number" min={0} step="0.01" className={inputCls(fe('amount')) + ' font-bold'} value={form.amount || ''} onChange={e => setForm({ ...form, amount: Number(e.target.value) })} /></Field>
            <Field label={tr ? 'Para birimi' : 'Currency'}><select className={inputCls()} value={form.currency} onChange={e => setForm({ ...form, currency: e.target.value as Currency })}>{Object.values(Currency).map(c => <option key={c} value={c}>{c}</option>)}</select></Field>
          </div>
          <Field label={tr ? 'Ödeme periyodu' : 'Billing cycle'}><Segmented<BillingCycle> value={form.billingCycle || BillingCycle.MONTHLY} onChange={v => setForm({ ...form, billingCycle: v })} options={[{ value: BillingCycle.MONTHLY, label: tr ? 'Aylık' : 'Monthly' }, { value: BillingCycle.YEARLY, label: tr ? 'Yıllık' : 'Yearly' }]} /></Field>
          <div className="grid grid-cols-2 gap-4">
            <Field label={tr ? 'Başlangıç' : 'Start date'}><input type="date" className={inputCls()} value={form.startDate || ''} onChange={e => setForm({ ...form, startDate: e.target.value })} /></Field>
            <Field label={tr ? 'Sonraki ödeme' : 'Next payment'} required error={fe('next')}><input type="date" className={inputCls(fe('next'))} value={form.nextBillingDate || ''} onChange={e => setForm({ ...form, nextBillingDate: e.target.value })} /></Field>
          </div>
          <Field label={tr ? 'Fatura / sözleşme' : 'Invoice / contract'}>
            {form.documentUrl ? <div className="flex items-center gap-2 h-11"><a href={form.documentUrl} target="_blank" rel="noreferrer" className="text-sm font-semibold text-indigo-600 hover:underline inline-flex items-center gap-1 truncate"><FileText size={14} />{form.documentName || (tr ? 'Belgeyi aç' : 'Open')}<ExternalLink size={11} /></a><button type="button" onClick={() => setForm({ ...form, documentUrl: undefined, documentName: undefined })} className="text-xs text-slate-400 hover:text-rose-500">{tr ? 'kaldır' : 'remove'}</button></div>
              : <label className={btnGhost + ' w-full cursor-pointer !h-11'}>{uploading ? <Loader2 size={15} className="animate-spin" /> : <Upload size={15} />}{tr ? 'Dosya yükle' : 'Upload'}<input type="file" className="hidden" onChange={e => upload(e.target.files?.[0])} /></label>}
          </Field>
          {form.id && <Field label={tr ? 'Durum' : 'Status'}><Segmented<'Active' | 'Cancelled'> value={form.status || 'Active'} onChange={v => setForm({ ...form, status: v })} options={[{ value: 'Active', label: tr ? 'Aktif' : 'Active' }, { value: 'Cancelled', label: tr ? 'İptal edildi' : 'Cancelled' }]} /></Field>}
          {form.id && (
            <div>
              <p className="text-xs font-semibold text-slate-500 mb-2 flex items-center gap-1.5"><History size={13} />{tr ? 'Ödeme geçmişi' : 'Payment history'}</p>
              {history.length === 0 ? <p className="text-xs text-slate-400">{tr ? 'Bu sayfadan "Ödendi" ile kaydedilmiş ödeme yok.' : 'No recorded payments.'}</p> : (
                <div className="rounded-xl border border-slate-100 dark:border-slate-800 divide-y divide-slate-100 dark:divide-slate-800">
                  {history.slice(0, 12).map(t => <div key={t.id} className="flex items-center justify-between px-3 py-2 text-xs"><span className="text-slate-500">{t.date}</span><span className="font-semibold text-slate-700 dark:text-slate-200">{show(t.amount, t.currency)}</span></div>)}
                  <div className="flex items-center justify-between px-3 py-2 text-xs bg-slate-50 dark:bg-white/[0.03]"><span className="text-slate-500">{tr ? `Toplam (${history.length} ödeme)` : 'Total'}</span><b className="text-slate-800 dark:text-slate-100">{showFinancials ? formatTRY(history.reduce((a, t) => a + toTRY(t.amount, t.currency, rates), 0)) : '••••'}</b></div>
                </div>
              )}
            </div>
          )}
        </>}
      </Sheet>
    </div>
  );
};

export default SubscriptionsView;
