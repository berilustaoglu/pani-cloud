import React, { useEffect, useMemo, useState } from 'react';
import { X, Briefcase, Edit2, Shield, LayoutDashboard, ListChecks, Wallet, FileText, Download, CheckCircle2, AlertTriangle, Clock, Zap, Copy, ExternalLink, Plus, Globe, Star, RotateCcw, Link2, Eye, PauseCircle, PlayCircle, BellOff } from 'lucide-react';
import { Project, Task, TaskStatus, User, UserRole, Transaction, PortalSettings } from '../types';
import ProjectDetailSummary from './ProjectDetailSummary';
import ProjectHoldSheet, { CLEAR_HOLD } from './ProjectHoldSheet';
import ModalPortal from './ModalPortal';
import { DeleteButton, Segmented, Avatar, EmptyState, money, inputCls, btnGhost } from './ui/Kit';
import { GrowBar } from './ui/Motion';
import { localISO, dayDiff, isHoldExpired } from '../services/insights';
import { toast } from '../services/toast';

interface Props {
  project: Project;
  tasks: Task[];
  users: User[];
  language: 'tr' | 'en';
  showFinancials: boolean;
  canManage: boolean;
  onClose: () => void;
  onEdit: (p: Project) => void;
  onDelete?: (id: string) => Promise<void>;
  onUpdateProject: (p: Project) => Promise<void>;
  onUpsertTask?: (t: Task) => Promise<void>;
  onAddTransaction: (t: Transaction) => Promise<void>;
  onDeleteTransaction?: (id: string) => Promise<void>;
  onOpenTasks?: () => void;
}

type Tab = 'overview' | 'tasks' | 'payments' | 'docs' | 'portal';
const PORTAL_DEFAULTS: PortalSettings = { showTasks: true, showFinancials: true, showTeam: true, isPublic: true, themeColor: '#6366f1' };
const STATUS: Record<string, { tr: string; en: string; chip: string }> = {
  Active: { tr: 'Aktif', en: 'Active', chip: 'bg-emerald-50 text-emerald-700 dark:bg-emerald-500/10 dark:text-emerald-300' },
  Revizyonda: { tr: 'Revizyonda', en: 'In revision', chip: 'bg-amber-50 text-amber-700 dark:bg-amber-500/10 dark:text-amber-300' },
  'On Hold': { tr: 'Beklemede', en: 'On hold', chip: 'bg-slate-100 text-slate-600 dark:bg-white/5 dark:text-slate-300' },
  Completed: { tr: 'Tamamlandı', en: 'Completed', chip: 'bg-indigo-50 text-indigo-700 dark:bg-indigo-500/10 dark:text-indigo-300' },
};
const TASK_STATUS: Record<string, { tr: string; en: string; cls: string }> = {
  [TaskStatus.TODO]: { tr: 'Başlanmadı', en: 'To do', cls: 'bg-slate-100 text-slate-600 dark:bg-white/5 dark:text-slate-300' },
  [TaskStatus.DOING]: { tr: 'Devam ediyor', en: 'In progress', cls: 'bg-sky-50 text-sky-700 dark:bg-sky-500/10 dark:text-sky-300' },
  [TaskStatus.BLOCKED]: { tr: 'Takıldı', en: 'Blocked', cls: 'bg-orange-50 text-orange-700 dark:bg-orange-500/10 dark:text-orange-300' },
  [TaskStatus.DONE]: { tr: 'Tamamlandı', en: 'Done', cls: 'bg-emerald-50 text-emerald-700 dark:bg-emerald-500/10 dark:text-emerald-300' },
};

const ProjectDetailPanel: React.FC<Props> = ({ project: p, tasks, users, language, showFinancials, canManage, onClose, onEdit, onDelete, onUpdateProject, onUpsertTask, onAddTransaction, onDeleteTransaction, onOpenTasks }) => {
  const tr = language === 'tr';
  const today = localISO();
  const [tab, setTab] = useState<Tab>('overview');
  const [holdOpen, setHoldOpen] = useState(false);
  const [progress, setProgress] = useState(p.progress || 0);
  const [busy, setBusy] = useState<string | null>(null);
  const [portalMsg, setPortalMsg] = useState(p.portalSettings?.customMessage || '');
  useEffect(() => { setProgress(p.progress || 0); }, [p.progress]);
  useEffect(() => { const k = (e: KeyboardEvent) => { if (e.key === 'Escape') onClose(); }; window.addEventListener('keydown', k); return () => window.removeEventListener('keydown', k); }, [onClose]);

  const show = (n: number) => (showFinancials ? money(n, p.currency, 0) : '••••');
  const projectTasks = useMemo(() => tasks.filter(t => t.projectId === p.id).sort((a, b) => (Number(a.status === TaskStatus.DONE) - Number(b.status === TaskStatus.DONE)) || (a.deadline || '9').localeCompare(b.deadline || '9')), [tasks, p.id]);
  const inst = p.installments || [];
  const total = p.totalAmountWithTax || p.budget || 0;
  const collected = inst.length ? inst.reduce((a, i) => a + (i.isPaid ? (i.paidAmount ?? i.amount) : (i.paidAmount || 0)), 0) : 0;
  const overdueInst = inst.filter(i => !i.isPaid && i.dueDate && i.dueDate < today);
  const docs = [...(p.contracts || []), ...(p.documents || [])];
  const pendingDocs = docs.filter(d => d.approvalStatus === 'pending').length;
  const portal = { ...PORTAL_DEFAULTS, ...(p.portalSettings || {}) };
  const portalUrl = `${window.location.origin}${window.location.pathname}?portal=${p.id}&mode=standalone`;
  const fb = p.clientFeedback || [];
  const st = STATUS[p.status] || STATUS.Active;

  // ---------- İşlemler ----------
  const save = async (patch: Partial<Project>, msg?: string) => {
    try { await onUpdateProject({ ...p, ...patch }); if (msg) toast.success(msg); } catch (e: any) { toast.error(e?.message || 'Hata'); }
  };
  const allPaid = (list = inst) => list.length === 0 || list.every(i => i.isPaid);
  const commitProgress = async (v: number) => {
    if (v === (p.progress || 0)) return;
    const status = v === 100 && allPaid() ? 'Completed' : (p.status === 'Completed' && v < 100 ? 'Active' : p.status);
    await save({ progress: v, status }, status === 'Completed' && p.status !== 'Completed' ? (tr ? 'İlerleme %100 ve ödemeler tamam — proje tamamlandı 🎉' : 'Project completed 🎉') : undefined);
  };
  const syncFromTasks = async () => {
    if (!projectTasks.length) { toast.warning(tr ? 'Bu projede görev yok' : 'No tasks'); return; }
    const v = Math.round((projectTasks.filter(t => t.status === TaskStatus.DONE).length / projectTasks.length) * 100);
    setProgress(v); await commitProgress(v);
    toast.success(tr ? `İlerleme görevlere göre %${v} yapıldı` : `Progress set to ${v}%`);
  };
  const txId = (instId: string) => `tr_inst_${p.id}_${instId}`;
  const collect = async (idx: number) => {
    const i = inst[idx]; setBusy(i.id);
    try {
      const list = inst.map((x, j) => j === idx ? { ...x, isPaid: true } : x);
      await onUpdateProject({ ...p, installments: list, status: allPaid(list) && (p.progress || 0) === 100 ? 'Completed' : p.status });
      await onAddTransaction({ id: txId(i.id), type: 'Income', amount: i.amount, currency: p.currency, category: tr ? 'Proje Taksit Ödemesi' : 'Project Installment Payment', date: today, description: `${p.name} - ${i.label} tahsilatı.`, projectId: p.id });
      toast.success(tr ? `${i.label} tahsil edildi · gelire işlendi` : 'Collected');
    } finally { setBusy(null); }
  };
  const uncollect = async (idx: number) => {
    const i = inst[idx]; setBusy(i.id);
    try {
      await onUpdateProject({ ...p, installments: inst.map((x, j) => j === idx ? { ...x, isPaid: false } : x), status: p.status === 'Completed' ? 'Active' : p.status });
      if (onDeleteTransaction) { try { await onDeleteTransaction(txId(i.id)); } catch { /* eski kayıtlarda farklı kimlik olabilir */ } }
      toast(tr ? `${i.label} tahsilatı geri alındı${onDeleteTransaction ? ' · gelir kaydı silindi' : ''}` : 'Reverted', 'info');
    } finally { setBusy(null); }
  };
  const setTaskStatus = async (t: Task, status: TaskStatus) => { if (onUpsertTask) await onUpsertTask({ ...t, status, ...(status !== TaskStatus.BLOCKED ? { blockedReason: '' } : {}) }); };
  const assign = async (t: Task, uid: string) => { if (onUpsertTask && uid && !(t.assignedTo || []).includes(uid)) await onUpsertTask({ ...t, assignedTo: [...(t.assignedTo || []), uid] }); };
  const unassign = async (t: Task, uid: string) => { if (onUpsertTask) await onUpsertTask({ ...t, assignedTo: (t.assignedTo || []).filter(x => x !== uid) }); };
  const setPortal = (patch: Partial<PortalSettings>) => save({ portalSettings: { ...portal, ...patch } });
  const openDoc = (d: { url?: string; name: string }) => { if (d.url) window.open(d.url, '_blank', 'noopener'); else toast.warning(tr ? 'Bu belgenin dosyası yüklenmemiş' : 'No file attached'); };

  const tabs: { id: Tab; label: string; icon: React.ElementType; badge?: number; warn?: boolean }[] = [
    { id: 'overview', label: tr ? 'Genel' : 'Overview', icon: LayoutDashboard },
    { id: 'tasks', label: tr ? 'Görevler' : 'Tasks', icon: ListChecks, badge: projectTasks.filter(t => t.status !== TaskStatus.DONE).length },
    ...(showFinancials ? [{ id: 'payments' as Tab, label: tr ? 'Ödemeler' : 'Payments', icon: Wallet, badge: overdueInst.length, warn: overdueInst.length > 0 }] : []),
    { id: 'docs', label: tr ? 'Belgeler' : 'Documents', icon: FileText, badge: pendingDocs },
    ...(canManage ? [{ id: 'portal' as Tab, label: tr ? 'Portal' : 'Portal', icon: Shield }] : []),
  ];

  const Toggle = ({ on, onClick, label }: { on: boolean; onClick: () => void; label: string }) => (
    <button onClick={onClick} className="w-full flex items-center justify-between py-2.5 text-sm text-slate-700 dark:text-slate-200">
      {label}<span className={`w-10 h-6 rounded-full p-0.5 transition-colors ${on ? 'bg-indigo-600' : 'bg-slate-200 dark:bg-slate-700'}`}><span className={`block w-5 h-5 rounded-full bg-white shadow transition-transform ${on ? 'translate-x-4' : ''}`} /></span>
    </button>
  );

  return (
    <ModalPortal>
      <div className="fixed inset-0 z-[1000] flex justify-end" role="dialog" aria-modal="true">
        <div className="absolute inset-0 bg-slate-950/50 backdrop-blur-sm pc-backdrop" onClick={onClose} />
        <aside className="relative h-full w-full max-w-3xl bg-white dark:bg-slate-900 shadow-2xl flex flex-col animate-in slide-in-from-right duration-300 sm:rounded-l-[28px] overflow-hidden" style={{ paddingTop: 'env(safe-area-inset-top, 0px)' }}>
          {/* Başlık */}
          <div className="px-5 sm:px-6 pt-5 pb-4 border-b border-slate-100 dark:border-slate-800">
            <div className="flex items-start gap-3">
              <span className={`w-12 h-12 shrink-0 rounded-2xl text-white flex items-center justify-center shadow-lg ${overdueInst.length ? 'bg-gradient-to-br from-rose-500 to-red-600' : 'bg-gradient-to-br from-indigo-500 to-violet-600'}`}><Briefcase size={20} /></span>
              <div className="flex-1 min-w-0">
                <h2 className="text-xl font-black text-slate-900 dark:text-white leading-tight break-words">{p.name}</h2>
                <p className="text-sm text-slate-500 truncate">{p.client}{p.clientContactName ? ` · ${p.clientContactName}` : ''}</p>
              </div>
              <div className="flex items-center gap-1 shrink-0">
                <button onClick={() => onEdit(p)} title={tr ? 'Düzenle' : 'Edit'} className="p-2 rounded-xl text-slate-400 hover:text-indigo-600 hover:bg-indigo-50 dark:hover:bg-white/5"><Edit2 size={17} /></button>
                {onDelete && canManage && <DeleteButton language={language} confirmText={tr ? 'Projeyi sil' : 'Delete project'} onConfirm={async () => { await onDelete(p.id); toast(tr ? 'Proje silindi' : 'Deleted', 'info'); onClose(); }} />}
                <button onClick={onClose} className="p-2 rounded-xl text-slate-400 hover:text-slate-700 hover:bg-slate-100 dark:hover:bg-white/5" aria-label="Close"><X size={20} /></button>
              </div>
            </div>
            {/* Durum + ilerleme */}
            <div className="mt-4 flex flex-col sm:flex-row sm:items-center gap-3">
              {canManage ? (
                <Segmented<string> value={p.status} onChange={v => v === 'On Hold' ? setHoldOpen(true) : save({ status: v as Project['status'], ...(p.status === 'On Hold' ? CLEAR_HOLD : {}) }, tr ? `Durum: ${STATUS[v].tr}` : 'Status updated')} options={Object.entries(STATUS).map(([k, v]) => ({ value: k, label: tr ? v.tr : v.en }))} />
              ) : <span className={`self-start text-xs font-semibold px-2 py-1 rounded-lg ${st.chip}`}>{tr ? st.tr : st.en}</span>}
              <div className="flex-1 flex items-center gap-3 min-w-[200px]">
                <div className="relative flex-1 h-2.5 rounded-full bg-slate-100 dark:bg-slate-800 overflow-hidden">
                  <div className="absolute inset-y-0 left-0 rounded-full bg-gradient-to-r from-indigo-500 to-violet-500 transition-all duration-300" style={{ width: `${progress}%` }} />
                  {canManage && <input type="range" min={0} max={100} step={5} value={progress} onChange={e => setProgress(Number(e.target.value))} onMouseUp={() => commitProgress(progress)} onTouchEnd={() => commitProgress(progress)} onKeyUp={() => commitProgress(progress)} aria-label={tr ? 'İlerleme' : 'Progress'} className="absolute inset-0 w-full h-full opacity-0 cursor-pointer" />}
                </div>
                <span className="text-sm font-black text-slate-900 dark:text-white w-11 text-right">%{progress}</span>
                {canManage && <button onClick={syncFromTasks} title={tr ? 'Görevlere göre hesapla' : 'Sync from tasks'} className="p-1.5 rounded-lg text-slate-400 hover:text-indigo-600 hover:bg-indigo-50 dark:hover:bg-white/5"><Zap size={15} /></button>}
              </div>
            </div>
          </div>

          {p.status === 'On Hold' && (() => {
            const expired = isHoldExpired(p);
            const left = p.holdUntil ? dayDiff(p.holdUntil) : null;
            return (
              <div className={`mx-5 sm:mx-6 mt-3 p-3 rounded-2xl flex flex-wrap items-center gap-3 animate-in fade-in slide-in-from-top-1 duration-300 ${expired ? 'bg-rose-50 dark:bg-rose-500/10' : 'bg-amber-50 dark:bg-amber-500/10'}`}>
                <span className={`w-9 h-9 shrink-0 rounded-xl text-white flex items-center justify-center ${expired ? 'bg-rose-500' : 'bg-amber-500'}`}>{expired ? <AlertTriangle size={16} /> : <PauseCircle size={16} />}</span>
                <div className="flex-1 min-w-[180px]">
                  <p className={`text-sm font-bold ${expired ? 'text-rose-700 dark:text-rose-300' : 'text-amber-800 dark:text-amber-200'}`}>
                    {expired ? (tr ? 'Askı süresi doldu' : 'Hold period ended')
                      : p.holdUntil ? (tr ? `${new Date(p.holdUntil + 'T00:00').toLocaleDateString('tr-TR', { day: 'numeric', month: 'long' })} tarihine kadar askıda` : `On hold until ${p.holdUntil}`)
                      : (tr ? 'Süresiz askıda' : 'On hold indefinitely')}
                    {!expired && left !== null && <span className="font-semibold opacity-70"> · {left === 0 ? (tr ? 'bugün bitiyor' : 'ends today') : (tr ? `${left} gün kaldı` : `${left}d left`)}</span>}
                  </p>
                  <p className="text-[11px] text-slate-500 dark:text-slate-400 flex items-center gap-1 flex-wrap">
                    {!expired && <><BellOff size={11} />{tr ? 'Uyarılar susturuldu' : 'Alerts muted'}</>}
                    {expired && (tr ? 'Uyarılar yeniden açıldı. Projeyi devam ettirin ya da askıyı uzatın.' : 'Alerts are back on.')}
                    {p.holdReason && <span className="truncate">· {p.holdReason}</span>}
                  </p>
                </div>
                {canManage && (
                  <div className="flex gap-2">
                    <button onClick={() => setHoldOpen(true)} className="h-9 px-3 rounded-xl text-xs font-semibold border border-amber-300/70 text-amber-800 dark:text-amber-200 hover:bg-amber-100 dark:hover:bg-amber-500/10">{tr ? 'Uzat' : 'Extend'}</button>
                    <button onClick={() => save({ status: 'Active', ...CLEAR_HOLD }, tr ? 'Proje yeniden aktif' : 'Project resumed')} className="h-9 px-3 rounded-xl text-xs font-semibold bg-emerald-600 hover:bg-emerald-500 text-white inline-flex items-center gap-1.5"><PlayCircle size={14} />{tr ? 'Devam ettir' : 'Resume'}</button>
                  </div>
                )}
              </div>
            );
          })()}

          {/* Sekmeler */}
          <div className="px-5 sm:px-6 pt-3 flex gap-1 overflow-x-auto custom-scrollbar border-b border-slate-100 dark:border-slate-800">
            {tabs.map(t => { const I = t.icon; const on = tab === t.id; return (
              <button key={t.id} onClick={() => setTab(t.id)} className={`relative h-10 px-3 text-sm font-semibold inline-flex items-center gap-1.5 shrink-0 transition-colors ${on ? 'text-indigo-600 dark:text-indigo-300' : 'text-slate-500 hover:text-slate-800 dark:hover:text-slate-200'}`}>
                <I size={15} />{t.label}{!!t.badge && <span className={`text-[10px] min-w-[16px] h-4 px-1 rounded-full flex items-center justify-center ${t.warn ? 'bg-rose-500 text-white' : 'bg-slate-200 dark:bg-slate-700 text-slate-700 dark:text-slate-200'}`}>{t.badge}</span>}
                {on && <span className="absolute inset-x-2 -bottom-px h-0.5 rounded-full bg-indigo-600" />}
              </button>); })}
          </div>

          <div key={tab} className="flex-1 overflow-y-auto custom-scrollbar p-5 sm:p-6 animate-in fade-in duration-200" style={{ paddingBottom: 'calc(1.5rem + env(safe-area-inset-bottom, 0px))' }}>
            {tab === 'overview' && <>
              {overdueInst.length > 0 && showFinancials && (
                <button onClick={() => setTab('payments')} className="w-full mb-4 flex items-center gap-3 p-3 rounded-2xl bg-rose-50 dark:bg-rose-500/10 text-left">
                  <AlertTriangle size={18} className="text-rose-600 shrink-0" />
                  <span className="flex-1 text-sm text-rose-800 dark:text-rose-200"><b>{overdueInst.length} {tr ? 'taksitin vadesi geçti' : 'overdue installments'}</b> · {show(overdueInst.reduce((a, i) => a + i.amount, 0))}</span>
                  <span className="text-xs font-semibold text-rose-700">{tr ? 'Ödemeler' : 'Payments'} →</span>
                </button>
              )}
              <ProjectDetailSummary project={{ ...p, progress }} tasks={tasks} users={users} language={language} />
              {showFinancials && (
                <div className="grid grid-cols-3 gap-2">
                  <div className="rounded-2xl bg-slate-50 dark:bg-white/[0.03] p-3"><p className="text-[11px] text-slate-400">{tr ? 'Bütçe' : 'Budget'}{p.taxRate ? ` (KDV %${p.taxRate} dahil)` : ''}</p><p className="text-lg font-black text-slate-900 dark:text-white">{show(total)}</p></div>
                  <div className="rounded-2xl bg-emerald-50/70 dark:bg-emerald-500/10 p-3"><p className="text-[11px] text-emerald-700 dark:text-emerald-300">{tr ? 'Tahsil edilen' : 'Collected'}</p><p className="text-lg font-black text-emerald-700 dark:text-emerald-300">{inst.length ? show(collected) : '—'}</p></div>
                  <div className="rounded-2xl bg-slate-50 dark:bg-white/[0.03] p-3"><p className="text-[11px] text-slate-400">{tr ? 'Kalan' : 'Remaining'}</p><p className="text-lg font-black text-slate-900 dark:text-white">{inst.length ? show(Math.max(0, total - collected)) : '—'}</p></div>
                </div>
              )}
            </>}

            {tab === 'tasks' && (
              <div className="space-y-2">
                <div className="flex items-center justify-between mb-1">
                  <p className="text-sm text-slate-500">{projectTasks.filter(t => t.status === TaskStatus.DONE).length}/{projectTasks.length} {tr ? 'tamamlandı' : 'done'}</p>
                  {onOpenTasks && <button onClick={onOpenTasks} className="text-xs font-semibold text-indigo-600 hover:underline inline-flex items-center gap-1">{tr ? 'Görev yönetiminde aç' : 'Open in tasks'}<ExternalLink size={11} /></button>}
                </div>
                {projectTasks.length === 0 ? <EmptyState icon={ListChecks} text={tr ? 'Bu projede henüz görev yok' : 'No tasks yet'} /> : projectTasks.map(t => { const S = TASK_STATUS[t.status] || TASK_STATUS[TaskStatus.TODO]; const late = t.status !== TaskStatus.DONE && t.deadline && t.deadline < today; return (
                  <div key={t.id} className={`rounded-2xl border p-3 ${late ? 'border-rose-200 dark:border-rose-500/30' : 'border-slate-100 dark:border-slate-800'}`}>
                    <div className="flex items-start gap-3">
                      <div className="flex-1 min-w-0">
                        <p className={`text-sm font-semibold ${t.status === TaskStatus.DONE ? 'text-slate-400 line-through' : 'text-slate-800 dark:text-slate-100'}`}>{t.title}</p>
                        <p className={`text-[11px] flex items-center gap-1 ${late ? 'text-rose-600 font-semibold' : 'text-slate-400'}`}><Clock size={11} />{t.deadline ? (late ? (tr ? `${-dayDiff(t.deadline)!} gün gecikti` : 'overdue') : new Date(t.deadline + 'T00:00').toLocaleDateString(tr ? 'tr-TR' : 'en-US', { day: 'numeric', month: 'short' })) : '—'}{t.status === TaskStatus.BLOCKED && t.blockedReason ? <span className="text-orange-600"> · ⛔ {t.blockedReason}</span> : null}</p>
                      </div>
                      {onUpsertTask && canManage
                        ? <select value={t.status} onChange={e => setTaskStatus(t, e.target.value as TaskStatus)} className={`h-7 px-2 rounded-lg text-[11px] font-semibold border-0 outline-none cursor-pointer ${S.cls}`}>{Object.entries(TASK_STATUS).map(([k, v]) => <option key={k} value={k}>{tr ? v.tr : v.en}</option>)}</select>
                        : <span className={`text-[11px] font-semibold px-2 py-0.5 rounded-md ${S.cls}`}>{tr ? S.tr : S.en}</span>}
                    </div>
                    <div className="mt-2 flex flex-wrap items-center gap-1.5">
                      {(t.assignedTo || []).map(uid => { const u = users.find(x => x.id === uid); return (
                        <span key={uid} className="h-7 pl-0.5 pr-1.5 rounded-full bg-slate-100 dark:bg-white/5 text-[11px] font-semibold text-slate-700 dark:text-slate-200 inline-flex items-center gap-1">
                          <Avatar name={u?.name || '?'} src={u?.avatar} size="w-6 h-6" className="!rounded-full" />{u?.name?.split(' ')[0] || '—'}
                          {onUpsertTask && canManage && <button onClick={() => unassign(t, uid)} className="text-slate-400 hover:text-rose-500"><X size={11} /></button>}
                        </span>); })}
                      {onUpsertTask && canManage && (
                        <select value="" onChange={e => assign(t, e.target.value)} className="h-7 px-2 rounded-full border border-dashed border-slate-300 dark:border-slate-700 bg-transparent text-[11px] font-semibold text-slate-500 outline-none cursor-pointer">
                          <option value="">{tr ? '+ Kişi ekle' : '+ Assign'}</option>
                          {users.filter(u => u.role !== UserRole.ADMIN && !(t.assignedTo || []).includes(u.id)).map(u => <option key={u.id} value={u.id}>{u.name}</option>)}
                        </select>
                      )}
                    </div>
                  </div>); })}
              </div>
            )}

            {tab === 'payments' && showFinancials && (
              <div className="space-y-3">
                <div className="rounded-2xl bg-slate-50 dark:bg-white/[0.03] p-4">
                  <div className="flex justify-between text-sm mb-2"><span className="text-slate-500">{tr ? 'Tahsilat' : 'Collected'}</span><b className="text-slate-900 dark:text-white">{show(collected)} / {show(total)}</b></div>
                  <GrowBar value={total ? (collected / total) * 100 : 0} className="bg-emerald-500" />
                  <p className="text-[11px] text-slate-400 mt-2">{tr ? 'Ödeme tipi' : 'Payment type'}: {p.paymentType}</p>
                </div>
                {inst.length === 0 ? <EmptyState icon={Wallet} text={tr ? 'Taksit planı yok (peşin tahsilat)' : 'No installment plan'} /> : inst.map((i, idx) => { const late = !i.isPaid && i.dueDate && i.dueDate < today; const d = i.dueDate ? dayDiff(i.dueDate) : null; return (
                  <div key={i.id || idx} className={`rounded-2xl border p-3 flex items-center gap-3 ${i.isPaid ? 'border-slate-100 dark:border-slate-800 opacity-70' : late ? 'border-rose-200 bg-rose-50/40 dark:border-rose-500/30 dark:bg-rose-500/5' : 'border-slate-100 dark:border-slate-800'}`}>
                    <span className={`w-9 h-9 rounded-xl flex items-center justify-center shrink-0 ${i.isPaid ? 'bg-emerald-50 text-emerald-600 dark:bg-emerald-500/10' : late ? 'bg-rose-100 text-rose-600 dark:bg-rose-500/20' : 'bg-slate-100 text-slate-400 dark:bg-slate-800'}`}>{i.isPaid ? <CheckCircle2 size={17} /> : late ? <AlertTriangle size={16} /> : <Clock size={16} />}</span>
                    <div className="flex-1 min-w-0">
                      <p className="text-sm font-semibold text-slate-800 dark:text-slate-100 truncate">{i.label || `${idx + 1}. ${tr ? 'taksit' : 'installment'}`}</p>
                      <p className={`text-[11px] ${late ? 'text-rose-600 font-semibold' : 'text-slate-400'}`}>{i.isPaid ? (tr ? 'Tahsil edildi' : 'Paid') : late ? (tr ? `Vadesi ${-d!} gün geçti` : 'Overdue') : d === 0 ? (tr ? 'Vade bugün' : 'Due today') : `${tr ? 'Vade' : 'Due'} ${i.dueDate}`}</p>
                    </div>
                    <span className={`text-sm font-black ${i.isPaid ? 'text-emerald-600' : late ? 'text-rose-600' : 'text-slate-900 dark:text-white'}`}>{show(i.amount)}</span>
                    {i.paymentLink && !i.isPaid && <button onClick={() => { navigator.clipboard.writeText(i.paymentLink!); toast.success(tr ? 'Ödeme bağlantısı kopyalandı' : 'Copied'); }} title={tr ? 'Ödeme bağlantısını kopyala' : 'Copy pay link'} className="p-1.5 rounded-lg text-slate-400 hover:text-indigo-600"><Link2 size={14} /></button>}
                    {canManage && (i.isPaid
                      ? <DeleteButton language={language} label text={tr ? 'Geri al' : 'Undo'} confirmText={tr ? 'Tahsilatı geri al' : 'Revert'} onConfirm={() => uncollect(idx)} />
                      : <button disabled={busy === i.id} onClick={() => collect(idx)} className="h-8 px-2.5 rounded-lg text-[11px] font-semibold text-emerald-700 bg-emerald-50 hover:bg-emerald-100 dark:bg-emerald-500/10 dark:text-emerald-300 disabled:opacity-50">{tr ? 'Tahsil et' : 'Collect'}</button>)}
                  </div>); })}
              </div>
            )}

            {tab === 'docs' && (
              <div className="space-y-2">
                {docs.length === 0 ? <EmptyState icon={FileText} text={tr ? 'Belge yüklenmemiş' : 'No documents'} action={<button onClick={() => onEdit(p)} className={btnGhost}><Plus size={14} />{tr ? 'Düzenle ve belge ekle' : 'Add via edit'}</button>} /> : docs.map(d => (
                  <div key={d.id} className="rounded-2xl border border-slate-100 dark:border-slate-800 p-3 flex items-start gap-3">
                    <span className="w-9 h-9 rounded-xl bg-indigo-50 text-indigo-600 dark:bg-indigo-500/10 flex items-center justify-center shrink-0"><FileText size={16} /></span>
                    <div className="flex-1 min-w-0">
                      <p className="text-sm font-semibold text-slate-800 dark:text-slate-100 break-words">{d.name}</p>
                      <p className="text-[11px] text-slate-400">{d.type === 'contract' ? (tr ? 'Sözleşme' : 'Contract') : (d.fileType || '').toUpperCase()} · {d.uploadDate}</p>
                      {d.approvalStatus && <span className={`mt-1 inline-flex text-[11px] font-semibold px-2 py-0.5 rounded-md ${d.approvalStatus === 'approved' ? 'bg-emerald-50 text-emerald-700 dark:bg-emerald-500/10 dark:text-emerald-300' : d.approvalStatus === 'rejected' ? 'bg-rose-50 text-rose-700 dark:bg-rose-500/10 dark:text-rose-300' : 'bg-amber-50 text-amber-700 dark:bg-amber-500/10 dark:text-amber-300'}`}>{d.approvalStatus === 'approved' ? (tr ? 'Müşteri onayladı' : 'Approved') : d.approvalStatus === 'rejected' ? (tr ? 'Müşteri revizyon istedi' : 'Changes requested') : (tr ? 'Müşteri onayı bekliyor' : 'Awaiting client')}</span>}
                      {d.approvalStatus === 'rejected' && d.feedback && <p className="text-xs text-rose-700 dark:text-rose-300 mt-1 italic">“{d.feedback}”</p>}
                    </div>
                    <button onClick={() => openDoc(d)} title={tr ? 'Aç' : 'Open'} className="p-2 rounded-lg text-slate-400 hover:text-indigo-600 hover:bg-indigo-50 dark:hover:bg-white/5"><Download size={15} /></button>
                  </div>
                ))}
              </div>
            )}

            {tab === 'portal' && canManage && (
              <div className="space-y-4">
                <div className="rounded-2xl border border-slate-100 dark:border-slate-800 px-4 divide-y divide-slate-100 dark:divide-slate-800">
                  <Toggle on={portal.isPublic} onClick={() => setPortal({ isPublic: !portal.isPublic })} label={tr ? 'Portal yayında' : 'Portal live'} />
                  <Toggle on={portal.showTasks} onClick={() => setPortal({ showTasks: !portal.showTasks })} label={tr ? 'Görevler ve ilerleme' : 'Tasks & progress'} />
                  <Toggle on={portal.showFinancials} onClick={() => setPortal({ showFinancials: !portal.showFinancials })} label={tr ? 'Ödeme planı' : 'Payment plan'} />
                  <Toggle on={portal.showTeam} onClick={() => setPortal({ showTeam: !portal.showTeam })} label={tr ? 'Proje ekibi' : 'Team'} />
                </div>
                <div>
                  <p className="text-xs font-semibold text-slate-500 mb-1.5">{tr ? 'Karşılama mesajı' : 'Welcome message'}</p>
                  <textarea rows={2} maxLength={280} value={portalMsg} onChange={e => setPortalMsg(e.target.value)} onBlur={() => portalMsg !== (portal.customMessage || '') && setPortal({ customMessage: portalMsg })} className={inputCls() + ' !h-auto py-2.5 resize-none'} placeholder={tr ? 'Müşteri portalı açtığında görür' : 'Shown on portal'} />
                </div>
                <div className="rounded-2xl bg-slate-50 dark:bg-white/[0.03] p-3 flex items-center gap-2">
                  <Globe size={15} className={portal.isPublic ? 'text-emerald-500' : 'text-slate-400'} />
                  <span className="flex-1 min-w-0 truncate text-xs font-mono text-slate-500">{portalUrl}</span>
                  <button onClick={() => { navigator.clipboard.writeText(portalUrl); toast.success(tr ? 'Portal bağlantısı kopyalandı' : 'Copied'); }} className="p-1.5 rounded-lg text-slate-400 hover:text-indigo-600"><Copy size={14} /></button>
                  <a href={portalUrl} target="_blank" rel="noreferrer" className="p-1.5 rounded-lg text-slate-400 hover:text-indigo-600"><Eye size={14} /></a>
                </div>
                {fb.length > 0 && (
                  <div className="rounded-2xl border border-slate-100 dark:border-slate-800 p-3">
                    <p className="text-xs font-semibold text-slate-500 mb-2 flex items-center gap-1"><Star size={13} className="text-amber-400 fill-amber-400" />{tr ? 'Müşteri değerlendirmeleri' : 'Client feedback'} · {(fb.reduce((a, f) => a + f.score, 0) / fb.length).toFixed(1)}</p>
                    <div className="space-y-1.5">{[...fb].reverse().slice(0, 5).map((f, i) => <p key={i} className="text-xs text-slate-600 dark:text-slate-300"><span className="text-amber-500">{'★'.repeat(f.score)}</span> {f.comment || ''} <span className="text-slate-400">· {new Date(f.date).toLocaleDateString('tr-TR')}</span></p>)}</div>
                  </div>
                )}
              </div>
            )}
          </div>
        </aside>
      </div>
      <ProjectHoldSheet open={holdOpen} project={p} language={language} showFinancials={showFinancials} onClose={() => setHoldOpen(false)}
        onConfirm={patch => save(patch, p.status === 'On Hold' ? (tr ? 'Askı uzatıldı' : 'Hold extended') : (tr ? 'Proje askıya alındı — uyarılar susturuldu' : 'Project on hold — alerts muted'))} />
    </ModalPortal>
  );
};

export default ProjectDetailPanel;
