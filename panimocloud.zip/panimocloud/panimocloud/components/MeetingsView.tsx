import React, { useEffect, useMemo, useState } from 'react';
import { Video, CalendarClock, Clock, Users, Plus, LogOut, Play, Copy, Edit2, CheckCircle2, Ban, StickyNote, History, Radio } from 'lucide-react';
import { JitsiMeeting } from '@jitsi/react-sdk';
import { Meeting, User, UserRole } from '../types';
import { PageHeader, KpiGrid, SearchBox, Segmented, Field, EmptyState, DeleteButton, Sheet, Avatar, inputCls, cardCls, btnPrimary } from './ui/Kit';
import { localISO } from '../services/insights';
import { toast } from '../services/toast';

interface Props {
  meetings: Meeting[];
  users: User[];
  currentUser: User;
  language: 'tr' | 'en';
  onUpsertMeeting: (meeting: Meeting) => void | Promise<void>;
  onDeleteMeeting: (id: string) => void | Promise<void>;
}

const startOf = (m: Meeting) => new Date(`${m.date}T${m.time || '00:00'}`).getTime();
const endOf = (m: Meeting) => startOf(m) + (m.durationMinutes || 60) * 60000;
const linkOf = (m: Meeting) => `https://meet.jit.si/${m.roomName}`;
const DURATIONS = [15, 30, 45, 60, 90, 120];

const MeetingsView: React.FC<Props> = ({ meetings, users, currentUser, language, onUpsertMeeting, onDeleteMeeting }) => {
  const tr = language === 'tr';
  const isAdmin = currentUser.role === UserRole.ADMIN || currentUser.role === UserRole.MANAGER;
  const [now, setNow] = useState(Date.now());
  useEffect(() => { const t = setInterval(() => setNow(Date.now()), 30000); return () => clearInterval(t); }, []);
  const [active, setActive] = useState<Meeting | null>(null);
  const [tab, setTab] = useState<'upcoming' | 'past'>('upcoming');
  const [search, setSearch] = useState('');
  const [form, setForm] = useState<Partial<Meeting> | null>(null);
  const [notesFor, setNotesFor] = useState<Meeting | null>(null);
  const [touched, setTouched] = useState(false);

  // Gizlilik: yöneticiler hepsini, diğerleri sadece davetli oldukları veya oluşturdukları toplantıları görür
  const visible = useMemo(() => meetings.filter(m => isAdmin || m.createdBy === currentUser.id || (m.participants || []).includes(currentUser.id)), [meetings, isAdmin, currentUser.id]);
  const phase = (m: Meeting): 'live' | 'soon' | 'upcoming' | 'past' | 'cancelled' => {
    if (m.status === 'cancelled') return 'cancelled';
    if (m.status === 'completed' || endOf(m) < now) return 'past';
    if (m.status === 'active' || (startOf(m) <= now && endOf(m) >= now)) return 'live';
    if (startOf(m) - now <= 15 * 60000) return 'soon';
    return 'upcoming';
  };
  const list = useMemo(() => {
    const q = search.trim().toLocaleLowerCase('tr-TR');
    return visible.filter(m => {
      const p = phase(m);
      const isPast = p === 'past' || p === 'cancelled';
      return (tab === 'past' ? isPast : !isPast) && (!q || [m.title, m.description, m.notes].join(' ').toLocaleLowerCase('tr-TR').includes(q));
    }).sort((a, b) => (tab === 'past' ? startOf(b) - startOf(a) : startOf(a) - startOf(b)));
  }, [visible, tab, search, now]);

  const today = localISO();
  const stats = {
    today: visible.filter(m => m.date === today && phase(m) !== 'cancelled').length,
    week: visible.filter(m => { const d = (startOf(m) - now) / 86400000; return d >= 0 && d <= 7 && phase(m) !== 'cancelled'; }).length,
    live: visible.filter(m => phase(m) === 'live').length,
    mine: visible.filter(m => (m.participants || []).includes(currentUser.id) && phase(m) !== 'past' && phase(m) !== 'cancelled').length,
  };

  const relTime = (m: Meeting) => {
    const diff = startOf(m) - now;
    const p = phase(m);
    if (p === 'live') return tr ? 'Şu anda devam ediyor' : 'Live now';
    if (p === 'cancelled') return tr ? 'İptal edildi' : 'Cancelled';
    if (p === 'past') return tr ? 'Tamamlandı' : 'Done';
    const min = Math.round(diff / 60000);
    if (min < 60) return tr ? `${min} dk sonra` : `in ${min}m`;
    const h = Math.round(min / 60);
    if (h < 24) return tr ? `${h} saat sonra` : `in ${h}h`;
    return tr ? `${Math.round(h / 24)} gün sonra` : `in ${Math.round(h / 24)}d`;
  };

  // ---------- Form ----------
  const errors: Record<string, string> = {};
  if (form) {
    if (!form.title?.trim()) errors.title = tr ? 'Toplantı adı zorunlu.' : 'Title required.';
    if (!form.date) errors.date = tr ? 'Tarih seçin.' : 'Pick a date.';
    if (!form.time) errors.time = tr ? 'Saat seçin.' : 'Pick a time.';
    if (form.date && form.time && !form.id && new Date(`${form.date}T${form.time}`).getTime() < now - 60000) errors.time = tr ? 'Geçmiş bir zaman seçilemez.' : 'Time is in the past.';
  }
  const err = (k: string) => (touched ? errors[k] : undefined);
  const openForm = (m?: Meeting) => {
    setTouched(false);
    const d = new Date(now + 60 * 60000); d.setMinutes(0, 0, 0);
    setForm(m ? { ...m } : { title: '', description: '', date: localISO(d), time: `${String(d.getHours()).padStart(2, '0')}:00`, durationMinutes: 30, participants: [] });
  };
  const save = async () => {
    setTouched(true);
    if (!form || Object.keys(errors).length) return;
    const m: Meeting = {
      id: form.id || `mtg_${Date.now()}`, title: form.title!.trim(), description: form.description || '', date: form.date!, time: form.time!,
      participants: form.participants || [], createdBy: form.createdBy || currentUser.id, status: form.status || 'scheduled',
      roomName: form.roomName || `panimocloud_${Date.now()}_${Math.random().toString(36).slice(2, 7)}`, durationMinutes: form.durationMinutes || 60, notes: form.notes || '',
    };
    await onUpsertMeeting(m);
    toast.success(form.id ? (tr ? 'Toplantı güncellendi' : 'Updated') : (tr ? 'Toplantı planlandı' : 'Scheduled'));
    setForm(null);
  };
  const copyLink = (m: Meeting) => { navigator.clipboard.writeText(linkOf(m)); toast.success(tr ? 'Toplantı bağlantısı kopyalandı' : 'Link copied'); };
  const canEdit = (m: Meeting) => isAdmin || m.createdBy === currentUser.id;

  // ---------- Toplantı odası ----------
  if (active) {
    return (
      <div className="h-[calc(100dvh-140px)] flex flex-col bg-[#020617] rounded-[24px] overflow-hidden shadow-2xl animate-in fade-in zoom-in-95 duration-300">
        <div className="bg-[#0f172a] px-4 py-3 flex items-center gap-3 border-b border-white/10">
          <span className="w-2.5 h-2.5 rounded-full bg-rose-500 pc-dot-pulse" />
          <div className="flex-1 min-w-0"><h2 className="font-bold text-white truncate">{active.title}</h2><p className="text-[11px] text-slate-400">{(active.participants || []).length + 1} {tr ? 'davetli' : 'invited'} · {active.durationMinutes || 60} {tr ? 'dk' : 'min'}</p></div>
          <button onClick={() => copyLink(active)} className="h-9 px-3 rounded-xl text-xs font-semibold text-slate-200 bg-white/10 hover:bg-white/15 inline-flex items-center gap-1.5"><Copy size={14} />{tr ? 'Bağlantı' : 'Link'}</button>
          <button onClick={() => { const m = active; setActive(null); if (canEdit(m)) setNotesFor(m); }} className="h-9 px-3 rounded-xl text-xs font-semibold text-rose-200 bg-rose-500/20 hover:bg-rose-500/30 inline-flex items-center gap-1.5"><LogOut size={14} />{tr ? 'Ayrıl' : 'Leave'}</button>
        </div>
        <div className="flex-1 bg-black">
          <JitsiMeeting domain="meet.jit.si" roomName={active.roomName}
            configOverwrite={{ startWithAudioMuted: true, startWithVideoMuted: false, requireDisplayName: false, prejoinPageEnabled: false }}
            interfaceConfigOverwrite={{ DISABLE_JOIN_LEAVE_NOTIFICATIONS: true, SHOW_JITSI_WATERMARK: false, SHOW_PROMO_CLOSE_OVERLAY: false, SHOW_BRAND_WATERMARK: false }}
            userInfo={{ displayName: currentUser.name, email: currentUser.email || '' }}
            getIFrameRef={(iframe) => { iframe.style.height = '100%'; iframe.style.width = '100%'; }} />
        </div>
      </div>
    );
  }

  const card = (m: Meeting) => {
    const p = phase(m);
    const creator = users.find(u => u.id === m.createdBy);
    const people = (m.participants || []).map(id => users.find(u => u.id === id)).filter(Boolean) as User[];
    return (
      <div key={m.id} className={`${cardCls} p-4 flex flex-col pc-lift ${p === 'live' ? '!border-rose-300 ring-4 ring-rose-500/10' : p === 'soon' ? '!border-amber-300' : ''}`}>
        <div className="flex items-start gap-3">
          <div className={`w-12 shrink-0 rounded-xl text-center py-1.5 ${p === 'live' ? 'bg-rose-500 text-white' : 'bg-indigo-50 dark:bg-indigo-500/10 text-indigo-700 dark:text-indigo-300'}`}>
            <p className="text-[10px] font-bold uppercase">{new Date(m.date).toLocaleDateString(tr ? 'tr-TR' : 'en-US', { month: 'short' })}</p>
            <p className="text-lg font-black leading-none">{Number(m.date.slice(8))}</p>
          </div>
          <div className="flex-1 min-w-0">
            <p className="font-bold text-slate-900 dark:text-white truncate">{m.title}</p>
            <p className="text-xs text-slate-500 flex items-center gap-1"><Clock size={12} />{m.time} · {m.durationMinutes || 60} {tr ? 'dk' : 'min'}</p>
          </div>
          <span className={`text-[10px] font-semibold px-2 py-0.5 rounded-md shrink-0 inline-flex items-center gap-1 ${p === 'live' ? 'bg-rose-50 text-rose-600 dark:bg-rose-500/10' : p === 'soon' ? 'bg-amber-50 text-amber-700 dark:bg-amber-500/10' : p === 'cancelled' ? 'bg-slate-100 text-slate-500 dark:bg-white/5' : p === 'past' ? 'bg-emerald-50 text-emerald-700 dark:bg-emerald-500/10' : 'bg-slate-100 text-slate-600 dark:bg-white/5 dark:text-slate-300'}`}>{p === 'live' && <Radio size={10} />}{relTime(m)}</span>
        </div>
        {m.description && <p className="text-xs text-slate-500 dark:text-slate-400 mt-2 line-clamp-2">{m.description}</p>}
        {m.notes && p === 'past' && <p className="text-xs text-indigo-700 dark:text-indigo-300 mt-2 line-clamp-3 bg-indigo-50/60 dark:bg-indigo-500/10 rounded-lg p-2 flex gap-1.5"><StickyNote size={12} className="shrink-0 mt-0.5" />{m.notes}</p>}
        <div className="flex items-center justify-between mt-3">
          <div className="flex -space-x-1.5">{people.slice(0, 5).map(u => <Avatar key={u.id} name={u.name} src={u.avatar} size="w-7 h-7" className="!rounded-full ring-2 ring-white dark:ring-slate-900" />)}{people.length > 5 && <span className="w-7 h-7 rounded-full ring-2 ring-white dark:ring-slate-900 bg-slate-100 dark:bg-slate-800 text-[10px] font-bold flex items-center justify-center">+{people.length - 5}</span>}{!people.length && <span className="text-[11px] text-slate-400">{tr ? 'Bağlantı ile katılım' : 'Link only'}</span>}</div>
          <span className="text-[11px] text-slate-400 truncate">{creator ? (tr ? `Düzenleyen: ${creator.name.split(' ')[0]}` : `By ${creator.name.split(' ')[0]}`) : ''}</span>
        </div>
        <div className="flex items-center gap-1.5 mt-3 pt-3 border-t border-slate-100 dark:border-slate-800">
          {p !== 'past' && p !== 'cancelled' ? (
            <button onClick={() => { setActive(m); if (p === 'live' && m.status !== 'active' && canEdit(m)) onUpsertMeeting({ ...m, status: 'active' }); }} className={`flex-1 h-9 rounded-xl text-xs font-semibold inline-flex items-center justify-center gap-1.5 ${p === 'live' || p === 'soon' ? 'text-white bg-indigo-600 hover:bg-indigo-500 shadow-md shadow-indigo-500/20' : 'text-indigo-700 bg-indigo-50 hover:bg-indigo-100 dark:bg-indigo-500/10 dark:text-indigo-300'}`}><Play size={14} />{tr ? 'Katıl' : 'Join'}</button>
          ) : canEdit(m) ? (
            <button onClick={() => setNotesFor(m)} className="flex-1 h-9 rounded-xl text-xs font-semibold text-slate-600 dark:text-slate-300 bg-slate-100 dark:bg-white/5 hover:bg-indigo-50 hover:text-indigo-700 inline-flex items-center justify-center gap-1.5"><StickyNote size={14} />{m.notes ? (tr ? 'Notları düzenle' : 'Edit notes') : (tr ? 'Not ekle' : 'Add notes')}</button>
          ) : <span className="flex-1" />}
          <button onClick={() => copyLink(m)} title={tr ? 'Bağlantıyı kopyala' : 'Copy link'} className="p-2 rounded-lg text-slate-400 hover:text-indigo-600 hover:bg-indigo-50 dark:hover:bg-white/5"><Copy size={14} /></button>
          {canEdit(m) && p !== 'past' && p !== 'cancelled' && <>
            <button onClick={() => openForm(m)} title={tr ? 'Düzenle' : 'Edit'} className="p-2 rounded-lg text-slate-400 hover:text-indigo-600 hover:bg-indigo-50 dark:hover:bg-white/5"><Edit2 size={14} /></button>
            <button onClick={async () => { await onUpsertMeeting({ ...m, status: 'cancelled' }); toast(tr ? 'Toplantı iptal edildi' : 'Cancelled', 'info'); }} title={tr ? 'İptal et' : 'Cancel'} className="p-2 rounded-lg text-slate-400 hover:text-amber-600 hover:bg-amber-50 dark:hover:bg-white/5"><Ban size={14} /></button>
          </>}
          {canEdit(m) && <DeleteButton language={language} onConfirm={async () => { await onDeleteMeeting(m.id); toast(tr ? 'Toplantı silindi' : 'Deleted', 'info'); }} />}
        </div>
      </div>
    );
  };

  return (
    <div className="space-y-5 pb-10">
      <PageHeader title={tr ? 'Toplantılar' : 'Meetings'} subtitle={tr ? 'Görüntülü toplantılar, davetler ve toplantı notları.' : 'Video meetings, invites and notes.'}
        actions={<button onClick={() => openForm()} className={btnPrimary}><Plus size={16} />{tr ? 'Toplantı planla' : 'Schedule'}</button>} />
      <KpiGrid items={[
        { label: tr ? 'Şu an canlı' : 'Live now', value: stats.live, icon: Radio, grad: 'from-rose-500 to-red-600', sub: stats.live ? (tr ? 'Katılmak için tıklayın' : 'Click to join') : (tr ? 'Aktif toplantı yok' : 'None live'), onClick: () => setTab('upcoming') },
        { label: tr ? 'Bugün' : 'Today', value: stats.today, icon: CalendarClock, grad: 'from-indigo-500 to-violet-600', onClick: () => setTab('upcoming') },
        { label: tr ? 'Önümüzdeki 7 gün' : 'Next 7 days', value: stats.week, icon: Video, grad: 'from-sky-500 to-blue-600' },
        { label: tr ? 'Davetli olduklarım' : 'Invited to', value: stats.mine, icon: Users, grad: 'from-emerald-500 to-teal-600' },
      ]} />
      <div className={`${cardCls} p-3 flex flex-col sm:flex-row gap-2`}>
        <Segmented<'upcoming' | 'past'> value={tab} onChange={setTab} options={[{ value: 'upcoming', label: <><CalendarClock size={14} />{tr ? 'Yaklaşan' : 'Upcoming'}</> }, { value: 'past', label: <><History size={14} />{tr ? 'Geçmiş' : 'Past'}</> }]} />
        <SearchBox value={search} onChange={setSearch} placeholder={tr ? 'Toplantı veya not ara…' : 'Search…'} />
      </div>
      <div key={tab}>
        {list.length === 0 ? <div className={cardCls}><EmptyState icon={Video} text={tab === 'upcoming' ? (tr ? 'Planlanmış toplantı yok' : 'No upcoming meetings') : (tr ? 'Geçmiş toplantı yok' : 'No past meetings')} action={tab === 'upcoming' && <button onClick={() => openForm()} className="text-xs font-semibold text-indigo-600 hover:underline">{tr ? 'İlk toplantıyı planla' : 'Schedule one'}</button>} /></div>
          : <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-4 pc-stagger">{list.map(card)}</div>}
      </div>

      <Sheet open={!!form} language={language} title={form?.id ? (tr ? 'Toplantıyı düzenle' : 'Edit meeting') : (tr ? 'Toplantı planla' : 'Schedule meeting')} icon={Video} onClose={() => setForm(null)} onSubmit={save} submitLabel={form?.id ? (tr ? 'Güncelle' : 'Update') : (tr ? 'Planla' : 'Schedule')}>
        {form && <>
          <Field label={tr ? 'Toplantı adı' : 'Title'} required error={err('title')}><input autoFocus className={inputCls(err('title'))} value={form.title || ''} onChange={e => setForm({ ...form, title: e.target.value })} placeholder={tr ? 'Örn: Haftalık değerlendirme' : 'e.g. Weekly sync'} /></Field>
          <div className="grid grid-cols-2 gap-4">
            <Field label={tr ? 'Tarih' : 'Date'} required error={err('date')} hint={<div className="flex gap-1">{[[0, tr ? 'Bugün' : 'Today'], [1, tr ? 'Yarın' : 'Tomorrow']].map(([n, l]) => <button key={l as string} type="button" onClick={() => setForm({ ...form, date: localISO(new Date(now + (n as number) * 86400000)) })} className="h-6 px-2 rounded-md bg-slate-100 dark:bg-white/5 font-semibold hover:bg-indigo-50 hover:text-indigo-600">{l}</button>)}</div>}><input type="date" min={form.id ? undefined : localISO()} className={inputCls(err('date'))} value={form.date || ''} onChange={e => setForm({ ...form, date: e.target.value })} /></Field>
            <Field label={tr ? 'Saat' : 'Time'} required error={err('time')}><input type="time" className={inputCls(err('time'))} value={form.time || ''} onChange={e => setForm({ ...form, time: e.target.value })} /></Field>
          </div>
          <Field label={tr ? 'Süre' : 'Duration'}>
            <div className="flex flex-wrap gap-1.5">{DURATIONS.map(d => <button key={d} type="button" onClick={() => setForm({ ...form, durationMinutes: d })} className={`h-9 px-3 rounded-lg text-xs font-semibold border ${form.durationMinutes === d ? 'border-indigo-500 bg-indigo-50 text-indigo-700 dark:bg-indigo-500/10 dark:text-indigo-200' : 'border-slate-200 dark:border-slate-700 text-slate-600 dark:text-slate-300'}`}>{d < 60 ? `${d} ${tr ? 'dk' : 'min'}` : `${d / 60} ${tr ? 'sa' : 'h'}`}</button>)}</div>
          </Field>
          <Field label={tr ? 'Gündem / açıklama' : 'Agenda'}><textarea rows={3} className={inputCls() + ' h-auto py-2.5 resize-none'} value={form.description || ''} onChange={e => setForm({ ...form, description: e.target.value })} placeholder={tr ? '1. Sprint durumu\n2. Engeller…' : 'Agenda…'} /></Field>
          <Field label={`${tr ? 'Katılımcılar' : 'Participants'} (${(form.participants || []).length})`} hint={<button type="button" onClick={() => setForm({ ...form, participants: (form.participants || []).length === users.filter(u => u.id !== currentUser.id).length ? [] : users.filter(u => u.id !== currentUser.id).map(u => u.id) })} className="font-semibold text-indigo-600 hover:underline">{tr ? 'Tümünü seç / kaldır' : 'Toggle all'}</button>}>
            <div className="flex flex-wrap gap-2">
              {users.filter(u => u.id !== currentUser.id).map(u => {
                const on = (form.participants || []).includes(u.id);
                return <button key={u.id} type="button" onClick={() => setForm({ ...form, participants: on ? form.participants!.filter(x => x !== u.id) : [...(form.participants || []), u.id] })} className={`inline-flex items-center gap-2 pl-1 pr-3 h-9 rounded-full border text-xs font-semibold transition-all ${on ? 'bg-indigo-600 border-indigo-600 text-white' : 'border-slate-200 dark:border-slate-700 text-slate-600 dark:text-slate-300 hover:border-indigo-300'}`}><Avatar name={u.name} src={u.avatar} size="w-7 h-7" className="!rounded-full" />{u.name}{on && <CheckCircle2 size={13} />}</button>;
              })}
            </div>
          </Field>
        </>}
      </Sheet>

      <Sheet open={!!notesFor} language={language} title={tr ? 'Toplantı notları' : 'Meeting notes'} subtitle={notesFor?.title} icon={StickyNote} onClose={() => setNotesFor(null)}
        onSubmit={async () => { if (!notesFor) return; await onUpsertMeeting({ ...notesFor, notes: notesFor.notes || '', status: endOf(notesFor) < now ? 'completed' : notesFor.status }); toast.success(tr ? 'Notlar kaydedildi' : 'Notes saved'); setNotesFor(null); }}>
        {notesFor && <Field label={tr ? 'Alınan kararlar, aksiyonlar' : 'Decisions & action items'} hint={tr ? 'Katılımcılar geçmiş toplantılarda bu notu görür.' : 'Visible to participants.'}>
          <textarea autoFocus rows={8} className={inputCls() + ' h-auto py-2.5'} value={notesFor.notes || ''} onChange={e => setNotesFor({ ...notesFor, notes: e.target.value })} placeholder={tr ? '• Karar: …\n• Aksiyon: Ayşe → logo revizyonu (Cuma)' : '• Decision…'} />
        </Field>}
      </Sheet>
    </div>
  );
};

export default MeetingsView;
