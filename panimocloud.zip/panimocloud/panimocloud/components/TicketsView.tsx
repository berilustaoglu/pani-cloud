import React, { useEffect, useMemo, useRef, useState } from 'react';
import { MessageSquare, Search, Send, ArrowLeft, Clock, AlertTriangle, CheckCircle2, Inbox, Zap, User as UserIcon, Headphones, X } from 'lucide-react';
import { Project, Ticket, TicketStatus, TicketPriority, User } from '../types';
import { AnimatedNumber } from './ui/Motion';
import { toast } from '../services/toast';

interface Props {
  tickets: Ticket[];
  projects: Project[];
  currentUser: User;
  language: 'tr' | 'en';
  onUpsertTicket: (ticket: Ticket) => Promise<void>;
}

const STATUS: Record<TicketStatus, { tr: string; en: string; chip: string; dot: string }> = {
  'Open': { tr: 'Açık', en: 'Open', chip: 'bg-sky-50 text-sky-700 dark:bg-sky-500/10 dark:text-sky-300', dot: 'bg-sky-500' },
  'In Progress': { tr: 'İşlemde', en: 'In progress', chip: 'bg-amber-50 text-amber-700 dark:bg-amber-500/10 dark:text-amber-300', dot: 'bg-amber-500' },
  'Resolved': { tr: 'Çözüldü', en: 'Resolved', chip: 'bg-emerald-50 text-emerald-700 dark:bg-emerald-500/10 dark:text-emerald-300', dot: 'bg-emerald-500' },
  'Closed': { tr: 'Kapandı', en: 'Closed', chip: 'bg-slate-100 text-slate-500 dark:bg-white/5 dark:text-slate-400', dot: 'bg-slate-400' },
};
const PRIORITY: Record<TicketPriority, { tr: string; en: string; chip: string; order: number }> = {
  Critical: { tr: 'Kritik', en: 'Critical', chip: 'bg-rose-50 text-rose-700 dark:bg-rose-500/10 dark:text-rose-300', order: 0 },
  High: { tr: 'Yüksek', en: 'High', chip: 'bg-orange-50 text-orange-700 dark:bg-orange-500/10 dark:text-orange-300', order: 1 },
  Medium: { tr: 'Orta', en: 'Medium', chip: 'bg-sky-50 text-sky-700 dark:bg-sky-500/10 dark:text-sky-300', order: 2 },
  Low: { tr: 'Düşük', en: 'Low', chip: 'bg-slate-100 text-slate-600 dark:bg-white/5 dark:text-slate-300', order: 3 },
};
const QUICK_REPLIES_TR = ['Talebinizi aldık, inceliyoruz. En kısa sürede dönüş yapacağız.', 'Sorun çözüldü, kontrol edip bize bilgi verebilir misiniz?', 'Konuyu netleştirmek için ekran görüntüsü paylaşabilir misiniz?', 'Bu geliştirme bir sonraki sürüme planlandı.'];
const QUICK_REPLIES_EN = ['We received your request and are looking into it.', 'The issue is fixed — could you please verify?', 'Could you share a screenshot to clarify?', 'This is planned for the next release.'];

const ago = (iso: string, tr: boolean) => {
  const m = Math.max(0, Math.round((Date.now() - new Date(iso).getTime()) / 60000));
  if (m < 1) return tr ? 'şimdi' : 'now';
  if (m < 60) return tr ? `${m} dk önce` : `${m}m ago`;
  const h = Math.round(m / 60);
  if (h < 24) return tr ? `${h} sa önce` : `${h}h ago`;
  const d = Math.round(h / 24);
  return tr ? `${d} gün önce` : `${d}d ago`;
};
const isOpen = (t: Ticket) => t.status === 'Open' || t.status === 'In Progress';
const awaitingUs = (t: Ticket) => { const last = (t.responses || []).slice(-1)[0]; return isOpen(t) && (!last || last.isClient); };

const TicketsView: React.FC<Props> = ({ tickets, projects, currentUser, language, onUpsertTicket }) => {
  const tr = language === 'tr';
  const [selectedId, setSelectedId] = useState<string | null>(null);
  const [reply, setReply] = useState('');
  const [sending, setSending] = useState(false);
  const [statusF, setStatusF] = useState<'active' | TicketStatus | 'all'>('active');
  const [projectF, setProjectF] = useState('all');
  const [search, setSearch] = useState('');
  const [showQuick, setShowQuick] = useState(false);
  const threadRef = useRef<HTMLDivElement>(null);

  // Gerçek zamanlı güncellemeler için her zaman listeden oku
  const selected = tickets.find(t => t.id === selectedId) || null;
  const projectName = (id: string) => projects.find(p => p.id === id)?.name || (tr ? 'Bilinmeyen proje' : 'Unknown project');

  const filtered = useMemo(() => {
    const q = search.trim().toLocaleLowerCase('tr-TR');
    return tickets.filter(t =>
      (statusF === 'all' || (statusF === 'active' ? isOpen(t) : t.status === statusF)) &&
      (projectF === 'all' || t.projectId === projectF) &&
      (!q || [t.title, t.description, projectName(t.projectId)].join(' ').toLocaleLowerCase('tr-TR').includes(q))
    ).sort((a, b) => Number(awaitingUs(b)) - Number(awaitingUs(a)) || PRIORITY[a.priority].order - PRIORITY[b.priority].order || (b.updatedAt || '').localeCompare(a.updatedAt || ''));
  }, [tickets, statusF, projectF, search, projects]);

  const stats = useMemo(() => ({
    open: tickets.filter(isOpen).length,
    awaiting: tickets.filter(awaitingUs).length,
    critical: tickets.filter(t => isOpen(t) && (t.priority === 'Critical' || t.priority === 'High')).length,
    resolved: tickets.filter(t => t.status === 'Resolved' || t.status === 'Closed').length,
  }), [tickets]);

  useEffect(() => { threadRef.current?.scrollTo({ top: threadRef.current.scrollHeight, behavior: 'smooth' }); }, [selected?.responses?.length, selectedId]);

  const update = async (patch: Partial<Ticket>, msg?: string) => {
    if (!selected) return;
    await onUpsertTicket({ ...selected, ...patch, updatedAt: new Date().toISOString() });
    if (msg) toast(msg, 'success', 2000);
  };
  const send = async (closeAfter?: TicketStatus) => {
    if (!selected || !reply.trim()) return;
    setSending(true);
    try {
      const responses = [...(selected.responses || []), { id: `resp_${Date.now()}`, userId: currentUser.id, message: reply.trim(), createdAt: new Date().toISOString(), isClient: false }];
      const status: TicketStatus = closeAfter || (selected.status === 'Open' ? 'In Progress' : selected.status);
      await onUpsertTicket({ ...selected, responses, status, updatedAt: new Date().toISOString() });
      setReply('');
      toast.success(closeAfter ? (tr ? 'Yanıt gönderildi ve talep çözüldü' : 'Replied & resolved') : (tr ? 'Yanıt gönderildi' : 'Reply sent'));
    } finally { setSending(false); }
  };

  const kpis = [
    { label: tr ? 'Açık talep' : 'Open', value: stats.open, icon: Inbox, grad: 'from-indigo-500 to-violet-600', on: () => setStatusF('active') },
    { label: tr ? 'Yanıt bekleyen' : 'Awaiting reply', value: stats.awaiting, icon: Clock, grad: 'from-amber-500 to-orange-600', on: () => setStatusF('active') },
    { label: tr ? 'Kritik / yüksek' : 'Critical / high', value: stats.critical, icon: AlertTriangle, grad: 'from-rose-500 to-red-600', on: () => setStatusF('active') },
    { label: tr ? 'Çözülen' : 'Resolved', value: stats.resolved, icon: CheckCircle2, grad: 'from-emerald-500 to-teal-600', on: () => setStatusF('Resolved') },
  ];

  const list = (
    <div className={`${selected ? 'hidden lg:flex' : 'flex'} lg:col-span-2 flex-col bg-white dark:bg-slate-900 border border-slate-100 dark:border-slate-800 rounded-[20px] overflow-hidden min-h-[520px] lg:h-[calc(100dvh-320px)]`}>
      <div className="p-3 space-y-2 border-b border-slate-100 dark:border-slate-800">
        <div className="relative"><Search size={16} className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" /><input value={search} onChange={e => setSearch(e.target.value)} placeholder={tr ? 'Talep ara…' : 'Search…'} className="w-full h-10 pl-9 pr-3 rounded-xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700 text-sm outline-none focus:border-indigo-500" /></div>
        <div className="flex gap-2">
          <select value={statusF} onChange={e => setStatusF(e.target.value as any)} className="flex-1 h-9 px-2 rounded-lg bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700 text-xs font-semibold outline-none">
            <option value="active">{tr ? 'Aktif talepler' : 'Active'}</option><option value="all">{tr ? 'Tümü' : 'All'}</option>
            {(Object.keys(STATUS) as TicketStatus[]).map(s => <option key={s} value={s}>{tr ? STATUS[s].tr : STATUS[s].en}</option>)}
          </select>
          <select value={projectF} onChange={e => setProjectF(e.target.value)} className="flex-1 h-9 px-2 rounded-lg bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700 text-xs font-semibold outline-none max-w-[50%]">
            <option value="all">{tr ? 'Tüm projeler' : 'All projects'}</option>{projects.map(p => <option key={p.id} value={p.id}>{p.name}</option>)}
          </select>
        </div>
      </div>
      <div className="flex-1 overflow-y-auto custom-scrollbar p-2 space-y-1 pc-stagger" key={`${statusF}-${projectF}`}>
        {filtered.length === 0 && <div className="py-16 text-center text-slate-400"><Inbox size={34} className="mx-auto mb-2 opacity-40 pc-float" /><p className="text-sm font-semibold">{tr ? 'Talep yok' : 'No tickets'}</p></div>}
        {filtered.map(t => {
          const wait = awaitingUs(t);
          const last = (t.responses || []).slice(-1)[0];
          return (
            <button key={t.id} onClick={() => setSelectedId(t.id)} className={`w-full text-left p-3 rounded-xl transition-colors ${selectedId === t.id ? 'bg-indigo-50 dark:bg-indigo-500/10' : 'hover:bg-slate-50 dark:hover:bg-white/[0.03]'}`}>
              <div className="flex items-center gap-2">
                <span className={`w-2 h-2 rounded-full shrink-0 ${STATUS[t.status].dot} ${wait ? 'pc-dot-pulse' : ''}`} />
                <p className={`flex-1 text-sm truncate ${wait ? 'font-bold text-slate-900 dark:text-white' : 'font-semibold text-slate-700 dark:text-slate-200'}`}>{t.title}</p>
                <span className="text-[10px] text-slate-400 shrink-0">{ago(t.updatedAt || t.createdAt, tr)}</span>
              </div>
              <p className="text-xs text-slate-500 dark:text-slate-400 truncate mt-0.5 pl-4">{last ? `${last.isClient ? (tr ? 'Müşteri' : 'Client') : (tr ? 'Siz' : 'You')}: ${last.message}` : t.description}</p>
              <div className="flex items-center gap-1.5 mt-1.5 pl-4">
                <span className={`text-[10px] font-semibold px-1.5 py-0.5 rounded-md ${PRIORITY[t.priority].chip}`}>{tr ? PRIORITY[t.priority].tr : PRIORITY[t.priority].en}</span>
                <span className="text-[10px] text-slate-400 truncate">{projectName(t.projectId)}</span>
                {wait && <span className="ml-auto text-[10px] font-semibold text-amber-600">{tr ? 'Yanıt bekliyor' : 'Awaiting'}</span>}
              </div>
            </button>
          );
        })}
      </div>
    </div>
  );

  const detail = selected ? (
    <div key={selected.id} className="lg:col-span-3 flex flex-col bg-white dark:bg-slate-900 border border-slate-100 dark:border-slate-800 rounded-[20px] overflow-hidden min-h-[520px] h-[calc(100dvh-180px)] lg:h-[calc(100dvh-320px)] animate-in fade-in slide-in-from-right-4 duration-300">
      <div className="p-4 border-b border-slate-100 dark:border-slate-800 space-y-3">
        <div className="flex items-start gap-3">
          <button onClick={() => setSelectedId(null)} className="lg:hidden p-2 -ml-1 rounded-lg hover:bg-slate-100 dark:hover:bg-white/5"><ArrowLeft size={18} /></button>
          <div className="flex-1 min-w-0">
            <h3 className="font-bold text-slate-900 dark:text-white leading-snug">{selected.title}</h3>
            <p className="text-xs text-slate-500">{projectName(selected.projectId)} · {new Date(selected.createdAt).toLocaleString(tr ? 'tr-TR' : 'en-US', { dateStyle: 'medium', timeStyle: 'short' })}</p>
          </div>
        </div>
        <div className="flex flex-wrap gap-2">
          <div className="flex p-0.5 rounded-lg bg-slate-100 dark:bg-slate-800">
            {(Object.keys(STATUS) as TicketStatus[]).map(s => <button key={s} onClick={() => update({ status: s }, tr ? `Durum: ${STATUS[s].tr}` : `Status: ${STATUS[s].en}`)} className={`h-7 px-2.5 rounded-md text-[11px] font-semibold inline-flex items-center gap-1 ${selected.status === s ? 'bg-white dark:bg-slate-900 shadow-sm text-slate-900 dark:text-white' : 'text-slate-500'}`}><span className={`w-1.5 h-1.5 rounded-full ${STATUS[s].dot}`} />{tr ? STATUS[s].tr : STATUS[s].en}</button>)}
          </div>
          <select value={selected.priority} onChange={e => update({ priority: e.target.value as TicketPriority }, tr ? 'Öncelik güncellendi' : 'Priority updated')} className={`h-8 px-2 rounded-lg text-[11px] font-semibold outline-none border-0 ${PRIORITY[selected.priority].chip}`}>
            {(Object.keys(PRIORITY) as TicketPriority[]).map(p => <option key={p} value={p}>{tr ? PRIORITY[p].tr : PRIORITY[p].en}</option>)}
          </select>
        </div>
      </div>
      <div ref={threadRef} className="flex-1 overflow-y-auto custom-scrollbar p-4 space-y-3 bg-slate-50/60 dark:bg-white/[0.02]">
        <div className="flex gap-2.5">
          <span className="w-8 h-8 shrink-0 rounded-full bg-slate-200 dark:bg-slate-700 flex items-center justify-center text-slate-500"><UserIcon size={15} /></span>
          <div className="max-w-[85%] rounded-2xl rounded-tl-md bg-white dark:bg-slate-800 border border-slate-100 dark:border-slate-700 p-3">
            <p className="text-[11px] font-semibold text-slate-500 mb-1">{tr ? 'Talep açıklaması' : 'Description'}</p>
            <p className="text-sm text-slate-700 dark:text-slate-200 whitespace-pre-wrap leading-relaxed">{selected.description}</p>
          </div>
        </div>
        {(selected.responses || []).map(r => (
          <div key={r.id} className={`flex gap-2.5 animate-in fade-in slide-in-from-bottom-2 duration-200 ${r.isClient ? '' : 'flex-row-reverse'}`}>
            <span className={`w-8 h-8 shrink-0 rounded-full flex items-center justify-center ${r.isClient ? 'bg-slate-200 dark:bg-slate-700 text-slate-500' : 'bg-indigo-600 text-white'}`}>{r.isClient ? <UserIcon size={15} /> : <Headphones size={15} />}</span>
            <div className={`max-w-[80%] rounded-2xl p-3 ${r.isClient ? 'rounded-tl-md bg-white dark:bg-slate-800 border border-slate-100 dark:border-slate-700' : 'rounded-tr-md bg-indigo-600 text-white'}`}>
              <p className="text-sm whitespace-pre-wrap leading-relaxed">{r.message}</p>
              <p className={`text-[10px] mt-1 ${r.isClient ? 'text-slate-400' : 'text-indigo-200'}`}>{r.isClient ? (tr ? 'Müşteri' : 'Client') : (tr ? 'Ekip' : 'Team')} · {new Date(r.createdAt).toLocaleString(tr ? 'tr-TR' : 'en-US', { dateStyle: 'short', timeStyle: 'short' })}</p>
            </div>
          </div>
        ))}
      </div>
      <div className="p-3 border-t border-slate-100 dark:border-slate-800 space-y-2">
        {showQuick && (
          <div className="flex flex-wrap gap-1.5 animate-in fade-in slide-in-from-bottom-2 duration-200">
            {(tr ? QUICK_REPLIES_TR : QUICK_REPLIES_EN).map(q => <button key={q} onClick={() => { setReply(q); setShowQuick(false); }} className="text-left text-xs px-2.5 py-1.5 rounded-lg bg-slate-100 dark:bg-white/5 text-slate-600 dark:text-slate-300 hover:bg-indigo-50 hover:text-indigo-700">{q}</button>)}
          </div>
        )}
        <div className="flex items-end gap-2">
          <button onClick={() => setShowQuick(v => !v)} title={tr ? 'Hazır yanıtlar' : 'Quick replies'} className={`h-11 w-11 shrink-0 rounded-xl border inline-flex items-center justify-center ${showQuick ? 'border-indigo-300 text-indigo-600 bg-indigo-50 dark:bg-indigo-500/10' : 'border-slate-200 dark:border-slate-700 text-slate-500'}`}>{showQuick ? <X size={16} /> : <Zap size={16} />}</button>
          <textarea rows={1} value={reply} onChange={e => setReply(e.target.value)} onKeyDown={e => { if (e.key === 'Enter' && (e.ctrlKey || e.metaKey)) { e.preventDefault(); send(); } }}
            placeholder={tr ? 'Yanıt yazın… (Ctrl+Enter gönderir)' : 'Write a reply… (Ctrl+Enter)'} className="flex-1 min-h-[44px] max-h-40 px-3 py-2.5 rounded-xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-sm outline-none focus:border-indigo-500 resize-y" />
          <button onClick={() => send()} disabled={!reply.trim() || sending} className="h-11 px-4 shrink-0 rounded-xl text-sm font-semibold text-white bg-indigo-600 hover:bg-indigo-500 disabled:opacity-50 inline-flex items-center gap-1.5"><Send size={15} /><span className="hidden sm:inline">{tr ? 'Gönder' : 'Send'}</span></button>
        </div>
        {isOpen(selected) && reply.trim() && <button onClick={() => send('Resolved')} className="text-xs font-semibold text-emerald-600 hover:underline animate-in fade-in">{tr ? 'Gönder ve çözüldü olarak işaretle' : 'Send & mark resolved'}</button>}
      </div>
    </div>
  ) : (
    <div className="hidden lg:flex lg:col-span-3 flex-col items-center justify-center bg-white dark:bg-slate-900 border border-slate-100 dark:border-slate-800 rounded-[20px] h-[calc(100dvh-320px)] min-h-[520px] text-slate-400">
      <MessageSquare size={44} className="mb-3 opacity-30 pc-float" /><p className="text-sm font-semibold">{tr ? 'Görüntülemek için bir talep seçin' : 'Select a ticket'}</p>
      {stats.awaiting > 0 && <p className="text-xs mt-1">{tr ? `${stats.awaiting} talep yanıtınızı bekliyor` : `${stats.awaiting} awaiting reply`}</p>}
    </div>
  );

  return (
    <div className="space-y-5 pb-6">
      <div>
        <h2 className="text-2xl lg:text-3xl font-black text-slate-900 dark:text-white tracking-tight">{tr ? 'Müşteri Talepleri' : 'Support Tickets'}</h2>
        <p className="text-sm text-slate-500 dark:text-slate-400">{tr ? 'Müşteri portalından gelen talepler ve yazışmalar.' : 'Requests and conversations from the client portal.'}</p>
      </div>
      <div className={`grid grid-cols-2 lg:grid-cols-4 gap-3 pc-stagger ${selected ? 'hidden lg:grid' : ''}`}>
        {kpis.map(k => { const Icon = k.icon; return (
          <button key={k.label} onClick={k.on} className="text-left bg-white dark:bg-slate-900 border border-slate-100 dark:border-slate-800 rounded-[20px] p-4 pc-lift">
            <div className="flex items-center gap-2.5"><span className={`p-2 rounded-xl bg-gradient-to-br ${k.grad} text-white shadow-md`}><Icon size={16} /></span><span className="text-[11px] font-semibold text-slate-500 dark:text-slate-400">{k.label}</span></div>
            <p className="text-2xl font-black text-slate-900 dark:text-white mt-2"><AnimatedNumber value={k.value} /></p>
          </button>
        ); })}
      </div>
      <div className="grid grid-cols-1 lg:grid-cols-5 gap-4">{list}{detail}</div>
    </div>
  );
};

export default TicketsView;
