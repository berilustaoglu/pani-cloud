
import React, { useEffect, useRef, useState } from 'react';
import { ScreenRequest } from '../types';
import { X, Maximize2, Minimize2, ShieldAlert, MonitorPlay, Loader2, Activity, Info, RefreshCcw, Play, Volume2, VolumeX } from 'lucide-react';
import { doc, onSnapshot } from 'firebase/firestore';
import { db } from '../firebase';

interface Props {
    request: ScreenRequest;
    stream: MediaStream | null;
    connectionState: string;
    iceState: string;
    adminCandidates: number;
    staffCandidates: number;
    staffName: string;
    language: 'tr' | 'en';
    onClose: () => void;
    onReconnect?: () => void;
}

const ScreenViewerModal: React.FC<Props> = ({ request, stream, connectionState, iceState, adminCandidates, staffCandidates, staffName, language, onClose, onReconnect }) => {
    const videoRef = useRef<HTMLVideoElement>(null);
    const [status, setStatus] = useState<'Connecting' | 'Live' | 'Ended'>('Connecting');
    const [isFullScreen, setIsFullScreen] = useState(false);
    const [showDiagnostics, setShowDiagnostics] = useState(false);
    const [isPaused, setIsPaused] = useState(false);
    const [volume, setVolume] = useState(1);
    const [isMuted, setIsMuted] = useState(false);

    useEffect(() => {
        if (videoRef.current && stream) {
            console.log("Attaching stream to video", stream.id, "Tracks:", stream.getVideoTracks().length);

            const video = videoRef.current;
            video.srcObject = stream;

            const playVideo = async () => {
                try {
                    await video.play();
                    setIsPaused(false);
                } catch (err) {
                    console.warn("Autoplay blocked or failed:", err);
                    setIsPaused(true);
                }
            };

            const videoTrack = stream.getVideoTracks()[0];
            if (videoTrack) {
                // If we have a track, we are officially "Live" from a connection perspective
                setStatus('Live');

                if (videoTrack.readyState === 'live') {
                    playVideo();
                } else {
                    console.log("Track not live yet, waiting...");
                    videoTrack.onunmute = () => {
                        console.log("Track unmuted, playing...");
                        playVideo();
                    };
                }
            } else {
                setStatus('Connecting');
            }
        } else if (!stream) {
            setStatus('Connecting');
        }
    }, [stream, connectionState]);

    useEffect(() => {
        if (videoRef.current) {
            videoRef.current.volume = volume;
            videoRef.current.muted = isMuted;
        }
    }, [volume, isMuted]);

    useEffect(() => {
        const unsub = onSnapshot(doc(db, "screen_requests", request.id), (snap) => {
            const data = snap.data();
            if (data?.status === 'Expired' || data?.status === 'Rejected') {
                setStatus('Ended');
            }
        });
        return () => unsub();
    }, [request.id]);

    const handleManualPlay = () => {
        if (videoRef.current) {
            videoRef.current.play().then(() => setIsPaused(false)).catch(e => console.error(e));
        }
    };

    return (
        <div className={`fixed inset-0 z-[10000] flex flex-col transition-all duration-500 ${isFullScreen ? 'bg-black p-0' : 'bg-slate-950/40 backdrop-blur-2xl p-6 lg:p-12'}`}>
            <div className={`relative bg-black w-full h-full overflow-hidden flex flex-col ${isFullScreen ? '' : 'rounded-[40px] border border-white/10 shadow-2xl'}`}>
                {/* Header */}
                <div className="absolute top-0 inset-x-0 p-6 flex justify-between items-center z-50 bg-gradient-to-b from-black/80 to-transparent">
                    <div className="flex items-center gap-4">
                        <div className={`w-3 h-3 rounded-full ${status === 'Live' ? 'bg-red-500 animate-pulse' : 'bg-slate-500'}`} />
                        <div>
                            <h3 className="text-white font-black text-lg tracking-tight uppercase">{staffName}</h3>
                            <p className="text-white/50 text-[10px] font-black tracking-widest uppercase">
                                {status === 'Live' ? 'LIVE STREAMING' : status.toUpperCase()}
                            </p>
                        </div>
                    </div>

                    <div className="flex items-center gap-2">
                        {onReconnect && (
                            <button
                                onClick={onReconnect}
                                className="p-3 bg-white/10 hover:bg-white/20 text-white rounded-2xl transition-all"
                                title="Bağlantıyı Sıfırla"
                            >
                                <RefreshCcw size={20} />
                            </button>
                        )}
                        <button
                            onClick={() => setShowDiagnostics(!showDiagnostics)}
                            className={`p-3 rounded-2xl transition-all ${showDiagnostics ? 'bg-indigo-500 text-white' : 'bg-white/10 text-white/50 hover:bg-white/20'}`}
                        >
                            <Info size={20} />
                        </button>
                        <button
                            onClick={() => setIsFullScreen(!isFullScreen)}
                            className="p-3 bg-white/10 hover:bg-white/20 text-white rounded-2xl transition-all"
                        >
                            {isFullScreen ? <Minimize2 size={20} /> : <Maximize2 size={20} />}
                        </button>
                        <button
                            onClick={onClose}
                            className="p-3 bg-red-500/20 hover:bg-red-500 text-white rounded-2xl transition-all"
                        >
                            <X size={20} />
                        </button>
                    </div>
                </div>

                {/* Diagnostics Panel */}
                {showDiagnostics && (
                    <div className="absolute top-24 right-6 z-[60] bg-slate-900/95 backdrop-blur-md p-6 rounded-3xl border border-white/10 w-72 shadow-2xl animate-in slide-in-from-right duration-300">
                        <h4 className="text-white font-black text-[10px] uppercase tracking-widest mb-4 flex items-center gap-2 border-b border-white/5 pb-3">
                            <Activity size={14} className="text-indigo-400" />
                            Diagnostics Panel
                        </h4>
                        <div className="space-y-4">
                            <div className="flex flex-col gap-1">
                                <span className="text-white/40 text-[9px] font-black uppercase">Connection / ICE</span>
                                <div className="flex gap-2">
                                    <span className={`text-[8px] font-black uppercase px-2 py-0.5 rounded ${connectionState === 'connected' ? 'bg-green-500/20 text-green-400' : 'bg-amber-500/20 text-amber-400'}`}>{connectionState}</span>
                                    <span className={`text-[8px] font-black uppercase px-2 py-0.5 rounded ${iceState === 'connected' ? 'bg-green-500/20 text-green-400' : 'bg-amber-500/20 text-amber-400'}`}>{iceState}</span>
                                </div>
                            </div>
                            <div className="grid grid-cols-2 gap-2">
                                <div className="flex flex-col gap-1">
                                    <span className="text-white/40 text-[9px] font-black uppercase">Admin ICE</span>
                                    <span className="text-white/60 text-[9px] font-black">{adminCandidates}</span>
                                </div>
                                <div className="flex flex-col gap-1">
                                    <span className="text-white/40 text-[9px] font-black uppercase">Staff ICE</span>
                                    <span className="text-white/60 text-[9px] font-black">{staffCandidates}</span>
                                </div>
                            </div>
                            <div className="flex justify-between items-center">
                                <span className="text-white/40 text-[9px] font-black uppercase">Video Tracks</span>
                                <span className="text-white/60 text-[9px] font-black">{stream?.getVideoTracks().length || 0}</span>
                            </div>
                            {stream?.getVideoTracks()[0] && (
                                <div className="flex justify-between items-center">
                                    <span className="text-white/40 text-[9px] font-black uppercase">Track Status</span>
                                    <span className="text-green-400 text-[9px] font-black uppercase">{stream.getVideoTracks()[0].readyState}</span>
                                </div>
                            )}
                            <div className="flex justify-between items-center">
                                <span className="text-white/40 text-[9px] font-black uppercase">Audio Tracks</span>
                                <span className={`${(stream?.getAudioTracks().length || 0) > 0 ? 'text-green-400' : 'text-rose-400'} text-[9px] font-black`}>{stream?.getAudioTracks().length || 0}</span>
                            </div>
                            <button
                                onClick={handleManualPlay}
                                className="w-full py-2 bg-indigo-500 text-white rounded-xl text-[9px] font-black uppercase tracking-widest mt-2 hover:bg-indigo-600 transition-all flex items-center justify-center gap-2"
                            >
                                <Play size={10} fill="currentColor" /> Force Play Video
                            </button>
                        </div>
                    </div>
                )}

                {/* Video Area */}
                <div className="flex-1 relative flex items-center justify-center">
                    <video
                        ref={videoRef}
                        autoPlay
                        playsInline
                        className="w-full h-full object-contain"
                    />

                    {isPaused && status === 'Live' && (
                        <div className="absolute inset-0 bg-black/60 backdrop-blur-sm flex flex-col items-center justify-center gap-4 z-40">
                            <div className="p-6 bg-white rounded-full text-black hover:scale-110 transition-transform cursor-pointer shadow-2xl" onClick={handleManualPlay}>
                                <Play size={40} fill="currentColor" />
                            </div>
                            <p className="text-white font-black text-sm uppercase tracking-widest animate-pulse">
                                {language === 'tr' ? 'VİDEOYU BAŞLATMAK İÇİN TIKLAYIN' : 'CLICK TO START VIDEO'}
                            </p>
                        </div>
                    )}

                    {status !== 'Live' && (
                        <div className="absolute inset-0 flex flex-col items-center justify-center gap-4 bg-slate-950/50 backdrop-blur-sm">
                            {status === 'Connecting' ? (
                                <>
                                    <Loader2 size={48} className="text-indigo-500 animate-spin" />
                                    <p className="text-white font-black text-sm uppercase tracking-widest">
                                        {language === 'tr' ? 'BAĞLANTI KURULUYOR...' : 'ESTABLISHING...'}
                                    </p>
                                    <p className="text-white/30 text-[9px] font-black uppercase mt-1">Status: {connectionState} / {iceState}</p>
                                </>
                            ) : (
                                <>
                                    <ShieldAlert size={48} className="text-amber-500" />
                                    <p className="text-white font-black text-sm uppercase tracking-widest">
                                        {language === 'tr' ? 'YAYIN SONLANDI' : 'STREAM ENDED'}
                                    </p>
                                    <button onClick={onClose} className="mt-4 px-8 py-3 bg-white text-black rounded-2xl font-black text-[10px] uppercase tracking-widest hover:bg-slate-100 transition-all">
                                        {language === 'tr' ? 'KAPAT' : 'CLOSE'}
                                    </button>
                                </>
                            )}
                        </div>
                    )}
                </div>

                {/* Footer Info */}
                {!isFullScreen && (
                    <div className="p-6 bg-slate-950/50 border-t border-white/5 flex justify-between items-center">
                        <div className="flex items-center gap-6">
                            <div className="flex items-center gap-2">
                                <MonitorPlay size={16} className="text-white/30" />
                                <span className="text-white/40 text-[9px] font-black uppercase tracking-widest">PanimoCloud Secure Link</span>
                            </div>
                             <div className="flex items-center gap-2">
                                <Activity size={16} className="text-white/30" />
                                <span className="text-white/40 text-[9px] font-black uppercase tracking-widest">State: {connectionState}</span>
                            </div>
                        </div>

                        <div className="flex items-center gap-4 bg-white/5 px-4 py-2 rounded-2xl border border-white/5">
                            <button 
                                onClick={() => setIsMuted(!isMuted)}
                                className="text-white/60 hover:text-white transition-colors"
                            >
                                {isMuted || volume === 0 ? <VolumeX size={18} /> : <Volume2 size={18} />}
                            </button>
                            <input 
                                type="range" 
                                min="0" 
                                max="1" 
                                step="0.01" 
                                value={volume} 
                                onChange={(e) => {
                                    setVolume(parseFloat(e.target.value));
                                    if (parseFloat(e.target.value) > 0) setIsMuted(false);
                                }}
                                className="w-24 h-1 bg-white/10 rounded-lg appearance-none cursor-pointer accent-indigo-500"
                            />
                        </div>
                    </div>
                )}
            </div>
        </div>
    );
};

export default ScreenViewerModal;
