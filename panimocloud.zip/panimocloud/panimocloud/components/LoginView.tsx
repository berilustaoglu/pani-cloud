
import React, { useState, useRef } from 'react';
import { User } from '../types';
import { translations } from '../translations';
import { Mail, Lock, Shield, Eye, EyeOff, Loader2, UserPlus, ArrowRight } from 'lucide-react';
import { signInWithEmailAndPassword, createUserWithEmailAndPassword, sendPasswordResetEmail } from 'firebase/auth';
import { auth } from '../firebase';

interface Props {
  onLogin: (user: User) => void;
  /** Uygulamanın gösterdiği bilgilendirme (doğrulama e-postası gönderildi, e-posta tanımsız vb.) */
  notice?: string | null;
  onDismissNotice?: () => void;
  language: 'tr' | 'en';
}

type ViewMode = 'login' | 'register' | 'forgot-password';

const LoginView: React.FC<Props> = ({ onLogin, language = 'tr', notice, onDismissNotice }) => {
  const [viewMode, setViewMode] = useState<ViewMode>('login');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [error, setError] = useState('');
  const [isAuthenticating, setIsAuthenticating] = useState(false);
  const [resetSent, setResetSent] = useState(false);

  // Refs for focus
  const emailRef = useRef<HTMLInputElement>(null);
  const passwordRef = useRef<HTMLInputElement>(null);

  const handleAuth = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setIsAuthenticating(true);

    try {
      const cleanEmail = (email || '').toLowerCase().trim();
      
      if (viewMode === 'forgot-password') {
        if (!cleanEmail) throw new Error(language === 'tr' ? 'Lütfen e-posta adresinizi girin.' : 'Please enter your email.');
        await sendPasswordResetEmail(auth, cleanEmail);
        setResetSent(true);
      } else if (viewMode === 'register') {
        if (!cleanEmail || !password) throw new Error(language === 'tr' ? 'E-posta ve şifre gereklidir.' : 'Email and password are required.');
        
        // Ekipte tanımlı olup olmadığı ve e-posta doğrulaması sunucuda (linkAccount) kontrol edilir
        await createUserWithEmailAndPassword(auth, cleanEmail, password);
      } else {
        if (!cleanEmail || !password) throw new Error(language === 'tr' ? 'E-posta ve şifre gereklidir.' : 'Email and password are required.');
        await signInWithEmailAndPassword(auth, cleanEmail, password);
      }
    } catch (err: any) {
      console.error("Auth error:", err);
      let msg = language === 'tr' ? 'İşlem başarısız.' : 'Operation failed.';

      if (err.code === 'auth/invalid-credential' || err.code === 'auth/user-not-found' || err.code === 'auth/wrong-password') {
        msg = language === 'tr' ? 'Hatalı e-posta veya şifre.' : 'Invalid email or password.';
      } else if (err.code === 'auth/email-already-in-use') {
        msg = language === 'tr' ? 'Bu e-posta zaten kullanımda. Lütfen giriş yapmayı deneyin.' : 'Email already in use. Please try logging in.';
      } else if (err.code === 'auth/too-many-requests') {
        msg = language === 'tr' ? 'Çok fazla deneme yaptınız. Lütfen bir süre sonra tekrar deneyin.' : 'Too many attempts. Please try again later.';
      } else if (err.code === 'auth/network-request-failed') {
        msg = language === 'tr' ? 'Şirket ağı/güvenlik duvarı (Firewall/Proxy/VPN) Firebase erişimini engelliyor. İnternet ve proxy ayarlarınızı kontrol edin.' : 'Corporate network/firewall is blocking Firebase auth requests. Check network/VPN/proxy settings.';
      } else if (err.code === 'auth/unauthorized-domain') {
        msg = language === 'tr' ? 'Bu web adresi (Domain/IP) Firebase Yetkili Alan Adları listesinde ekli değil.' : 'This domain is not added to Firebase Authorized Domains.';
      } else if (err.message) {
        msg = err.message;
      }
      setError(String(msg));
    } finally {
      setIsAuthenticating(false);
    }
  };

  const getHeaderTitle = () => {
    if (viewMode === 'forgot-password') return language === 'tr' ? 'ŞİFRE SIFIRLAMA' : 'PASSWORD RESET';
    if (viewMode === 'register') return language === 'tr' ? 'HESAP OLUŞTURMA' : 'ACCOUNT REGISTRATION';
    return language === 'tr' ? 'TEKRAR HOŞ GELDİNİZ' : 'WELCOME BACK';
  };

  return (
    <div className="h-dvh bg-[#030712] flex p-4 relative overflow-y-auto overscroll-contain text-white">
      <div className="fixed inset-0 overflow-hidden pointer-events-none">
        <div className="absolute -top-[20%] -left-[10%] w-[70%] h-[70%] bg-indigo-900/10 rounded-full blur-[120px]"></div>
        <div className="absolute bottom-[10%] -right-[10%] w-[50%] h-[50%] bg-blue-900/10 rounded-full blur-[100px]"></div>
      </div>

      <div className="bg-[#050a18] border border-slate-800/60 p-8 lg:p-12 rounded-[48px] shadow-2xl w-full max-w-[420px] m-auto relative z-20 flex flex-col items-center">
        <div className="text-center mb-10 w-full">
          <h1 className="text-4xl font-black italic">PanimoCloud <span className="text-indigo-500 not-italic">ERP</span></h1>
          <div className="w-16 h-1.5 bg-indigo-600 mt-4 mx-auto rounded-full shadow-lg"></div>
          <p className="text-slate-500 mt-8 font-black uppercase text-[10px] tracking-[0.3em]">
            {getHeaderTitle()}
          </p>
        </div>

        {resetSent ? (
          <div className="text-center w-full">
            <div className="w-20 h-20 bg-green-500/10 rounded-full flex items-center justify-center mx-auto mb-6">
              <Mail className="text-green-500" size={32} />
            </div>
            <h3 className="text-xl font-bold mb-4">{language === 'tr' ? 'E-posta Gönderildi' : 'Email Sent'}</h3>
            <p className="text-slate-400 text-sm mb-8">
              {language === 'tr' ? 'Şifre sıfırlama bağlantısı gönderildi.' : 'Reset link sent.'}
            </p>
            <button
              onClick={() => { setResetSent(false); setViewMode('login'); }}
              className="text-indigo-400 font-black text-[10px] uppercase underline"
            >
              {language === 'tr' ? 'GİRİŞ EKRANINA DÖN' : 'BACK TO LOGIN'}
            </button>
          </div>
        ) : (
          <form onSubmit={handleAuth} className="w-full space-y-5">
            <div className="space-y-4">
              <div className="relative group" onClick={() => emailRef.current?.focus()}>
                <Mail className="absolute left-5 top-1/2 -translate-y-1/2 text-slate-500" size={20} />
                <input
                  ref={emailRef}
                  type="email" required disabled={isAuthenticating}
                  value={email} onChange={(e) => setEmail(e.target.value)}
                  className="w-full bg-[#0B1121] border border-slate-800 rounded-3xl py-5 pl-14 pr-6 text-white font-bold outline-none focus:border-indigo-500"
                  placeholder="email@panimo.com"
                />
              </div>

              {viewMode !== 'forgot-password' && (
                <div className="relative group" onClick={() => passwordRef.current?.focus()}>
                  <Lock className="absolute left-5 top-1/2 -translate-y-1/2 text-slate-500" size={20} />
                  <input
                    ref={passwordRef}
                    type={showPassword ? "text" : "password"} required disabled={isAuthenticating}
                    value={password} onChange={(e) => setPassword(e.target.value)}
                    className="w-full bg-[#0B1121] border border-slate-800 rounded-3xl py-5 pl-14 pr-14 text-white font-bold outline-none focus:border-indigo-500"
                    placeholder="••••••••"
                  />
                  <button type="button" onClick={() => setShowPassword(!showPassword)} className="absolute right-5 top-1/2 -translate-y-1/2 text-slate-500">
                    {showPassword ? <EyeOff size={18} /> : <Eye size={18} />}
                  </button>
                </div>
              )}
            </div>

            {viewMode === 'login' && (
              <div className="flex justify-end pr-2">
                <button type="button" onClick={() => setViewMode('forgot-password')} className="text-[10px] font-black text-slate-500 hover:text-indigo-400">
                  {language === 'tr' ? 'ŞİFREMİ UNUTTUM' : 'FORGOT PASSWORD?'}
                </button>
              </div>
            )}

            {notice && !error && (
              <div className="bg-indigo-500/10 border border-indigo-500/30 p-4 rounded-2xl flex items-start gap-3 text-indigo-200 text-xs font-semibold leading-relaxed">
                <Shield size={16} className="shrink-0 mt-0.5" />
                <span className="flex-1">{notice}</span>
                {onDismissNotice && <button type="button" onClick={onDismissNotice} className="text-indigo-300 hover:text-white">×</button>}
              </div>
            )}

            {error && (
              <div className="bg-red-500/10 border border-red-500/20 p-4 rounded-2xl flex items-center gap-3 text-red-500 text-[10px] font-black uppercase">
                <Shield size={16} /> {error}
              </div>
            )}

            <button
              type="submit" disabled={isAuthenticating}
              className={`w-full py-5 rounded-3xl font-black text-[11px] uppercase tracking-widest ${viewMode !== 'login' ? 'bg-indigo-600 text-white' : 'bg-white text-slate-950'}`}
            >
              {isAuthenticating ? <Loader2 className="animate-spin mx-auto" size={20} /> : (
                <div className="flex items-center justify-center gap-2">
                  {viewMode === 'forgot-password' ? <Mail size={18} /> : viewMode === 'register' ? <UserPlus size={18} /> : <ArrowRight size={18} />}
                  {viewMode === 'forgot-password' ? (language === 'tr' ? 'BAĞLANTI GÖNDER' : 'SEND LINK') : viewMode === 'register' ? (language === 'tr' ? 'KAYIT OL' : 'REGISTER') : (language === 'tr' ? 'GİRİŞ YAP' : 'LOGIN')}
                </div>
              )}
            </button>

            <div className="mt-8 text-center">
              <button
                type="button"
                onClick={() => {
                  if (viewMode === 'forgot-password') {
                    setViewMode('login');
                  } else {
                    setViewMode(viewMode === 'register' ? 'login' : 'register');
                  }
                  setError('');
                }}
                className="text-indigo-400 text-[10px] font-black uppercase underline"
              >
                {viewMode === 'forgot-password' 
                   ? (language === 'tr' ? 'GİRİŞ EKRANINA DÖN' : 'BACK TO LOGIN') 
                   : (viewMode === 'register' 
                      ? (language === 'tr' ? 'HESABINIZ VAR MI?' : 'HAVE AN ACCOUNT?') 
                      : (language === 'tr' ? 'HESABINIZ YOK MU?' : 'NO ACCOUNT?'))}
              </button>
            </div>
          </form>
        )}

        <div className="mt-10 pt-8 border-t border-slate-800/50 w-full text-center opacity-50">
          <p className="text-[9px] font-black uppercase tracking-widest">PANIMO SOFT CLOUD V3.0</p>
        </div>
      </div>
    </div>
  );
};

export default LoginView;
