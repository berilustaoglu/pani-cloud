import React, { useEffect, useMemo, useState } from 'react';
import {
  Plus, Search, LayoutGrid, List, GanttChartSquare, FileSpreadsheet, Archive, Edit, AlertTriangle, Timer,
  ListChecks, Wallet, Briefcase, TrendingUp, ShieldAlert, CalendarClock, X, SlidersHorizontal, ArrowUpDown,
  PauseCircle, CheckCircle2, Layers, Tag, UserCog, ChevronRight
} from 'lucide-react';
import { Project, Task, User, Currency, ProjectPriority, ProjectType } from '../types';
import {
  computeProjectMetrics, ProjectMetrics, PRIORITY_META, PRIORITY_ORDER, TYPE_META, RISK_META, daysLeftText
} from '../services/projectMetrics';
import { toTRY, formatTRY, localISO, isHoldExpired } from '../services/insights';
import { AnimatedNumber, GrowBar } from './ui/Motion';

type StatusTab = 'active' | 'on_hold' | 'completed' | 'all';
type ViewKind = 'grid' | 'list' | 'timeline';
type SortKey = 'deadline' | 'priority' | 'risk' | 'progress' | 'budget' | 'name' | 'newest';

interface Props {
  projects: Project[];
  tasks: Task[];
  users: User[];
  language: 'tr' | 'en';
  showFinancials: boolean;
  rates: { TRY: number; EUR: number };
  onOpen: (p: Project) => void;
  onEdit: (p: Project) => void;
  onNew: () => void;
  onExport: () => void;
  onOpenArchive?: () => void;
}

const sym = (c?: Currency) => (c === Currency.TRY ? '₺' : c === Currency.EUR ? '€' : '$');
const money = (n: number, c?: Currency) => `${sym(c)}${Math.round(n).toLocaleString('tr-TR')}`;
const RISK_ORDER = { critical: 0, risk: 1, watch: 2, ok: 3 } as const;

const readPref = <T,>(key: string, fallback: T): T => {
  try { const v = localStorage.getItem(key); return v ? (JSON.parse(v) as T) : fallback; } catch { return fallback; }
};

const Avatars: React.FC<{ people: User[]; max?: number }> = ({ people, max = 4 }) => (
  <div className="flex -space-x-2">
    {people.slice(0, max).map(u => (
      u.avatar
        ? <img key={u.id} src={u.avatar} alt={u.name} title={u.name} className="w-7 h-7 rounded-full object-cover ring-2 ring-white dark:ring-slate-900" />
        : <span key={u.id} title={u.name} className="w-7 h-7 rounded-full ring-2 ring-white dark:ring-slate-900 bg-gradient-to-br from-indigo-500 to-violet-500 text-white text-[10px] font-black flex items-center justify-center">{u.name?.[0]}</span>
    ))}
    {people.length > max && <span className="w-7 h-7 rounded-full ring-2 ring-white dark:ring-slate-900 bg-slate-100 dark:bg-slate-800 text-slate-500 text-[10px] font-black flex items-center justify-center">+{people.length - max}</span>}
  </div>
);

const ProjectsBoard: React.FC<Props> = ({ projects, tasks, users, language, showFinancials, rates, onOpen, onEdit, onNew, onExport, onOpenArchive }) => {
  const tr = language === 'tr';
  const [tab, setTab] = useState<StatusTab>(() => readPref('pc-proj-tab', 'active'));
  const [view, setView] = useState<ViewKind>(() => readPref('pc-proj-view', readPref<string>('projectsDisplayMode', 'grid') === 'list' ? 'list' : 'grid'));
  const [sort, setSort] = useState<SortKey>(() => readPref('pc-proj-sort', 'deadline'));
  const [search, setSearch] = useState('');
  const [typeF, setTypeF] = useState<string>('all');
  const [prioF, setPrioF] = useState<string>('all');
  const [managerF, setManagerF] = useState<string>('all');
  const [tagF, setTagF] = useState<string[]>([]);
  const [riskOnly, setRiskOnly] = useState(false);
  const [showFilters, setShowFilters] = useState(false);

  useEffect(() => { try { localStorage.setItem('pc-proj-tab', JSON.stringify(tab)); localStorage.setItem('pc-proj-view', JSON.stringify(view)); localStorage.setItem('pc-proj-sort', JSON.stringify(sort)); } catch {} }, [tab, view, sort]);

  const metrics = useMemo(() => {
    const m = new Map<string, ProjectMetrics>();
    projects.forEach(p => m.set(p.id, computeProjectMetrics(p, tasks, language)));
    return m;
  }, [projects, tasks, language]);

  const userById = useMemo(() => new Map(users.map(u => [u.id, u])), [users]);
  const peopleOf = (p: Project) => {
    const ids = new Set<string>(p.teamMemberIds || []);
    tasks.filter(t => t.projectId === p.id).forEach(t => (t.assignedTo || []).forEach(id => ids.add(id)));
    if (p.projectManagerId) ids.delete(p.projectManagerId);
    const list = [...ids].map(id => userById.get(id)).filter(Boolean) as User[];
    const pm = p.projectManagerId ? userById.get(p.projectManagerId) : undefined;
    return pm ? [pm, ...list] : list;
  };

  const counts = useMemo(() => ({
    active: projects.filter(p => p.status === 'Active' || p.status === 'Revizyonda').length,
    on_hold: projects.filter(p => p.status === 'On Hold').length,
    completed: projects.filter(p => p.status === 'Completed').length,
    all: projects.length,
  }), [projects]);

  const allTags = useMemo(() => {
    const c = new Map<string, number>();
    projects.forEach(p => (p.tags || []).forEach(t => c.set(t, (c.get(t) || 0) + 1)));
    return [...c.entries()].sort((a, b) => b[1] - a[1]).map(([t]) => t);
  }, [projects]);
  const managers = useMemo(() => [...new Set(projects.map(p => p.projectManagerId).filter(Boolean))].map(id => userById.get(id!)).filter(Boolean) as User[], [projects, userById]);

  const filtered = useMemo(() => {
    const q = search.trim().toLocaleLowerCase('tr-TR');
    const list = projects.filter(p => {
      if (tab === 'active' && !(p.status === 'Active' || p.status === 'Revizyonda')) return false;
      if (tab === 'on_hold' && p.status !== 'On Hold') return false;
      if (tab === 'completed' && p.status !== 'Completed') return false;
      if (typeF !== 'all' && p.projectType !== typeF) return false;
      if (prioF !== 'all' && (p.priority || 'none') !== prioF) return false;
      if (managerF !== 'all' && p.projectManagerId !== managerF) return false;
      if (tagF.length && !tagF.every(t => (p.tags || []).includes(t))) return false;
      if (riskOnly && !['risk', 'critical'].includes(metrics.get(p.id)!.risk)) return false;
      if (q) {
        const hay = [p.name, p.client, p.description, p.clientContactName, p.clientEmail, ...(p.tags || [])].join(' ').toLocaleLowerCase('tr-TR');
        if (!hay.includes(q)) return false;
      }
      return true;
    });
    const val = (p: Project) => toTRY(p.totalAmountWithTax || p.budget || 0, p.currency, rates);
    return list.sort((a, b) => {
      const ma = metrics.get(a.id)!, mb = metrics.get(b.id)!;
      switch (sort) {
        case 'deadline': return (a.deliveryDate || '9999').localeCompare(b.deliveryDate || '9999');
        case 'priority': return (PRIORITY_ORDER[a.priority as ProjectPriority] ?? 9) - (PRIORITY_ORDER[b.priority as ProjectPriority] ?? 9);
        case 'risk': return RISK_ORDER[ma.risk] - RISK_ORDER[mb.risk];
        case 'progress': return (b.progress || 0) - (a.progress || 0);
        case 'budget': return val(b) - val(a);
        case 'name': return a.name.localeCompare(b.name, 'tr');
        case 'newest': return b.id.localeCompare(a.id);
      }
    });
  }, [projects, tab, typeF, prioF, managerF, tagF, riskOnly, search, sort, metrics, rates]);

  const kpi = useMemo(() => {
    const active = projects.filter(p => p.status === 'Active' || p.status === 'Revizyonda');
    const ms = active.map(p => metrics.get(p.id)!);
    const portfolio = projects.filter(p => p.status !== 'Completed').reduce((s, p) => s + toTRY(p.totalAmountWithTax || p.budget || 0, p.currency, rates), 0);
    const collected = projects.reduce((s, p) => s + toTRY(metrics.get(p.id)!.paidAmount, p.currency, rates), 0);
    const totalValue = projects.reduce((s, p) => s + toTRY(p.totalAmountWithTax || p.budget || 0, p.currency, rates), 0);
    return {
      active: active.length,
      avgProgress: active.length ? Math.round(active.reduce((s, p) => s + (p.progress || 0), 0) / active.length) : 0,
      behind: ms.filter(m => m.scheduleGap !== null && m.scheduleGap <= -10).length,
      atRisk: ms.filter(m => m.risk === 'risk' || m.risk === 'critical').length,
      dueSoon: ms.filter(m => m.daysLeft !== null && m.daysLeft >= 0 && m.daysLeft <= 30).length,
      late: ms.filter(m => m.daysLeft !== null && m.daysLeft < 0).length,
      overduePayments: projects.reduce((s, p) => s + metrics.get(p.id)!.overduePayments, 0),
      portfolio,
      collectedPct: totalValue ? Math.round((collected / totalValue) * 100) : 0,
    };
  }, [projects, metrics, rates]);

  const activeFilterCount = [typeF !== 'all', prioF !== 'all', managerF !== 'all', tagF.length > 0, riskOnly].filter(Boolean).length;
  const clearFilters = () => { setTypeF('all'); setPrioF('all'); setManagerF('all'); setTagF([]); setRiskOnly(false); setSearch(''); };

  const selectCls = 'h-10 px-3 rounded-xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700 text-xs font-semibold text-slate-700 dark:text-slate-200 outline-none focus:border-indigo-500 cursor-pointer';

  // ---------- Ortak parçalar ----------
  const deliveryChip = (p: Project, m: ProjectMetrics) => {
    if (p.status === 'Completed') return <span className="text-emerald-600 dark:text-emerald-400">{tr ? 'Teslim edildi' : 'Delivered'}</span>;
    const cls = m.daysLeft === null ? 'text-slate-400' : m.daysLeft < 0 ? 'text-rose-600 dark:text-rose-400' : m.daysLeft <= 7 ? 'text-amber-600 dark:text-amber-400' : 'text-slate-600 dark:text-slate-300';
    return <span className={cls}>{daysLeftText(m.daysLeft, language)}</span>;
  };

  const progressWithPlan = (p: Project, m: ProjectMetrics, compact?: boolean) => {
    const color = p.status === 'Completed' ? 'bg-emerald-500' : p.status === 'On Hold' ? 'bg-amber-400' : m.scheduleGap !== null && m.scheduleGap <= -10 ? 'bg-gradient-to-r from-orange-400 to-rose-500' : 'bg-gradient-to-r from-indigo-500 to-violet-500';
    return (
      <div>
        {!compact && (
          <div className="flex items-center justify-between text-[11px] font-semibold mb-1.5">
            <span className="text-slate-500 dark:text-slate-400">{tr ? 'İlerleme' : 'Progress'} <b className="text-slate-900 dark:text-white">%{p.progress || 0}</b></span>
            {m.plannedProgress !== null && p.status !== 'Completed' && (
              <span className={m.scheduleGap! <= -10 ? 'text-rose-500' : m.scheduleGap! >= 5 ? 'text-emerald-600' : 'text-slate-400'}>
                {tr ? 'Plan' : 'Plan'} %{m.plannedProgress} · {m.scheduleGap! >= 0 ? (tr ? `+${m.scheduleGap} ileride` : `+${m.scheduleGap} ahead`) : (tr ? `${Math.abs(m.scheduleGap!)} geride` : `${Math.abs(m.scheduleGap!)} behind`)}
              </span>
            )}
          </div>
        )}
        <div className="relative h-2 w-full rounded-full bg-slate-100 dark:bg-white/5">
          <div className={`h-full rounded-full pc-grow-x ${color}`} style={{ width: `${p.progress || 0}%` }} />
          {m.plannedProgress !== null && p.status !== 'Completed' && (
            <span className="absolute -top-1 -bottom-1 w-0.5 rounded-full bg-slate-900/60 dark:bg-white/70" style={{ left: `calc(${m.plannedProgress}% - 1px)` }} title={(tr ? 'Planlanan: %' : 'Planned: ') + m.plannedProgress} />
          )}
        </div>
      </div>
    );
  };

  // ---------- Kart görünümü ----------
  const card = (p: Project) => {
    const m = metrics.get(p.id)!;
    const type = TYPE_META[p.projectType] || TYPE_META[ProjectType.OTHER];
    const people = peopleOf(p);
    const risk = RISK_META[m.risk];
    const payPct = m.totalAmount ? Math.round((m.paidAmount / m.totalAmount) * 100) : 0;
    return (
      <div
        onClick={() => onOpen(p)}
        className="group relative flex flex-col bg-white dark:bg-slate-900 border border-slate-100 dark:border-slate-800 rounded-[24px] p-5 cursor-pointer pc-lift overflow-hidden"
      >
        <span className={`absolute inset-x-0 top-0 h-1 bg-gradient-to-r ${type.grad} opacity-80`} />
        <div className="flex items-start justify-between gap-2 mb-3">
          <div className="flex flex-wrap items-center gap-1.5">
            <span className="text-[11px] font-semibold px-2 py-1 rounded-lg bg-slate-50 dark:bg-white/5 text-slate-600 dark:text-slate-300">{type.emoji} {tr ? type.tr : type.en}</span>
            {p.priority && (
              <span className={`inline-flex items-center gap-1 text-[11px] font-semibold px-2 py-1 rounded-lg ${PRIORITY_META[p.priority].chip}`}>
                <span className={`w-1.5 h-1.5 rounded-full ${PRIORITY_META[p.priority].dot}`} /> {tr ? PRIORITY_META[p.priority].tr : PRIORITY_META[p.priority].en}
              </span>
            )}
            {p.status === 'On Hold' && (isHoldExpired(p)
              ? <span className="text-[11px] font-semibold px-2 py-1 rounded-lg bg-rose-50 text-rose-700 dark:bg-rose-500/10 dark:text-rose-300">{tr ? 'Askı süresi doldu' : 'Hold ended'}</span>
              : <span title={p.holdReason || undefined} className="text-[11px] font-semibold px-2 py-1 rounded-lg bg-amber-50 text-amber-700 dark:bg-amber-500/10 dark:text-amber-300">{tr ? 'Askıda' : 'On hold'}{p.holdUntil ? ` · ${tr ? 'bitiş ' : 'until '}${new Date(p.holdUntil + 'T00:00').toLocaleDateString(tr ? 'tr-TR' : 'en-US', { day: 'numeric', month: 'short' })}` : ''}</span>)}
            {p.status === 'Completed' && <span className="text-[11px] font-semibold px-2 py-1 rounded-lg bg-emerald-50 text-emerald-700 dark:bg-emerald-500/10 dark:text-emerald-300">{tr ? 'Tamamlandı' : 'Completed'}</span>}
          </div>
          {p.status !== 'Completed' && p.status !== 'On Hold' && (
            <span title={m.riskReasons.join(' · ')} className={`shrink-0 text-[11px] font-semibold px-2 py-1 rounded-lg ${risk.chip} ${m.risk === 'critical' ? 'animate-pulse' : ''}`}>{tr ? risk.tr : risk.en}</span>
          )}
        </div>

        <h3 className="text-lg font-bold text-slate-900 dark:text-white leading-snug line-clamp-2 pr-8">{p.name}</h3>
        <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5 truncate">{p.client}{p.clientContactName ? ` · ${p.clientContactName}` : ''}</p>

        <div className="mt-4">{progressWithPlan(p, m)}</div>

        <div className="grid grid-cols-3 gap-2 mt-4 text-[11px]">
          <div className="rounded-xl bg-slate-50 dark:bg-white/[0.03] px-2.5 py-2">
            <p className="text-slate-400 flex items-center gap-1"><Timer size={11} /> {tr ? 'Teslim' : 'Due'}</p>
            <p className="font-semibold mt-0.5 truncate">{deliveryChip(p, m)}</p>
          </div>
          <div className="rounded-xl bg-slate-50 dark:bg-white/[0.03] px-2.5 py-2">
            <p className="text-slate-400 flex items-center gap-1"><ListChecks size={11} /> {tr ? 'Görev' : 'Tasks'}</p>
            <p className={`font-semibold mt-0.5 ${m.tasksOverdue ? 'text-rose-600' : 'text-slate-700 dark:text-slate-200'}`}>{m.tasksDone}/{m.tasksTotal}{m.tasksOverdue ? ` · ${m.tasksOverdue}!` : ''}</p>
          </div>
          <div className="rounded-xl bg-slate-50 dark:bg-white/[0.03] px-2.5 py-2">
            <p className="text-slate-400 flex items-center gap-1"><Wallet size={11} /> {tr ? 'Tahsilat' : 'Paid'}</p>
            <p className={`font-semibold mt-0.5 ${m.overduePayments ? 'text-rose-600' : 'text-slate-700 dark:text-slate-200'}`}>{showFinancials ? `%${payPct}` : '—'}{m.overduePayments ? ` · ${m.overduePayments}!` : ''}</p>
          </div>
        </div>

        {(p.tags || []).length > 0 && (
          <div className="flex flex-wrap gap-1 mt-3">
            {(p.tags || []).slice(0, 3).map(t => <span key={t} className="text-[10px] font-semibold px-1.5 py-0.5 rounded-md bg-indigo-50 dark:bg-indigo-500/10 text-indigo-600 dark:text-indigo-300">#{t}</span>)}
            {(p.tags || []).length > 3 && <span className="text-[10px] font-semibold text-slate-400">+{(p.tags || []).length - 3}</span>}
          </div>
        )}

        <div className="flex items-center justify-between mt-auto pt-4">
          {people.length ? <Avatars people={people} /> : <span className="text-[11px] text-slate-400">{tr ? 'Ekip atanmadı' : 'No team'}</span>}
          <span className="text-sm font-bold text-slate-900 dark:text-white">{showFinancials ? money(m.totalAmount, p.currency) : '••••'}</span>
        </div>

        <button
          onClick={e => { e.stopPropagation(); onEdit(p); }}
          className="absolute top-12 right-4 p-2 rounded-xl bg-white dark:bg-slate-800 border border-slate-100 dark:border-slate-700 text-slate-400 hover:text-indigo-600 shadow-sm opacity-0 group-hover:opacity-100 transition-opacity"
          title={tr ? 'Düzenle' : 'Edit'}
        ><Edit size={14} /></button>
      </div>
    );
  };

  // ---------- Liste görünümü ----------
  const row = (p: Project) => {
    const m = metrics.get(p.id)!;
    const type = TYPE_META[p.projectType] || TYPE_META[ProjectType.OTHER];
    const risk = RISK_META[m.risk];
    return (
      <div onClick={() => onOpen(p)} className="group grid grid-cols-12 items-center gap-3 px-4 py-3 rounded-2xl bg-white dark:bg-slate-900 border border-slate-100 dark:border-slate-800 hover:border-indigo-200 dark:hover:border-indigo-500/30 hover:shadow-md cursor-pointer transition-all">
        <div className="col-span-12 md:col-span-4 flex items-center gap-3 min-w-0">
          <span className={`shrink-0 w-10 h-10 rounded-xl bg-gradient-to-br ${type.grad} flex items-center justify-center text-lg`}>{type.emoji}</span>
          <div className="min-w-0">
            <p className="font-bold text-slate-900 dark:text-white truncate">{p.name}</p>
            <p className="text-xs text-slate-500 dark:text-slate-400 truncate">{p.client}</p>
          </div>
        </div>
        <div className="col-span-6 md:col-span-3">{progressWithPlan(p, m, true)}<p className="text-[11px] text-slate-400 mt-1">%{p.progress || 0}{m.plannedProgress !== null && p.status !== 'Completed' ? ` / ${tr ? 'plan' : 'plan'} %${m.plannedProgress}` : ''}</p></div>
        <div className="col-span-3 md:col-span-2 text-xs font-semibold">{deliveryChip(p, m)}<p className="text-[11px] text-slate-400 font-normal">{p.deliveryDate || '—'}</p></div>
        <div className="hidden md:flex col-span-1 items-center gap-1">
          {p.priority && <span title={PRIORITY_META[p.priority].tr} className={`w-2.5 h-2.5 rounded-full ${PRIORITY_META[p.priority].dot}`} />}
          {p.status !== 'Completed' && p.status !== 'On Hold' && <span title={m.riskReasons.join(' · ')} className={`text-[10px] font-semibold px-1.5 py-0.5 rounded-md ${risk.chip}`}>{tr ? risk.tr : risk.en}</span>}
        </div>
        <div className="col-span-3 md:col-span-2 flex items-center justify-end gap-2">
          <span className="text-sm font-bold text-slate-900 dark:text-white">{showFinancials ? money(m.totalAmount, p.currency) : '••••'}</span>
          <button onClick={e => { e.stopPropagation(); onEdit(p); }} className="p-1.5 rounded-lg text-slate-400 hover:text-indigo-600 hover:bg-indigo-50 dark:hover:bg-white/5 opacity-0 group-hover:opacity-100"><Edit size={14} /></button>
        </div>
      </div>
    );
  };

  // ---------- Zaman çizelgesi ----------
  const timeline = () => {
    const withDates = filtered.filter(p => p.deliveryDate);
    if (!withDates.length) return emptyState(<GanttChartSquare size={40} />, tr ? 'Zaman çizelgesi için teslim tarihi olan proje yok.' : 'No projects with a delivery date.');
    const toDay = (s: string) => { const [y, mo, d] = s.slice(0, 10).split('-').map(Number); return new Date(y, mo - 1, d).getTime(); };
    const startOf = (p: Project) => p.startDate ? toDay(p.startDate) : toDay(p.deliveryDate!) - 30 * 86400000;
    const now = toDay(localISO());
    let min = Math.min(now, ...withDates.map(startOf));
    let max = Math.max(now, ...withDates.map(p => toDay(p.deliveryDate!)));
    min = new Date(new Date(min).getFullYear(), new Date(min).getMonth(), 1).getTime();
    max = new Date(new Date(max).getFullYear(), new Date(max).getMonth() + 1, 1).getTime();
    const span = max - min;
    const pct = (t: number) => ((t - min) / span) * 100;
    const months: { label: string; left: number }[] = [];
    for (let d = new Date(min); d.getTime() < max; d.setMonth(d.getMonth() + 1)) months.push({ label: d.toLocaleDateString(tr ? 'tr-TR' : 'en-US', { month: 'short', year: '2-digit' }), left: pct(d.getTime()) });

    return (
      <div className="bg-white dark:bg-slate-900 border border-slate-100 dark:border-slate-800 rounded-[24px] p-4 sm:p-5 overflow-x-auto custom-scrollbar">
        <div className="min-w-[720px]">
          <div className="relative h-6 ml-[220px] mb-2 border-b border-slate-100 dark:border-slate-800">
            {months.map(mo => <span key={mo.label + mo.left} className="absolute text-[10px] font-semibold text-slate-400 uppercase" style={{ left: `${mo.left}%` }}>{mo.label}</span>)}
          </div>
          <div className="relative space-y-2">
            <div className="absolute top-0 bottom-0 left-[220px] right-0 pointer-events-none">
              {months.map(mo => <span key={'l' + mo.left} className="absolute top-0 bottom-0 w-px bg-slate-100 dark:bg-slate-800" style={{ left: `${mo.left}%` }} />)}
              <span className="absolute top-0 bottom-0 w-0.5 bg-rose-500/80 z-10" style={{ left: `${pct(now)}%` }}>
                <span className="absolute -top-5 -translate-x-1/2 text-[9px] font-black text-rose-500 uppercase">{tr ? 'Bugün' : 'Today'}</span>
              </span>
            </div>
            {withDates.map(p => {
              const m = metrics.get(p.id)!;
              const s = startOf(p), e = toDay(p.deliveryDate!);
              const left = pct(s), width = Math.max(1.5, pct(e) - left);
              const color = p.status === 'Completed' ? 'from-emerald-400 to-emerald-500' : m.risk === 'critical' ? 'from-rose-400 to-rose-500' : m.risk === 'risk' ? 'from-orange-400 to-orange-500' : 'from-indigo-400 to-violet-500';
              return (
                <div key={p.id} className="flex items-center h-10 group cursor-pointer" onClick={() => onOpen(p)}>
                  <div className="w-[220px] shrink-0 pr-3 min-w-0">
                    <p className="text-sm font-semibold text-slate-800 dark:text-slate-100 truncate group-hover:text-indigo-600">{p.name}</p>
                    <p className="text-[10px] text-slate-400 truncate">{p.client}</p>
                  </div>
                  <div className="relative flex-1 h-full">
                    <div
                      className={`absolute top-1.5 bottom-1.5 rounded-lg bg-gradient-to-r ${color} shadow-sm overflow-hidden pc-grow-x ${p.startDate ? '' : 'opacity-60 border border-dashed border-white/60'}`}
                      style={{ left: `${left}%`, width: `${width}%` }}
                      title={`${p.startDate || '?'} → ${p.deliveryDate} · %${p.progress}`}
                    >
                      <div className="h-full bg-white/30" style={{ width: `${p.progress || 0}%` }} />
                      <span className="absolute inset-0 flex items-center px-2 text-[10px] font-bold text-white whitespace-nowrap">%{p.progress || 0}</span>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
          <p className="text-[10px] text-slate-400 mt-3 ml-[220px]">{tr ? 'Kesikli çubuklar: başlangıç tarihi girilmemiş (teslimden 30 gün önce varsayıldı). Açık kısım: ilerleme.' : 'Dashed bars: no start date (assumed 30 days before delivery). Light section: progress.'}</p>
        </div>
      </div>
    );
  };

  const emptyState = (icon: React.ReactNode, text: string) => (
    <div className="col-span-full py-16 rounded-[24px] border border-dashed border-slate-200 dark:border-slate-700 flex flex-col items-center justify-center text-center text-slate-400 animate-in fade-in zoom-in-95">
      <div className="mb-3 opacity-40 pc-float">{icon}</div>
      <p className="text-sm font-semibold">{text}</p>
      {(activeFilterCount > 0 || search) && <button onClick={clearFilters} className="mt-3 text-xs font-semibold text-indigo-600 hover:underline">{tr ? 'Filtreleri temizle' : 'Clear filters'}</button>}
    </div>
  );

  const kpis = [
    { icon: Briefcase, label: tr ? 'Aktif Proje' : 'Active', value: kpi.active, sub: `${counts.all} ${tr ? 'toplam' : 'total'} · ${counts.on_hold} ${tr ? 'askıda' : 'on hold'}`, grad: 'from-indigo-500 to-violet-600', bar: counts.all ? (kpi.active / counts.all) * 100 : 0 },
    { icon: TrendingUp, label: tr ? 'Ort. İlerleme' : 'Avg. Progress', value: kpi.avgProgress, prefix: '%', sub: kpi.behind ? `${kpi.behind} ${tr ? 'proje plandan geride' : 'behind plan'}` : (tr ? 'Plana uygun' : 'On plan'), grad: 'from-sky-500 to-blue-600', bar: kpi.avgProgress },
    { icon: ShieldAlert, label: tr ? 'Riskli Proje' : 'At Risk', value: kpi.atRisk, sub: `${kpi.late} ${tr ? 'gecikmiş teslim' : 'late'} · ${kpi.overduePayments} ${tr ? 'geciken ödeme' : 'late payments'}`, grad: 'from-rose-500 to-orange-500', bar: kpi.active ? 100 - (kpi.atRisk / kpi.active) * 100 : 100, onClick: () => { setTab('active'); setRiskOnly(true); } },
    { icon: CalendarClock, label: tr ? '30 Günde Teslim' : 'Due in 30d', value: kpi.dueSoon, sub: tr ? 'Yaklaşan teslimler' : 'Upcoming deliveries', grad: 'from-amber-500 to-orange-600', bar: kpi.active ? (kpi.dueSoon / kpi.active) * 100 : 0, onClick: () => { setTab('active'); setSort('deadline'); } },
    ...(showFinancials ? [{ icon: Wallet, label: tr ? 'Açık Portföy' : 'Open Portfolio', value: kpi.portfolio, money: true, sub: `${tr ? 'Tahsil edilen' : 'Collected'} %${kpi.collectedPct}`, grad: 'from-emerald-500 to-teal-600', bar: kpi.collectedPct }] : []),
  ];

  const tabs: { key: StatusTab; label: string; icon: React.ReactNode }[] = [
    { key: 'active', label: tr ? 'Aktif' : 'Active', icon: <Layers size={14} /> },
    { key: 'on_hold', label: tr ? 'Askıda' : 'On hold', icon: <PauseCircle size={14} /> },
    { key: 'completed', label: tr ? 'Tamamlanan' : 'Completed', icon: <CheckCircle2 size={14} /> },
    { key: 'all', label: tr ? 'Tümü' : 'All', icon: <Briefcase size={14} /> },
  ];

  return (
    <div className="space-y-5">
      {/* BAŞLIK */}
      <div className="flex flex-col lg:flex-row lg:items-end justify-between gap-4">
        <div>
          <h2 className="text-2xl lg:text-3xl font-black text-slate-900 dark:text-white tracking-tight">{tr ? 'Projeler' : 'Projects'}</h2>
          <p className="text-sm text-slate-500 dark:text-slate-400">{tr ? 'Portföy, takvim, ekip ve tahsilat takibi tek ekranda.' : 'Portfolio, schedule, team and collections in one place.'}</p>
        </div>
        <div className="flex flex-wrap gap-2">
          {onOpenArchive && <button onClick={onOpenArchive} className="h-10 px-3 rounded-xl border border-slate-200 dark:border-slate-700 text-slate-600 dark:text-slate-300 text-sm font-semibold inline-flex items-center gap-2 hover:border-indigo-300 hover:text-indigo-600"><Archive size={16} /> <span className="hidden sm:inline">{tr ? 'Arşiv' : 'Archive'}</span></button>}
          <button onClick={onExport} className="h-10 px-3 rounded-xl border border-slate-200 dark:border-slate-700 text-slate-600 dark:text-slate-300 text-sm font-semibold inline-flex items-center gap-2 hover:border-emerald-300 hover:text-emerald-600"><FileSpreadsheet size={16} /> <span className="hidden sm:inline">CSV</span></button>
          <button onClick={onNew} className="h-10 px-4 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white text-sm font-semibold inline-flex items-center gap-2 shadow-lg shadow-indigo-500/25"><Plus size={16} /> {tr ? 'Yeni Proje' : 'New Project'}</button>
        </div>
      </div>

      {/* KPI */}
      <div className={`grid grid-cols-2 ${showFinancials ? 'lg:grid-cols-5' : 'lg:grid-cols-4'} gap-3 pc-stagger`}>
        {kpis.map((k: any, i: number) => {
          const Icon = k.icon;
          return (
            <button key={k.label} onClick={k.onClick} className={`text-left bg-white dark:bg-slate-900 border border-slate-100 dark:border-slate-800 rounded-[20px] p-4 ${k.onClick ? 'pc-lift' : 'cursor-default'} min-w-0 ${i === 4 ? 'col-span-2 lg:col-span-1' : ''}`}>
              <div className="flex items-center gap-2.5">
                <span className={`p-2 rounded-xl bg-gradient-to-br ${k.grad} text-white shadow-md`}><Icon size={16} /></span>
                <span className="text-[11px] font-semibold text-slate-500 dark:text-slate-400 truncate">{k.label}</span>
              </div>
              <p className="text-xl sm:text-2xl font-black text-slate-900 dark:text-white mt-2 truncate">
                {k.prefix}<AnimatedNumber value={k.value} format={k.money ? formatTRY : undefined} />
              </p>
              <p className="text-[11px] text-slate-400 truncate">{k.sub}</p>
              <div className="mt-2.5"><GrowBar value={k.bar} className={`bg-gradient-to-r ${k.grad}`} /></div>
            </button>
          );
        })}
      </div>

      {/* SEKME + ARAÇLAR */}
      <div className="bg-white dark:bg-slate-900 border border-slate-100 dark:border-slate-800 rounded-[20px] p-3 space-y-3">
        <div className="flex flex-col xl:flex-row xl:items-center gap-3">
          <div className="flex gap-1 p-1 rounded-xl bg-slate-100 dark:bg-slate-800/60 overflow-x-auto">
            {tabs.map(tb => (
              <button key={tb.key} onClick={() => setTab(tb.key)} className={`shrink-0 inline-flex items-center gap-1.5 h-8 px-3 rounded-lg text-xs font-semibold transition-all ${tab === tb.key ? 'bg-white dark:bg-slate-900 text-indigo-600 dark:text-indigo-300 shadow-sm' : 'text-slate-500 hover:text-slate-700 dark:hover:text-slate-200'}`}>
                {tb.icon} {tb.label}
                <span className={`min-w-[18px] h-[18px] px-1 rounded-full text-[10px] flex items-center justify-center ${tab === tb.key ? 'bg-indigo-100 dark:bg-indigo-500/20' : 'bg-slate-200/70 dark:bg-white/10'}`}>{counts[tb.key]}</span>
              </button>
            ))}
          </div>

          <div className="relative flex-1">
            <Search size={16} className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
            <input value={search} onChange={e => setSearch(e.target.value)} placeholder={tr ? 'Proje, müşteri, yetkili, etiket ara…' : 'Search project, client, contact, tag…'} className="w-full h-10 pl-9 pr-8 rounded-xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700 text-sm outline-none focus:border-indigo-500" />
            {search && <button onClick={() => setSearch('')} className="absolute right-2 top-1/2 -translate-y-1/2 p-1 text-slate-400 hover:text-slate-700"><X size={14} /></button>}
          </div>

          <div className="flex flex-wrap items-center gap-2">
            <button onClick={() => setShowFilters(v => !v)} className={`relative h-10 px-3 rounded-xl border text-xs font-semibold inline-flex items-center gap-2 ${showFilters || activeFilterCount ? 'border-indigo-300 text-indigo-600 bg-indigo-50/60 dark:bg-indigo-500/10' : 'border-slate-200 dark:border-slate-700 text-slate-600 dark:text-slate-300'}`}>
              <SlidersHorizontal size={15} /> {tr ? 'Filtreler' : 'Filters'}
              {activeFilterCount > 0 && <span className="w-5 h-5 rounded-full bg-indigo-600 text-white text-[10px] flex items-center justify-center animate-in zoom-in-50">{activeFilterCount}</span>}
            </button>
            <div className="relative">
              <ArrowUpDown size={14} className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400 pointer-events-none" />
              <select value={sort} onChange={e => setSort(e.target.value as SortKey)} className={selectCls + ' pl-8'}>
                <option value="deadline">{tr ? 'Teslim tarihi' : 'Delivery date'}</option>
                <option value="risk">{tr ? 'Risk' : 'Risk'}</option>
                <option value="priority">{tr ? 'Öncelik' : 'Priority'}</option>
                <option value="progress">{tr ? 'İlerleme' : 'Progress'}</option>
                {showFinancials && <option value="budget">{tr ? 'Bütçe' : 'Budget'}</option>}
                <option value="name">{tr ? 'Ad (A-Z)' : 'Name (A-Z)'}</option>
                <option value="newest">{tr ? 'En yeni' : 'Newest'}</option>
              </select>
            </div>
            <div className="flex p-1 rounded-xl bg-slate-100 dark:bg-slate-800/60">
              {([['grid', LayoutGrid, tr ? 'Kart' : 'Cards'], ['list', List, tr ? 'Liste' : 'List'], ['timeline', GanttChartSquare, tr ? 'Zaman çizelgesi' : 'Timeline']] as const).map(([k, Icon, label]) => (
                <button key={k} title={label} onClick={() => setView(k)} className={`p-2 rounded-lg transition-all ${view === k ? 'bg-white dark:bg-slate-900 text-indigo-600 shadow-sm' : 'text-slate-400 hover:text-slate-600'}`}><Icon size={16} /></button>
              ))}
            </div>
          </div>
        </div>

        {showFilters && (
          <div className="flex flex-wrap items-center gap-2 pt-3 border-t border-slate-100 dark:border-slate-800 animate-in fade-in slide-in-from-top-2 duration-300">
            <select value={typeF} onChange={e => setTypeF(e.target.value)} className={selectCls}>
              <option value="all">{tr ? 'Tüm tipler' : 'All types'}</option>
              {Object.values(ProjectType).map(v => <option key={v} value={v}>{TYPE_META[v]?.emoji} {tr ? TYPE_META[v]?.tr : TYPE_META[v]?.en}</option>)}
            </select>
            <select value={prioF} onChange={e => setPrioF(e.target.value)} className={selectCls}>
              <option value="all">{tr ? 'Tüm öncelikler' : 'All priorities'}</option>
              {(Object.keys(PRIORITY_META) as ProjectPriority[]).map(k => <option key={k} value={k}>{tr ? PRIORITY_META[k].tr : PRIORITY_META[k].en}</option>)}
              <option value="none">{tr ? 'Önceliksiz' : 'No priority'}</option>
            </select>
            {managers.length > 0 && (
              <div className="relative">
                <UserCog size={14} className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400 pointer-events-none" />
                <select value={managerF} onChange={e => setManagerF(e.target.value)} className={selectCls + ' pl-8'}>
                  <option value="all">{tr ? 'Tüm yöneticiler' : 'All managers'}</option>
                  {managers.map(u => <option key={u.id} value={u.id}>{u.name}</option>)}
                </select>
              </div>
            )}
            <button onClick={() => setRiskOnly(v => !v)} className={`h-10 px-3 rounded-xl border text-xs font-semibold inline-flex items-center gap-1.5 ${riskOnly ? 'border-rose-300 bg-rose-50 text-rose-600 dark:bg-rose-500/10' : 'border-slate-200 dark:border-slate-700 text-slate-600 dark:text-slate-300'}`}>
              <AlertTriangle size={14} /> {tr ? 'Sadece riskli' : 'At risk only'}
            </button>
            {allTags.length > 0 && (
              <div className="flex flex-wrap items-center gap-1.5">
                <Tag size={14} className="text-slate-400 ml-1" />
                {allTags.slice(0, 12).map(t => {
                  const on = tagF.includes(t);
                  return <button key={t} onClick={() => setTagF(on ? tagF.filter(x => x !== t) : [...tagF, t])} className={`h-7 px-2 rounded-lg text-[11px] font-semibold transition-colors ${on ? 'bg-indigo-600 text-white' : 'bg-slate-100 dark:bg-white/5 text-slate-600 dark:text-slate-300 hover:bg-indigo-50'}`}>#{t}</button>;
                })}
              </div>
            )}
            {(activeFilterCount > 0 || search) && <button onClick={clearFilters} className="ml-auto text-xs font-semibold text-slate-500 hover:text-rose-600 inline-flex items-center gap-1"><X size={13} /> {tr ? 'Temizle' : 'Clear'}</button>}
          </div>
        )}
      </div>

      <div className="flex items-center justify-between text-xs text-slate-400 px-1">
        <span>{filtered.length} {tr ? 'proje gösteriliyor' : 'projects shown'}</span>
        {view !== 'timeline' && filtered.some(p => metrics.get(p.id)!.plannedProgress !== null) && (
          <span className="hidden sm:inline-flex items-center gap-1.5"><span className="w-0.5 h-3 bg-slate-700 dark:bg-white/70 rounded" /> {tr ? 'Çizgi: takvime göre olması gereken ilerleme' : 'Marker: planned progress by schedule'}</span>
        )}
      </div>

      {/* İÇERİK */}
      <div key={`${view}-${tab}`}>
        {view === 'timeline' ? timeline() : filtered.length === 0 ? (
          emptyState(
            tab === 'on_hold' ? <PauseCircle size={40} /> : tab === 'completed' ? <CheckCircle2 size={40} /> : <Briefcase size={40} />,
            activeFilterCount || search ? (tr ? 'Filtrelere uyan proje yok.' : 'No projects match the filters.') : tab === 'on_hold' ? (tr ? 'Askıda proje yok.' : 'No projects on hold.') : tab === 'completed' ? (tr ? 'Henüz tamamlanan proje yok.' : 'No completed projects yet.') : (tr ? 'Henüz proje yok. İlk projeyi ekleyin.' : 'No projects yet.')
          )
        ) : view === 'grid' ? (
          <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-3 gap-4 pc-stagger">
            {filtered.map(p => <React.Fragment key={p.id}>{card(p)}</React.Fragment>)}
          </div>
        ) : (
          <div className="space-y-2 pc-stagger">
            <div className="hidden md:grid grid-cols-12 gap-3 px-4 text-[10px] font-black uppercase tracking-widest text-slate-400">
              <span className="col-span-4">{tr ? 'Proje' : 'Project'}</span>
              <span className="col-span-3">{tr ? 'İlerleme / Plan' : 'Progress / Plan'}</span>
              <span className="col-span-2">{tr ? 'Teslim' : 'Delivery'}</span>
              <span className="col-span-1">{tr ? 'Durum' : 'Status'}</span>
              <span className="col-span-2 text-right">{tr ? 'Tutar' : 'Amount'}</span>
            </div>
            {filtered.map(p => <React.Fragment key={p.id}>{row(p)}</React.Fragment>)}
          </div>
        )}
      </div>
    </div>
  );
};

export default ProjectsBoard;
