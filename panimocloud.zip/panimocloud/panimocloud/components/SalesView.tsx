import React, { useMemo, useState } from 'react';
import { Plus, Gamepad2, Layers, Key, Copy, Edit2, RefreshCw, CheckCircle2, PauseCircle, PlayCircle, TrendingUp, Repeat, CalendarClock, AlertTriangle, Wallet } from 'lucide-react';
import { LicenseSale, ServiceSale, Currency, BillingCycle, Transaction } from '../types';
import { PageHeader, KpiGrid, SearchBox, Segmented, Field, EmptyState, DeleteButton, Sheet, Avatar, inputCls, selectSm, cardCls, btnPrimary, money } from './ui/Kit';
import { toTRY, formatTRY, dayDiff, localISO } from '../services/insights';
import { toast } from '../services/toast';

interface Props {
  sales: LicenseSale[];
  serviceSales: ServiceSale[];
  onUpsertSale: (sale: LicenseSale) => Promise<void>;
  onDeleteSale: (id: string) => Promise<void>;
  onUpsertServiceSale: (sale: ServiceSale) => Promise<void>;
  onDeleteServiceSale: (id: string) => Promise<void>;
  onAddTransaction: (transaction: Transaction) => Promise<void>;
  language: 'tr' | 'en';
  rates: { TRY: number; EUR: number };
  showFinancials: boolean;
}

const addPeriod = (iso: string, cycle: BillingCycle) => { const [y, m, d] = iso.split('-').map(Number); const dt = new Date(y, m - 1 + (cycle === BillingCycle.YEARLY ? 12 : 1), d); return localISO(dt); };
const plusYear = (iso: string) => { const [y, m, d] = iso.split('-').map(Number); return localISO(new Date(y + 1, m - 1, d)); };

const SalesView: React.FC<Props> = ({ sales, serviceSales, onUpsertSale, onDeleteSale, onUpsertServiceSale, onDeleteServiceSale, onAddTransaction, language, rates, showFinancials }) => {
  const tr = language === 'tr';
  const [tab, setTab] = useState<'licenses' | 'services'>('licenses');
  const [search, setSearch] = useState('');
  const [statusF, setStatusF] = useState('all');
  const [lic, setLic] = useState<Partial<LicenseSale> | null>(null);
  const [svc, setSvc] = useState<Partial<ServiceSale> | null>(null);
  const [record, setRecord] = useState(true);
  const [touched, setTouched] = useState(false);
  const [saving, setSaving] = useState(false);
  const show = (n: number, c?: string) => (showFinancials ? money(n, c, 2) : '••••');

  const licState = (s: LicenseSale) => {
    if (s.status === 'Refunded') return 'refunded';
    const d = dayDiff(s.expiryDate);
    if (d !== null && d < 0) return 'expired';
    if (d !== null && d <= 30) return 'expiring';
    return 'active';
  };
  const svcState = (s: ServiceSale) => {
    if (s.status !== 'Active') return s.status === 'Paused' ? 'paused' : 'cancelled';
    const d = dayDiff(s.nextBillingDate);
    return d !== null && d < 0 ? 'overdue' : d !== null && d <= 7 ? 'due' : 'ok';
  };

  const stats = useMemo(() => {
    const year = String(new Date().getFullYear());
    const mrr = serviceSales.filter(s => s.status === 'Active').reduce((a, s) => a + toTRY(s.billingCycle === BillingCycle.YEARLY ? s.amount / 12 : s.amount, s.currency, rates), 0);
    return {
      licYear: sales.filter(s => s.status !== 'Refunded' && (s.saleDate || '').startsWith(year)).reduce((a, s) => a + toTRY(s.amount, s.currency, rates), 0),
      mrr, arr: mrr * 12,
      expiring: sales.filter(s => licState(s) === 'expiring').length,
      expired: sales.filter(s => licState(s) === 'expired').length,
      overdue: serviceSales.filter(s => svcState(s) === 'overdue').length,
      active: sales.filter(s => licState(s) === 'active' || licState(s) === 'expiring').length + serviceSales.filter(s => s.status === 'Active').length,
    };
  }, [sales, serviceSales, rates]);

  const q = search.trim().toLocaleLowerCase('tr-TR');
  const licenses = useMemo(() => sales.filter(s => (statusF === 'all' || licState(s) === statusF) && (!q || [s.customerName, s.productName, s.licenseKey].join(' ').toLocaleLowerCase('tr-TR').includes(q)))
    .sort((a, b) => (a.expiryDate || '').localeCompare(b.expiryDate || '')), [sales, statusF, q]);
  const services = useMemo(() => serviceSales.filter(s => (statusF === 'all' || svcState(s) === statusF) && (!q || [s.customerName, s.serviceName].join(' ').toLocaleLowerCase('tr-TR').includes(q)))
    .sort((a, b) => ({ overdue: 0, due: 1, ok: 2, paused: 3, cancelled: 4 }[svcState(a)] - { overdue: 0, due: 1, ok: 2, paused: 3, cancelled: 4 }[svcState(b)]) || (a.nextBillingDate || '').localeCompare(b.nextBillingDate || '')), [serviceSales, statusF, q]);

  const income = (amount: number, currency: Currency, category: string, description: string) =>
    onAddTransaction({ id: `tr_sale_${Date.now()}_${Math.random().toString(36).slice(2, 6)}`, type: 'Income', amount, currency, category, date: localISO(), description, taxRate: 0, taxAmount: 0, totalAmountWithTax: amount });

  // ---------- Lisans ----------
  const licErr: Record<string, string> = {};
  if (lic) {
    if (!lic.customerName?.trim()) licErr.customer = tr ? 'Müşteri zorunlu.' : 'Customer required.';
    if (!lic.productName?.trim()) licErr.product = tr ? 'Ürün zorunlu.' : 'Product required.';
    if (!(Number(lic.amount) > 0)) licErr.amount = tr ? 'Tutar girin.' : 'Enter amount.';
    if (lic.saleDate && lic.expiryDate && lic.expiryDate < lic.saleDate) licErr.expiry = tr ? 'Bitiş, satıştan önce olamaz.' : 'Expiry before sale.';
  }
  const saveLic = async () => {
    setTouched(true);
    if (!lic || Object.keys(licErr).length) return;
    setSaving(true);
    try {
      const isNew = !lic.id;
      const sale: LicenseSale = { id: lic.id || `sale${Date.now()}`, customerName: lic.customerName!.trim(), productName: lic.productName!.trim(), saleDate: lic.saleDate || localISO(), expiryDate: lic.expiryDate || plusYear(lic.saleDate || localISO()), amount: Number(lic.amount), currency: lic.currency || Currency.TRY, status: lic.status || 'Active', licenseKey: lic.licenseKey || '' };
      await onUpsertSale(sale);
      if (isNew && record) await income(sale.amount, sale.currency, 'Oyun Satışı', `Lisans: ${sale.productName} · ${sale.customerName}`);
      toast.success(isNew ? (tr ? `Lisans kaydedildi${record ? ' ve gelire işlendi' : ''}` : 'License saved') : (tr ? 'Lisans güncellendi' : 'Updated'));
      setLic(null);
    } catch (e: any) { toast.error(e?.message || 'Hata'); } finally { setSaving(false); }
  };
  const renew = async (s: LicenseSale) => {
    const from = (dayDiff(s.expiryDate) ?? -1) >= 0 ? s.expiryDate : localISO();
    await onUpsertSale({ ...s, status: 'Active', expiryDate: plusYear(from) });
    await income(s.amount, s.currency, 'Oyun Satışı', `Lisans yenileme: ${s.productName} · ${s.customerName}`);
    toast.success(tr ? `${s.customerName} lisansı 1 yıl uzatıldı ve gelire işlendi` : 'Renewed');
  };
  const genKey = () => Array.from({ length: 4 }, () => Math.random().toString(36).slice(2, 6).toUpperCase()).join('-');

  // ---------- Hizmet ----------
  const svcErr: Record<string, string> = {};
  if (svc) {
    if (!svc.customerName?.trim()) svcErr.customer = tr ? 'Müşteri zorunlu.' : 'Customer required.';
    if (!svc.serviceName?.trim()) svcErr.service = tr ? 'Hizmet adı zorunlu.' : 'Service required.';
    if (!(Number(svc.amount) > 0)) svcErr.amount = tr ? 'Tutar girin.' : 'Enter amount.';
  }
  const saveSvc = async () => {
    setTouched(true);
    if (!svc || Object.keys(svcErr).length) return;
    setSaving(true);
    try {
      await onUpsertServiceSale({ id: svc.id || `ssale${Date.now()}`, customerName: svc.customerName!.trim(), serviceName: svc.serviceName!.trim(), amount: Number(svc.amount), currency: svc.currency || Currency.TRY, billingCycle: svc.billingCycle || BillingCycle.MONTHLY, nextBillingDate: svc.nextBillingDate || localISO(), status: svc.status || 'Active' });
      toast.success(svc.id ? (tr ? 'Hizmet güncellendi' : 'Updated') : (tr ? 'Hizmet aboneliği eklendi' : 'Added'));
      setSvc(null);
    } catch (e: any) { toast.error(e?.message || 'Hata'); } finally { setSaving(false); }
  };
  const collect = async (s: ServiceSale) => {
    await income(s.amount, s.currency, 'Yazılım Hizmet Bedeli', `${s.serviceName} · ${s.customerName} (${s.nextBillingDate})`);
    await onUpsertServiceSale({ ...s, nextBillingDate: addPeriod(s.nextBillingDate || localISO(), s.billingCycle) });
    toast.success(tr ? `Tahsilat kaydedildi · sonraki fatura ${addPeriod(s.nextBillingDate || localISO(), s.billingCycle)}` : 'Collected');
  };

  // ---------- Parçalar ----------
  const chip = (text: string, cls: string) => <span className={`text-[11px] font-semibold px-2 py-0.5 rounded-md whitespace-nowrap ${cls}`}>{text}</span>;
  const licChip = (s: LicenseSale) => {
    const st = licState(s); const d = dayDiff(s.expiryDate);
    if (st === 'refunded') return chip(tr ? 'İade edildi' : 'Refunded', 'bg-slate-100 text-slate-500 dark:bg-white/5');
    if (st === 'expired') return chip(tr ? `${Math.abs(d!)} gün önce doldu` : 'Expired', 'bg-rose-50 text-rose-700 dark:bg-rose-500/10 dark:text-rose-300');
    if (st === 'expiring') return chip(tr ? `${d} gün kaldı` : `${d}d left`, 'bg-amber-50 text-amber-700 dark:bg-amber-500/10 dark:text-amber-300');
    return chip(tr ? 'Aktif' : 'Active', 'bg-emerald-50 text-emerald-700 dark:bg-emerald-500/10 dark:text-emerald-300');
  };
  const svcChip = (s: ServiceSale) => {
    const st = svcState(s); const d = dayDiff(s.nextBillingDate);
    return {
      overdue: chip(tr ? `${Math.abs(d!)} gün gecikti` : 'Overdue', 'bg-rose-50 text-rose-700 dark:bg-rose-500/10 dark:text-rose-300'),
      due: chip(d === 0 ? (tr ? 'Bugün' : 'Today') : (tr ? `${d} gün sonra` : `in ${d}d`), 'bg-amber-50 text-amber-700 dark:bg-amber-500/10 dark:text-amber-300'),
      ok: chip(tr ? 'Düzenli' : 'On track', 'bg-emerald-50 text-emerald-700 dark:bg-emerald-500/10 dark:text-emerald-300'),
      paused: chip(tr ? 'Duraklatıldı' : 'Paused', 'bg-slate-100 text-slate-600 dark:bg-white/5 dark:text-slate-300'),
      cancelled: chip(tr ? 'İptal' : 'Cancelled', 'bg-slate-100 text-slate-500 dark:bg-white/5'),
    }[st];
  };

  const licRow = (s: LicenseSale) => (
    <div key={s.id} className="group grid grid-cols-12 gap-3 items-center px-4 py-3 hover:bg-slate-50/70 dark:hover:bg-white/[0.02]">
      <div className="col-span-12 md:col-span-4 flex items-center gap-3 min-w-0"><Avatar name={s.customerName} /><div className="min-w-0"><p className="text-sm font-semibold text-slate-800 dark:text-slate-100 truncate">{s.customerName}</p><p className="text-[11px] text-slate-400 truncate flex items-center gap-1"><Gamepad2 size={11} />{s.productName}</p></div></div>
      <div className="col-span-6 md:col-span-3 min-w-0">{s.licenseKey ? <button onClick={() => { navigator.clipboard.writeText(s.licenseKey!); toast.success(tr ? 'Lisans anahtarı kopyalandı' : 'Copied'); }} className="text-[11px] font-mono text-slate-500 hover:text-indigo-600 inline-flex items-center gap-1 truncate max-w-full"><Key size={11} />{s.licenseKey}<Copy size={10} /></button> : <span className="text-[11px] text-slate-400">—</span>}</div>
      <div className="col-span-6 md:col-span-2 text-xs"><div>{licChip(s)}</div><p className="text-[10px] text-slate-400 mt-0.5">{s.expiryDate}</p></div>
      <div className="col-span-6 md:col-span-1 text-right text-sm font-bold text-slate-900 dark:text-white">{show(s.amount, s.currency)}</div>
      <div className="col-span-6 md:col-span-2 flex justify-end items-center gap-1">
        {(licState(s) === 'expiring' || licState(s) === 'expired') && <button onClick={() => renew(s)} className="h-8 px-2.5 rounded-lg text-[11px] font-semibold text-indigo-700 bg-indigo-50 hover:bg-indigo-100 dark:bg-indigo-500/10 dark:text-indigo-300 inline-flex items-center gap-1"><RefreshCw size={12} />{tr ? 'Yenile' : 'Renew'}</button>}
        <button onClick={() => { setLic({ ...s }); setTouched(false); }} className="p-1.5 rounded-lg text-slate-400 hover:text-indigo-600 hover:bg-indigo-50 dark:hover:bg-white/5"><Edit2 size={14} /></button>
        <DeleteButton language={language} onConfirm={async () => { await onDeleteSale(s.id); toast(tr ? 'Lisans silindi' : 'Deleted', 'info'); }} />
      </div>
    </div>
  );
  const svcRow = (s: ServiceSale) => (
    <div key={s.id} className="group grid grid-cols-12 gap-3 items-center px-4 py-3 hover:bg-slate-50/70 dark:hover:bg-white/[0.02]">
      <div className="col-span-12 md:col-span-4 flex items-center gap-3 min-w-0"><Avatar name={s.customerName} /><div className="min-w-0"><p className="text-sm font-semibold text-slate-800 dark:text-slate-100 truncate">{s.customerName}</p><p className="text-[11px] text-slate-400 truncate flex items-center gap-1"><Layers size={11} />{s.serviceName}</p></div></div>
      <div className="col-span-6 md:col-span-2 text-xs text-slate-500 flex items-center gap-1"><Repeat size={12} />{s.billingCycle === BillingCycle.YEARLY ? (tr ? 'Yıllık' : 'Yearly') : (tr ? 'Aylık' : 'Monthly')}</div>
      <div className="col-span-6 md:col-span-2 text-xs"><div>{svcChip(s)}</div><p className="text-[10px] text-slate-400 mt-0.5">{s.nextBillingDate}</p></div>
      <div className="col-span-6 md:col-span-1 text-right text-sm font-bold text-slate-900 dark:text-white">{show(s.amount, s.currency)}</div>
      <div className="col-span-6 md:col-span-3 flex justify-end items-center gap-1">
        {s.status === 'Active' && <button onClick={() => collect(s)} className="h-8 px-2.5 rounded-lg text-[11px] font-semibold text-emerald-700 bg-emerald-50 hover:bg-emerald-100 dark:bg-emerald-500/10 dark:text-emerald-300 inline-flex items-center gap-1"><CheckCircle2 size={12} />{tr ? 'Tahsil edildi' : 'Collected'}</button>}
        {s.status !== 'Cancelled' && <button onClick={async () => { await onUpsertServiceSale({ ...s, status: s.status === 'Active' ? 'Paused' : 'Active' }); toast(s.status === 'Active' ? (tr ? 'Duraklatıldı' : 'Paused') : (tr ? 'Devam ettirildi' : 'Resumed'), 'info', 2000); }} title={s.status === 'Active' ? (tr ? 'Duraklat' : 'Pause') : (tr ? 'Devam ettir' : 'Resume')} className="p-1.5 rounded-lg text-slate-400 hover:text-amber-600 hover:bg-amber-50 dark:hover:bg-white/5">{s.status === 'Active' ? <PauseCircle size={15} /> : <PlayCircle size={15} />}</button>}
        <button onClick={() => { setSvc({ ...s }); setTouched(false); }} className="p-1.5 rounded-lg text-slate-400 hover:text-indigo-600 hover:bg-indigo-50 dark:hover:bg-white/5"><Edit2 size={14} /></button>
        <DeleteButton language={language} onConfirm={async () => { await onDeleteServiceSale(s.id); toast(tr ? 'Hizmet silindi' : 'Deleted', 'info'); }} />
      </div>
    </div>
  );

  const le = (k: string) => (touched ? licErr[k] : undefined);
  const se = (k: string) => (touched ? svcErr[k] : undefined);

  return (
    <div className="space-y-5 pb-10">
      <PageHeader title={tr ? 'Satış Yönetimi' : 'Sales'} subtitle={tr ? 'Lisans satışları, yenilemeler ve düzenli hizmet gelirleri.' : 'Licenses, renewals and recurring services.'}
        actions={<button onClick={() => { setTouched(false); setRecord(true); tab === 'licenses' ? setLic({ currency: Currency.TRY, status: 'Active', saleDate: localISO(), expiryDate: plusYear(localISO()) }) : setSvc({ currency: Currency.TRY, status: 'Active', billingCycle: BillingCycle.MONTHLY, nextBillingDate: localISO() }); }} className={btnPrimary}><Plus size={16} />{tab === 'licenses' ? (tr ? 'Lisans satışı' : 'New license') : (tr ? 'Hizmet aboneliği' : 'New service')}</button>} />

      <KpiGrid items={[
        { label: tr ? 'Bu yıl lisans geliri' : 'License revenue (YTD)', value: showFinancials ? stats.licYear : 0, format: formatTRY, icon: Gamepad2, grad: 'from-indigo-500 to-violet-600', sub: `${sales.length} ${tr ? 'lisans' : 'licenses'}` },
        { label: tr ? 'Aylık düzenli gelir (MRR)' : 'MRR', value: showFinancials ? stats.mrr : 0, format: formatTRY, icon: TrendingUp, grad: 'from-emerald-500 to-teal-600', sub: `${tr ? 'Yıllık' : 'ARR'} ${showFinancials ? formatTRY(stats.arr) : '••'}` },
        { label: tr ? 'Yenilemesi yaklaşan' : 'Renewals due', value: stats.expiring, icon: CalendarClock, grad: 'from-amber-500 to-orange-600', sub: stats.expired ? (tr ? `${stats.expired} lisansın süresi doldu` : `${stats.expired} expired`) : (tr ? '30 gün içinde' : 'Within 30 days'), onClick: () => { setTab('licenses'); setStatusF('expiring'); }, active: tab === 'licenses' && statusF === 'expiring' },
        { label: tr ? 'Geciken tahsilat' : 'Overdue billing', value: stats.overdue, icon: AlertTriangle, grad: 'from-rose-500 to-red-600', sub: tr ? 'Hizmet faturaları' : 'Service invoices', onClick: () => { setTab('services'); setStatusF('overdue'); }, active: tab === 'services' && statusF === 'overdue' },
      ]} />

      <div className={`${cardCls} p-3 flex flex-col lg:flex-row gap-2`}>
        <Segmented<'licenses' | 'services'> value={tab} onChange={v => { setTab(v); setStatusF('all'); }} options={[{ value: 'licenses', label: <><Gamepad2 size={14} />{tr ? 'Lisanslar' : 'Licenses'} <span className="text-[10px] opacity-60">{sales.length}</span></> }, { value: 'services', label: <><Layers size={14} />{tr ? 'Hizmetler' : 'Services'} <span className="text-[10px] opacity-60">{serviceSales.length}</span></> }]} />
        <SearchBox value={search} onChange={setSearch} placeholder={tab === 'licenses' ? (tr ? 'Müşteri, ürün veya anahtar ara…' : 'Search…') : (tr ? 'Müşteri veya hizmet ara…' : 'Search…')} />
        <select value={statusF} onChange={e => setStatusF(e.target.value)} className={selectSm}>
          <option value="all">{tr ? 'Tüm durumlar' : 'All'}</option>
          {tab === 'licenses'
            ? [['active', tr ? 'Aktif' : 'Active'], ['expiring', tr ? 'Yenilemesi yaklaşan' : 'Expiring'], ['expired', tr ? 'Süresi dolan' : 'Expired'], ['refunded', tr ? 'İade' : 'Refunded']].map(([v, l]) => <option key={v} value={v}>{l}</option>)
            : [['overdue', tr ? 'Geciken' : 'Overdue'], ['due', tr ? '7 gün içinde' : 'Due soon'], ['ok', tr ? 'Düzenli' : 'On track'], ['paused', tr ? 'Duraklatılan' : 'Paused'], ['cancelled', tr ? 'İptal' : 'Cancelled']].map(([v, l]) => <option key={v} value={v}>{l}</option>)}
        </select>
      </div>

      <div key={tab} className={`${cardCls} overflow-hidden animate-in fade-in duration-300`}>
        {(tab === 'licenses' ? licenses : services).length === 0 ? <EmptyState icon={tab === 'licenses' ? Gamepad2 : Layers} text={tr ? 'Kayıt yok' : 'No records'} /> : (
          <div className="divide-y divide-slate-100 dark:divide-slate-800 pc-stagger">{tab === 'licenses' ? licenses.map(licRow) : services.map(svcRow)}</div>
        )}
      </div>

      <Sheet open={!!lic} language={language} title={lic?.id ? (tr ? 'Lisansı düzenle' : 'Edit license') : (tr ? 'Yeni lisans satışı' : 'New license sale')} icon={Gamepad2} onClose={() => setLic(null)} onSubmit={saveLic} saving={saving}>
        {lic && <>
          <Field label={tr ? 'Müşteri / firma' : 'Customer'} required error={le('customer')}><input autoFocus className={inputCls(le('customer'))} value={lic.customerName || ''} onChange={e => setLic({ ...lic, customerName: e.target.value })} /></Field>
          <Field label={tr ? 'Ürün / oyun' : 'Product'} required error={le('product')}><input className={inputCls(le('product'))} value={lic.productName || ''} onChange={e => setLic({ ...lic, productName: e.target.value })} /></Field>
          <Field label={tr ? 'Lisans anahtarı' : 'License key'} hint={<button type="button" onClick={() => setLic({ ...lic, licenseKey: genKey() })} className="font-semibold text-indigo-600 hover:underline">{tr ? 'Rastgele anahtar üret' : 'Generate key'}</button>}><input className={inputCls() + ' font-mono'} value={lic.licenseKey || ''} onChange={e => setLic({ ...lic, licenseKey: e.target.value.toUpperCase() })} placeholder="XXXX-XXXX-XXXX-XXXX" /></Field>
          <div className="grid grid-cols-3 gap-4">
            <Field label={tr ? 'Tutar' : 'Amount'} required error={le('amount')} className="col-span-2"><input type="number" min={0} className={inputCls(le('amount')) + ' font-bold'} value={lic.amount || ''} onChange={e => setLic({ ...lic, amount: Number(e.target.value) })} /></Field>
            <Field label={tr ? 'Para birimi' : 'Currency'}><select className={inputCls()} value={lic.currency} onChange={e => setLic({ ...lic, currency: e.target.value as Currency })}>{Object.values(Currency).map(c => <option key={c} value={c}>{c}</option>)}</select></Field>
          </div>
          <div className="grid grid-cols-2 gap-4">
            <Field label={tr ? 'Satış tarihi' : 'Sale date'}><input type="date" className={inputCls()} value={lic.saleDate || ''} onChange={e => setLic({ ...lic, saleDate: e.target.value, expiryDate: lic.id ? lic.expiryDate : plusYear(e.target.value) })} /></Field>
            <Field label={tr ? 'Bitiş tarihi' : 'Expiry'} error={le('expiry')}><input type="date" className={inputCls(le('expiry'))} value={lic.expiryDate || ''} onChange={e => setLic({ ...lic, expiryDate: e.target.value })} /></Field>
          </div>
          {lic.id && <Field label={tr ? 'Durum' : 'Status'}><select className={inputCls()} value={lic.status} onChange={e => setLic({ ...lic, status: e.target.value as any })}><option value="Active">{tr ? 'Aktif' : 'Active'}</option><option value="Expired">{tr ? 'Süresi doldu' : 'Expired'}</option><option value="Refunded">{tr ? 'İade edildi' : 'Refunded'}</option></select></Field>}
          {!lic.id && <label className="flex items-center gap-2 text-sm text-slate-700 dark:text-slate-200 cursor-pointer"><input type="checkbox" className="w-4 h-4 accent-indigo-600" checked={record} onChange={e => setRecord(e.target.checked)} /><Wallet size={14} className="text-emerald-500" />{tr ? 'Muhasebeye gelir olarak işle' : 'Record as income'}</label>}
        </>}
      </Sheet>

      <Sheet open={!!svc} language={language} title={svc?.id ? (tr ? 'Hizmeti düzenle' : 'Edit service') : (tr ? 'Yeni hizmet aboneliği' : 'New service')} icon={Layers} tone="from-emerald-500 to-teal-600" onClose={() => setSvc(null)} onSubmit={saveSvc} saving={saving}
        footerLeft={svc && Number(svc.amount) > 0 && showFinancials ? <span className="text-slate-400">{tr ? 'Yıllık değer' : 'Annual'} <b className="text-slate-800 dark:text-slate-100">{money(Number(svc.amount) * (svc.billingCycle === BillingCycle.YEARLY ? 1 : 12), svc.currency)}</b></span> : undefined}>
        {svc && <>
          <Field label={tr ? 'Müşteri / firma' : 'Customer'} required error={se('customer')}><input autoFocus className={inputCls(se('customer'))} value={svc.customerName || ''} onChange={e => setSvc({ ...svc, customerName: e.target.value })} /></Field>
          <Field label={tr ? 'Hizmet' : 'Service'} required error={se('service')}><input className={inputCls(se('service'))} value={svc.serviceName || ''} onChange={e => setSvc({ ...svc, serviceName: e.target.value })} placeholder={tr ? 'Örn: Bakım & destek paketi' : 'e.g. Maintenance'} /></Field>
          <Field label={tr ? 'Faturalama' : 'Billing'}><Segmented<BillingCycle> value={svc.billingCycle || BillingCycle.MONTHLY} onChange={v => setSvc({ ...svc, billingCycle: v })} options={[{ value: BillingCycle.MONTHLY, label: tr ? 'Aylık' : 'Monthly' }, { value: BillingCycle.YEARLY, label: tr ? 'Yıllık' : 'Yearly' }]} /></Field>
          <div className="grid grid-cols-3 gap-4">
            <Field label={tr ? 'Tutar' : 'Amount'} required error={se('amount')} className="col-span-2"><input type="number" min={0} className={inputCls(se('amount')) + ' font-bold'} value={svc.amount || ''} onChange={e => setSvc({ ...svc, amount: Number(e.target.value) })} /></Field>
            <Field label={tr ? 'Para birimi' : 'Currency'}><select className={inputCls()} value={svc.currency} onChange={e => setSvc({ ...svc, currency: e.target.value as Currency })}>{Object.values(Currency).map(c => <option key={c} value={c}>{c}</option>)}</select></Field>
          </div>
          <Field label={tr ? 'Sonraki fatura tarihi' : 'Next billing'}><input type="date" className={inputCls()} value={svc.nextBillingDate || ''} onChange={e => setSvc({ ...svc, nextBillingDate: e.target.value })} /></Field>
          {svc.id && <Field label={tr ? 'Durum' : 'Status'}><select className={inputCls()} value={svc.status} onChange={e => setSvc({ ...svc, status: e.target.value as any })}><option value="Active">{tr ? 'Aktif' : 'Active'}</option><option value="Paused">{tr ? 'Duraklatıldı' : 'Paused'}</option><option value="Cancelled">{tr ? 'İptal' : 'Cancelled'}</option></select></Field>}
        </>}
      </Sheet>
    </div>
  );
};

export default SalesView;
