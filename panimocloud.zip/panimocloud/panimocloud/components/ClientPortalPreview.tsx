import React, { useCallback, useEffect, useMemo, useState } from 'react';
import { Shield, CheckCircle2, Clock, FileText, MessageSquare, ExternalLink, Send, ArrowLeft, Check, X, Calendar, Wallet, Users, Star, Lock, LayoutDashboard, AlertTriangle, CircleDot, Plus, Loader2 } from 'lucide-react';
import { Project, Task, TaskStatus, User, Ticket, ProjectDocument, CompanySettings, TicketPriority } from '../types';
import { pushNotification } from '../services/notificationService';
import { callPortal } from '../firebase';
import { ProgressRing, GrowBar } from './ui/Motion';
import { toast } from '../services/toast';

interface Props {
  project: Project;
  tasks: Task[];
  language: 'tr' | 'en';
  users?: User[];
  tickets?: Ticket[];
  onAddTicket?: (ticket: Ticket) => Promise<void>;
  onUpdateProject?: (project: Project) => Promise<void>;
  company?: CompanySettings;
  /** Giriş yapmamış müşteri: veri ve işlemler sunucu fonksiyonundan (portalAction) geçer */
  publicMode?: boolean;
}

const SYM: Record<string, string> = { TRY: '₺', USD: '$', EUR: '€' };
const today = () => { const d = new Date(); return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`; };
const daysTo = (iso?: string) => { if (!iso) return null; const [y, m, d] = iso.split('-').map(Number); const t = new Date(); return Math.round((new Date(y, m - 1, d).getTime() - new Date(t.getFullYear(), t.getMonth(), t.getDate()).getTime()) / 86400000); };

const ClientPortalPreview: React.FC<Props> = ({ project, tasks: tasksProp, language, users: usersProp = [], tickets: ticketsProp = [], onAddTicket, onUpdateProject, company: companyProp = {}, publicMode = false }) => {
  // Giriş yapmamış müşteri talepleri, ekibi ve şirket bilgisini Firestore'dan okuyamaz; sunucudan alınır
  const [remote, setRemote] = useState<{ tickets: Ticket[]; team: (User & { role: any })[]; company: CompanySettings; tasks?: Task[] } | null>(null);
  const loadRemote = useCallback(async () => {
    if (!publicMode) return;
    try { setRemote(await callPortal('getData', { projectId: project.id })); } catch (e) { console.error('Portal data error', e); }
  }, [publicMode, project.id]);
  useEffect(() => { loadRemote(); }, [loadRemote]);
  const users = publicMode ? ((remote?.team || []) as User[]) : usersProp;
  const tickets = publicMode ? (remote?.tickets || []) : ticketsProp;
  // Görevler giriş yapmadan Firestore'dan okunamaz; portalda sunucudan gelir
  const tasks = publicMode ? (remote?.tasks || []) : tasksProp;
  const company = publicMode ? { ...companyProp, ...(remote?.company || {}) } : companyProp;
  const canAct = publicMode || !!onUpdateProject;
  const canTicket = publicMode || !!onAddTicket;

  const [lang, setLang] = useState<'tr' | 'en'>(language);
  const tr = lang === 'tr';
  const [tab, setTab] = useState<'overview' | 'documents' | 'support'>('overview');
  const [ticketForm, setTicketForm] = useState<{ title: string; description: string; priority: TicketPriority } | null>(null);
  const [openTicketId, setOpenTicketId] = useState<string | null>(null);
  const [reply, setReply] = useState('');
  const [rejecting, setRejecting] = useState<{ id: string; note: string } | null>(null);
  const [busy, setBusy] = useState(false);
  const [score, setScore] = useState(0);
  const [hover, setHover] = useState(0);
  const [comment, setComment] = useState('');
  useEffect(() => { if (!publicMode || tab !== 'support') return; const t = setInterval(loadRemote, 30000); return () => clearInterval(t); }, [publicMode, tab, loadRemote]);

  const settings = { showFinancials: true, showTeam: true, showTasks: true, isPublic: true, themeColor: '#6366f1', ...(project.portalSettings || {}) };
  const color = settings.themeColor || '#6366f1';
  const money = (n: number) => `${SYM[project.currency] || ''}${(Number(n) || 0).toLocaleString('tr-TR', { maximumFractionDigits: 2 })}`;
  const fmtDate = (iso?: string) => iso ? new Date(iso.length === 10 ? iso + 'T00:00' : iso).toLocaleDateString(tr ? 'tr-TR' : 'en-US', { day: 'numeric', month: 'long', year: 'numeric' }) : '—';
  const companyName = company.name || company.legalName || 'Panimo Soft';

  const projectTasks = useMemo(() => tasks.filter(t => t.projectId === project.id).sort((a, b) => (a.deadline || '9').localeCompare(b.deadline || '9')), [tasks, project.id]);
  const doneTasks = projectTasks.filter(t => t.status === TaskStatus.DONE);
  const progress = project.status === 'Completed' ? 100 : projectTasks.length > 3 ? Math.round((doneTasks.length / projectTasks.length) * 100) : (project.progress || (projectTasks.length ? Math.round((doneTasks.length / projectTasks.length) * 100) : 0));

  // Gerçek ekip: proje yöneticisi + ekip üyeleri + görev atananlar
  const team = useMemo(() => {
    const ids = [project.projectManagerId, ...(project.teamMemberIds || []), ...projectTasks.flatMap(t => t.assignedTo || [])].filter(Boolean) as string[];
    return [...new Set(ids)].map(id => users.find(u => u.id === id)).filter(Boolean).map(u => ({ ...u!, isPM: u!.id === project.projectManagerId }));
  }, [users, project, projectTasks]);

  const docs: ProjectDocument[] = [...(project.contracts || []), ...(project.documents || [])];
  const pendingDocs = docs.filter(d => (d.approvalStatus || 'pending') === 'pending' && d.type !== 'contract').length;
  const projectTickets = tickets.filter(t => t.projectId === project.id).sort((a, b) => (b.updatedAt || '').localeCompare(a.updatedAt || ''));
  const openTickets = projectTickets.filter(t => t.status === 'Open' || t.status === 'In Progress').length;
  const openTicket = projectTickets.find(t => t.id === openTicketId) || null;

  const inst = project.installments || [];
  const total = project.totalAmountWithTax || project.budget || inst.reduce((a, i) => a + i.amount, 0);
  const paid = inst.reduce((a, i) => a + (i.isPaid ? (i.paidAmount ?? i.amount) : (i.paidAmount || 0)), 0);
  const nextDue = inst.filter(i => !i.isPaid).sort((a, b) => (a.dueDate || '').localeCompare(b.dueDate || ''))[0];
  const dLeft = daysTo(project.deliveryDate);
  const myFeedback = project.clientFeedback || [];

  const statusInfo = ({
    Active: { label: tr ? 'Aktif olarak çalışılıyor' : 'In progress', cls: 'bg-emerald-50 text-emerald-700 dark:bg-emerald-500/10 dark:text-emerald-300' },
    Revizyonda: { label: tr ? 'Revizyon aşamasında' : 'In revision', cls: 'bg-amber-50 text-amber-700 dark:bg-amber-500/10 dark:text-amber-300' },
    'On Hold': { label: tr ? 'Beklemede' : 'On hold', cls: 'bg-slate-100 text-slate-600 dark:bg-white/5 dark:text-slate-300' },
    Completed: { label: tr ? 'Tamamlandı' : 'Completed', cls: 'bg-indigo-50 text-indigo-700 dark:bg-indigo-500/10 dark:text-indigo-300' },
  } as Record<string, { label: string; cls: string }>)[project.status] || { label: project.status, cls: 'bg-slate-100 text-slate-600' };
  const tStatus = (s: string) => ({ Open: tr ? 'Açık' : 'Open', 'In Progress': tr ? 'İnceleniyor' : 'In progress', Resolved: tr ? 'Çözüldü' : 'Resolved', Closed: tr ? 'Kapatıldı' : 'Closed' } as Record<string, string>)[s] || s;
  const tStatusCls = (s: string) => s === 'Resolved' || s === 'Closed' ? 'bg-emerald-50 text-emerald-700 dark:bg-emerald-500/10 dark:text-emerald-300' : s === 'In Progress' ? 'bg-sky-50 text-sky-700 dark:bg-sky-500/10 dark:text-sky-300' : 'bg-amber-50 text-amber-700 dark:bg-amber-500/10 dark:text-amber-300';

  if (!settings.isPublic) {
    return (
      <div className="min-h-full flex flex-col items-center justify-center bg-slate-50 dark:bg-slate-950 p-6 text-center">
        <span className="w-16 h-16 rounded-2xl bg-slate-200 dark:bg-slate-800 text-slate-500 flex items-center justify-center mb-4"><Lock size={28} /></span>
        <h2 className="text-xl font-bold text-slate-900 dark:text-white">{tr ? 'Bu portal şu anda erişime kapalı' : 'This portal is currently unavailable'}</h2>
        <p className="text-sm text-slate-500 mt-1 max-w-sm">{tr ? `Proje bilgilerine ulaşmak için ${companyName} ile iletişime geçebilirsiniz.` : `Please contact ${companyName}.`}</p>
        {(company.email || company.phone) && <p className="text-sm text-slate-600 dark:text-slate-300 mt-3">{[company.email, company.phone].filter(Boolean).join(' · ')}</p>}
      </div>
    );
  }

  // ---------- İşlemler ----------
  const decideDoc = async (doc: ProjectDocument, approved: boolean, note?: string) => {
    if (!canAct) return;
    setBusy(true);
    try {
      if (publicMode) {
        await callPortal('decideDoc', { projectId: project.id, docId: doc.id, approved, note: note || '' });
      } else {
      const patch = (d: ProjectDocument) => d.id === doc.id ? { ...d, approvalStatus: approved ? 'approved' : 'rejected', feedback: approved ? d.feedback : (note || '').trim() } as ProjectDocument : d;
      await onUpdateProject!({ ...project, documents: (project.documents || []).map(patch), contracts: (project.contracts || []).map(patch), status: approved ? project.status : 'Revizyonda' });
      await pushNotification(approved ? 'Doküman onaylandı' : 'Revizyon istendi', `${project.name} · ${doc.name}${!approved && note ? ` — "${note.trim()}"` : ''}`, approved ? 'success' : 'warning', 'projects');
      }
      toast.success(approved ? (tr ? 'Belge onaylandı, teşekkürler!' : 'Approved') : (tr ? 'Revizyon talebiniz ekibe iletildi' : 'Revision requested'));
      setRejecting(null);
    } catch { toast.error(tr ? 'İşlem kaydedilemedi, lütfen tekrar deneyin.' : 'Could not save.'); } finally { setBusy(false); }
  };

  const createTicket = async () => {
    if (!ticketForm || !canTicket || !ticketForm.title.trim() || !ticketForm.description.trim()) return;
    setBusy(true);
    try {
      const now = new Date().toISOString();
      const t: Ticket = { id: `ticket_${Date.now()}`, projectId: project.id, title: ticketForm.title.trim(), description: ticketForm.description.trim(), status: 'Open', priority: ticketForm.priority, createdAt: now, updatedAt: now, responses: [] };
      if (publicMode) {
        const res = await callPortal<{ ticket: Ticket }>('createTicket', { projectId: project.id, title: t.title, description: t.description, priority: t.priority });
        t.id = res.ticket.id;
        await loadRemote();
      } else {
        await onAddTicket!(t);
        await pushNotification('Yeni müşteri talebi', `${project.name}: ${t.title}`, 'info', 'tickets');
      }
      toast.success(tr ? 'Talebiniz alındı. Ekibimiz en kısa sürede dönüş yapacak.' : 'Request received');
      setTicketForm(null); setOpenTicketId(t.id);
    } catch { toast.error(tr ? 'Talep gönderilemedi.' : 'Failed.'); } finally { setBusy(false); }
  };
  const sendReply = async () => {
    if (!openTicket || !reply.trim() || !canTicket) return;
    setBusy(true);
    try {
      const now = new Date().toISOString();
      if (publicMode) { await callPortal('replyTicket', { projectId: project.id, ticketId: openTicket.id, message: reply.trim() }); await loadRemote(); }
      else await onAddTicket!({ ...openTicket, status: openTicket.status === 'Resolved' ? 'Open' : openTicket.status, updatedAt: now, responses: [...(openTicket.responses || []), { id: `resp_${Date.now()}`, userId: 'client', message: reply.trim(), createdAt: now, isClient: true }] });
      setReply('');
    } catch { toast.error(tr ? 'Mesaj gönderilemedi.' : 'Failed.'); } finally { setBusy(false); }
  };
  const sendFeedback = async () => {
    if (!score || !canAct) return;
    setBusy(true);
    try {
      if (publicMode) await callPortal('feedback', { projectId: project.id, score, comment: comment.trim() });
      else {
      await onUpdateProject!({ ...project, clientFeedback: [...myFeedback, { score, comment: comment.trim() || undefined as any, date: new Date().toISOString() }].map(f => f.comment ? f : { score: f.score, date: f.date }) });
      await pushNotification('Müşteri değerlendirmesi', `${project.name}: ${'★'.repeat(score)}${comment.trim() ? ` — "${comment.trim()}"` : ''}`, score >= 4 ? 'success' : 'warning', 'projects');
      }
      toast.success(tr ? 'Değerlendirmeniz için teşekkürler!' : 'Thanks for your feedback!');
      setScore(0); setComment('');
    } catch { toast.error(tr ? 'Gönderilemedi.' : 'Failed.'); } finally { setBusy(false); }
  };

  const card = 'bg-white dark:bg-slate-900 border border-slate-100 dark:border-slate-800 rounded-[22px]';
  const tabs = [
    { id: 'overview' as const, label: tr ? 'Genel bakış' : 'Overview', icon: LayoutDashboard, badge: 0 },
    { id: 'documents' as const, label: tr ? 'Belgeler' : 'Documents', icon: FileText, badge: pendingDocs },
    { id: 'support' as const, label: tr ? 'Destek' : 'Support', icon: MessageSquare, badge: openTickets },
  ];

  return (
    <div className="min-h-full bg-slate-50 dark:bg-slate-950 text-slate-900 dark:text-slate-100" style={{ ['--pc' as any]: color }}>
      {/* Üst bant */}
      <div className="relative overflow-hidden">
        <div className="absolute inset-0 opacity-[0.12]" style={{ background: `radial-gradient(circle at 15% 0%, ${color}, transparent 55%), radial-gradient(circle at 90% 20%, ${color}, transparent 45%)` }} />
        <div className="relative max-w-6xl mx-auto px-4 sm:px-6 pt-5 pb-8">
          <div className="flex items-center gap-3">
            {company.logoUrl ? <img src={company.logoUrl} alt="" className="h-9 w-9 rounded-xl object-contain bg-white" /> : <span className="h-9 w-9 rounded-xl text-white flex items-center justify-center font-black" style={{ background: color }}>{companyName.charAt(0)}</span>}
            <div className="min-w-0 flex-1"><p className="text-sm font-bold truncate">{companyName}</p><p className="text-[11px] text-slate-500">{tr ? 'Müşteri portalı' : 'Client portal'}</p></div>
            <div className="flex rounded-lg bg-white/70 dark:bg-white/5 border border-slate-200 dark:border-slate-800 p-0.5 text-[11px] font-semibold">
              {(['tr', 'en'] as const).map(l => <button key={l} onClick={() => setLang(l)} className={`px-2 py-1 rounded-md ${lang === l ? 'text-white' : 'text-slate-500'}`} style={lang === l ? { background: color } : undefined}>{l.toUpperCase()}</button>)}
            </div>
          </div>

          <div className="mt-8 grid grid-cols-1 lg:grid-cols-12 gap-6 items-center animate-in fade-in slide-in-from-bottom-2 duration-500">
            <div className="lg:col-span-8">
              <span className={`inline-flex items-center gap-1.5 text-[11px] font-semibold px-2 py-0.5 rounded-md ${statusInfo.cls}`}><CircleDot size={11} />{statusInfo.label}</span>
              <h1 className="text-3xl sm:text-4xl font-black tracking-tight mt-2">{project.name}</h1>
              <p className="text-sm text-slate-500 mt-1">{project.client}</p>
              <p className="text-sm text-slate-600 dark:text-slate-300 mt-4 max-w-2xl leading-relaxed">{settings.customMessage || (tr ? 'Projenizin güncel durumunu, belgeleri ve ödeme planını bu sayfadan takip edebilir, ekibimize doğrudan talep iletebilirsiniz.' : 'Follow progress, documents and payments, and reach our team directly.')}</p>
            </div>
            <div className={`${card} lg:col-span-4 p-5 flex items-center gap-4`}>
              <ProgressRing value={progress} size={92} stroke={9} color={color}><div className="text-center"><p className="text-xl font-black">%{progress}</p><p className="text-[9px] text-slate-400">{tr ? 'tamamlandı' : 'done'}</p></div></ProgressRing>
              <div className="space-y-1.5 text-xs min-w-0">
                <p className="text-slate-400">{tr ? 'Teslim' : 'Delivery'}</p>
                <p className="font-bold text-sm">{fmtDate(project.deliveryDate)}</p>
                {dLeft !== null && project.status !== 'Completed' && <p className={`font-semibold ${dLeft < 0 ? 'text-rose-600' : 'text-slate-500'}`}>{dLeft < 0 ? (tr ? `${-dLeft} gün gecikme` : `${-dLeft}d late`) : dLeft === 0 ? (tr ? 'Bugün' : 'Today') : (tr ? `${dLeft} gün kaldı` : `${dLeft} days left`)}</p>}
                {settings.showTasks && projectTasks.length > 0 && <p className="text-slate-500">{doneTasks.length}/{projectTasks.length} {tr ? 'aşama' : 'milestones'}</p>}
              </div>
            </div>
          </div>

          <div className="mt-6 flex gap-1.5 overflow-x-auto custom-scrollbar">
            {tabs.map(t => { const I = t.icon; const on = tab === t.id; return (
              <button key={t.id} onClick={() => { setTab(t.id); setOpenTicketId(null); }} className={`h-10 px-4 rounded-xl text-sm font-semibold inline-flex items-center gap-2 shrink-0 transition-all ${on ? 'text-white shadow-lg' : 'bg-white/70 dark:bg-white/5 text-slate-600 dark:text-slate-300 hover:bg-white'}`} style={on ? { background: color } : undefined}>
                <I size={15} />{t.label}{t.badge > 0 && <span className={`text-[10px] font-bold min-w-[18px] h-[18px] px-1 rounded-full flex items-center justify-center ${on ? 'bg-white/25' : 'bg-rose-500 text-white'}`}>{t.badge}</span>}
              </button>); })}
          </div>
        </div>
      </div>

      <div key={tab} className="max-w-6xl mx-auto px-4 sm:px-6 pb-12 grid grid-cols-1 lg:grid-cols-12 gap-5 animate-in fade-in duration-300">
        {/* ANA ALAN */}
        <div className="lg:col-span-8 space-y-5">
          {tab === 'overview' && <>
            {pendingDocs > 0 && (
              <button onClick={() => setTab('documents')} className={`${card} w-full p-4 flex items-center gap-3 text-left border-amber-200 dark:border-amber-500/30 hover:shadow-md transition-shadow`}>
                <span className="p-2 rounded-xl bg-amber-50 text-amber-600 dark:bg-amber-500/10"><AlertTriangle size={18} /></span>
                <span className="flex-1"><span className="block text-sm font-bold">{tr ? `${pendingDocs} belge onayınızı bekliyor` : `${pendingDocs} document(s) await your approval`}</span><span className="block text-xs text-slate-500">{tr ? 'İnceleyip onaylamanız projenin ilerlemesini hızlandırır.' : 'Reviewing them keeps the project moving.'}</span></span>
                <ArrowLeft size={16} className="rotate-180 text-slate-400" />
              </button>
            )}

            {settings.showTasks && (
              <div className={card}>
                <div className="px-5 py-4 border-b border-slate-100 dark:border-slate-800 flex items-center gap-2"><h3 className="font-bold flex-1">{tr ? 'Proje aşamaları' : 'Milestones'}</h3><span className="text-xs text-slate-400">{doneTasks.length}/{projectTasks.length}</span></div>
                {projectTasks.length === 0 ? <p className="p-8 text-center text-sm text-slate-400">{tr ? 'Aşamalar yakında burada görünecek.' : 'Milestones will appear here soon.'}</p> : (
                  <div className="p-5 relative">
                    <div className="absolute left-[33px] top-7 bottom-7 w-px bg-slate-200 dark:bg-slate-800" />
                    <div className="space-y-3 max-h-[460px] overflow-y-auto custom-scrollbar pr-1">
                      {projectTasks.map(t => { const done = t.status === TaskStatus.DONE; const doing = !done && t.status !== TaskStatus.TODO; return (
                        <div key={t.id} className="relative flex items-start gap-3">
                          <span className={`relative z-10 w-6 h-6 rounded-full flex items-center justify-center ring-4 ring-white dark:ring-slate-900 ${done ? 'text-white' : doing ? 'bg-white dark:bg-slate-900 border-2' : 'bg-slate-100 dark:bg-slate-800 text-slate-400'}`} style={done ? { background: color } : doing ? { borderColor: color } : undefined}>{done ? <Check size={13} /> : doing ? <span className="w-2 h-2 rounded-full pc-dot-pulse" style={{ background: color }} /> : <Clock size={11} />}</span>
                          <div className="flex-1 min-w-0 pb-1">
                            <p className={`text-sm font-semibold ${done ? 'text-slate-400 line-through decoration-slate-300' : ''}`}>{t.title}</p>
                            <p className="text-[11px] text-slate-400">{done ? (tr ? 'Tamamlandı' : 'Done') : doing ? (tr ? 'Üzerinde çalışılıyor' : 'In progress') : (tr ? 'Sırada' : 'Upcoming')}{t.deadline ? ` · ${fmtDate(t.deadline)}` : ''}</p>
                          </div>
                        </div>); })}
                    </div>
                  </div>
                )}
              </div>
            )}

            {settings.showFinancials && (
              <div className={card}>
                <div className="px-5 py-4 border-b border-slate-100 dark:border-slate-800 flex items-center gap-2"><Wallet size={16} style={{ color }} /><h3 className="font-bold flex-1">{tr ? 'Ödeme planı' : 'Payment plan'}</h3></div>
                {inst.length === 0 ? <p className="p-8 text-center text-sm text-slate-400">{tr ? 'Ödeme planı henüz paylaşılmadı.' : 'No payment plan yet.'}</p> : <>
                  <div className="p-5 grid grid-cols-3 gap-3 text-center">
                    <div className="rounded-xl bg-slate-50 dark:bg-white/[0.03] py-3"><p className="text-[11px] text-slate-400">{tr ? 'Toplam' : 'Total'}</p><p className="font-black">{money(total)}</p></div>
                    <div className="rounded-xl bg-emerald-50/70 dark:bg-emerald-500/10 py-3"><p className="text-[11px] text-emerald-700 dark:text-emerald-300">{tr ? 'Ödenen' : 'Paid'}</p><p className="font-black text-emerald-700 dark:text-emerald-300">{money(paid)}</p></div>
                    <div className="rounded-xl bg-slate-50 dark:bg-white/[0.03] py-3"><p className="text-[11px] text-slate-400">{tr ? 'Kalan' : 'Remaining'}</p><p className="font-black">{money(Math.max(0, total - paid))}</p></div>
                    <div className="col-span-3"><GrowBar value={total ? (paid / total) * 100 : 0} className="bg-emerald-500" /></div>
                  </div>
                  <div className="divide-y divide-slate-100 dark:divide-slate-800 border-t border-slate-100 dark:border-slate-800">
                    {inst.map((i, idx) => { const d = daysTo(i.dueDate); const late = !i.isPaid && d !== null && d < 0; const isNext = nextDue?.id === i.id; return (
                      <div key={i.id} className={`px-5 py-3 flex items-center gap-3 ${isNext ? 'bg-slate-50/70 dark:bg-white/[0.02]' : ''}`}>
                        <span className={`w-9 h-9 rounded-xl flex items-center justify-center ${i.isPaid ? 'bg-emerald-50 text-emerald-600 dark:bg-emerald-500/10' : late ? 'bg-rose-50 text-rose-600 dark:bg-rose-500/10' : 'bg-slate-100 text-slate-500 dark:bg-slate-800'}`}>{i.isPaid ? <CheckCircle2 size={16} /> : <Calendar size={15} />}</span>
                        <div className="flex-1 min-w-0"><p className="text-sm font-semibold truncate">{i.label || `${idx + 1}. ${tr ? 'taksit' : 'installment'}`}</p><p className={`text-[11px] ${late ? 'text-rose-600 font-semibold' : 'text-slate-400'}`}>{i.isPaid ? (tr ? 'Ödendi' : 'Paid') : late ? (tr ? `Vadesi ${-d!} gün geçti` : 'Overdue') : `${tr ? 'Vade' : 'Due'} ${fmtDate(i.dueDate)}`}</p></div>
                        <div className="text-right"><p className="text-sm font-bold">{money(i.amount)}</p>
                          {!i.isPaid && i.paymentLink && <a href={i.paymentLink} target="_blank" rel="noreferrer" className="mt-1 inline-flex items-center gap-1 h-7 px-2.5 rounded-lg text-[11px] font-semibold text-white" style={{ background: color }}>{tr ? 'Öde' : 'Pay'}<ExternalLink size={10} /></a>}
                        </div>
                      </div>); })}
                  </div>
                  {company.iban && <p className="px-5 py-3 text-[11px] text-slate-500 border-t border-slate-100 dark:border-slate-800">{tr ? 'Havale/EFT için' : 'Bank transfer'}: <b className="font-mono text-slate-700 dark:text-slate-200">{company.iban}</b>{company.legalName ? ` · ${company.legalName}` : ''}</p>}
                </>}
              </div>
            )}

            {canAct && (
              <div className={`${card} p-5`}>
                <h3 className="font-bold">{tr ? 'Deneyiminizi değerlendirin' : 'Rate your experience'}</h3>
                <p className="text-xs text-slate-500 mt-0.5">{tr ? 'Görüşleriniz doğrudan proje ekibine iletilir.' : 'Your feedback goes straight to the team.'}</p>
                <div className="flex items-center gap-1 mt-3" onMouseLeave={() => setHover(0)}>
                  {[1, 2, 3, 4, 5].map(n => <button key={n} onMouseEnter={() => setHover(n)} onClick={() => setScore(n)} className="p-1 transition-transform hover:scale-110"><Star size={26} className={(hover || score) >= n ? 'fill-amber-400 text-amber-400' : 'text-slate-300 dark:text-slate-600'} /></button>)}
                  {myFeedback.length > 0 && <span className="ml-2 text-[11px] text-slate-400">{tr ? `Son değerlendirmeniz: ${'★'.repeat(myFeedback[myFeedback.length - 1].score)}` : 'Last rating saved'}</span>}
                </div>
                {score > 0 && <div className="mt-3 space-y-2 animate-in fade-in slide-in-from-top-1 duration-200">
                  <textarea rows={2} value={comment} onChange={e => setComment(e.target.value)} placeholder={tr ? 'Eklemek istedikleriniz (isteğe bağlı)' : 'Comment (optional)'} className="w-full rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 px-3 py-2 text-sm outline-none focus:border-[var(--pc)] resize-none" />
                  <button onClick={sendFeedback} disabled={busy} className="h-9 px-4 rounded-xl text-sm font-semibold text-white inline-flex items-center gap-2 disabled:opacity-60" style={{ background: color }}>{busy ? <Loader2 size={14} className="animate-spin" /> : <Send size={14} />}{tr ? 'Gönder' : 'Send'}</button>
                </div>}
              </div>
            )}
          </>}

          {tab === 'documents' && (
            <div className={card}>
              <div className="px-5 py-4 border-b border-slate-100 dark:border-slate-800"><h3 className="font-bold">{tr ? 'Belgeler ve teslimler' : 'Documents & deliverables'}</h3><p className="text-xs text-slate-500">{tr ? 'Dosyaları inceleyip onaylayabilir ya da revizyon isteyebilirsiniz.' : 'Review, approve or request changes.'}</p></div>
              {docs.length === 0 ? <div className="p-12 text-center text-slate-400"><FileText size={36} className="mx-auto mb-3 opacity-30" /><p className="text-sm">{tr ? 'Henüz paylaşılan belge yok.' : 'No documents yet.'}</p></div> : (
                <div className="divide-y divide-slate-100 dark:divide-slate-800">
                  {docs.map(d => { const st = d.approvalStatus || (d.type === 'contract' ? undefined : 'pending'); return (
                    <div key={d.id} className="px-5 py-4">
                      <div className="flex items-start gap-3">
                        <span className="w-10 h-10 rounded-xl flex items-center justify-center text-white shrink-0" style={{ background: color }}><FileText size={17} /></span>
                        <div className="flex-1 min-w-0">
                          <p className="text-sm font-semibold break-words">{d.name}</p>
                          <p className="text-[11px] text-slate-400">{d.type === 'contract' ? (tr ? 'Sözleşme' : 'Contract') : (d.fileType || '').toUpperCase()} · {fmtDate(d.uploadDate)}</p>
                          {st && <span className={`mt-1.5 inline-flex text-[11px] font-semibold px-2 py-0.5 rounded-md ${st === 'approved' ? 'bg-emerald-50 text-emerald-700 dark:bg-emerald-500/10 dark:text-emerald-300' : st === 'rejected' ? 'bg-rose-50 text-rose-700 dark:bg-rose-500/10 dark:text-rose-300' : 'bg-amber-50 text-amber-700 dark:bg-amber-500/10 dark:text-amber-300'}`}>{st === 'approved' ? (tr ? 'Onaylandı' : 'Approved') : st === 'rejected' ? (tr ? 'Revizyon istendi' : 'Changes requested') : (tr ? 'Onayınızı bekliyor' : 'Awaiting approval')}</span>}
                          {st === 'rejected' && d.feedback && <p className="mt-1.5 text-xs text-slate-500 italic">“{d.feedback}”</p>}
                        </div>
                        <div className="flex items-center gap-1.5 shrink-0">
                          {d.url ? <a href={d.url} target="_blank" rel="noreferrer" className="h-9 px-3 rounded-xl border border-slate-200 dark:border-slate-700 text-xs font-semibold inline-flex items-center gap-1.5 hover:border-[var(--pc)]"><ExternalLink size={13} />{tr ? 'Aç' : 'Open'}</a> : <span className="text-[11px] text-slate-400">{tr ? 'Dosya hazırlanıyor' : 'Not available'}</span>}
                        </div>
                      </div>
                      {st === 'pending' && canAct && (rejecting?.id === d.id ? (
                        <div className="mt-3 ml-[52px] space-y-2 animate-in fade-in duration-200">
                          <textarea autoFocus rows={2} value={rejecting.note} onChange={e => setRejecting({ id: d.id, note: e.target.value })} placeholder={tr ? 'Neyin değişmesini istiyorsunuz?' : 'What should change?'} className="w-full rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 px-3 py-2 text-sm outline-none focus:border-rose-400 resize-none" />
                          <div className="flex gap-2"><button disabled={busy || !rejecting.note.trim()} onClick={() => decideDoc(d, false, rejecting.note)} className="h-9 px-3 rounded-xl bg-rose-600 text-white text-xs font-semibold disabled:opacity-50">{tr ? 'Revizyon iste' : 'Request changes'}</button><button onClick={() => setRejecting(null)} className="h-9 px-3 rounded-xl text-xs font-semibold text-slate-500">{tr ? 'Vazgeç' : 'Cancel'}</button></div>
                        </div>
                      ) : (
                        <div className="mt-3 ml-[52px] flex gap-2">
                          <button disabled={busy} onClick={() => decideDoc(d, true)} className="h-9 px-3 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-semibold inline-flex items-center gap-1.5 disabled:opacity-50"><Check size={14} />{tr ? 'Onayla' : 'Approve'}</button>
                          <button onClick={() => setRejecting({ id: d.id, note: '' })} className="h-9 px-3 rounded-xl border border-slate-200 dark:border-slate-700 text-xs font-semibold text-slate-600 dark:text-slate-300 inline-flex items-center gap-1.5 hover:border-rose-300 hover:text-rose-600"><X size={14} />{tr ? 'Revizyon iste' : 'Request changes'}</button>
                        </div>
                      ))}
                    </div>); })}
                </div>
              )}
            </div>
          )}

          {tab === 'support' && (openTicket ? (
            <div className={`${card} flex flex-col h-[620px] overflow-hidden`}>
              <div className="px-5 py-3 border-b border-slate-100 dark:border-slate-800 flex items-center gap-3">
                <button onClick={() => setOpenTicketId(null)} className="p-2 rounded-xl hover:bg-slate-100 dark:hover:bg-white/5"><ArrowLeft size={16} /></button>
                <div className="min-w-0 flex-1"><p className="font-bold truncate">{openTicket.title}</p><p className="text-[11px] text-slate-400">{fmtDate(openTicket.createdAt)}</p></div>
                <span className={`text-[11px] font-semibold px-2 py-0.5 rounded-md ${tStatusCls(openTicket.status)}`}>{tStatus(openTicket.status)}</span>
              </div>
              <div className="flex-1 overflow-y-auto custom-scrollbar p-5 space-y-3 bg-slate-50/60 dark:bg-white/[0.02]">
                {[{ id: 'desc', message: openTicket.description, createdAt: openTicket.createdAt, isClient: true } as any, ...(openTicket.responses || [])].map(r => (
                  <div key={r.id} className={`flex ${r.isClient ? 'justify-end' : 'justify-start'}`}>
                    <div className={`max-w-[80%] px-3.5 py-2.5 rounded-2xl text-sm ${r.isClient ? 'text-white rounded-br-md' : 'bg-white dark:bg-slate-800 border border-slate-100 dark:border-slate-700 rounded-bl-md'}`} style={r.isClient ? { background: color } : undefined}>
                      {!r.isClient && <p className="text-[11px] font-semibold mb-0.5" style={{ color }}>{users.find(u => u.id === r.userId)?.name || companyName}</p>}
                      <p className="whitespace-pre-wrap break-words leading-relaxed">{r.message}</p>
                      <p className={`text-[10px] mt-1 ${r.isClient ? 'text-white/70' : 'text-slate-400'}`}>{new Date(r.createdAt).toLocaleString(tr ? 'tr-TR' : 'en-US', { day: 'numeric', month: 'short', hour: '2-digit', minute: '2-digit' })}</p>
                    </div>
                  </div>
                ))}
              </div>
              {openTicket.status === 'Closed' ? <p className="p-4 text-center text-xs text-slate-400 border-t border-slate-100 dark:border-slate-800">{tr ? 'Bu talep kapatıldı. Yeni bir konu için yeni talep oluşturabilirsiniz.' : 'This ticket is closed.'}</p> : (
                <div className="p-3 border-t border-slate-100 dark:border-slate-800 flex items-end gap-2">
                  <textarea rows={1} value={reply} onChange={e => setReply(e.target.value)} onKeyDown={e => { if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); sendReply(); } }} placeholder={tr ? 'Mesajınızı yazın…' : 'Type a message…'} className="flex-1 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 px-3 py-2.5 text-sm outline-none focus:border-[var(--pc)] resize-none max-h-32" />
                  <button onClick={sendReply} disabled={busy || !reply.trim()} className="w-11 h-11 rounded-xl text-white flex items-center justify-center disabled:opacity-40" style={{ background: color }}>{busy ? <Loader2 size={16} className="animate-spin" /> : <Send size={16} />}</button>
                </div>
              )}
            </div>
          ) : (
            <div className={card}>
              <div className="px-5 py-4 border-b border-slate-100 dark:border-slate-800 flex items-center gap-2"><h3 className="font-bold flex-1">{tr ? 'Destek talepleriniz' : 'Your requests'}</h3>
                {canTicket && !ticketForm && <button onClick={() => setTicketForm({ title: '', description: '', priority: 'Medium' })} className="h-9 px-3 rounded-xl text-white text-xs font-semibold inline-flex items-center gap-1.5" style={{ background: color }}><Plus size={14} />{tr ? 'Yeni talep' : 'New request'}</button>}
              </div>
              {ticketForm && (
                <div className="p-5 space-y-3 border-b border-slate-100 dark:border-slate-800 bg-slate-50/60 dark:bg-white/[0.02] animate-in fade-in slide-in-from-top-1 duration-200">
                  <input autoFocus value={ticketForm.title} onChange={e => setTicketForm({ ...ticketForm, title: e.target.value })} placeholder={tr ? 'Konu (örn: Ana sayfa tasarım revizyonu)' : 'Subject'} className="w-full h-11 rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 px-3 text-sm outline-none focus:border-[var(--pc)]" />
                  <textarea rows={4} value={ticketForm.description} onChange={e => setTicketForm({ ...ticketForm, description: e.target.value })} placeholder={tr ? 'Talebinizi ayrıntılı açıklayın…' : 'Describe your request…'} className="w-full rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 px-3 py-2.5 text-sm outline-none focus:border-[var(--pc)] resize-none" />
                  <div className="flex flex-wrap items-center gap-2">
                    <span className="text-xs text-slate-500">{tr ? 'Öncelik' : 'Priority'}</span>
                    {(['Low', 'Medium', 'High'] as TicketPriority[]).map(p => <button key={p} onClick={() => setTicketForm({ ...ticketForm, priority: p })} className={`h-8 px-2.5 rounded-lg text-xs font-semibold border ${ticketForm.priority === p ? 'text-white border-transparent' : 'border-slate-200 dark:border-slate-700 text-slate-500'}`} style={ticketForm.priority === p ? { background: color } : undefined}>{({ Low: tr ? 'Düşük' : 'Low', Medium: tr ? 'Normal' : 'Normal', High: tr ? 'Acil' : 'Urgent' } as any)[p]}</button>)}
                    <span className="flex-1" />
                    <button onClick={() => setTicketForm(null)} className="h-9 px-3 rounded-xl text-xs font-semibold text-slate-500">{tr ? 'Vazgeç' : 'Cancel'}</button>
                    <button onClick={createTicket} disabled={busy || !ticketForm.title.trim() || !ticketForm.description.trim()} className="h-9 px-4 rounded-xl text-white text-xs font-semibold inline-flex items-center gap-1.5 disabled:opacity-50" style={{ background: color }}>{busy ? <Loader2 size={13} className="animate-spin" /> : <Send size={13} />}{tr ? 'Gönder' : 'Submit'}</button>
                  </div>
                </div>
              )}
              {projectTickets.length === 0 ? <p className="p-10 text-center text-sm text-slate-400">{tr ? 'Henüz talep oluşturmadınız. Sorunuz veya isteğiniz için yeni talep açabilirsiniz.' : 'No requests yet.'}</p> : (
                <div className="divide-y divide-slate-100 dark:divide-slate-800">
                  {projectTickets.map(t => { const last = t.responses?.[t.responses.length - 1]; const awaiting = last && !last.isClient && t.status !== 'Closed' && t.status !== 'Resolved'; return (
                    <button key={t.id} onClick={() => setOpenTicketId(t.id)} className="w-full text-left px-5 py-3.5 flex items-center gap-3 hover:bg-slate-50/70 dark:hover:bg-white/[0.02]">
                      <span className="w-9 h-9 rounded-xl bg-slate-100 dark:bg-slate-800 flex items-center justify-center text-slate-500"><MessageSquare size={15} /></span>
                      <div className="min-w-0 flex-1"><p className="text-sm font-semibold truncate">{t.title}</p><p className="text-[11px] text-slate-400 truncate">{last ? `${last.isClient ? (tr ? 'Siz' : 'You') : companyName}: ${last.message}` : fmtDate(t.createdAt)}</p></div>
                      {awaiting && <span className="w-2 h-2 rounded-full bg-rose-500" title={tr ? 'Yeni yanıt' : 'New reply'} />}
                      <span className={`text-[11px] font-semibold px-2 py-0.5 rounded-md ${tStatusCls(t.status)}`}>{tStatus(t.status)}</span>
                    </button>); })}
                </div>
              )}
            </div>
          ))}
        </div>

        {/* YAN ALAN */}
        <div className="lg:col-span-4 space-y-5">
          <div className={`${card} p-5 space-y-3`}>
            <h4 className="font-bold text-sm">{tr ? 'Proje bilgileri' : 'Project details'}</h4>
            {[[Calendar, tr ? 'Başlangıç' : 'Start', fmtDate(project.startDate)], [Clock, tr ? 'Planlanan teslim' : 'Delivery', fmtDate(project.deliveryDate)], [Shield, tr ? 'Durum' : 'Status', statusInfo.label]].map(([I, l, v]: any) => (
              <div key={l} className="flex items-center gap-3 text-sm"><span className="p-1.5 rounded-lg bg-slate-100 dark:bg-slate-800 text-slate-500"><I size={14} /></span><span className="text-slate-500 flex-1">{l}</span><span className="font-semibold text-right">{v}</span></div>
            ))}
          </div>

          {settings.showTeam && team.length > 0 && (
            <div className={`${card} p-5`}>
              <h4 className="font-bold text-sm mb-3 flex items-center gap-2"><Users size={15} style={{ color }} />{tr ? 'Proje ekibi' : 'Project team'}</h4>
              <div className="space-y-3">
                {team.map(m => (
                  <div key={m.id} className="flex items-center gap-3">
                    {m.avatar ? <img src={m.avatar} alt="" className="w-10 h-10 rounded-xl object-cover" /> : <span className="w-10 h-10 rounded-xl text-white flex items-center justify-center font-bold" style={{ background: color }}>{m.name.charAt(0)}</span>}
                    <div className="min-w-0"><p className="text-sm font-semibold truncate">{m.name}</p><p className="text-[11px] text-slate-400 truncate">{m.isPM ? (tr ? 'Proje yöneticisi' : 'Project manager') : (m.jobTitle || (tr ? 'Ekip üyesi' : 'Team member'))}</p></div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {(company.email || company.phone || company.website) && (
            <div className={`${card} p-5`}>
              <h4 className="font-bold text-sm mb-2">{tr ? 'İletişim' : 'Contact'}</h4>
              <div className="space-y-1 text-sm">
                {company.email && <a href={`mailto:${company.email}`} className="block text-slate-600 dark:text-slate-300 hover:underline">{company.email}</a>}
                {company.phone && <a href={`tel:${company.phone}`} className="block text-slate-600 dark:text-slate-300 hover:underline">{company.phone}</a>}
                {company.website && <a href={company.website.startsWith('http') ? company.website : `https://${company.website}`} target="_blank" rel="noreferrer" className="block hover:underline" style={{ color }}>{company.website}</a>}
              </div>
              {canTicket && <button onClick={() => { setTab('support'); setTicketForm({ title: '', description: '', priority: 'Medium' }); }} className="mt-3 w-full h-9 rounded-xl text-xs font-semibold border border-slate-200 dark:border-slate-700 hover:border-[var(--pc)]">{tr ? 'Destek talebi oluştur' : 'Open a request'}</button>}
            </div>
          )}
        </div>
      </div>

      <p className="text-center text-[11px] text-slate-400 pb-8">{companyName} · {today().slice(0, 4)}</p>
    </div>
  );
};

export default ClientPortalPreview;
