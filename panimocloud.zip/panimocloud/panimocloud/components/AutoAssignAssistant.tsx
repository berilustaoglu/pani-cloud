import React, { useState } from 'react';
import { User, Task, TaskStatus } from '../types';
import { Sparkles, Brain, UserPlus, Check, ChevronRight, Info } from 'lucide-react';

interface Props {
  task: Task;
  users: User[];
  allTasks: Task[];
  onAssign: (userId: string) => void;
  language: 'tr' | 'en';
}

const AutoAssignAssistant: React.FC<Props> = ({ task, users, allTasks, onAssign, language }) => {
  const [selectedCandidate, setSelectedCandidate] = useState<string | null>(null);

  const candidates = users.map(user => {
    const activeTasks = allTasks.filter(t => t.assignedTo?.includes(user.id) && t.status !== TaskStatus.DONE).length;
    const completedTasks = allTasks.filter(t => t.assignedTo?.includes(user.id) && t.status === TaskStatus.DONE).length;
    
    // Simple Score Calculation
    // Lower active tasks + higher completed tasks = better candidate
    let score = 100 - (activeTasks * 10) + (completedTasks * 2);
    score = Math.max(0, Math.min(100, score));

    return {
      ...user,
      activeTasks,
      score,
      reason: activeTasks < 2 
        ? (language === 'tr' ? 'Düşük İş Yükü' : 'Low Workload') 
        : (language === 'tr' ? 'Yüksek Tecrübe' : 'High Experience')
    };
  }).sort((a, b) => b.score - a.score);

  return (
    <div className="bg-white dark:bg-slate-900 rounded-[40px] border border-slate-100 dark:border-slate-800 shadow-2xl overflow-hidden max-w-2xl w-full">
      <div className="p-8 border-b border-slate-50 dark:border-slate-800 bg-indigo-600 text-white flex items-center justify-between">
         <div className="flex items-center gap-4">
            <div className="p-3 bg-white/20 rounded-2xl backdrop-blur-md">
               <Brain size={24} />
            </div>
            <div>
               <h3 className="text-xl font-black tracking-tight">{language === 'tr' ? 'AI Görev Atama Asistanı' : 'AI Assignment Assistant'}</h3>
               <p className="text-[10px] font-black uppercase tracking-widest opacity-60">Smart Workload Balancing</p>
            </div>
         </div>
         <Sparkles className="animate-pulse" />
      </div>

      <div className="p-8 space-y-6">
         <div className="p-6 bg-slate-50 dark:bg-slate-800/50 rounded-3xl border border-slate-100 dark:border-slate-800">
            <h4 className="text-[10px] font-black text-slate-400 uppercase tracking-widest mb-2 flex items-center gap-2">
               <Info size={14} /> {language === 'tr' ? 'ATANACAK GÖREV' : 'TASK TO ASSIGN'}
            </h4>
            <p className="text-lg font-black text-slate-900 dark:text-white">{task.title}</p>
         </div>

         <div className="space-y-4">
            <h4 className="text-[10px] font-black text-slate-400 uppercase tracking-widest ml-2">{language === 'tr' ? 'EN UYGUN ADAYLAR' : 'BEST CANDIDATES'}</h4>
            <div className="grid grid-cols-1 gap-3">
               {candidates.slice(0, 3).map((candidate, i) => (
                 <button 
                   key={candidate.id}
                   onClick={() => setSelectedCandidate(candidate.id)}
                   className={`p-6 rounded-[32px] border-2 transition-all flex items-center justify-between text-left ${selectedCandidate === candidate.id ? 'bg-indigo-50 dark:bg-indigo-900/20 border-indigo-500' : 'bg-white dark:bg-slate-900 border-slate-100 dark:border-slate-800 hover:border-slate-200'}`}
                 >
                    <div className="flex items-center gap-4">
                       <div className="relative">
                          <img src={candidate.avatar} className="w-12 h-12 rounded-2xl object-cover" alt={candidate.name} />
                          {i === 0 && <div className="absolute -top-2 -right-2 bg-amber-400 text-white rounded-full p-1"><Sparkles size={10} /></div>}
                       </div>
                       <div>
                          <h5 className="font-black text-sm text-slate-900 dark:text-white">{candidate.name}</h5>
                          <div className="flex items-center gap-2 mt-1">
                             <span className="text-[9px] font-black bg-emerald-100 dark:bg-emerald-900/30 text-emerald-600 px-2 py-0.5 rounded-full uppercase">{candidate.reason}</span>
                             <span className="text-[9px] font-bold text-slate-400">{candidate.activeTasks} {language === 'tr' ? 'Aktif İş' : 'Active Tasks'}</span>
                          </div>
                       </div>
                    </div>
                    <div className="text-right">
                       <div className="text-2xl font-black text-indigo-600 tracking-tighter">%{candidate.score}</div>
                       <p className="text-[8px] font-black text-slate-400 uppercase tracking-widest">Match Score</p>
                    </div>
                 </button>
               ))}
            </div>
         </div>

         <button 
           disabled={!selectedCandidate}
           onClick={() => selectedCandidate && onAssign(selectedCandidate)}
           className="w-full py-5 bg-indigo-600 text-white rounded-[28px] font-black uppercase tracking-widest text-xs hover:bg-indigo-700 transition-all shadow-2xl shadow-indigo-100 dark:shadow-none flex items-center justify-center gap-3 disabled:opacity-50"
         >
            {selectedCandidate ? (
              <>
                 <UserPlus size={18} /> {language === 'tr' ? 'GÖREVLENDİRMEYİ ONAYLA' : 'CONFIRM ASSIGNMENT'}
              </>
            ) : (
              language === 'tr' ? 'LÜTFEN BİR ADAY SEÇİN' : 'PLEASE SELECT A CANDIDATE'
            )}
         </button>
      </div>
    </div>
  );
};

export default AutoAssignAssistant;
