import React, { useEffect, useMemo, useState } from 'react';
import { PauseCircle, BellOff, CalendarClock, Wallet } from 'lucide-react';
import { Project } from '../types';
import { Sheet, Field, inputCls } from './ui/Kit';
import { localISO, dayDiff } from '../services/insights';

/** Tarihe gün ekler (yerel saat, YYYY-MM-DD). */
export const addDaysISO = (iso: string, n: number) => {
  const [y, m, d] = iso.slice(0, 10).split('-').map(Number);
  return localISO(new Date(y, m - 1, d + n));
};

/** Askıdan çıkarken temizlenecek alanlar (undefined → Firestore'da silinir). */
export const CLEAR_HOLD: Pick<Project, 'holdUntil' | 'holdSince' | 'holdReason'> = { holdUntil: undefined, holdSince: undefined, holdReason: undefined };

const fmt = (iso: string, tr: boolean) => new Date(iso + 'T00:00').toLocaleDateString(tr ? 'tr-TR' : 'en-US', { day: 'numeric', month: 'long', year: 'numeric' });

type Preset = '7' | '14' | '30' | '90' | 'custom' | 'open';

interface Props {
  open: boolean;
  project: Project;
  language: 'tr' | 'en';
  showFinancials?: boolean;
  onClose: () => void;
  /** Askıya alma / uzatma için projeye uygulanacak alanlar */
  onConfirm: (patch: Partial<Project>) => Promise<void> | void;
}

/**
 * Projeyi belirli bir süre askıya alır. Askı süresince projeden ve görevlerinden
 * teslim, gecikme ve tahsilat uyarısı üretilmez; süre dolunca tek bir hatırlatma gelir.
 */
const ProjectHoldSheet: React.FC<Props> = ({ open, project: p, language, showFinancials, onClose, onConfirm }) => {
  const tr = language === 'tr';
  const today = localISO();
  const extending = p.status === 'On Hold';
  // Uzatmada süre mevcut askı bitişinden (geçmişteyse bugünden) itibaren hesaplanır
  const base = extending && p.holdUntil && p.holdUntil > today ? p.holdUntil : today;

  const [preset, setPreset] = useState<Preset>('30');
  const [custom, setCustom] = useState(addDaysISO(base, 30));
  const [reason, setReason] = useState('');
  const [shiftDelivery, setShiftDelivery] = useState(true);
  const [shiftInst, setShiftInst] = useState(false);
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    if (!open) return;
    setPreset('30'); setCustom(addDaysISO(base, 30)); setReason(extending ? (p.holdReason || '') : '');
    setShiftDelivery(!!p.deliveryDate); setShiftInst(false); setSaving(false);
  }, [open]); // eslint-disable-line react-hooks/exhaustive-deps

  const until = preset === 'open' ? null : preset === 'custom' ? custom : addDaysISO(base, Number(preset));
  // Ötelenecek gün sayısı: yeni askı bitişi ile mevcut başlangıç noktası arasındaki fark
  const shiftDays = until ? Math.max(0, (dayDiff(until) ?? 0) - (dayDiff(base) ?? 0)) : 0;
  const unpaid = (p.installments || []).filter(i => !i.isPaid);
  const newDelivery = p.deliveryDate && shiftDays ? addDaysISO(p.deliveryDate, shiftDays) : null;
  const invalid = preset === 'custom' && (!custom || custom < today);

  const presets = useMemo(() => ([
    ['7', tr ? '1 hafta' : '1 week'], ['14', tr ? '2 hafta' : '2 weeks'], ['30', tr ? '1 ay' : '1 month'],
    ['90', tr ? '3 ay' : '3 months'], ['custom', tr ? 'Tarih seç' : 'Pick date'], ['open', tr ? 'Süresiz' : 'Indefinite'],
  ] as [Preset, string][]), [tr]);

  const submit = async () => {
    if (invalid || saving) return;
    setSaving(true);
    try {
      const patch: Partial<Project> = {
        status: 'On Hold',
        holdUntil: until || undefined,
        holdSince: extending && p.holdSince ? p.holdSince : today,
        holdReason: reason.trim() || undefined,
      };
      if (shiftDays && shiftDelivery && newDelivery) patch.deliveryDate = newDelivery;
      if (shiftDays && shiftInst && unpaid.length) patch.installments = (p.installments || []).map(i => i.isPaid || !i.dueDate ? i : { ...i, dueDate: addDaysISO(i.dueDate, shiftDays) });
      await onConfirm(patch);
      onClose();
    } finally { setSaving(false); }
  };

  return (
    <Sheet open={open} onClose={onClose} onSubmit={submit} saving={saving} language={language} width="max-w-lg"
      icon={PauseCircle} tone="from-amber-500 to-orange-600"
      title={extending ? (tr ? 'Askıyı uzat' : 'Extend hold') : (tr ? 'Projeyi askıya al' : 'Put project on hold')}
      subtitle={p.name}
      submitLabel={extending ? (tr ? 'Askıyı uzat' : 'Extend') : (tr ? 'Askıya al' : 'Put on hold')}
      footerLeft={until ? <span className="text-xs text-slate-500">{tr ? 'Bitiş:' : 'Until:'} <b className="text-slate-800 dark:text-slate-100">{fmt(until, tr)}</b></span> : <span className="text-xs text-slate-500">{tr ? 'Elle devam ettirilene kadar' : 'Until resumed'}</span>}>

      <Field label={tr ? 'Askı süresi' : 'Hold duration'} required error={invalid ? (tr ? 'Bugün veya sonrası olmalı' : 'Must be today or later') : undefined}>
        <div className="grid grid-cols-3 gap-2">
          {presets.map(([k, l]) => (
            <button key={k} type="button" onClick={() => setPreset(k)}
              className={`h-10 rounded-xl text-sm font-semibold border transition-all ${preset === k ? 'bg-amber-500 border-amber-500 text-white shadow-md shadow-amber-500/25' : 'border-slate-200 dark:border-slate-700 text-slate-600 dark:text-slate-300 hover:border-amber-300'}`}>{l}</button>
          ))}
        </div>
        {preset === 'custom' && <input type="date" min={today} value={custom} onChange={e => setCustom(e.target.value)} className={`${inputCls(invalid ? 'x' : undefined)} mt-2`} />}
      </Field>

      <Field label={tr ? 'Neden (isteğe bağlı)' : 'Reason (optional)'}>
        <textarea value={reason} onChange={e => setReason(e.target.value)} rows={2} maxLength={300}
          placeholder={tr ? 'Örn. müşteri içerik bekliyor, bütçe onayı bekleniyor…' : 'e.g. waiting for client content…'}
          className={`${inputCls()} h-auto py-2.5 resize-none`} />
      </Field>

      {shiftDays > 0 && (p.deliveryDate || unpaid.length > 0) && (
        <div className="space-y-2">
          <p className="text-xs font-semibold text-slate-500">{tr ? `Tarihleri ${shiftDays} gün ötele` : `Shift dates by ${shiftDays} days`}</p>
          {p.deliveryDate && newDelivery && (
            <label className="flex items-center gap-3 p-3 rounded-xl border border-slate-200 dark:border-slate-700 cursor-pointer hover:border-amber-300">
              <input type="checkbox" checked={shiftDelivery} onChange={e => setShiftDelivery(e.target.checked)} className="w-4 h-4 accent-amber-500" />
              <CalendarClock size={16} className="text-slate-400 shrink-0" />
              <span className="text-sm text-slate-700 dark:text-slate-200 flex-1">{tr ? 'Teslim tarihi' : 'Delivery date'}<span className="block text-[11px] text-slate-400">{fmt(p.deliveryDate, tr)} → <b className="text-slate-600 dark:text-slate-300">{fmt(newDelivery, tr)}</b></span></span>
            </label>
          )}
          {showFinancials && unpaid.length > 0 && (
            <label className="flex items-center gap-3 p-3 rounded-xl border border-slate-200 dark:border-slate-700 cursor-pointer hover:border-amber-300">
              <input type="checkbox" checked={shiftInst} onChange={e => setShiftInst(e.target.checked)} className="w-4 h-4 accent-amber-500" />
              <Wallet size={16} className="text-slate-400 shrink-0" />
              <span className="text-sm text-slate-700 dark:text-slate-200 flex-1">{tr ? `Ödenmemiş ${unpaid.length} taksitin vadesi` : `${unpaid.length} unpaid installment due dates`}</span>
            </label>
          )}
        </div>
      )}

      <div className="flex gap-3 p-3.5 rounded-2xl bg-amber-50 dark:bg-amber-500/10 text-amber-800 dark:text-amber-200 text-xs leading-relaxed">
        <BellOff size={16} className="shrink-0 mt-0.5" />
        <span>{tr
          ? 'Askı süresince bu projeden ve görevlerinden teslim, gecikme ve tahsilat uyarısı gelmez; görevleri gecikmiş sayılmaz. Süre dolunca tek bir “askı süresi doldu” hatırlatması alırsın.'
          : 'While on hold, this project and its tasks raise no delivery, overdue or payment alerts. You get a single reminder when the hold ends.'}</span>
      </div>
    </Sheet>
  );
};

export default ProjectHoldSheet;
