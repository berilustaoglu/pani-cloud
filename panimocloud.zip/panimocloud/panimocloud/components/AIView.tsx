import React, { useEffect, useState } from 'react';
import { BarChart3, Target, ShieldCheck, Sparkles, Loader2, Lightbulb, AlertTriangle, TrendingUp, ArrowUpRight, ArrowDownRight, CheckCircle2, Copy, Database, RefreshCcw } from 'lucide-react';
import { analyzeOperations, predictFinancials, performSystemAudit } from '../services/aiService';
import { Task, Transaction, Project, AIAnalysis, Deal, User, AttendanceRecord, Subscription, LicenseSale, ServiceSale, Customer } from '../types';
import { PageHeader, EmptyState, cardCls, btnGhost } from './ui/Kit';
import { ProgressRing } from './ui/Motion';
import { formatTRY } from '../services/insights';
import { toast } from '../services/toast';

interface Props {
  tasks: Task[];
  transactions: Transaction[];
  projects: Project[];
  deals: Deal[];
  users: User[];
  attendance: AttendanceRecord[];
  subscriptions: Subscription[];
  licenseSales: LicenseSale[];
  serviceSales: ServiceSale[];
  customers: Customer[];
  language: 'tr' | 'en';
}

type Mod = 'ops' | 'forecast' | 'audit';
type Saved = { at: string; data: any };
const STORE = 'panimo-ai-results';
const load = (): Partial<Record<Mod, Saved>> => { try { return JSON.parse(localStorage.getItem(STORE) || '{}'); } catch { return {}; } };

const AIView: React.FC<Props> = ({ tasks, transactions, projects, deals, users, attendance, subscriptions, licenseSales, serviceSales, customers, language }) => {
  const tr = language === 'tr';
  const [results, setResults] = useState<Partial<Record<Mod, Saved>>>(load);
  const [running, setRunning] = useState<Mod | null>(null);
  const [active, setActive] = useState<Mod>(() => (['ops', 'forecast', 'audit'] as Mod[]).find(m => load()[m]) || 'ops');
  useEffect(() => { try { localStorage.setItem(STORE, JSON.stringify(results)); } catch { /* depolama kapalı olabilir */ } }, [results]);

  const MODS: Record<Mod, { title: string; desc: string; icon: React.ElementType; tone: string; feeds: string }> = {
    ops: { title: tr ? 'Operasyonel analiz' : 'Operational analysis', desc: tr ? 'Görev, proje ve ekip verimliliğini değerlendirir; darboğazları bulur.' : 'Evaluates task & project efficiency.', icon: BarChart3, tone: 'from-indigo-500 to-violet-600', feeds: `${tasks.length} ${tr ? 'görev' : 'tasks'} · ${projects.length} ${tr ? 'proje' : 'projects'} · ${users.length} ${tr ? 'kişi' : 'people'}` },
    forecast: { title: tr ? 'Finansal tahmin' : 'Financial forecast', desc: tr ? 'Nakit akışını, satış hunisini ve düzenli gelirleri projekte eder.' : 'Projects cash flow and pipeline.', icon: Target, tone: 'from-emerald-500 to-teal-600', feeds: `${transactions.length} ${tr ? 'işlem' : 'tx'} · ${deals.length} ${tr ? 'fırsat' : 'deals'} · ${licenseSales.length + serviceSales.length} ${tr ? 'satış' : 'sales'}` },
    audit: { title: tr ? 'Stratejik denetim' : 'Strategic audit', desc: tr ? 'Tüm sistem verisini çapraz sorgular; riskleri ve fırsatları raporlar.' : 'Cross-audits all system data.', icon: ShieldCheck, tone: 'from-amber-500 to-orange-600', feeds: `${customers.length} ${tr ? 'müşteri' : 'customers'} · ${subscriptions.length} ${tr ? 'abonelik' : 'subs'} · ${attendance.length} ${tr ? 'mesai kaydı' : 'attendance'}` },
  };

  const run = async (m: Mod) => {
    setRunning(m); setActive(m);
    try {
      const data = m === 'ops' ? await analyzeOperations(tasks, transactions, projects, users, language)
        : m === 'forecast' ? await predictFinancials(transactions, projects, deals, subscriptions, licenseSales, serviceSales, language)
        : await performSystemAudit(users, projects, tasks, transactions, subscriptions, serviceSales, attendance, customers, language);
      if (!data) throw new Error('empty');
      setResults(r => ({ ...r, [m]: { at: new Date().toISOString(), data } }));
      toast.success(tr ? `${MODS[m].title} hazır` : 'Ready');
    } catch (e) {
      console.error(e);
      toast.error(tr ? 'Yapay zekâ yanıt vermedi. API anahtarını ve bağlantıyı kontrol edin.' : 'AI request failed.');
    } finally { setRunning(null); }
  };

  const ago = (iso?: string) => {
    if (!iso) return '';
    const m = Math.round((Date.now() - new Date(iso).getTime()) / 60000);
    return m < 1 ? (tr ? 'az önce' : 'just now') : m < 60 ? (tr ? `${m} dk önce` : `${m}m ago`) : m < 1440 ? (tr ? `${Math.round(m / 60)} sa önce` : `${Math.round(m / 60)}h ago`) : new Date(iso).toLocaleDateString('tr-TR');
  };

  const cur = results[active];
  const textOf = (m: Mod, d: any) => m === 'forecast'
    ? [`${MODS[m].title}`, `Gelir: ${d?.forecast?.nextMonth?.income ?? 0} · Gider: ${d?.forecast?.nextMonth?.expense ?? 0}`, ...(d?.risks || []).map((r: string) => `Risk: ${r}`), ...(d?.opportunities || []).map((o: string) => `Fırsat: ${o}`)].join('\n')
    : [MODS[m].title, d?.summary, ...(d?.suggestions || []).map((s: string) => `• ${s}`)].filter(Boolean).join('\n');

  const item = (icon: React.ReactNode, text: string, cls: string) => (
    <div className={`flex gap-3 p-3 rounded-xl ${cls}`}><span className="mt-0.5 shrink-0">{icon}</span><p className="text-sm leading-relaxed break-words whitespace-pre-wrap">{text}</p></div>
  );

  const body = () => {
    if (running === active) return (
      <div className="p-10 flex flex-col items-center gap-4 text-center">
        <div className="relative w-16 h-16"><span className="absolute inset-0 rounded-full bg-indigo-500/20 animate-ping" /><span className={`relative w-16 h-16 rounded-full bg-gradient-to-br ${MODS[active].tone} text-white flex items-center justify-center`}><Sparkles size={26} className="pc-float" /></span></div>
        <p className="text-sm font-semibold text-slate-700 dark:text-slate-200">{tr ? 'Veriler inceleniyor…' : 'Analyzing data…'}</p>
        <div className="w-full max-w-md space-y-2">{[0, 1, 2].map(i => <div key={i} className="h-3 rounded-full pc-skeleton" style={{ width: `${90 - i * 18}%` }} />)}</div>
      </div>
    );
    if (!cur) return <EmptyState icon={MODS[active].icon} text={tr ? 'Henüz çalıştırılmadı. Yukarıdaki karttan başlatın.' : 'Not run yet.'} />;
    const d = cur.data as any;
    if (active === 'forecast') return (
      <div className="p-5 space-y-4">
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
          <div className="rounded-2xl bg-emerald-50 dark:bg-emerald-500/10 p-4"><p className="text-[11px] text-emerald-700 dark:text-emerald-300 flex items-center gap-1"><ArrowUpRight size={12} />{tr ? 'Gelecek ay gelir' : 'Next month income'}</p><p className="text-xl font-black text-emerald-700 dark:text-emerald-300 mt-1">{formatTRY(Number(d?.forecast?.nextMonth?.income) || 0)}</p></div>
          <div className="rounded-2xl bg-rose-50 dark:bg-rose-500/10 p-4"><p className="text-[11px] text-rose-700 dark:text-rose-300 flex items-center gap-1"><ArrowDownRight size={12} />{tr ? 'Gelecek ay gider' : 'Next month expense'}</p><p className="text-xl font-black text-rose-700 dark:text-rose-300 mt-1">{formatTRY(Number(d?.forecast?.nextMonth?.expense) || 0)}</p></div>
          <div className="rounded-2xl bg-slate-50 dark:bg-white/[0.03] p-4 flex items-center gap-3"><ProgressRing value={Number(d?.confidence) || 0} size={56} stroke={6} color="#10b981"><span className="text-xs font-bold">%{Number(d?.confidence) || 0}</span></ProgressRing><div><p className="text-[11px] text-slate-400">{tr ? 'Güven' : 'Confidence'}</p><p className="text-sm font-semibold text-slate-700 dark:text-slate-200">{tr ? 'Model tahmini' : 'Model estimate'}</p></div></div>
        </div>
        {(d?.risks || []).length > 0 && <div className="space-y-2"><p className="text-xs font-semibold text-slate-500">{tr ? 'Riskler' : 'Risks'}</p>{d.risks.map((r: string, i: number) => <div key={i}>{item(<AlertTriangle size={16} className="text-rose-500" />, r, 'bg-rose-50/70 dark:bg-rose-500/5 text-rose-900 dark:text-rose-200')}</div>)}</div>}
        {(d?.opportunities || []).length > 0 && <div className="space-y-2"><p className="text-xs font-semibold text-slate-500">{tr ? 'Fırsatlar' : 'Opportunities'}</p>{d.opportunities.map((o: string, i: number) => <div key={i}>{item(<TrendingUp size={16} className="text-emerald-500" />, o, 'bg-emerald-50/70 dark:bg-emerald-500/5 text-emerald-900 dark:text-emerald-200')}</div>)}</div>}
      </div>
    );
    const a = d as AIAnalysis;
    return (
      <div className="p-5 space-y-4">
        <div className="flex flex-col sm:flex-row gap-4 items-start">
          {active === 'ops' && typeof a.efficiencyScore === 'number' && <ProgressRing value={a.efficiencyScore} size={96} stroke={8}><div className="text-center"><p className="text-xl font-black">{a.efficiencyScore}</p><p className="text-[9px] text-slate-400">{tr ? 'verimlilik' : 'efficiency'}</p></div></ProgressRing>}
          <p className="flex-1 text-sm text-slate-600 dark:text-slate-300 leading-relaxed whitespace-pre-wrap break-words">{a.summary}</p>
        </div>
        {(a.suggestions || []).length > 0 && <div className="space-y-2"><p className="text-xs font-semibold text-slate-500">{tr ? 'Öneriler' : 'Suggestions'}</p>{a.suggestions.map((s, i) => <div key={i} className="animate-in fade-in slide-in-from-bottom-1 duration-300" style={{ animationDelay: `${i * 60}ms` }}>{item(active === 'audit' ? <CheckCircle2 size={16} className="text-amber-500" /> : <Lightbulb size={16} className="text-indigo-500" />, s, 'bg-slate-50 dark:bg-white/[0.03] text-slate-700 dark:text-slate-200')}</div>)}</div>}
      </div>
    );
  };

  return (
    <div className="space-y-5 pb-10">
      <PageHeader title={tr ? 'Yapay Zekâ Analizi' : 'AI Insights'} subtitle={tr ? 'Sistem verilerinizle çalışan tahmin ve optimizasyon araçları.' : 'Forecasting and optimization on your data.'} />

      <div className="grid grid-cols-1 md:grid-cols-3 gap-3 pc-stagger">
        {(Object.keys(MODS) as Mod[]).map(m => { const M = MODS[m]; const I = M.icon; const r = results[m]; return (
          <div key={m} onClick={() => r && setActive(m)} className={`${cardCls} p-5 flex flex-col gap-3 relative overflow-hidden ${r ? 'cursor-pointer pc-lift' : ''} ${active === m ? '!border-indigo-400 ring-4 ring-indigo-500/10' : ''}`}>
            <div className={`absolute -top-12 -right-12 w-32 h-32 rounded-full bg-gradient-to-br ${M.tone} opacity-10 blur-2xl`} />
            <div className="flex items-center gap-3"><span className={`w-10 h-10 rounded-xl bg-gradient-to-br ${M.tone} text-white flex items-center justify-center shadow-md`}><I size={18} /></span><div className="min-w-0"><h3 className="text-sm font-bold text-slate-900 dark:text-white">{M.title}</h3><p className="text-[11px] text-slate-400">{r ? `${tr ? 'Son çalıştırma' : 'Last run'}: ${ago(r.at)}` : (tr ? 'Henüz çalıştırılmadı' : 'Never run')}</p></div></div>
            <p className="text-xs text-slate-500 dark:text-slate-400 leading-relaxed">{M.desc}</p>
            <p className="text-[10px] text-slate-400 flex items-center gap-1"><Database size={10} />{M.feeds}</p>
            <button onClick={e => { e.stopPropagation(); run(m); }} disabled={!!running} className={`mt-auto h-10 rounded-xl text-white text-sm font-semibold inline-flex items-center justify-center gap-2 bg-gradient-to-r ${M.tone} shadow-md disabled:opacity-60 hover:brightness-110 transition`}>
              {running === m ? <Loader2 size={15} className="animate-spin" /> : r ? <RefreshCcw size={15} /> : <Sparkles size={15} />}
              {running === m ? (tr ? 'Çalışıyor…' : 'Running…') : r ? (tr ? 'Yeniden çalıştır' : 'Run again') : (tr ? 'Analizi başlat' : 'Run')}
            </button>
          </div>); })}
      </div>

      <div className={`${cardCls} overflow-hidden`}>
        <div className="px-5 py-3 border-b border-slate-100 dark:border-slate-800 flex items-center gap-2">
          {(Object.keys(MODS) as Mod[]).map(m => <button key={m} onClick={() => setActive(m)} className={`h-8 px-3 rounded-lg text-xs font-semibold transition-colors ${active === m ? 'bg-indigo-600 text-white' : 'text-slate-500 hover:bg-slate-100 dark:hover:bg-white/5'}`}>{MODS[m].title}</button>)}
          <span className="flex-1" />
          {cur && running !== active && <button onClick={() => { navigator.clipboard.writeText(textOf(active, cur.data)); toast.success(tr ? 'Rapor kopyalandı' : 'Copied'); }} className={btnGhost + ' !h-8 !text-xs'}><Copy size={13} />{tr ? 'Kopyala' : 'Copy'}</button>}
        </div>
        <div key={active + (cur?.at || '') + (running || '')} className="animate-in fade-in duration-300">{body()}</div>
      </div>
      <p className="text-[11px] text-slate-400">{tr ? 'Sonuçlar yapay zekâ tarafından üretilir; karar vermeden önce kaynak verilerle doğrulayın. Son sonuçlar yalnızca bu tarayıcıda saklanır.' : 'AI-generated; verify before acting. Results are kept in this browser only.'}</p>
    </div>
  );
};

export default AIView;
