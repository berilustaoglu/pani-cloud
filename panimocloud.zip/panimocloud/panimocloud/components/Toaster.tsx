import React, { useEffect, useState } from 'react';
import { createPortal } from 'react-dom';
import { CheckCircle2, XCircle, AlertTriangle, Info, X } from 'lucide-react';
import { ToastItem, subscribeToasts, dismissToast } from '../services/toast';

const STYLES = {
  success: { icon: CheckCircle2, ring: 'from-emerald-400 to-teal-500', text: 'text-emerald-500', bar: 'bg-emerald-500' },
  error: { icon: XCircle, ring: 'from-rose-500 to-red-600', text: 'text-rose-500', bar: 'bg-rose-500' },
  warning: { icon: AlertTriangle, ring: 'from-amber-400 to-orange-500', text: 'text-amber-500', bar: 'bg-amber-500' },
  info: { icon: Info, ring: 'from-indigo-400 to-violet-500', text: 'text-indigo-500', bar: 'bg-indigo-500' },
};

const ToastCard: React.FC<{ item: ToastItem }> = ({ item }) => {
  const [leaving, setLeaving] = useState(false);
  const [paused, setPaused] = useState(false);
  const s = STYLES[item.type];
  const Icon = s.icon;

  const close = () => {
    setLeaving(true);
    setTimeout(() => dismissToast(item.id), 260);
  };

  return (
    <div
      onMouseEnter={() => setPaused(true)}
      onMouseLeave={() => setPaused(false)}
      className={`pointer-events-auto relative w-[min(92vw,380px)] overflow-hidden rounded-2xl border border-slate-200/70 dark:border-white/10 bg-white/95 dark:bg-slate-900/95 backdrop-blur-xl shadow-2xl shadow-slate-900/10 ${leaving ? 'pc-toast-out' : 'pc-toast-in'}`}
      role="status"
    >
      <div className="flex items-start gap-3 p-4 pr-10">
        <div className={`shrink-0 p-2 rounded-xl bg-gradient-to-br ${s.ring} text-white shadow-lg`}>
          <Icon size={18} />
        </div>
        <p className="text-sm font-semibold text-slate-700 dark:text-slate-200 leading-snug pt-1 break-words">{item.message}</p>
      </div>
      <button onClick={close} className="absolute top-3 right-3 p-1 rounded-lg text-slate-400 hover:text-slate-700 dark:hover:text-white hover:bg-slate-100 dark:hover:bg-white/10" aria-label="Kapat">
        <X size={14} />
      </button>
      <div
        className={`pc-toast-timer absolute bottom-0 left-0 h-1 w-full ${s.bar} opacity-70`}
        style={{ animationDuration: `${item.duration}ms`, animationPlayState: paused ? 'paused' : 'running' }}
        onAnimationEnd={close}
      />
    </div>
  );
};

const Toaster: React.FC = () => {
  const [items, setItems] = useState<ToastItem[]>([]);
  useEffect(() => subscribeToasts(setItems), []);

  if (typeof document === 'undefined') return null;
  return createPortal(
    <div className="fixed z-[9999] bottom-4 right-4 flex flex-col items-end gap-3 pointer-events-none" style={{ paddingBottom: 'env(safe-area-inset-bottom)' }}>
      {items.map(item => <ToastCard key={item.id} item={item} />)}
    </div>,
    document.body
  );
};

export default Toaster;
