import React, { useMemo } from 'react';
import { AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Legend } from 'recharts';
import { Transaction, Project, Currency } from '../types';
import { TrendingUp, AlertCircle, Zap } from 'lucide-react';

interface Props {
  transactions: Transaction[];
  projects: Project[];
  language: 'tr' | 'en';
  rates: { TRY: number, EUR: number };
}

const FinancialForecastView: React.FC<Props> = ({ transactions, projects, language, rates }) => {
  const convertToUSD = (amount: number, currency: Currency) => {
    if (!rates.TRY || !rates.EUR) return amount;
    switch (currency) {
      case Currency.TRY: return amount / rates.TRY;
      case Currency.EUR: return amount / rates.EUR;
      default: return amount;
    }
  };

  const forecastData = useMemo(() => {
    const months = [];
    const now = new Date();
    
    // Geçmiş 3 ay + Gelecek 3 ay
    for (let i = -3; i <= 3; i++) {
      const d = new Date(now.getFullYear(), now.getMonth() + i, 1);
      const label = d.toLocaleString(language === 'tr' ? 'tr-TR' : 'en-US', { month: 'short', year: '2-digit' });
      const yearMonth = `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}`;
      
      const actualIncome = transactions
        .filter(tr => tr.type === 'Income' && tr.date.startsWith(yearMonth))
        .reduce((sum, tr) => sum + convertToUSD(tr.amount, tr.currency || Currency.USD), 0);

      // Gelecek projeksiyonu (Sadece basitleştirilmiş bir model)
      let projectedIncome = actualIncome;
      if (i > 0) {
        // Beklenen taksitleri veya proje ödemelerini ekleyebiliriz
        const expectedPayments = projects.reduce((sum, p) => {
          const monthlyInstallments = p.installments.filter(inst => !inst.isPaid && inst.dueDate.startsWith(yearMonth));
          return sum + monthlyInstallments.reduce((s, inst) => s + convertToUSD(inst.amount, p.currency || Currency.USD), 0);
        }, 0);
        projectedIncome = expectedPayments;
      }

      months.push({ 
        name: label, 
        income: Math.round(actualIncome || (i > 0 ? projectedIncome : 0)),
        isProjected: i > 0
      });
    }
    return months;
  }, [transactions, projects, language, rates]);

  return (
    <div className="bg-white dark:bg-slate-900 pt-4 px-6 pb-2 rounded-[40px] border border-slate-100 dark:border-slate-800 shadow-sm h-[500px] flex flex-col overflow-hidden">
      <div className="flex justify-between items-center mb-2">
        <h3 className="text-xl font-black text-slate-900 dark:text-white flex items-center gap-3">
          <div className="w-1.5 h-8 bg-emerald-500 rounded-full" />
          {language === 'tr' ? 'Finansal Nakit Akışı Tahmini' : 'Financial Cash Flow Forecast'}
        </h3>
        <div className="flex items-center gap-2 px-3 py-1 bg-emerald-50 text-emerald-600 rounded-full text-[10px] font-black uppercase">
          <Zap size={14} /> AI ENABLED
        </div>
      </div>

      <div className="flex-1 w-full min-h-[400px] mt-2 mb-2">
        <ResponsiveContainer width="100%" height="100%">
          <AreaChart data={forecastData} margin={{ top: 10, right: 10, left: 0, bottom: 0 }}>
            <defs>
              <linearGradient id="colorIncome" x1="0" y1="0" x2="0" y2="1">
                <stop offset="5%" stopColor="#10b981" stopOpacity={0.3}/>
                <stop offset="95%" stopColor="#10b981" stopOpacity={0}/>
              </linearGradient>
            </defs>
            <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f1f5f9" />
            <XAxis dataKey="name" axisLine={false} tickLine={false} tick={{ fontSize: 11, fontWeight: 'bold', fill: '#94a3b8' }} dy={10} />
            <YAxis axisLine={false} tickLine={false} tick={{ fontSize: 11, fontWeight: 'bold', fill: '#94a3b8' }} width={40} />
            <Tooltip 
              contentStyle={{ backgroundColor: '#0f172a', border: 'none', borderRadius: '16px', color: '#fff' }}
              itemStyle={{ color: '#fff', fontSize: '12px', fontWeight: 'bold' }}
              formatter={(value: any) => `$${value.toLocaleString()}`}
            />
            <Area type="monotone" dataKey="income" stroke="#10b981" strokeWidth={5} fillOpacity={1} fill="url(#colorIncome)" />
          </AreaChart>
        </ResponsiveContainer>
      </div>

    </div>
  );
};

export default FinancialForecastView;
