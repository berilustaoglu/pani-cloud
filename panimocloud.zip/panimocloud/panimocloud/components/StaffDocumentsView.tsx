import React, { useMemo, useRef, useState } from 'react';
import { ref, uploadBytesResumable, getDownloadURL } from 'firebase/storage';
import { storage } from '../firebase';
import { FileText, FileImage, FileSpreadsheet, FileArchive, FileVideo, FileCode, File as FileIcon, Download, FolderOpen, Upload, Inbox, Send, Layers, X, Check, Users, LayoutGrid, List, ShieldCheck } from 'lucide-react';
import { StaffDocument, User, Project, UserRole } from '../types';
import { PageHeader, KpiGrid, SearchBox, Segmented, Field, EmptyState, DeleteButton, Sheet, Avatar, inputCls, selectSm, cardCls, btnPrimary } from './ui/Kit';
import { localISO, dayDiff } from '../services/insights';
import { toast } from '../services/toast';

interface Props {
  currentUser: User;
  staffDocuments: StaffDocument[];
  language: 'tr' | 'en';
  onDeleteStaffDoc: (id: string) => Promise<void>;
  staffList: User[];
  projects: Project[];
  onAddStaffDoc: (doc: StaffDocument) => Promise<void>;
}

const MAX_MB = 25;
const kind = (ext: string) => {
  const e = ext.toLowerCase();
  if (['png', 'jpg', 'jpeg', 'gif', 'webp', 'svg', 'heic'].includes(e)) return { icon: FileImage, tone: 'from-pink-500 to-rose-500', label: 'Görsel' };
  if (['xls', 'xlsx', 'csv', 'ods'].includes(e)) return { icon: FileSpreadsheet, tone: 'from-emerald-500 to-green-600', label: 'Tablo' };
  if (['zip', 'rar', '7z', 'tar', 'gz'].includes(e)) return { icon: FileArchive, tone: 'from-amber-500 to-orange-500', label: 'Arşiv' };
  if (['mp4', 'mov', 'avi', 'mkv', 'webm'].includes(e)) return { icon: FileVideo, tone: 'from-violet-500 to-purple-600', label: 'Video' };
  if (['js', 'ts', 'tsx', 'json', 'cs', 'py', 'html', 'css', 'unity', 'apk'].includes(e)) return { icon: FileCode, tone: 'from-slate-600 to-slate-800', label: 'Kod' };
  if (['pdf', 'doc', 'docx', 'txt', 'ppt', 'pptx', 'odt', 'rtf'].includes(e)) return { icon: FileText, tone: 'from-indigo-500 to-blue-600', label: 'Doküman' };
  return { icon: FileIcon, tone: 'from-slate-400 to-slate-500', label: 'Dosya' };
};
const fmtSize = (b?: number) => (!b ? '' : b < 1024 * 1024 ? `${Math.max(1, Math.round(b / 1024))} KB` : `${(b / 1024 / 1024).toFixed(1)} MB`);

const StaffDocumentsView: React.FC<Props> = ({ currentUser, staffDocuments, language, onDeleteStaffDoc, staffList, projects, onAddStaffDoc }) => {
  const tr = language === 'tr';
  const isAdmin = currentUser.role === UserRole.ADMIN;
  const [box, setBox] = useState<'inbox' | 'sent' | 'all'>('inbox');
  const [layout, setLayout] = useState<'grid' | 'list'>(() => { try { return (localStorage.getItem('panimo-docs-layout') as any) || 'grid'; } catch { return 'grid'; } });
  const [search, setSearch] = useState('');
  const [projectF, setProjectF] = useState('all');
  const [typeF, setTypeF] = useState('all');

  const [open, setOpen] = useState(false);
  const [files, setFiles] = useState<File[]>([]);
  const [targets, setTargets] = useState<string[]>([]);
  const [projectId, setProjectId] = useState('');
  const [note, setNote] = useState('');
  const [progress, setProgress] = useState<number | null>(null);
  const [drag, setDrag] = useState(false);
  const [touched, setTouched] = useState(false);
  const fileInput = useRef<HTMLInputElement>(null);

  const inbox = useMemo(() => staffDocuments.filter(d => d.userId === currentUser.id), [staffDocuments, currentUser.id]);
  const sent = useMemo(() => staffDocuments.filter(d => d.sharedById === currentUser.id), [staffDocuments, currentUser.id]);
  const unread = inbox.filter(d => !d.readAt && d.sharedById !== currentUser.id).length;
  const base = box === 'inbox' ? inbox : box === 'sent' ? sent : staffDocuments;

  const q = search.trim().toLocaleLowerCase('tr-TR');
  const list = useMemo(() => base.filter(d =>
    (projectF === 'all' || d.projectId === projectF) &&
    (typeF === 'all' || kind(d.fileType).label === typeF) &&
    (!q || [d.fileName, d.projectName, d.note, d.sharedByName, staffList.find(u => u.id === d.userId)?.name].join(' ').toLocaleLowerCase('tr-TR').includes(q))
  ).sort((a, b) => (b.uploadDate || '').localeCompare(a.uploadDate || '') || b.id.localeCompare(a.id)), [base, projectF, typeF, q, staffList]);

  const usedProjects = useMemo(() => { const m = new Map<string, string>(); base.forEach(d => m.set(d.projectId, d.projectName)); return [...m.entries()]; }, [base]);
  const usedTypes = useMemo(() => [...new Set(base.map(d => kind(d.fileType).label))], [base]);

  const openDoc = async (d: StaffDocument) => {
    if (!d.fileUrl) { toast.error(tr ? 'Dosya bağlantısı bulunamadı.' : 'File URL missing.'); return; }
    window.open(d.fileUrl, '_blank', 'noopener');
    if (d.userId === currentUser.id && !d.readAt) { try { await onAddStaffDoc({ ...d, readAt: new Date().toISOString() }); } catch { /* okundu bilgisi kritik değil */ } }
  };

  const addFiles = (fl: FileList | File[] | null) => {
    if (!fl) return;
    const arr = Array.from(fl);
    const big = arr.filter(f => f.size > MAX_MB * 1024 * 1024);
    if (big.length) toast.warning(tr ? `${big.map(f => f.name).join(', ')} ${MAX_MB} MB sınırını aşıyor` : `Over ${MAX_MB} MB limit`);
    setFiles(prev => [...prev, ...arr.filter(f => f.size <= MAX_MB * 1024 * 1024 && !prev.some(p => p.name === f.name && p.size === f.size))]);
  };
  const reset = () => { setFiles([]); setTargets([]); setProjectId(''); setNote(''); setProgress(null); setTouched(false); };

  const errs: Record<string, string> = {};
  if (!files.length) errs.files = tr ? 'En az bir dosya seçin.' : 'Select a file.';
  if (!targets.length) errs.targets = tr ? 'En az bir alıcı seçin.' : 'Select a recipient.';

  const share = async () => {
    setTouched(true);
    if (Object.keys(errs).length || progress !== null) return;
    const project = projects.find(p => p.id === projectId);
    const total = files.reduce((a, f) => a + f.size, 0) || 1;
    let done = 0;
    setProgress(0);
    try {
      for (const f of files) {
        const r = ref(storage, `staff_docs/${Date.now()}_${f.name}`);
        const task = uploadBytesResumable(r, f);
        await new Promise<void>((res, rej) => task.on('state_changed', s => setProgress(Math.round(((done + s.bytesTransferred) / total) * 100)), rej, () => res()));
        done += f.size;
        const url = await getDownloadURL(r);
        for (const uid of targets) {
          await onAddStaffDoc({
            id: `doc_${Date.now()}_${Math.random().toString(36).slice(2, 7)}`, userId: uid, projectId: projectId || 'general', projectName: project?.name || (tr ? 'Genel doküman' : 'General'),
            fileName: f.name, fileType: f.name.includes('.') ? f.name.split('.').pop()!.toLowerCase() : 'file', uploadDate: localISO(), note: note.trim(), fileUrl: url,
            sharedById: currentUser.id, sharedByName: currentUser.name, fileSize: f.size,
          });
        }
      }
      toast.success(tr ? `${files.length} dosya ${targets.length} kişiyle paylaşıldı` : 'Shared');
      setOpen(false); reset(); setBox('sent');
    } catch (e: any) {
      console.error('Share error:', e);
      toast.error(tr ? 'Yükleme başarısız oldu. Bağlantınızı kontrol edin.' : 'Upload failed.');
      setProgress(null);
    }
  };

  const canDelete = (d: StaffDocument) => isAdmin || d.userId === currentUser.id || d.sharedById === currentUser.id;
  const person = (id?: string) => staffList.find(u => u.id === id);
  const meta = (d: StaffDocument) => box === 'inbox'
    ? (d.sharedByName ? `${d.sharedByName} ${tr ? 'paylaştı' : 'shared'}` : (tr ? 'Yönetim' : 'Management'))
    : `→ ${person(d.userId)?.name || '—'}${d.readAt ? (tr ? ' · görüldü' : ' · seen') : ''}`;
  const isNew = (d: StaffDocument) => box === 'inbox' && !d.readAt && d.sharedById !== currentUser.id && (dayDiff(d.uploadDate) ?? -99) >= -14;

  const card = (d: StaffDocument) => {
    const k = kind(d.fileType); const Icon = k.icon;
    return (
      <div key={d.id} className={`${cardCls} p-4 flex flex-col gap-3 pc-lift group relative`}>
        {isNew(d) && <span className="absolute top-3 right-3 text-[10px] font-bold px-1.5 py-0.5 rounded-md bg-indigo-600 text-white">{tr ? 'Yeni' : 'New'}</span>}
        <div className="flex items-start gap-3">
          <span className={`w-11 h-11 shrink-0 rounded-xl bg-gradient-to-br ${k.tone} text-white flex items-center justify-center shadow-md group-hover:scale-105 transition-transform`}><Icon size={20} /></span>
          <div className="min-w-0 flex-1 pr-8"><p className="text-sm font-semibold text-slate-800 dark:text-slate-100 break-words line-clamp-2" title={d.fileName}>{d.fileName}</p><p className="text-[11px] text-slate-400 mt-0.5">{d.fileType.toUpperCase()}{d.fileSize ? ` · ${fmtSize(d.fileSize)}` : ''} · {d.uploadDate}</p></div>
        </div>
        <p className="text-[11px] text-indigo-600 dark:text-indigo-300 font-semibold flex items-center gap-1 truncate"><Layers size={12} />{d.projectName}</p>
        {d.note && <p className="text-xs text-slate-500 dark:text-slate-400 bg-slate-50 dark:bg-white/[0.03] rounded-xl px-3 py-2 line-clamp-3">{d.note}</p>}
        <div className="mt-auto pt-2 flex items-center gap-2 border-t border-slate-100 dark:border-slate-800">
          <span className="flex-1 min-w-0 text-[11px] text-slate-400 truncate">{meta(d)}</span>
          {canDelete(d) && <DeleteButton language={language} onConfirm={async () => { await onDeleteStaffDoc(d.id); toast(tr ? 'Dosya kaldırıldı' : 'Removed', 'info'); }} />}
          <button onClick={() => openDoc(d)} className="h-8 px-3 rounded-lg bg-slate-900 dark:bg-white/10 text-white text-xs font-semibold inline-flex items-center gap-1.5 hover:bg-indigo-600"><Download size={13} />{tr ? 'Aç' : 'Open'}</button>
        </div>
      </div>
    );
  };
  const row = (d: StaffDocument) => {
    const k = kind(d.fileType); const Icon = k.icon;
    return (
      <div key={d.id} className="grid grid-cols-12 gap-3 items-center px-4 py-3 hover:bg-slate-50/70 dark:hover:bg-white/[0.02]">
        <div className="col-span-12 sm:col-span-5 flex items-center gap-3 min-w-0"><span className={`w-9 h-9 shrink-0 rounded-lg bg-gradient-to-br ${k.tone} text-white flex items-center justify-center`}><Icon size={16} /></span><div className="min-w-0"><p className="text-sm font-semibold text-slate-800 dark:text-slate-100 truncate flex items-center gap-2">{d.fileName}{isNew(d) && <span className="text-[9px] font-bold px-1.5 py-0.5 rounded bg-indigo-600 text-white">{tr ? 'Yeni' : 'New'}</span>}</p><p className="text-[11px] text-slate-400 truncate">{d.note || d.fileType.toUpperCase()}</p></div></div>
        <div className="col-span-6 sm:col-span-2 text-[11px] text-indigo-600 dark:text-indigo-300 font-semibold truncate">{d.projectName}</div>
        <div className="col-span-6 sm:col-span-2 text-[11px] text-slate-400 truncate">{meta(d)}</div>
        <div className="col-span-6 sm:col-span-1 text-[11px] text-slate-400">{d.uploadDate}{d.fileSize ? <><br />{fmtSize(d.fileSize)}</> : null}</div>
        <div className="col-span-6 sm:col-span-2 flex justify-end items-center gap-1">
          {canDelete(d) && <DeleteButton language={language} onConfirm={async () => { await onDeleteStaffDoc(d.id); toast(tr ? 'Dosya kaldırıldı' : 'Removed', 'info'); }} />}
          <button onClick={() => openDoc(d)} className="p-1.5 rounded-lg text-slate-400 hover:text-indigo-600 hover:bg-indigo-50 dark:hover:bg-white/5"><Download size={15} /></button>
        </div>
      </div>
    );
  };

  const recipients = staffList.filter(u => u.id !== currentUser.id);
  const allSel = recipients.length > 0 && targets.length === recipients.length;

  return (
    <div className="space-y-5 pb-10">
      <PageHeader title={tr ? 'Dosyalarım' : 'My files'} subtitle={tr ? 'Ekip içi belge paylaşımı · proje bazlı arşiv' : 'Team document sharing'}
        actions={<button onClick={() => { reset(); setOpen(true); }} className={btnPrimary}><Upload size={16} />{tr ? 'Dosya paylaş' : 'Share file'}</button>} />

      <KpiGrid items={[
        { label: tr ? 'Bana gelenler' : 'Received', value: inbox.length, icon: Inbox, grad: 'from-indigo-500 to-violet-600', sub: unread ? (tr ? `${unread} açılmamış` : `${unread} unopened`) : (tr ? 'Hepsi görüldü' : 'All seen'), onClick: () => setBox('inbox'), active: box === 'inbox' },
        { label: tr ? 'Paylaştıklarım' : 'Sent', value: sent.length, icon: Send, grad: 'from-emerald-500 to-teal-600', sub: tr ? `${sent.filter(d => d.readAt).length} tanesi görüldü` : 'seen', onClick: () => setBox('sent'), active: box === 'sent' },
        { label: tr ? 'Proje klasörü' : 'Projects', value: new Set(inbox.map(d => d.projectId)).size, icon: FolderOpen, grad: 'from-amber-500 to-orange-600', sub: tr ? 'Gelen dosyalarda' : 'In inbox' },
        { label: tr ? 'Toplam boyut' : 'Total size', value: Math.round(inbox.reduce((a, d) => a + (d.fileSize || 0), 0) / 1024 / 1024 * 10) / 10, format: n => `${n.toLocaleString('tr-TR')} MB`, icon: ShieldCheck, grad: 'from-sky-500 to-blue-600', sub: tr ? 'Gelen dosyalar' : 'Inbox' },
      ]} />

      <div className={`${cardCls} p-3 flex flex-col lg:flex-row gap-2`}>
        <Segmented<'inbox' | 'sent' | 'all'> value={box} onChange={v => { setBox(v); setProjectF('all'); setTypeF('all'); }} options={[
          { value: 'inbox', label: <><Inbox size={14} />{tr ? 'Gelen' : 'Inbox'}{unread > 0 && <span className="text-[10px] px-1.5 rounded-full bg-indigo-600 text-white">{unread}</span>}</> },
          { value: 'sent', label: <><Send size={14} />{tr ? 'Gönderilen' : 'Sent'}</> },
          ...(isAdmin ? [{ value: 'all' as const, label: <><Users size={14} />{tr ? 'Tümü' : 'All'}</> }] : []),
        ]} />
        <SearchBox value={search} onChange={setSearch} placeholder={tr ? 'Dosya, proje, not veya kişi ara…' : 'Search…'} />
        <select value={projectF} onChange={e => setProjectF(e.target.value)} className={selectSm}><option value="all">{tr ? 'Tüm projeler' : 'All projects'}</option>{usedProjects.map(([id, n]) => <option key={id} value={id}>{n}</option>)}</select>
        <select value={typeF} onChange={e => setTypeF(e.target.value)} className={selectSm}><option value="all">{tr ? 'Tüm türler' : 'All types'}</option>{usedTypes.map(t => <option key={t} value={t}>{t}</option>)}</select>
        <div className="flex bg-slate-100 dark:bg-slate-800 rounded-xl p-1 shrink-0">
          {(['grid', 'list'] as const).map(l => <button key={l} onClick={() => { setLayout(l); try { localStorage.setItem('panimo-docs-layout', l); } catch { /* yok say */ } }} className={`p-1.5 rounded-lg ${layout === l ? 'bg-white dark:bg-slate-900 text-indigo-600 shadow-sm' : 'text-slate-400'}`}>{l === 'grid' ? <LayoutGrid size={15} /> : <List size={15} />}</button>)}
        </div>
      </div>

      {list.length === 0
        ? <div className={cardCls}><EmptyState icon={FolderOpen} text={box === 'inbox' ? (tr ? 'Sizinle paylaşılan dosya yok' : 'Nothing shared with you') : (tr ? 'Kayıt yok' : 'No files')} action={<button onClick={() => { reset(); setOpen(true); }} className={btnPrimary}><Upload size={15} />{tr ? 'Dosya paylaş' : 'Share'}</button>} /></div>
        : layout === 'grid'
          ? <div key={box + layout} className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-3 gap-3 pc-stagger">{list.map(card)}</div>
          : <div key={box + layout} className={`${cardCls} overflow-hidden divide-y divide-slate-100 dark:divide-slate-800 pc-stagger`}>{list.map(row)}</div>}

      <p className="text-[11px] text-slate-400 flex items-center gap-1.5"><ShieldCheck size={13} />{tr ? 'Bu alandaki dosyalar şirket gizlilik politikasına tabidir; üçüncü kişilerle paylaşmayın.' : 'Files here are confidential.'}</p>

      <Sheet open={open} language={language} title={tr ? 'Dosya paylaş' : 'Share files'} subtitle={tr ? `Dosya başına en fazla ${MAX_MB} MB` : `Max ${MAX_MB} MB per file`} icon={Upload} onClose={() => { if (progress === null) setOpen(false); }} onSubmit={share} saving={progress !== null} submitLabel={tr ? 'Paylaş' : 'Share'}
        footerLeft={progress !== null ? <div className="flex items-center gap-2"><div className="w-28 h-1.5 rounded-full bg-slate-100 dark:bg-slate-800 overflow-hidden"><div className="h-full bg-indigo-500 transition-all" style={{ width: `${progress}%` }} /></div><span className="text-xs font-semibold text-slate-500">%{progress}</span></div> : files.length ? <span className="text-slate-400">{files.length} {tr ? 'dosya' : 'files'} · {fmtSize(files.reduce((a, f) => a + f.size, 0))}</span> : undefined}>
        <Field label={tr ? 'Dosyalar' : 'Files'} required error={touched ? errs.files : undefined}>
          <div onDragOver={e => { e.preventDefault(); setDrag(true); }} onDragLeave={() => setDrag(false)} onDrop={e => { e.preventDefault(); setDrag(false); addFiles(e.dataTransfer.files); }} onClick={() => fileInput.current?.click()}
            className={`cursor-pointer rounded-2xl border-2 border-dashed p-6 flex flex-col items-center gap-2 text-center transition-all ${drag ? 'border-indigo-500 bg-indigo-50/60 dark:bg-indigo-500/10 scale-[1.01]' : 'border-slate-200 dark:border-slate-700 hover:border-indigo-300 bg-slate-50/50 dark:bg-white/[0.02]'}`}>
            <Upload size={26} className={drag ? 'text-indigo-500 pc-float' : 'text-slate-300'} />
            <p className="text-sm font-semibold text-slate-600 dark:text-slate-300">{tr ? 'Sürükleyip bırakın veya tıklayıp seçin' : 'Drop files or click'}</p>
            <p className="text-[11px] text-slate-400">{tr ? 'Birden fazla dosya seçebilirsiniz' : 'Multiple allowed'}</p>
            <input ref={fileInput} type="file" multiple className="hidden" onChange={e => { addFiles(e.target.files); e.target.value = ''; }} />
          </div>
          {files.length > 0 && <div className="mt-2 space-y-1.5">{files.map((f, i) => { const k = kind(f.name.split('.').pop() || ''); const I = k.icon; return (
            <div key={f.name + i} className="flex items-center gap-2 px-3 py-2 rounded-xl bg-slate-50 dark:bg-white/[0.03] animate-in fade-in slide-in-from-top-1 duration-200"><I size={15} className="text-slate-400" /><span className="flex-1 min-w-0 truncate text-sm text-slate-700 dark:text-slate-200">{f.name}</span><span className="text-[11px] text-slate-400">{fmtSize(f.size)}</span>{progress === null && <button onClick={() => setFiles(files.filter((_, j) => j !== i))} className="p-1 text-slate-400 hover:text-rose-500"><X size={13} /></button>}</div>); })}</div>}
        </Field>
        <Field label={tr ? 'Alıcılar' : 'Recipients'} required error={touched ? errs.targets : undefined} hint={<button type="button" onClick={() => setTargets(allSel ? [] : recipients.map(u => u.id))} className="font-semibold text-indigo-600 hover:underline">{allSel ? (tr ? 'Seçimi temizle' : 'Clear') : (tr ? 'Tüm ekibi seç' : 'Select all')}</button>}>
          <div className="flex flex-wrap gap-1.5 max-h-44 overflow-y-auto custom-scrollbar">
            {recipients.map(u => { const on = targets.includes(u.id); return (
              <button key={u.id} type="button" onClick={() => setTargets(on ? targets.filter(x => x !== u.id) : [...targets, u.id])} className={`h-9 pl-1 pr-3 rounded-full border text-xs font-semibold inline-flex items-center gap-2 transition-all ${on ? 'bg-indigo-600 border-indigo-600 text-white shadow-md shadow-indigo-500/20' : 'border-slate-200 dark:border-slate-700 text-slate-600 dark:text-slate-300 hover:border-indigo-300'}`}>
                {on ? <span className="w-7 h-7 rounded-full bg-white/20 flex items-center justify-center"><Check size={13} /></span> : <Avatar name={u.name} src={u.avatar} size="w-7 h-7" className="!rounded-full" />}{u.name}
              </button>); })}
          </div>
        </Field>
        <Field label={tr ? 'Proje' : 'Project'}><select className={inputCls()} value={projectId} onChange={e => setProjectId(e.target.value)}><option value="">{tr ? 'Genel doküman' : 'General'}</option>{projects.map(p => <option key={p.id} value={p.id}>{p.name}</option>)}</select></Field>
        <Field label={tr ? 'Not' : 'Note'}><textarea rows={3} className={inputCls() + ' !h-auto py-2.5 resize-none'} value={note} onChange={e => setNote(e.target.value)} placeholder={tr ? 'Örn: Sözleşmenin imzalı hali, lütfen inceleyin.' : 'Optional note'} /></Field>
      </Sheet>
    </div>
  );
};

export default StaffDocumentsView;
