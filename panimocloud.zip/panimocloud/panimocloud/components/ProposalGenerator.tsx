import React, { useState } from 'react';
import { FileText, Plus, Trash2, Send, Download, Zap, CheckCircle2 } from 'lucide-react';
import { Currency } from '../types';

interface ServiceItem {
  id: string;
  name: string;
  price: number;
  description: string;
}

interface Props {
  language: 'tr' | 'en';
  clientName?: string;
}

const ProposalGenerator: React.FC<Props> = ({ language, clientName = '' }) => {
  const [client, setClient] = useState(clientName);
  const [items, setItems] = useState<ServiceItem[]>([
    { id: '1', name: 'UI/UX Design', price: 1500, description: 'Premium interface design' }
  ]);
  const [showPreview, setShowPreview] = useState(false);

  const addItem = () => {
    setItems([...items, { id: Date.now().toString(), name: '', price: 0, description: '' }]);
  };

  const removeItem = (id: string) => {
    setItems(items.filter(i => i.id !== id));
  };

  const updateItem = (id: string, field: keyof ServiceItem, value: string | number) => {
    setItems(items.map(i => i.id === id ? { ...i, [field]: value } : i));
  };

  const total = items.reduce((sum, item) => sum + (Number(item.price) || 0), 0);

  return (
    <div className="bg-white dark:bg-slate-900 min-h-screen rounded-[48px] border border-slate-100 dark:border-slate-800 shadow-2xl overflow-hidden flex flex-col lg:flex-row">
      {/* EDITOR SIDE */}
      <div className="flex-1 p-8 lg:p-12 border-r border-slate-50 dark:border-slate-800">
        <div className="flex items-center gap-4 mb-12">
           <div className="w-12 h-12 bg-indigo-600 text-white rounded-2xl flex items-center justify-center shadow-lg shadow-indigo-100 dark:shadow-none">
              <FileText size={24} />
           </div>
           <div>
              <h2 className="text-2xl font-black text-slate-900 dark:text-white tracking-tight">
                 {language === 'tr' ? 'Yeni Teklif Oluştur' : 'Create New Proposal'}
              </h2>
              <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest mt-1">Professional Document Engine</p>
           </div>
        </div>

        <div className="space-y-8">
           <div className="space-y-2">
              <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest">{language === 'tr' ? 'MÜŞTERİ ADI' : 'CLIENT NAME'}</label>
              <input 
                value={client}
                onChange={(e) => setClient(e.target.value)}
                className="w-full bg-slate-50 dark:bg-slate-800/50 border border-slate-100 dark:border-slate-800 p-4 rounded-2xl text-slate-900 dark:text-white font-bold focus:outline-none focus:ring-2 focus:ring-indigo-500/20 transition-all"
                placeholder="Google Inc."
              />
           </div>

           <div className="space-y-4">
              <div className="flex items-center justify-between">
                 <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest">{language === 'tr' ? 'HİZMETLER' : 'SERVICES'}</label>
                 <button 
                   onClick={addItem}
                   className="text-[10px] font-black text-indigo-600 flex items-center gap-1 hover:underline"
                 >
                    <Plus size={14} /> {language === 'tr' ? 'KALEM EKLE' : 'ADD ITEM'}
                 </button>
              </div>
              
              <div className="space-y-4">
                 {items.map(item => (
                   <div key={item.id} className="p-6 bg-slate-50 dark:bg-slate-800/50 border border-slate-100 dark:border-slate-800 rounded-[28px] relative group">
                      <button 
                        onClick={() => removeItem(item.id)}
                        className="absolute top-4 right-4 text-slate-300 hover:text-red-500 transition-colors"
                      >
                         <Trash2 size={16} />
                      </button>
                      <div className="grid grid-cols-1 md:grid-cols-12 gap-4">
                         <div className="md:col-span-8">
                            <input 
                              value={item.name}
                              onChange={(e) => updateItem(item.id, 'name', e.target.value)}
                              className="w-full bg-transparent border-none p-0 text-sm font-black text-slate-900 dark:text-white focus:ring-0"
                              placeholder={language === 'tr' ? 'Hizmet adı...' : 'Service name...'}
                            />
                            <textarea 
                              value={item.description}
                              onChange={(e) => updateItem(item.id, 'description', e.target.value)}
                              className="w-full bg-transparent border-none p-0 text-xs text-slate-400 font-medium focus:ring-0 mt-2 resize-none"
                              placeholder={language === 'tr' ? 'Kısa açıklama...' : 'Short description...'}
                            />
                         </div>
                         <div className="md:col-span-4">
                            <div className="flex items-center bg-white dark:bg-slate-900 rounded-xl p-2 border border-slate-100 dark:border-slate-800">
                               <span className="text-slate-400 font-bold px-2">$</span>
                               <input 
                                 type="number"
                                 value={item.price}
                                 onChange={(e) => updateItem(item.id, 'price', e.target.value)}
                                 className="w-full bg-transparent border-none p-2 text-right font-black text-slate-900 dark:text-white focus:ring-0"
                               />
                            </div>
                         </div>
                      </div>
                   </div>
                 ))}
              </div>
           </div>
        </div>

        <div className="mt-12 flex items-center justify-between p-8 bg-indigo-600 rounded-[32px] text-white">
           <div>
              <p className="text-[10px] font-black uppercase tracking-widest opacity-60">TOTAL VALUE</p>
              <h3 className="text-3xl font-black">${total.toLocaleString()}</h3>
           </div>
           <button 
             onClick={() => setShowPreview(true)}
             className="px-8 py-4 bg-white text-indigo-600 rounded-2xl text-xs font-black uppercase tracking-widest hover:scale-105 transition-all shadow-xl"
           >
              {language === 'tr' ? 'TEKLİFİ OLUŞTUR' : 'GENERATE PROPOSAL'}
           </button>
        </div>
      </div>

      {/* PREVIEW SIDE */}
      <div className="lg:w-[450px] bg-slate-50 dark:bg-slate-950 p-8 lg:p-12 flex flex-col justify-center items-center text-center">
         {!showPreview ? (
           <div className="space-y-6 max-w-xs">
              <div className="w-20 h-20 bg-slate-200 dark:bg-slate-800 rounded-full mx-auto flex items-center justify-center text-slate-400">
                 <Zap size={32} />
              </div>
              <h3 className="text-xl font-black text-slate-900 dark:text-white">AI Assistant Ready</h3>
              <p className="text-xs text-slate-400 font-bold leading-relaxed">
                 {language === 'tr' 
                   ? 'Hizmetlerinizi ekleyin ve AI motorumuzun teklifinizi profesyonel bir taslağa dönüştürmesini bekleyin.' 
                   : 'Add your services and let our AI engine transform your proposal into a professional draft.'}
              </p>
           </div>
         ) : (
           <div className="w-full space-y-8 animate-in zoom-in-95 duration-500">
              <div className="p-8 bg-white dark:bg-slate-900 rounded-[40px] shadow-2xl border border-slate-100 dark:border-slate-800 text-left relative overflow-hidden">
                 <div className="absolute top-0 left-0 w-full h-2 bg-indigo-600"></div>
                 <div className="flex justify-between items-start mb-12">
                    <div className="font-black italic text-xl">PanimoCloud</div>
                    <div className="text-[10px] font-black text-slate-400">PROPOSAL #2024-001</div>
                 </div>
                 
                 <div className="mb-12">
                    <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest">PREPARED FOR</p>
                    <h4 className="text-2xl font-black text-slate-900 dark:text-white mt-1">{client}</h4>
                 </div>

                 <div className="space-y-4 mb-12">
                    {items.map(item => (
                      <div key={item.id} className="flex justify-between border-b border-slate-50 dark:border-slate-800 pb-2">
                         <div className="text-xs font-bold text-slate-700 dark:text-slate-300">{item.name}</div>
                         <div className="text-xs font-black text-slate-900 dark:text-white">${item.price}</div>
                      </div>
                    ))}
                    <div className="flex justify-between pt-4">
                       <div className="text-xs font-black text-indigo-600 uppercase tracking-widest">TOTAL</div>
                       <div className="text-xl font-black text-slate-900 dark:text-white">${total}</div>
                    </div>
                 </div>

                 <div className="flex items-center gap-2 text-emerald-500 font-black text-[10px] uppercase">
                    <CheckCircle2 size={14} /> Ready to send
                 </div>
              </div>

              <div className="flex flex-col gap-3">
                 <button className="w-full py-4 bg-indigo-600 text-white rounded-2xl text-xs font-black uppercase tracking-widest flex items-center justify-center gap-2 hover:bg-indigo-700 transition-all">
                    <Send size={16} /> {language === 'tr' ? 'MÜŞTERİYE GÖNDER' : 'SEND TO CLIENT'}
                 </button>
                 <button className="w-full py-4 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 text-slate-600 dark:text-slate-300 rounded-2xl text-xs font-black uppercase tracking-widest flex items-center justify-center gap-2 hover:bg-slate-50 transition-all">
                    <Download size={16} /> {language === 'tr' ? 'PDF OLARAK İNDİR' : 'DOWNLOAD PDF'}
                 </button>
              </div>
           </div>
         )}
      </div>
    </div>
  );
};

export default ProposalGenerator;
