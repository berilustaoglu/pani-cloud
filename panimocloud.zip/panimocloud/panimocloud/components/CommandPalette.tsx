import React, { useEffect, useMemo, useRef, useState } from 'react';
import { createPortal } from 'react-dom';
import { Search, CornerDownLeft, Briefcase, ListChecks, Users, Handshake, FileText, Package, LifeBuoy, UserCircle2, Command, ArrowRight } from 'lucide-react';
import { Project, Task, User, Customer, Deal, Invoice, InventoryItem, Ticket } from '../types';

export interface PaletteNavItem { tab: string; label: string; section: string; icon: React.ReactNode }
export interface PaletteAction { id: string; label: string; hint?: string; icon: React.ReactNode; run: () => void }

interface Props {
  open: boolean;
  onClose: () => void;
  language: 'tr' | 'en';
  navItems: PaletteNavItem[];
  actions: PaletteAction[];
  onNavigate: (tab: string) => void;
  data: {
    projects: Project[]; tasks: Task[]; users: User[]; customers: Customer[]; deals: Deal[];
    invoices: Invoice[]; inventoryItems: InventoryItem[]; tickets: Ticket[];
  };
}

interface Result { id: string; group: string; label: string; sub?: string; icon: React.ReactNode; run: () => void; score: number }

const norm = (s: string) => (s || '').toLocaleLowerCase('tr-TR');
const score = (q: string, ...fields: (string | undefined)[]) => {
  let best = 0;
  for (const f of fields) {
    const v = norm(f || '');
    if (!v) continue;
    if (v.startsWith(q)) best = Math.max(best, 3);
    else if (v.split(/\s+/).some(w => w.startsWith(q))) best = Math.max(best, 2);
    else if (v.includes(q)) best = Math.max(best, 1);
  }
  return best;
};

const CommandPalette: React.FC<Props> = ({ open, onClose, language, navItems, actions, onNavigate, data }) => {
  const tr = language === 'tr';
  const [q, setQ] = useState('');
  const [active, setActive] = useState(0);
  const inputRef = useRef<HTMLInputElement>(null);
  const listRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (open) { setQ(''); setActive(0); setTimeout(() => inputRef.current?.focus(), 30); }
  }, [open]);

  const results = useMemo<Result[]>(() => {
    const query = norm(q.trim());
    const go = (tab: string) => () => { onNavigate(tab); onClose(); };
    const out: Result[] = [];

    navItems.forEach(n => {
      const s = query ? score(query, n.label, n.section) : 1;
      if (s) out.push({ id: `nav-${n.tab}`, group: tr ? 'Sayfalar' : 'Pages', label: n.label, sub: n.section, icon: n.icon, run: go(n.tab), score: s + 0.5 });
    });
    actions.forEach(a => {
      const s = query ? score(query, a.label, a.hint) : 1;
      if (s) out.push({ id: `act-${a.id}`, group: tr ? 'Komutlar' : 'Commands', label: a.label, sub: a.hint, icon: a.icon, run: () => { a.run(); onClose(); }, score: s });
    });

    if (query.length >= 2) {
      const add = (group: string, icon: React.ReactNode, tab: string, items: { id: string; label: string; sub?: string; s: number }[]) =>
        items.filter(i => i.s > 0).slice(0, 6).forEach(i => out.push({ id: `${group}-${i.id}`, group, label: i.label, sub: i.sub, icon, run: go(tab), score: i.s }));

      const allowed = new Set(navItems.map(n => n.tab));
      if (allowed.has('projects')) add(tr ? 'Projeler' : 'Projects', <Briefcase size={16} />, 'projects', data.projects.map(p => ({ id: p.id, label: p.name, sub: `${p.client} · %${p.progress || 0}`, s: score(query, p.name, p.client) })));
      add(tr ? 'Görevler' : 'Tasks', <ListChecks size={16} />, 'tasks', data.tasks.map(t => ({ id: t.id, label: t.title, sub: `${t.status} · ${t.deadline || ''}`, s: score(query, t.title) })));
      if (allowed.has('team')) add(tr ? 'Ekip' : 'Team', <UserCircle2 size={16} />, 'team', data.users.map(u => ({ id: u.id, label: u.name, sub: `${u.jobTitle || u.role} · ${u.email}`, s: score(query, u.name, u.email, u.jobTitle) })));
      if (allowed.has('crm')) add('CRM', <Handshake size={16} />, 'crm', data.deals.map(d => ({ id: d.id, label: d.companyName || d.contactName, sub: `${d.contactName} · ${d.status}`, s: score(query, d.companyName, d.contactName, d.email) })));
      if (allowed.has('customersms') || allowed.has('crm')) add(tr ? 'Müşteriler' : 'Customers', <Users size={16} />, allowed.has('crm') ? 'crm' : 'customersms', data.customers.map(c => ({ id: c.id, label: c.name, sub: [c.company, c.phone].filter(Boolean).join(' · '), s: score(query, c.name, c.company, c.phone, c.email) })));
      if (allowed.has('invoices')) add(tr ? 'Faturalar' : 'Invoices', <FileText size={16} />, 'invoices', data.invoices.map(i => ({ id: i.id, label: `${i.invoiceNumber} · ${i.customerName}`, sub: `${i.date} · ${i.status}`, s: score(query, i.invoiceNumber, i.customerName) })));
      if (allowed.has('inventory')) add(tr ? 'Stok' : 'Inventory', <Package size={16} />, 'inventory', data.inventoryItems.map(i => ({ id: i.id, label: i.name, sub: `SKU ${i.sku} · ${i.currentQuantity}`, s: score(query, i.name, i.sku, i.category) })));
      if (allowed.has('tickets')) add(tr ? 'Talepler' : 'Tickets', <LifeBuoy size={16} />, 'tickets', data.tickets.map(t => ({ id: t.id, label: t.title, sub: `${t.priority} · ${t.status}`, s: score(query, t.title) })));
    }

    // Grup sırası korunarak her grup içinde skora göre sırala
    const groups: string[] = [];
    out.forEach(r => { if (!groups.includes(r.group)) groups.push(r.group); });
    if (query) groups.sort((a, b) => Math.max(...out.filter(r => r.group === b).map(r => r.score)) - Math.max(...out.filter(r => r.group === a).map(r => r.score)));
    return groups.flatMap(g => out.filter(r => r.group === g).sort((a, b) => b.score - a.score).slice(0, query ? 8 : 40));
  }, [q, navItems, actions, data, tr, onNavigate, onClose]);

  useEffect(() => { setActive(0); }, [q]);

  useEffect(() => {
    const el = listRef.current?.querySelector(`[data-idx="${active}"]`) as HTMLElement | null;
    el?.scrollIntoView({ block: 'nearest' });
  }, [active]);

  const onKey = (e: React.KeyboardEvent) => {
    if (e.key === 'ArrowDown') { e.preventDefault(); setActive(a => Math.min(results.length - 1, a + 1)); }
    else if (e.key === 'ArrowUp') { e.preventDefault(); setActive(a => Math.max(0, a - 1)); }
    else if (e.key === 'Enter') { e.preventDefault(); results[active]?.run(); }
    else if (e.key === 'Escape') { e.preventDefault(); onClose(); }
  };

  if (!open || typeof document === 'undefined') return null;

  let lastGroup = '';
  return createPortal(
    <div className="fixed inset-0 z-[9000] flex items-start justify-center px-4 pt-[10vh]" role="dialog" aria-modal="true">
      <div className="absolute inset-0 bg-slate-950/50 backdrop-blur-md pc-backdrop" onClick={onClose} />
      <div className="relative w-full max-w-2xl rounded-[28px] bg-white/95 dark:bg-slate-900/95 border border-slate-200/60 dark:border-white/10 shadow-2xl shadow-indigo-950/40 overflow-hidden pc-pop">
        <div className="flex items-center gap-3 px-5 py-4 border-b border-slate-100 dark:border-white/5">
          <Search size={20} className="text-indigo-500 shrink-0" />
          <input
            ref={inputRef}
            value={q}
            onChange={e => setQ(e.target.value)}
            onKeyDown={onKey}
            placeholder={tr ? 'Sayfa, proje, görev, müşteri, fatura ara veya komut çalıştır…' : 'Search pages, projects, tasks, customers or run a command…'}
            className="pc-plain-input flex-1 outline-none text-base font-semibold text-slate-800 dark:text-white placeholder:text-slate-400"
          />
          <kbd className="hidden sm:inline text-[10px] font-black text-slate-400 border border-slate-200 dark:border-slate-700 rounded-md px-1.5 py-0.5">ESC</kbd>
        </div>
        <div ref={listRef} className="max-h-[55vh] overflow-y-auto custom-scrollbar p-2">
          {results.length === 0 && (
            <div className="py-14 text-center text-slate-400 animate-in fade-in">
              <Search size={28} className="mx-auto mb-2 opacity-50" />
              <p className="text-sm font-bold">{tr ? 'Sonuç bulunamadı' : 'No results'}</p>
            </div>
          )}
          {results.map((r, idx) => {
            const header = r.group !== lastGroup ? r.group : null;
            lastGroup = r.group;
            return (
              <React.Fragment key={r.id}>
                {header && <p className="px-3 pt-3 pb-1 text-[10px] font-black uppercase tracking-[0.2em] text-slate-400">{header}</p>}
                <button
                  data-idx={idx}
                  onMouseMove={() => setActive(idx)}
                  onClick={r.run}
                  className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-xl text-left transition-colors ${idx === active ? 'bg-indigo-600 text-white' : 'text-slate-700 dark:text-slate-200'}`}
                >
                  <span className={`shrink-0 p-1.5 rounded-lg ${idx === active ? 'bg-white/20' : 'bg-slate-100 dark:bg-white/5 text-indigo-500'}`}>{r.icon}</span>
                  <span className="flex-1 min-w-0">
                    <span className="block text-sm font-bold truncate">{r.label}</span>
                    {r.sub && <span className={`block text-[11px] truncate ${idx === active ? 'text-indigo-100' : 'text-slate-400'}`}>{r.sub}</span>}
                  </span>
                  {idx === active ? <CornerDownLeft size={14} className="shrink-0" /> : <ArrowRight size={14} className="shrink-0 opacity-0" />}
                </button>
              </React.Fragment>
            );
          })}
        </div>
        <div className="flex items-center justify-between px-5 py-2.5 border-t border-slate-100 dark:border-white/5 text-[10px] font-bold text-slate-400">
          <span className="flex items-center gap-3"><span>↑↓ {tr ? 'gezin' : 'navigate'}</span><span>↵ {tr ? 'aç' : 'open'}</span></span>
          <span className="flex items-center gap-1"><Command size={11} />K</span>
        </div>
      </div>
    </div>,
    document.body
  );
};

export default CommandPalette;
