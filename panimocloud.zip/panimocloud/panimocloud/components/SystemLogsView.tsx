import React, { useState, useEffect } from 'react';
import { collection, query, orderBy, limit, onSnapshot, where, getDocs } from 'firebase/firestore';
import { db } from '../firebase';
import { AuditLog } from '../types';
import { Activity, ShieldAlert, FileEdit, Trash2, LogIn, Search, Plus, Calendar, Folder, ArrowLeft, Clock } from 'lucide-react';

interface Props {
  language: 'tr' | 'en';
}

const SystemLogsView: React.FC<Props> = ({ language }) => {
  const [recentLogs, setRecentLogs] = useState<AuditLog[]>([]);
  const [loadingRecent, setLoadingRecent] = useState(true);
  
  const [viewMode, setViewMode] = useState<'recent' | 'archive' | 'month-detail'>('recent');
  const [selectedMonth, setSelectedMonth] = useState<{ label: string, start: string, end: string } | null>(null);
  
  const [monthlyLogs, setMonthlyLogs] = useState<AuditLog[]>([]);
  const [loadingMonthly, setLoadingMonthly] = useState(false);
  const [searchTerm, setSearchTerm] = useState('');

  // Fetch recent 10 logs
  useEffect(() => {
    const q = query(collection(db, 'audit_logs'), orderBy('timestamp', 'desc'), limit(10));
    const unsubscribe = onSnapshot(q, (snapshot) => {
      const logsData = snapshot.docs.map(doc => ({ ...doc.data(), id: doc.id } as AuditLog));
      setRecentLogs(logsData);
      setLoadingRecent(false);
    });
    return () => unsubscribe();
  }, []);

  const getActionIcon = (action: string) => {
    switch (action) {
      case 'CREATE': return <Plus size={16} className="text-emerald-500" />;
      case 'UPDATE': return <FileEdit size={16} className="text-blue-500" />;
      case 'DELETE': return <Trash2 size={16} className="text-red-500" />;
      case 'LOGIN': return <LogIn size={16} className="text-indigo-500" />;
      default: return <Activity size={16} className="text-slate-500" />;
    }
  };

  const getActionColor = (action: string) => {
    switch (action) {
      case 'CREATE': return 'bg-emerald-100 text-emerald-700 dark:bg-emerald-900/30 dark:text-emerald-400';
      case 'UPDATE': return 'bg-blue-100 text-blue-700 dark:bg-blue-900/30 dark:text-blue-400';
      case 'DELETE': return 'bg-red-100 text-red-700 dark:bg-red-900/30 dark:text-red-400';
      case 'LOGIN': return 'bg-indigo-100 text-indigo-700 dark:bg-indigo-900/30 dark:text-indigo-400';
      default: return 'bg-slate-100 text-slate-700 dark:bg-slate-800 dark:text-slate-400';
    }
  };

  // Generate last 12 months
  const generateMonths = () => {
    const months = [];
    const now = new Date();
    const formatter = new Intl.DateTimeFormat(language === 'tr' ? 'tr-TR' : 'en-US', { month: 'long', year: 'numeric' });
    
    for (let i = 0; i < 12; i++) {
      const d = new Date(now.getFullYear(), now.getMonth() - i, 1);
      const year = d.getFullYear();
      const month = String(d.getMonth() + 1).padStart(2, '0');
      
      const start = `${year}-${month}-01T00:00:00.000Z`;
      // Calculate end of month
      const endD = new Date(year, d.getMonth() + 1, 0, 23, 59, 59, 999);
      const endStr = endD.toISOString();

      months.push({
        id: `${year}-${month}`,
        label: formatter.format(d),
        start,
        end: endStr
      });
    }
    return months;
  };

  const months = generateMonths();

  const handleMonthSelect = async (month: { label: string, start: string, end: string }) => {
    setSelectedMonth(month);
    setViewMode('month-detail');
    setLoadingMonthly(true);
    setSearchTerm('');

    try {
      const q = query(
        collection(db, 'audit_logs'),
        where('timestamp', '>=', month.start),
        where('timestamp', '<=', month.end),
        orderBy('timestamp', 'desc')
      );
      const snapshot = await getDocs(q);
      const logsData = snapshot.docs.map(doc => ({ ...doc.data(), id: doc.id } as AuditLog));
      setMonthlyLogs(logsData);
    } catch (error) {
      console.error("Error fetching monthly logs:", error);
      // Fallback without orderBy if composite index is missing
      try {
        const qNoOrder = query(
          collection(db, 'audit_logs'),
          where('timestamp', '>=', month.start),
          where('timestamp', '<=', month.end)
        );
        const snapshotNoOrder = await getDocs(qNoOrder);
        const logsData = snapshotNoOrder.docs.map(doc => ({ ...doc.data(), id: doc.id } as AuditLog));
        logsData.sort((a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime());
        setMonthlyLogs(logsData);
      } catch (err2) {
        console.error("Fallback error:", err2);
      }
    } finally {
      setLoadingMonthly(false);
    }
  };

  const logsToDisplay = viewMode === 'month-detail' ? monthlyLogs : recentLogs;
  const filteredLogs = logsToDisplay.filter(log => 
    log.userName.toLowerCase().includes(searchTerm.toLowerCase()) ||
    log.details.toLowerCase().includes(searchTerm.toLowerCase()) ||
    log.entityType.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const renderLogTable = (logs: AuditLog[], isLoading: boolean) => (
    <div className="bg-white dark:bg-slate-900 rounded-[32px] border border-slate-100 dark:border-slate-800 shadow-sm overflow-hidden mt-6 animate-in fade-in slide-in-from-bottom-4 duration-500">
      {isLoading ? (
        <div className="p-12 text-center text-slate-400 font-bold animate-pulse">
          {language === 'tr' ? 'Kayıtlar yükleniyor...' : 'Loading logs...'}
        </div>
      ) : logs.length === 0 ? (
        <div className="p-12 text-center text-slate-400 font-bold">
          {language === 'tr' ? 'Kayıt bulunamadı.' : 'No logs found.'}
        </div>
      ) : (
        <div className="overflow-x-auto custom-scrollbar">
          <table className="w-full text-left text-sm">
            <thead className="bg-slate-50 dark:bg-slate-800/50 text-slate-500 dark:text-slate-400 font-bold border-b border-slate-100 dark:border-slate-800">
              <tr>
                <th className="p-6">{language === 'tr' ? 'Zaman' : 'Time'}</th>
                <th className="p-6">{language === 'tr' ? 'Kullanıcı' : 'User'}</th>
                <th className="p-6">{language === 'tr' ? 'İşlem' : 'Action'}</th>
                <th className="p-6">{language === 'tr' ? 'Modül' : 'Module'}</th>
                <th className="p-6">{language === 'tr' ? 'Detay' : 'Details'}</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
              {logs.map(log => (
                <tr key={log.id} className="hover:bg-slate-50 dark:hover:bg-slate-800/30 transition-colors">
                  <td className="p-6 whitespace-nowrap text-slate-500 dark:text-slate-400 font-medium">
                    {new Date(log.timestamp).toLocaleString(language === 'tr' ? 'tr-TR' : 'en-US')}
                  </td>
                  <td className="p-6 font-bold text-slate-900 dark:text-white">
                    {log.userName}
                  </td>
                  <td className="p-6">
                    <div className={`inline-flex items-center gap-2 px-3 py-1.5 rounded-xl text-xs font-black tracking-widest ${getActionColor(log.action)}`}>
                      {getActionIcon(log.action)}
                      {log.action}
                    </div>
                  </td>
                  <td className="p-6 font-bold text-slate-600 dark:text-slate-300">
                    {log.entityType}
                  </td>
                  <td className="p-6 text-slate-600 dark:text-slate-300 font-medium max-w-md truncate" title={log.details}>
                    {log.details}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );

  return (
    <div className="p-8 lg:p-12 max-w-7xl mx-auto space-y-8 animate-in fade-in duration-500 font-sans">
      <div className="flex flex-col md:flex-row md:items-end justify-between gap-6">
        <div>
          <div className="flex items-center gap-3 mb-2">
            <div className="w-10 h-10 bg-indigo-600 rounded-2xl flex items-center justify-center text-white shadow-lg shadow-indigo-200 dark:shadow-none">
              <ShieldAlert size={20} />
            </div>
            <span className="text-[10px] font-black uppercase tracking-[0.3em] text-indigo-600 dark:text-indigo-400">
              {language === 'tr' ? 'Güvenlik & Denetim' : 'Security & Audit'}
            </span>
          </div>
          <h2 className="text-4xl font-black text-slate-900 dark:text-white tracking-tighter italic">
            {language === 'tr' ? 'Sistem Kayıtları' : 'System Logs'}
          </h2>
          <p className="text-slate-500 dark:text-slate-400 mt-2 font-medium max-w-xl leading-relaxed">
            {language === 'tr' ? 'Son işlemleri hızlıca görüntüleyin veya geçmişe dönük arşiv dosyalarını inceleyin.' : 'Quickly view recent actions or browse historical archive files.'}
          </p>
        </div>
        
        <div className="flex items-center gap-3 bg-white dark:bg-slate-900 p-2 rounded-[24px] border border-slate-200 dark:border-slate-800 shadow-sm">
          <button 
            onClick={() => setViewMode('recent')}
            className={`px-6 py-3 rounded-[16px] text-xs font-black uppercase tracking-widest transition-all flex items-center gap-2 ${viewMode === 'recent' ? 'bg-slate-900 text-white dark:bg-white dark:text-slate-900' : 'text-slate-500 hover:bg-slate-50 dark:hover:bg-slate-800'}`}
          >
            <Clock size={16} /> {language === 'tr' ? 'Son İşlemler' : 'Recent'}
          </button>
          <button 
            onClick={() => setViewMode('archive')}
            className={`px-6 py-3 rounded-[16px] text-xs font-black uppercase tracking-widest transition-all flex items-center gap-2 ${viewMode !== 'recent' ? 'bg-slate-900 text-white dark:bg-white dark:text-slate-900' : 'text-slate-500 hover:bg-slate-50 dark:hover:bg-slate-800'}`}
          >
            <Calendar size={16} /> {language === 'tr' ? 'Aylık Arşiv' : 'Monthly Archive'}
          </button>
        </div>
      </div>

      {viewMode === 'recent' && (
        <div className="animate-in fade-in slide-in-from-bottom-4 duration-500">
          <div className="flex items-center justify-between mb-2 px-2">
            <h3 className="text-lg font-black text-slate-900 dark:text-white flex items-center gap-2">
              <Activity size={18} className="text-indigo-500" />
              {language === 'tr' ? 'Son 10 İşlem' : 'Last 10 Operations'}
            </h3>
            
            <div className="relative">
              <Search size={16} className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400" />
              <input
                type="text"
                placeholder={language === 'tr' ? 'Ara...' : 'Search...'}
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="w-full md:w-64 pl-12 pr-4 py-2.5 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl text-xs font-bold focus:ring-2 focus:ring-indigo-500/20 outline-none transition-all"
              />
            </div>
          </div>
          {renderLogTable(filteredLogs, loadingRecent)}
        </div>
      )}

      {viewMode === 'archive' && (
        <div className="animate-in fade-in zoom-in-95 duration-500 mt-8">
          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
            {months.map((month) => (
              <button 
                key={month.id}
                onClick={() => handleMonthSelect(month)}
                className="bg-white dark:bg-slate-900 p-8 rounded-[32px] border border-slate-100 dark:border-slate-800 shadow-sm hover:shadow-xl hover:-translate-y-1 hover:border-indigo-300 dark:hover:border-indigo-700 transition-all group flex flex-col items-center justify-center gap-4 relative overflow-hidden"
              >
                <div className="absolute inset-0 bg-indigo-500/5 dark:bg-indigo-500/10 opacity-0 group-hover:opacity-100 transition-opacity"></div>
                <div className="w-16 h-16 bg-slate-50 dark:bg-slate-800 group-hover:bg-indigo-100 dark:group-hover:bg-indigo-900/50 rounded-2xl flex items-center justify-center text-slate-400 group-hover:text-indigo-600 transition-colors z-10">
                  <Folder size={32} />
                </div>
                <div className="text-center z-10">
                  <p className="font-black text-slate-900 dark:text-white capitalize">{month.label.split(' ')[0]}</p>
                  <p className="text-[10px] font-black uppercase tracking-widest text-slate-400 mt-1">{month.label.split(' ')[1]}</p>
                </div>
              </button>
            ))}
          </div>
        </div>
      )}

      {viewMode === 'month-detail' && selectedMonth && (
        <div className="animate-in fade-in slide-in-from-right-8 duration-500">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-4 px-2">
            <div className="flex items-center gap-4">
              <button 
                onClick={() => setViewMode('archive')}
                className="w-10 h-10 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl flex items-center justify-center text-slate-500 hover:text-indigo-600 hover:border-indigo-500 transition-all"
              >
                <ArrowLeft size={18} />
              </button>
              <div>
                <h3 className="text-xl font-black text-slate-900 dark:text-white capitalize">{selectedMonth.label}</h3>
                <p className="text-[10px] font-black uppercase tracking-widest text-slate-500">
                  {language === 'tr' ? 'AYLIK ARŞİV DOSYASI' : 'MONTHLY ARCHIVE FILE'}
                </p>
              </div>
            </div>
            
            <div className="relative">
              <Search size={16} className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400" />
              <input
                type="text"
                placeholder={language === 'tr' ? 'Bu ayda ara...' : 'Search this month...'}
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="w-full md:w-64 pl-12 pr-4 py-2.5 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl text-xs font-bold focus:ring-2 focus:ring-indigo-500/20 outline-none transition-all"
              />
            </div>
          </div>
          
          {renderLogTable(filteredLogs, loadingMonthly)}
        </div>
      )}
    </div>
  );
};

export default SystemLogsView;
