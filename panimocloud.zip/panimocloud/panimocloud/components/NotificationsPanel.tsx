import React, { useEffect, useMemo, useState } from 'react';
import { X, Bell, Calendar, Clock, AlertTriangle, CheckCircle2, Briefcase, UserCheck, Info, BellRing, BellOff, Smartphone, Share, CheckCheck, Loader2, ChevronRight, Settings2 } from 'lucide-react';
import { AttendanceRecord, LeaveRequest, Project, Task, User, TaskStatus, SystemNotification } from '../types';
import { getPushStatus, enablePushNotifications, PushStatus } from '../firebase';
import ModalPortal from './ModalPortal';
import { toast } from '../services/toast';
import { suspendedProjectIds } from '../services/insights';

interface Props {
  onClose: () => void;
  attendance: AttendanceRecord[];
  leaveRequests: LeaveRequest[];
  projects: Project[];
  tasks: Task[];
  currentUser: User;
  language: 'tr' | 'en';
  onNavigate: (tab: string, param?: string) => void;
  /** Bu kullanıcıya görünür sistem bildirimleri (App filtreler) */
  systemNotifications?: SystemNotification[];
  onMarkRead?: (ids: string[]) => Promise<void> | void;
  onUpdateUser?: (u: User) => Promise<void> | void;
}

type Reminder = { id: string; tone: 'warning' | 'info' | 'success' | 'error'; icon: React.ElementType; title: string; description: string; tab?: string };

const TONE: Record<string, { icon: React.ElementType; chip: string; dot: string }> = {
  success: { icon: CheckCircle2, chip: 'bg-emerald-50 text-emerald-600 dark:bg-emerald-500/10 dark:text-emerald-300', dot: 'bg-emerald-500' },
  warning: { icon: AlertTriangle, chip: 'bg-amber-50 text-amber-600 dark:bg-amber-500/10 dark:text-amber-300', dot: 'bg-amber-500' },
  error: { icon: AlertTriangle, chip: 'bg-rose-50 text-rose-600 dark:bg-rose-500/10 dark:text-rose-300', dot: 'bg-rose-500' },
  info: { icon: Info, chip: 'bg-indigo-50 text-indigo-600 dark:bg-indigo-500/10 dark:text-indigo-300', dot: 'bg-indigo-500' },
};

const NotificationsPanel: React.FC<Props> = ({ onClose, attendance, leaveRequests, projects, tasks, currentUser, language, onNavigate, systemNotifications = [], onMarkRead, onUpdateUser }) => {
  const tr = language === 'tr';
  const [tab, setTab] = useState<'inbox' | 'reminders'>('inbox');
  const [onlyUnread, setOnlyUnread] = useState(false);
  const [push, setPush] = useState<PushStatus | null>(null);
  const [pushBusy, setPushBusy] = useState(false);
  const [showPrefs, setShowPrefs] = useState(false);
  const canManage = currentUser.role === 'Admin' || currentUser.role === 'Manager';

  useEffect(() => { getPushStatus().then(setPush).catch(() => setPush('unsupported')); }, []);
  useEffect(() => { const k = (e: KeyboardEvent) => { if (e.key === 'Escape') onClose(); }; window.addEventListener('keydown', k); return () => window.removeEventListener('keydown', k); }, [onClose]);

  const isUnread = (n: SystemNotification) => !n.readBy?.includes(currentUser.id) && n.createdBy !== currentUser.id;
  const inbox = useMemo(() => [...systemNotifications].sort((a, b) => (b.createdAt || '').localeCompare(a.createdAt || '')), [systemNotifications]);
  const unread = inbox.filter(isUnread);
  const visible = onlyUnread ? unread : inbox;

  const groups = useMemo(() => {
    const today = new Date(); const y = new Date(); y.setDate(y.getDate() - 1);
    const label = (iso: string) => { const d = new Date(iso); if (d.toDateString() === today.toDateString()) return tr ? 'Bugün' : 'Today'; if (d.toDateString() === y.toDateString()) return tr ? 'Dün' : 'Yesterday'; return d.toLocaleDateString(tr ? 'tr-TR' : 'en-US', { day: 'numeric', month: 'long' }); };
    const m = new Map<string, SystemNotification[]>();
    visible.forEach(n => { const k = label(n.createdAt); m.set(k, [...(m.get(k) || []), n]); });
    return [...m.entries()];
  }, [visible, tr]);

  // ---------- Hatırlatmalar (anlık durumdan hesaplanır) ----------
  const reminders = useMemo<Reminder[]>(() => {
    const r: Reminder[] = [];
    const now = new Date(); const todayStr = `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, '0')}-${String(now.getDate()).padStart(2, '0')}`;
    if (canManage) {
      const pending = leaveRequests.filter(l => l.status === 'Pending');
      if (pending.length) r.push({ id: 'leaves', tone: 'warning', icon: Calendar, tab: 'leave', title: tr ? `${pending.length} izin talebi onay bekliyor` : `${pending.length} leave requests pending`, description: pending.map(l => l.userName).slice(0, 3).join(', ') + (pending.length > 3 ? (tr ? ` ve ${pending.length - 3} kişi` : ` +${pending.length - 3}`) : '') });
    }
    projects.filter(p => p.status === 'Active' && p.deliveryDate && (canManage || p.projectManagerId === currentUser.id || p.teamMemberIds?.includes(currentUser.id))).forEach(p => {
      const d = Math.ceil((new Date(p.deliveryDate + 'T23:59').getTime() - now.getTime()) / 86400000);
      if (d >= 0 && d <= 3) r.push({ id: `proj-${p.id}`, tone: d === 0 ? 'error' : 'warning', icon: Briefcase, tab: 'projects', title: tr ? `Teslim yaklaşıyor: ${p.name}` : `Delivery soon: ${p.name}`, description: d === 0 ? (tr ? 'Bugün teslim edilmeli' : 'Due today') : (tr ? `${d} gün kaldı · ${p.client}` : `${d} days left`) });
    });
    const held = suspendedProjectIds(projects);
    const overdue = tasks.filter(t => t.assignedTo?.includes(currentUser.id) && t.status !== TaskStatus.DONE && t.deadline && t.deadline < todayStr && !held.has(t.projectId));
    if (overdue.length) r.push({ id: 'overdue', tone: 'error', icon: AlertTriangle, tab: 'mytasks', title: tr ? `${overdue.length} göreviniz gecikmiş` : `${overdue.length} overdue tasks`, description: overdue.slice(0, 2).map(t => t.title).join(', ') });
    const dueToday = tasks.filter(t => t.assignedTo?.includes(currentUser.id) && t.status !== TaskStatus.DONE && t.deadline === todayStr && !held.has(t.projectId));
    if (dueToday.length) r.push({ id: 'today', tone: 'info', icon: Clock, tab: 'mytasks', title: tr ? `Bugün teslim: ${dueToday.length} görev` : `${dueToday.length} tasks due today`, description: dueToday.slice(0, 2).map(t => t.title).join(', ') });
    const mine = leaveRequests.find(l => l.userId === currentUser.id && l.status === 'Pending');
    if (mine) r.push({ id: 'my-leave', tone: 'info', icon: Calendar, tab: 'leave', title: tr ? 'İzin talebiniz inceleniyor' : 'Leave request under review', description: `${mine.startDate} → ${mine.endDate}` });
    const session = attendance.find(a => a.userId === currentUser.id && !a.clockOut && a.date === todayStr);
    if (session) r.push({ id: 'session', tone: 'success', icon: UserCheck, tab: 'attendance', title: tr ? 'Mesainiz devam ediyor' : 'Shift in progress', description: `${tr ? 'Giriş' : 'In'} ${session.clockIn}` });
    return r;
  }, [attendance, leaveRequests, projects, tasks, currentUser, canManage, tr]);

  const open = (n: SystemNotification) => {
    if (isUnread(n)) onMarkRead?.([n.id]);
    if (n.tab) { onNavigate(n.tab); onClose(); }
  };
  const timeOf = (iso: string) => {
    const mins = Math.round((Date.now() - new Date(iso).getTime()) / 60000);
    if (mins < 1) return tr ? 'şimdi' : 'now';
    if (mins < 60) return tr ? `${mins} dk önce` : `${mins}m ago`;
    return new Date(iso).toLocaleTimeString(tr ? 'tr-TR' : 'en-US', { hour: '2-digit', minute: '2-digit' });
  };

  const enable = async () => {
    setPushBusy(true);
    try {
      const s = await enablePushNotifications(currentUser.id);
      setPush(s);
      if (s === 'granted') toast.success(tr ? 'Bu cihazda bildirimler açıldı' : 'Notifications enabled');
      else if (s === 'denied') toast.warning(tr ? 'Bildirim izni reddedildi' : 'Permission denied');
    } catch (e) { console.error(e); toast.error(tr ? 'Bildirimler açılamadı' : 'Could not enable'); } finally { setPushBusy(false); }
  };
  const testLocal = async () => {
    try { const reg = await navigator.serviceWorker.ready; await reg.showNotification('PanimoCloud', { body: tr ? 'Bu cihazda bildirimler çalışıyor ✅' : 'Notifications work on this device ✅', icon: 'https://i.imgur.com/bhZymBT.png' }); }
    catch { toast.error(tr ? 'Deneme bildirimi gösterilemedi' : 'Test failed'); }
  };
  const prefs = currentUser.notificationPrefs || {};
  const setPref = async (k: 'chat' | 'system' | 'staffOnline', v: boolean) => {
    if (!onUpdateUser) return;
    await onUpdateUser({ ...currentUser, notificationPrefs: { ...prefs, [k]: v } });
    toast(tr ? 'Bildirim tercihi kaydedildi' : 'Saved', 'info', 1800);
  };

  const pushCard = () => {
    if (push === null || push === 'unsupported') return null;
    const base = 'mx-4 mt-3 rounded-2xl p-3 flex items-start gap-3 text-xs';
    if (push === 'ios-needs-install') return (
      <div className={`${base} bg-sky-50 dark:bg-sky-500/10 text-sky-800 dark:text-sky-200`}><Smartphone size={18} className="shrink-0 mt-0.5" /><div><p className="font-semibold">{tr ? "iPhone'da bildirim almak için" : 'To get notifications on iPhone'}</p><p className="mt-0.5 opacity-80">{tr ? <>Safari'de <Share size={11} className="inline -mt-0.5" /> Paylaş → <b>Ana Ekrana Ekle</b> yapın, uygulamayı ana ekrandan açıp buradan bildirimleri açın.</> : <>Tap Share → Add to Home Screen, open the app from there and enable notifications.</>}</p></div></div>
    );
    if (push === 'denied') return (
      <div className={`${base} bg-amber-50 dark:bg-amber-500/10 text-amber-800 dark:text-amber-200`}><BellOff size={18} className="shrink-0 mt-0.5" /><div><p className="font-semibold">{tr ? 'Bildirim izni kapalı' : 'Notifications blocked'}</p><p className="mt-0.5 opacity-80">{tr ? 'Tarayıcı veya telefon ayarlarından bu site için bildirim iznini açın, sonra sayfayı yenileyin.' : 'Allow notifications for this site in settings, then reload.'}</p></div></div>
    );
    if (push === 'default') return (
      <div className={`${base} bg-indigo-50 dark:bg-indigo-500/10 text-indigo-900 dark:text-indigo-100`}><BellRing size={18} className="shrink-0 mt-0.5 text-indigo-600" /><div className="flex-1"><p className="font-semibold">{tr ? 'Uygulama kapalıyken de haberdar olun' : 'Get notified when the app is closed'}</p><p className="mt-0.5 opacity-80">{tr ? 'Mesajlar, onaylar ve size atanan işler bu cihaza bildirim olarak gelsin.' : 'Messages, approvals and assignments.'}</p>
        <button onClick={enable} disabled={pushBusy} className="mt-2 h-8 px-3 rounded-lg bg-indigo-600 hover:bg-indigo-500 text-white font-semibold inline-flex items-center gap-1.5 disabled:opacity-60">{pushBusy ? <Loader2 size={13} className="animate-spin" /> : <Bell size={13} />}{tr ? 'Bildirimleri aç' : 'Enable'}</button></div></div>
    );
    return null;
  };

  return (
    <ModalPortal>
      <div className="fixed inset-0 z-[1050] flex justify-end" role="dialog" aria-modal="true">
        <div className="absolute inset-0 bg-slate-950/40 backdrop-blur-[2px] pc-backdrop" onClick={onClose} />
        <aside className="relative h-full w-full max-w-[400px] bg-white dark:bg-slate-900 border-l border-slate-100 dark:border-slate-800 shadow-2xl flex flex-col animate-in slide-in-from-right duration-300" style={{ paddingTop: 'env(safe-area-inset-top, 0px)', paddingBottom: 'env(safe-area-inset-bottom, 0px)' }}>
          <div className="px-4 pt-4 pb-3 flex items-center gap-3 border-b border-slate-100 dark:border-slate-800">
            <span className="w-10 h-10 rounded-xl bg-gradient-to-br from-indigo-500 to-violet-600 text-white flex items-center justify-center shadow-md"><Bell size={18} /></span>
            <div className="flex-1 min-w-0"><h2 className="font-bold text-slate-900 dark:text-white">{tr ? 'Bildirimler' : 'Notifications'}</h2><p className="text-[11px] text-slate-400">{unread.length ? (tr ? `${unread.length} okunmamış` : `${unread.length} unread`) : (tr ? 'Hepsi okundu' : 'All caught up')}</p></div>
            {push === 'granted' && <button onClick={() => setShowPrefs(!showPrefs)} title={tr ? 'Bildirim tercihleri' : 'Preferences'} className={`p-2 rounded-xl ${showPrefs ? 'bg-indigo-50 text-indigo-600 dark:bg-indigo-500/10' : 'text-slate-400 hover:bg-slate-100 dark:hover:bg-white/5'}`}><Settings2 size={17} /></button>}
            <button onClick={onClose} className="p-2 rounded-xl text-slate-400 hover:text-slate-700 hover:bg-slate-100 dark:hover:bg-white/5" aria-label="Close"><X size={18} /></button>
          </div>

          {pushCard()}
          {showPrefs && push === 'granted' && (
            <div className="mx-4 mt-3 rounded-2xl border border-slate-100 dark:border-slate-800 p-3 space-y-2 animate-in fade-in slide-in-from-top-1 duration-200">
              <p className="text-[11px] font-semibold text-slate-500">{tr ? 'Bu hesap için push bildirimleri' : 'Push for this account'}</p>
              {([['chat', tr ? 'Mesajlar ve duyurular' : 'Messages', prefs.chat !== false], ['system', tr ? 'Onaylar, talepler, atamalar' : 'Approvals & requests', prefs.system !== false], ...(canManage ? [['staffOnline', tr ? 'Personel çevrim içi oldu' : 'Staff came online', prefs.staffOnline === true]] : [])] as [any, string, boolean][]).map(([k, l, on]) => (
                <button key={k} onClick={() => setPref(k, !on)} className="w-full flex items-center justify-between text-sm text-slate-700 dark:text-slate-200">
                  {l}<span className={`w-9 h-5 rounded-full p-0.5 transition-colors ${on ? 'bg-indigo-600' : 'bg-slate-200 dark:bg-slate-700'}`}><span className={`block w-4 h-4 rounded-full bg-white shadow transition-transform ${on ? 'translate-x-4' : ''}`} /></span>
                </button>
              ))}
              <button onClick={testLocal} className="text-[11px] font-semibold text-indigo-600 hover:underline">{tr ? 'Bu cihazda deneme bildirimi göster' : 'Show a test notification'}</button>
            </div>
          )}

          <div className="px-4 pt-3 flex items-center gap-2">
            <div className="flex bg-slate-100 dark:bg-slate-800 rounded-xl p-1 flex-1">
              {([['inbox', tr ? 'Bildirimler' : 'Inbox', unread.length], ['reminders', tr ? 'Hatırlatmalar' : 'Reminders', reminders.length]] as const).map(([k, l, c]) => (
                <button key={k} onClick={() => setTab(k)} className={`flex-1 h-8 rounded-lg text-xs font-semibold inline-flex items-center justify-center gap-1.5 transition-all ${tab === k ? 'bg-white dark:bg-slate-900 text-indigo-600 shadow-sm' : 'text-slate-500'}`}>{l}{c > 0 && <span className={`text-[10px] min-w-[16px] h-4 px-1 rounded-full flex items-center justify-center ${tab === k ? 'bg-indigo-600 text-white' : 'bg-slate-300 dark:bg-slate-700 text-slate-700 dark:text-slate-200'}`}>{c}</span>}</button>
              ))}
            </div>
          </div>
          {tab === 'inbox' && inbox.length > 0 && (
            <div className="px-4 pt-2 flex items-center justify-between text-[11px]">
              <button onClick={() => setOnlyUnread(!onlyUnread)} className={`font-semibold ${onlyUnread ? 'text-indigo-600' : 'text-slate-500 hover:text-slate-700'}`}>{onlyUnread ? (tr ? '✓ Yalnızca okunmamış' : '✓ Unread only') : (tr ? 'Yalnızca okunmamış' : 'Unread only')}</button>
              {unread.length > 0 && onMarkRead && <button onClick={() => onMarkRead(unread.map(n => n.id))} className="font-semibold text-indigo-600 hover:underline inline-flex items-center gap-1"><CheckCheck size={12} />{tr ? 'Tümünü okundu say' : 'Mark all read'}</button>}
            </div>
          )}

          <div key={tab} className="flex-1 overflow-y-auto custom-scrollbar px-3 py-3 animate-in fade-in duration-200">
            {tab === 'inbox' ? (visible.length === 0 ? (
              <div className="h-full flex flex-col items-center justify-center text-center gap-2 text-slate-400 px-6"><CheckCircle2 size={36} className="opacity-40" /><p className="text-sm font-semibold">{onlyUnread ? (tr ? 'Okunmamış bildirim yok' : 'No unread') : (tr ? 'Henüz bildirim yok' : 'No notifications yet')}</p><p className="text-xs">{tr ? 'Onaylar, talepler ve size atanan işler burada görünür.' : 'Approvals and assignments appear here.'}</p></div>
            ) : groups.map(([day, list]) => (
              <div key={day} className="mb-3">
                <p className="px-2 mb-1 text-[11px] font-semibold text-slate-400">{day}</p>
                {list.map(n => { const T = TONE[n.type] || TONE.info; const I = T.icon; const un = isUnread(n); return (
                  <button key={n.id} onClick={() => open(n)} className={`w-full text-left flex items-start gap-3 px-2.5 py-2.5 rounded-xl transition-colors ${un ? 'bg-indigo-50/60 dark:bg-indigo-500/[0.07]' : ''} hover:bg-slate-100/70 dark:hover:bg-white/5`}>
                    <span className={`w-8 h-8 shrink-0 rounded-lg flex items-center justify-center ${T.chip}`}><I size={15} /></span>
                    <span className="flex-1 min-w-0">
                      <span className="flex items-center gap-1.5"><span className={`text-sm truncate ${un ? 'font-bold text-slate-900 dark:text-white' : 'font-semibold text-slate-700 dark:text-slate-200'}`}>{n.title}</span>{un && <span className={`w-1.5 h-1.5 rounded-full shrink-0 ${T.dot}`} />}</span>
                      {n.description && <span className="block text-xs text-slate-500 dark:text-slate-400 line-clamp-2 mt-0.5">{n.description}</span>}
                      <span className="block text-[10px] text-slate-400 mt-0.5">{timeOf(n.createdAt)}</span>
                    </span>
                    {n.tab && <ChevronRight size={14} className="shrink-0 mt-2 text-slate-300" />}
                  </button>); })}
              </div>
            ))) : (reminders.length === 0 ? (
              <div className="h-full flex flex-col items-center justify-center text-center gap-2 text-slate-400"><CheckCircle2 size={36} className="opacity-40" /><p className="text-sm font-semibold">{tr ? 'Bekleyen bir şey yok 🎉' : 'Nothing pending 🎉'}</p></div>
            ) : (
              <div className="space-y-1.5">
                {reminders.map(r => { const T = TONE[r.tone]; const I = r.icon; return (
                  <button key={r.id} onClick={() => { if (r.tab) { onNavigate(r.tab); onClose(); } }} className="w-full text-left flex items-start gap-3 px-2.5 py-2.5 rounded-xl hover:bg-slate-100/70 dark:hover:bg-white/5">
                    <span className={`w-8 h-8 shrink-0 rounded-lg flex items-center justify-center ${T.chip}`}><I size={15} /></span>
                    <span className="flex-1 min-w-0"><span className="block text-sm font-semibold text-slate-800 dark:text-slate-100">{r.title}</span><span className="block text-xs text-slate-500 dark:text-slate-400 truncate">{r.description}</span></span>
                    <ChevronRight size={14} className="shrink-0 mt-2 text-slate-300" />
                  </button>); })}
              </div>
            ))}
          </div>
        </aside>
      </div>
    </ModalPortal>
  );
};

export default NotificationsPanel;
