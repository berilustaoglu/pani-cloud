import React, { useEffect, useRef, useState } from 'react';

const prefersReducedMotion = () =>
  typeof window !== 'undefined' && window.matchMedia?.('(prefers-reduced-motion: reduce)').matches;

/** Değer değiştiğinde yumuşakça sayan sayı. */
export const AnimatedNumber: React.FC<{
  value: number;
  duration?: number;
  format?: (n: number) => string;
  className?: string;
}> = ({ value, duration = 1100, format, className }) => {
  const [display, setDisplay] = useState(prefersReducedMotion() ? value : 0);
  const fromRef = useRef(display);

  useEffect(() => {
    if (prefersReducedMotion()) { setDisplay(value); return; }
    const from = fromRef.current;
    const start = performance.now();
    let raf = 0;
    const tick = (now: number) => {
      const p = Math.min(1, (now - start) / duration);
      const eased = 1 - Math.pow(1 - p, 4);
      const current = from + (value - from) * eased;
      fromRef.current = current;
      setDisplay(current);
      if (p < 1) raf = requestAnimationFrame(tick);
    };
    raf = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(raf);
  }, [value, duration]);

  const text = format ? format(display) : Math.round(display).toLocaleString('tr-TR');
  return <span className={`tabular-nums ${className || ''}`}>{text}</span>;
};

/** Animasyonlu dairesel ilerleme halkası. */
export const ProgressRing: React.FC<{
  value: number; // 0-100
  size?: number;
  stroke?: number;
  color?: string;
  track?: string;
  children?: React.ReactNode;
}> = ({ value, size = 120, stroke = 10, color = 'url(#pc-ring-grad)', track = 'rgba(148,163,184,.18)', children }) => {
  const r = (size - stroke) / 2;
  const circ = 2 * Math.PI * r;
  const clamped = Math.max(0, Math.min(100, value));
  const offset = circ - (clamped / 100) * circ;
  return (
    <div className="relative inline-flex items-center justify-center" style={{ width: size, height: size }}>
      <svg width={size} height={size} className="-rotate-90">
        <defs>
          <linearGradient id="pc-ring-grad" x1="0" y1="0" x2="1" y2="1">
            <stop offset="0%" stopColor="#818cf8" />
            <stop offset="100%" stopColor="#f97316" />
          </linearGradient>
        </defs>
        <circle cx={size / 2} cy={size / 2} r={r} fill="none" stroke={track} strokeWidth={stroke} />
        <circle
          cx={size / 2} cy={size / 2} r={r} fill="none" stroke={color} strokeWidth={stroke} strokeLinecap="round"
          strokeDasharray={circ} strokeDashoffset={offset}
          className="pc-draw"
          style={{ ['--pc-circ' as any]: circ, transition: 'stroke-dashoffset 900ms cubic-bezier(.16,1,.3,1)' }}
        />
      </svg>
      <div className="absolute inset-0 flex flex-col items-center justify-center">{children}</div>
    </div>
  );
};

/** Görünür olduğunda dolan yatay çubuk. */
export const GrowBar: React.FC<{ value: number; className?: string; delay?: number }> = ({ value, className = 'bg-indigo-500', delay = 0 }) => (
  <div className="h-2 w-full rounded-full bg-slate-100 dark:bg-white/5 overflow-hidden">
    <div
      className={`h-full rounded-full pc-grow-x ${className}`}
      style={{ width: `${Math.max(0, Math.min(100, value))}%`, animationDelay: `${delay}ms` }}
    />
  </div>
);
