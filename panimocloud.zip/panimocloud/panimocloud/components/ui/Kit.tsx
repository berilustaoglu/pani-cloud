// Yeniden yazılan sayfalarda ortak kullanılan arayüz parçaları
import React, { useEffect, useState } from 'react';
import { X, Save, Loader2, AlertCircle, Search, Trash2 } from 'lucide-react';
import ModalPortal from '../ModalPortal';
import { AnimatedNumber, GrowBar } from './Motion';

export const inputBase = 'w-full h-11 px-3.5 rounded-xl bg-white dark:bg-slate-800 border text-sm font-medium text-slate-900 dark:text-white outline-none transition-all placeholder:text-slate-400 focus:ring-4';
export const inputCls = (err?: string) => `${inputBase} ${err ? 'border-rose-300 focus:border-rose-400 focus:ring-rose-500/10' : 'border-slate-200 dark:border-slate-700 focus:border-indigo-500 focus:ring-indigo-500/10'}`;
export const selectSm = 'h-10 px-3 rounded-xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700 text-xs font-semibold text-slate-700 dark:text-slate-200 outline-none focus:border-indigo-500 cursor-pointer max-w-[220px]';
export const cardCls = 'bg-white dark:bg-slate-900 border border-slate-100 dark:border-slate-800 rounded-[20px]';
export const btnPrimary = 'h-10 px-4 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white text-sm font-semibold inline-flex items-center justify-center gap-2 shadow-lg shadow-indigo-500/25 disabled:opacity-60';
export const btnGhost = 'h-10 px-3 rounded-xl border border-slate-200 dark:border-slate-700 text-slate-600 dark:text-slate-300 text-sm font-semibold inline-flex items-center justify-center gap-2 hover:border-indigo-300 hover:text-indigo-600';

export const PageHeader: React.FC<{ title: string; subtitle?: string; actions?: React.ReactNode }> = ({ title, subtitle, actions }) => (
  <div className="flex flex-col lg:flex-row lg:items-end justify-between gap-4">
    <div>
      <h2 className="text-2xl lg:text-3xl font-black text-slate-900 dark:text-white tracking-tight">{title}</h2>
      {subtitle && <p className="text-sm text-slate-500 dark:text-slate-400">{subtitle}</p>}
    </div>
    {actions && <div className="flex flex-wrap gap-2">{actions}</div>}
  </div>
);

export interface Kpi { label: string; value: number; sub?: string; icon: React.ElementType; grad: string; bar?: number; format?: (n: number) => string; onClick?: () => void; active?: boolean; prefix?: string }
export const KpiGrid: React.FC<{ items: Kpi[]; cols?: string }> = ({ items, cols = 'lg:grid-cols-4' }) => (
  <div className={`grid grid-cols-2 ${cols} gap-3 pc-stagger`}>
    {items.map((k, i) => {
      const Icon = k.icon;
      const odd = items.length % 2 === 1 && i === items.length - 1;
      return (
        <button key={k.label} onClick={k.onClick} className={`text-left ${cardCls} p-4 min-w-0 ${k.onClick ? 'pc-lift' : 'cursor-default'} ${k.active ? '!border-indigo-400 ring-4 ring-indigo-500/10' : ''} ${odd ? 'col-span-2 lg:col-span-1' : ''}`}>
          <div className="flex items-center gap-2.5"><span className={`p-2 rounded-xl bg-gradient-to-br ${k.grad} text-white shadow-md`}><Icon size={16} /></span><span className="text-[11px] font-semibold text-slate-500 dark:text-slate-400 truncate">{k.label}</span></div>
          <p className="text-xl sm:text-2xl font-black text-slate-900 dark:text-white mt-2 truncate">{k.prefix}<AnimatedNumber value={k.value} format={k.format} /></p>
          {k.sub && <p className="text-[11px] text-slate-400 truncate">{k.sub}</p>}
          {k.bar !== undefined && <div className="mt-2.5"><GrowBar value={k.bar} className={`bg-gradient-to-r ${k.grad}`} /></div>}
        </button>
      );
    })}
  </div>
);

export const SearchBox: React.FC<{ value: string; onChange: (v: string) => void; placeholder: string; className?: string }> = ({ value, onChange, placeholder, className = '' }) => (
  <div className={`relative flex-1 ${className}`}>
    <Search size={16} className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
    <input value={value} onChange={e => onChange(e.target.value)} placeholder={placeholder} className="w-full h-10 pl-9 pr-8 rounded-xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700 text-sm outline-none focus:border-indigo-500" />
    {value && <button onClick={() => onChange('')} className="absolute right-2 top-1/2 -translate-y-1/2 p-1 text-slate-400 hover:text-slate-700"><X size={14} /></button>}
  </div>
);

export const Segmented = <T extends string>({ value, onChange, options }: { value: T; onChange: (v: T) => void; options: { value: T; label: React.ReactNode }[] }) => (
  <div className="flex p-1 rounded-xl bg-slate-100 dark:bg-slate-800/60 overflow-x-auto">
    {options.map(o => (
      <button key={o.value} onClick={() => onChange(o.value)} className={`shrink-0 h-8 px-3 rounded-lg text-xs font-semibold inline-flex items-center gap-1.5 whitespace-nowrap transition-all ${value === o.value ? 'bg-white dark:bg-slate-900 shadow-sm text-indigo-600 dark:text-indigo-300' : 'text-slate-500 hover:text-slate-700 dark:hover:text-slate-200'}`}>{o.label}</button>
    ))}
  </div>
);

export const Field: React.FC<{ label: string; required?: boolean; error?: string; hint?: React.ReactNode; children: React.ReactNode; className?: string }> = ({ label, required, error, hint, children, className = '' }) => (
  <div className={className}>
    <label className="flex items-center gap-1 text-xs font-semibold text-slate-600 dark:text-slate-300 mb-1.5">{label}{required && <span className="text-rose-500">*</span>}</label>
    {children}
    {error ? <p className="mt-1 text-[11px] font-semibold text-rose-600 flex items-center gap-1 animate-in fade-in slide-in-from-top-2 duration-200"><AlertCircle size={12} /> {error}</p> : hint ? <div className="mt-1 text-[11px] text-slate-400">{hint}</div> : null}
  </div>
);

export const EmptyState: React.FC<{ icon: React.ElementType; text: string; action?: React.ReactNode }> = ({ icon: Icon, text, action }) => (
  <div className="py-14 text-center text-slate-400 animate-in fade-in zoom-in-95">
    <Icon size={36} className="mx-auto mb-2 opacity-40 pc-float" />
    <p className="text-sm font-semibold">{text}</p>
    {action && <div className="mt-2">{action}</div>}
  </div>
);

/** İki aşamalı (onaylı) silme butonu */
export const DeleteButton: React.FC<{ onConfirm: () => Promise<void> | void; language: 'tr' | 'en'; label?: boolean; className?: string; text?: string; confirmText?: string }> = ({ onConfirm, language, label, className = '', text, confirmText }) => {
  const [ask, setAsk] = useState(false);
  const tr = language === 'tr';
  return ask ? (
    <span className="inline-flex items-center gap-1 animate-in fade-in zoom-in-95 duration-150" onClick={e => e.stopPropagation()}>
      <button onClick={() => setAsk(false)} className="h-7 px-2 rounded-lg text-[11px] font-semibold text-slate-500 hover:bg-slate-100 dark:hover:bg-white/5">{tr ? 'Vazgeç' : 'Cancel'}</button>
      <button onClick={async () => { await onConfirm(); setAsk(false); }} className="h-7 px-2 rounded-lg text-[11px] font-semibold text-white bg-rose-600 hover:bg-rose-500">{confirmText || (tr ? 'Sil' : 'Delete')}</button>
    </span>
  ) : (
    <button onClick={e => { e.stopPropagation(); setAsk(true); }} title={tr ? 'Sil' : 'Delete'} className={`p-1.5 rounded-lg text-slate-400 hover:text-rose-600 hover:bg-rose-50 dark:hover:bg-white/5 inline-flex items-center gap-1 ${className}`}><Trash2 size={14} />{label && <span className="text-xs font-semibold">{text || (tr ? 'Sil' : 'Delete')}</span>}</button>
  );
};

/** Form paneli: başlık, kaydırılabilir gövde, alt çubuk, Esc / Ctrl+Enter */
export const Sheet: React.FC<{
  open: boolean; title: string; subtitle?: string; icon: React.ElementType; tone?: string; onClose: () => void;
  onSubmit?: () => void; submitLabel?: string; saving?: boolean; children: React.ReactNode; footerLeft?: React.ReactNode; width?: string; language: 'tr' | 'en'; hideFooter?: boolean;
}> = ({ open, title, subtitle, icon: Icon, tone = 'from-indigo-500 to-violet-600', onClose, onSubmit, submitLabel, saving, children, footerLeft, width = 'max-w-xl', language, hideFooter }) => {
  useEffect(() => {
    if (!open) return;
    const onKey = (e: KeyboardEvent) => {
      if (e.key === 'Escape') { e.preventDefault(); onClose(); }
      if (onSubmit && (e.ctrlKey || e.metaKey) && e.key === 'Enter') { e.preventDefault(); onSubmit(); }
    };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  });
  if (!open) return null;
  const tr = language === 'tr';
  return (
    <ModalPortal>
      <div className="fixed inset-0 z-[1100] flex items-center justify-center p-0 sm:p-4" role="dialog" aria-modal="true">
        <div className="absolute inset-0 bg-slate-950/60 backdrop-blur-md pc-backdrop" onClick={onClose} />
        <div className={`relative w-full ${width} h-full sm:h-auto sm:max-h-[92vh] bg-white dark:bg-slate-900 sm:rounded-[28px] shadow-2xl flex flex-col overflow-hidden pc-pop border border-white/10`}>
          <div className="flex items-center gap-3 px-5 sm:px-6 py-4 border-b border-slate-100 dark:border-slate-800" style={{ paddingTop: 'max(env(safe-area-inset-top, 0px), 1rem)' }}>
            <span className={`w-10 h-10 shrink-0 rounded-xl bg-gradient-to-br ${tone} text-white flex items-center justify-center shadow-md`}><Icon size={18} /></span>
            <div className="flex-1 min-w-0"><h3 className="text-lg font-bold text-slate-900 dark:text-white truncate">{title}</h3>{subtitle && <p className="text-xs text-slate-400 truncate">{subtitle}</p>}</div>
            <button onClick={onClose} className="p-2 rounded-xl text-slate-400 hover:text-slate-700 hover:bg-slate-100 dark:hover:bg-white/5" aria-label="Close"><X size={20} /></button>
          </div>
          <div className="flex-1 overflow-y-auto custom-scrollbar p-5 sm:p-6 space-y-5">{children}</div>
          {!hideFooter && (
            <div className="flex items-center gap-2 px-5 sm:px-6 py-3 border-t border-slate-100 dark:border-slate-800" style={{ paddingBottom: 'max(env(safe-area-inset-bottom, 0px), 0.75rem)' }}>
              <div className="flex-1 min-w-0 text-sm">{footerLeft}</div>
              <button onClick={onClose} className="h-10 px-4 rounded-xl text-sm font-semibold text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-white/5">{onSubmit ? (tr ? 'Vazgeç' : 'Cancel') : (tr ? 'Kapat' : 'Close')}</button>
              {onSubmit && <button onClick={onSubmit} disabled={saving} className={btnPrimary}>{saving ? <Loader2 size={16} className="animate-spin" /> : <Save size={16} />}{submitLabel || (tr ? 'Kaydet' : 'Save')}</button>}
            </div>
          )}
        </div>
      </div>
    </ModalPortal>
  );
};

/** Basit avatar */
export const Avatar: React.FC<{ name?: string; src?: string; size?: string; className?: string }> = ({ name, src, size = 'w-9 h-9', className = '' }) =>
  src ? <img src={src} alt={name || ''} title={name} className={`${size} rounded-xl object-cover shrink-0 ${className}`} />
    : <span title={name} className={`${size} shrink-0 rounded-xl bg-gradient-to-br from-indigo-500 to-violet-500 text-white text-xs font-bold flex items-center justify-center ${className}`}>{(name || '?')[0]?.toUpperCase()}</span>;

/** Sayıyı ₺/$/€ ile biçimle */
export const SYM: Record<string, string> = { TRY: '₺', USD: '$', EUR: '€' };
export const money = (n: number, c?: string, digits = 0) => `${SYM[c || 'TRY'] || ''}${(Number(n) || 0).toLocaleString('tr-TR', { maximumFractionDigits: digits, minimumFractionDigits: digits })}`;
