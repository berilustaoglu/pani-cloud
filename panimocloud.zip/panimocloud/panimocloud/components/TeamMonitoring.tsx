
import React, { useEffect, useRef, useState } from 'react';
import { User, UserActivity, ScreenRequest } from '../types';
import { Monitor, Video, Clock, Eye, Activity, ShieldAlert, Maximize2, Loader2, Info, RefreshCw, Sparkles, History } from 'lucide-react';
import { PageHeader, KpiGrid, Segmented, EmptyState, Avatar, cardCls } from './ui/Kit';
import { doc, setDoc, onSnapshot, updateDoc, collection, addDoc, query, deleteDoc, getDocs, where, limit, orderBy } from 'firebase/firestore';
import { db } from '../firebase';
import { analyzeStaffPerformance } from '../services/aiService';
import { StaffAIAnalysis } from '../types';
import { toast } from '../services/toast';

interface Props {
    staffList: User[];
    userActivities: UserActivity[];
    currentUser: User | null;
    language: 'tr' | 'en';
    screenRequests: ScreenRequest[];
    activeStreams: Record<string, MediaStream>;
    connectionStates: Record<string, { conn: string, ice: string }>;
    candidateCounts: Record<string, { admin: number, staff: number }>;
    onReconnect: (requestId: string) => void;
    onShowGallery: (userId: string, userName: string) => void;
    onShowViewer: (request: ScreenRequest, name: string) => void;
}

// Optimized Sub-component for individual mosaic stream (Display only)
const LiveStreamThumb: React.FC<{ stream: MediaStream | null, staffName: string, onClick: () => void }> = ({ stream, staffName, onClick }) => {
    const videoRef = useRef<HTMLVideoElement>(null);

    useEffect(() => {
        if (videoRef.current && stream) {
            videoRef.current.srcObject = stream;
        }
    }, [stream]);

    return (
        <div onClick={onClick} className="relative aspect-video bg-slate-900 rounded-[20px] overflow-hidden group cursor-pointer border-2 border-transparent hover:border-rose-500 transition-all shadow-lg pc-lift">
            <video
                ref={videoRef}
                autoPlay
                playsInline
                muted
                className="w-full h-full object-cover opacity-80 group-hover:opacity-100 transition-opacity"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-transparent opacity-60" />
            <div className="absolute bottom-4 left-4 right-4 flex justify-between items-center">
                <span className="text-[10px] font-black text-white uppercase tracking-widest truncate max-w-[120px]">{staffName}</span>
                <div className="flex items-center gap-1.5 bg-red-600 px-2 py-1 rounded-lg">
                    <div className="w-1.5 h-1.5 bg-white rounded-full animate-pulse" />
                    <span className="text-[8px] font-black text-white uppercase">Live</span>
                </div>
            </div>
            <div className="absolute inset-0 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity">
                <div className="p-4 bg-white/10 backdrop-blur-md rounded-full text-white">
                    <Maximize2 size={24} />
                </div>
            </div>
        </div>
    );
};

const TeamMonitoring: React.FC<Props> = ({
    staffList,
    userActivities,
    currentUser,
    language,
    screenRequests,
    activeStreams,
    connectionStates,
    candidateCounts,
    onReconnect,
    onShowGallery,
    onShowViewer
}) => {
    const isAdmin = currentUser?.role === 'Admin';
    const isManager = currentUser?.role === 'Manager';
    const [filterRole, setFilterRole] = React.useState<string>('All');
    const [aiAnalyses, setAiAnalyses] = useState<Record<string, StaffAIAnalysis>>({});
    const [isAnalyzing, setIsAnalyzing] = useState<Record<string, boolean>>({});

    // Connections are now managed globally in App.tsx

    const sendScreenRequest = async (targetUserId: string) => {
        if (!currentUser) return;

        const existing = screenRequests.find(r => r.toId === targetUserId && (r.status === 'Pending' || r.status === 'Accepted'));
        if (existing) {
            if (existing.status === 'Accepted') {
                const staff = staffList.find(u => u.id === targetUserId);
                onShowViewer(existing, staff?.name || 'Staff');
            } else {
                toast(language === 'tr' ? 'Zaten bekleyen bir istek var.' : 'There is already a pending request.');
            }
            return;
        }

        const requestId = `req_${Date.now()}`;
        const request: ScreenRequest = {
            id: requestId,
            fromId: currentUser.id,
            toId: targetUserId,
            status: 'Pending',
            timestamp: new Date().toISOString()
        };
        await setDoc(doc(db, "screen_requests", requestId), request);
        toast(language === 'tr' ? 'Ekran izleme isteği gönderildi.' : 'Screen view request sent.');
    };

    const handleReconnect = async (requestId: string) => {
        await onReconnect(requestId);
    };

    const handleAnalyzeStaff = async (staffId: string, staffName: string) => {
        setIsAnalyzing(prev => ({ ...prev, [staffId]: true }));
        try {
            // Fetch usage logs for last 24h
            const usageRef = collection(db, "app_usage_logs");
            const usageQuery = query(
                usageRef,
                where("userId", "==", staffId),
                orderBy("timestamp", "desc"),
                limit(30)
            );

            // This might fail if index is missing, handle gracefully
            let usageLogs: any[] = [];
            try {
                const usageSnap = await getDocs(usageQuery);
                usageLogs = usageSnap.docs.map(d => d.data());
            } catch (e: any) {
                console.warn("Usage logs query failed (likely missing index):", e);
                // Fallback to empty if index missing
            }

            // Fetch activity brief
            const activityBrief = userActivities.find(a => a.id === staffId);

            const result = await analyzeStaffPerformance(
                staffName,
                activityBrief ? [activityBrief] : [],
                usageLogs,
                language
            );

            setAiAnalyses(prev => ({ ...prev, [staffId]: result }));
        } catch (error) {
            console.error("AI Analysis critical error:", error);
            toast(language === 'tr' ? 'Analiz motorunda hata oluştu.' : 'Error in analysis engine.');
        } finally {
            setIsAnalyzing(prev => ({ ...prev, [staffId]: false }));
        }
    };

    if (!isAdmin && !isManager) return null;

    const tr = language === 'tr';
    const acceptedRequests = screenRequests.filter(r => r.status === 'Accepted');
    const presence = (id: string) => {
        const a = userActivities.find(x => x.id === id);
        const online = !!a && Date.now() - new Date(a.lastActivity).getTime() < 5 * 60 * 1000;
        return { a, state: (!online ? 'offline' : a!.isIdle ? 'idle' : 'active') as 'active' | 'idle' | 'offline' };
    };
    const others = staffList.filter(u => u.id !== currentUser?.id);
    const roles = ['All', ...Array.from(new Set(others.map(u => u.role)))];
    const counts = others.reduce((acc, u) => { acc[presence(u.id).state]++; return acc; }, { active: 0, idle: 0, offline: 0 });
    const order = { active: 0, idle: 1, offline: 2 };
    const filteredStaff = others
        .filter(u => filterRole === 'All' || u.role === filterRole)
        .sort((a, b) => order[presence(a.id).state] - order[presence(b.id).state] || (a.name || '').localeCompare(b.name || '', 'tr'));
    const ago = (iso?: string) => {
        if (!iso) return '—';
        const m = Math.round((Date.now() - new Date(iso).getTime()) / 60000);
        return m < 1 ? (tr ? 'şimdi' : 'now') : m < 60 ? (tr ? `${m} dk önce` : `${m}m ago`) : m < 1440 ? (tr ? `${Math.round(m / 60)} sa önce` : `${Math.round(m / 60)}h ago`) : new Date(iso).toLocaleDateString('tr-TR');
    };
    const META = {
        active: { label: tr ? 'Aktif' : 'Active', dot: 'bg-emerald-500', chip: 'bg-emerald-50 text-emerald-700 dark:bg-emerald-500/10 dark:text-emerald-300' },
        idle: { label: tr ? 'Boşta' : 'Idle', dot: 'bg-amber-500', chip: 'bg-amber-50 text-amber-700 dark:bg-amber-500/10 dark:text-amber-300' },
        offline: { label: tr ? 'Çevrim dışı' : 'Offline', dot: 'bg-slate-300', chip: 'bg-slate-100 text-slate-500 dark:bg-white/5' },
    };

    return (
        <div className="space-y-5 pb-10">
            <PageHeader title={tr ? 'Ekip İzleme' : 'Team Monitoring'} subtitle={tr ? 'Anlık çevrim içi durum, aktivite ve onaylı ekran paylaşımı.' : 'Live presence, activity and consented screen sharing.'} />

            <KpiGrid items={[
                { label: tr ? 'Aktif çalışan' : 'Active', value: counts.active, icon: Activity, grad: 'from-emerald-500 to-teal-600', sub: `${others.length} ${tr ? 'kişiden' : 'people'}`, bar: others.length ? (counts.active / others.length) * 100 : 0 },
                { label: tr ? 'Boşta' : 'Idle', value: counts.idle, icon: Clock, grad: 'from-amber-500 to-orange-600', sub: tr ? 'Son 5 dk hareketsiz' : 'No input 5 min' },
                { label: tr ? 'Çevrim dışı' : 'Offline', value: counts.offline, icon: ShieldAlert, grad: 'from-slate-500 to-slate-700', sub: tr ? 'Bağlı değil' : 'Not connected' },
                { label: tr ? 'Canlı paylaşım' : 'Live shares', value: acceptedRequests.length, icon: Monitor, grad: 'from-rose-500 to-red-600', sub: tr ? 'Personel onaylı' : 'Consented' },
            ]} />

            <div className={`${cardCls} p-3 flex flex-col sm:flex-row gap-2 sm:items-center`}>
                <Segmented<string> value={filterRole} onChange={setFilterRole} options={roles.map(r => ({ value: r, label: r === 'All' ? (tr ? 'Tümü' : 'All') : r }))} />
                <p className="text-[11px] text-slate-400 flex items-center gap-1.5 sm:ml-auto"><Info size={13} />{tr ? 'Ekran paylaşımı yalnızca personel onay verdiğinde başlar.' : 'Screen sharing starts only after staff consent.'}</p>
            </div>

            {acceptedRequests.length > 0 && (
                <div className="space-y-3 animate-in fade-in duration-500">
                    <p className="text-xs font-semibold text-slate-500 flex items-center gap-2"><span className="w-2 h-2 rounded-full bg-rose-500 pc-dot-pulse" />{tr ? 'Canlı yayın duvarı' : 'Live wall'}</p>
                    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
                        {acceptedRequests.map(req => {
                            const staff = staffList.find(s => s.id === req.toId);
                            if (!staff) return null;
                            return <LiveStreamThumb key={req.id} stream={activeStreams[req.id]} staffName={staff.name} onClick={() => onShowViewer(req, staff.name)} />;
                        })}
                    </div>
                </div>
            )}

            {filteredStaff.length === 0 ? <div className={cardCls}><EmptyState icon={ShieldAlert} text={tr ? 'Personel bulunamadı' : 'No staff'} /></div> : (
                <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-3 pc-stagger">
                    {filteredStaff.map(staff => {
                        const { a: activity, state } = presence(staff.id);
                        const M = META[state];
                        const activeReq = screenRequests.find(r => r.toId === staff.id && (r.status === 'Pending' || r.status === 'Accepted'));
                        const ai = aiAnalyses[staff.id];
                        return (
                            <div key={staff.id} className={`${cardCls} p-4 flex flex-col gap-3 pc-lift`}>
                                <div className="flex items-center gap-3">
                                    <div className="relative"><Avatar name={staff.name} src={staff.avatar} size="w-11 h-11" /><span className={`absolute -bottom-0.5 -right-0.5 w-3.5 h-3.5 rounded-full border-2 border-white dark:border-slate-900 ${M.dot} ${state === 'active' ? 'pc-dot-pulse' : ''}`} /></div>
                                    <div className="min-w-0 flex-1"><p className="text-sm font-semibold text-slate-800 dark:text-slate-100 truncate">{staff.name}</p><p className="text-[11px] text-slate-400 truncate">{staff.jobTitle || staff.role}</p></div>
                                    {activeReq?.status === 'Accepted' ? <span className="text-[10px] font-bold px-2 py-0.5 rounded-md bg-rose-600 text-white inline-flex items-center gap-1"><span className="w-1.5 h-1.5 rounded-full bg-white animate-pulse" />{tr ? 'Yayında' : 'Live'}</span> : <span className={`text-[11px] font-semibold px-2 py-0.5 rounded-md ${M.chip}`}>{M.label}</span>}
                                </div>
                                <div className="grid grid-cols-2 gap-2">
                                    <div className="rounded-xl bg-slate-50 dark:bg-white/[0.03] px-3 py-2"><p className="text-[10px] text-slate-400">{tr ? 'Sekme' : 'Tab'}</p><p className="text-xs font-semibold text-slate-700 dark:text-slate-200 flex items-center gap-1"><Eye size={12} className={activity?.tabStatus === 'Active' ? 'text-emerald-500' : 'text-slate-300'} />{activity ? (activity.tabStatus === 'Active' ? (tr ? 'Odakta' : 'Focused') : (tr ? 'Arka planda' : 'Background')) : '—'}</p></div>
                                    <div className="rounded-xl bg-slate-50 dark:bg-white/[0.03] px-3 py-2"><p className="text-[10px] text-slate-400">{tr ? 'Son aktivite' : 'Last activity'}</p><p className="text-xs font-semibold text-slate-700 dark:text-slate-200 flex items-center gap-1"><Clock size={12} className="text-indigo-500" />{ago(activity?.lastActivity)}</p></div>
                                </div>

                                {ai ? (
                                    <div className="rounded-xl border border-indigo-100 dark:border-indigo-500/20 bg-indigo-50/50 dark:bg-indigo-500/5 p-3 space-y-2 animate-in fade-in duration-300">
                                        <div className="flex items-center justify-between"><span className="text-[11px] font-semibold text-indigo-600 dark:text-indigo-300">{tr ? 'Günlük verimlilik' : 'Productivity'}</span><span className={`text-sm font-black ${ai.productivityScore > 70 ? 'text-emerald-600' : 'text-amber-600'}`}>%{ai.productivityScore}</span></div>
                                        <div className="h-1.5 rounded-full bg-white dark:bg-slate-800 overflow-hidden"><div className={`h-full rounded-full transition-all duration-700 ${ai.productivityScore > 70 ? 'bg-emerald-500' : 'bg-amber-500'}`} style={{ width: `${ai.productivityScore}%` }} /></div>
                                        <p className="text-xs text-slate-600 dark:text-slate-300 leading-relaxed">{ai.summary}</p>
                                        {ai.focusApps?.length > 0 && <div className="flex flex-wrap gap-1">{ai.focusApps.slice(0, 3).map((app, i) => <span key={i} className="text-[10px] font-semibold px-1.5 py-0.5 rounded bg-white dark:bg-slate-800 text-indigo-600 dark:text-indigo-300">{app}</span>)}</div>}
                                    </div>
                                ) : null}

                                <div className="mt-auto pt-2 border-t border-slate-100 dark:border-slate-800 flex items-center gap-1.5">
                                    <button onClick={() => sendScreenRequest(staff.id)} disabled={state === 'offline' && activeReq?.status !== 'Accepted'}
                                        className={`flex-1 h-9 rounded-lg text-xs font-semibold inline-flex items-center justify-center gap-1.5 disabled:opacity-40 transition-colors ${activeReq?.status === 'Accepted' ? 'bg-indigo-600 text-white hover:bg-indigo-500' : activeReq?.status === 'Pending' ? 'bg-amber-50 text-amber-700 dark:bg-amber-500/10 dark:text-amber-300' : 'bg-slate-900 dark:bg-white/10 text-white hover:bg-rose-600'}`}>
                                        {activeReq?.status === 'Accepted' ? (activeStreams[activeReq.id] ? <Maximize2 size={14} /> : <Loader2 size={14} className="animate-spin" />) : activeReq?.status === 'Pending' ? <Loader2 size={14} className="animate-spin" /> : <Video size={14} />}
                                        {activeReq?.status === 'Accepted' ? (tr ? 'Yayını aç' : 'Open') : activeReq?.status === 'Pending' ? (tr ? 'Onay bekleniyor' : 'Awaiting consent') : (tr ? 'Paylaşım iste' : 'Request share')}
                                    </button>
                                    {activeReq?.status === 'Accepted' && <button onClick={() => handleReconnect(activeReq.id)} title={tr ? 'Yeniden bağlan' : 'Reconnect'} className="p-2 rounded-lg text-slate-400 hover:text-indigo-600 hover:bg-indigo-50 dark:hover:bg-white/5"><RefreshCw size={15} /></button>}
                                    <button onClick={() => handleAnalyzeStaff(staff.id, staff.name)} disabled={isAnalyzing[staff.id]} title={tr ? 'Günlük AI analizi' : 'AI analysis'} className="p-2 rounded-lg text-slate-400 hover:text-indigo-600 hover:bg-indigo-50 dark:hover:bg-white/5 disabled:opacity-50">{isAnalyzing[staff.id] ? <Loader2 size={15} className="animate-spin" /> : <Sparkles size={15} />}</button>
                                    <button onClick={() => onShowGallery(staff.id, staff.name)} title={tr ? 'Geçmiş kayıtlar' : 'History'} className="p-2 rounded-lg text-slate-400 hover:text-indigo-600 hover:bg-indigo-50 dark:hover:bg-white/5"><History size={15} /></button>
                                </div>
                            </div>
                        );
                    })}
                </div>
            )}
        </div>
    );
};

export default TeamMonitoring;
