import React from 'react';
import { User, Task, AttendanceRecord, TaskStatus } from '../types';
import { Target, Zap, Clock, TrendingUp, Award, AlertCircle } from 'lucide-react';
import { ResponsiveContainer, RadarChart, PolarGrid, PolarAngleAxis, PolarRadiusAxis, Radar } from 'recharts';

interface Props {
  user: User;
  tasks: Task[];
  attendance: AttendanceRecord[];
  language: 'tr' | 'en';
}

const PerformanceScorecard: React.FC<Props> = ({ user, tasks, attendance, language }) => {
  const userTasks = tasks.filter(t => t.assignedTo?.includes(user.id));
  const doneTasks = userTasks.filter(t => t.status === TaskStatus.DONE);
  const completionRate = userTasks.length > 0 ? Math.round((doneTasks.length / userTasks.length) * 100) : 0;
  
  // Attendance Consistency (Last 30 days)
  const last30Days = attendance.filter(r => r.userId === user.id).length;
  const attendanceScore = Math.min(Math.round((last30Days / 22) * 100), 100); // 22 working days target

  // Simulated AI Metrics
  const speedScore = completionRate > 80 ? 95 : 75;
  const qualityScore = 88;
  const collaborationScore = 92;

  const data = [
    { subject: language === 'tr' ? 'Hız' : 'Speed', A: speedScore, fullMark: 100 },
    { subject: language === 'tr' ? 'Kalite' : 'Quality', A: qualityScore, fullMark: 100 },
    { subject: language === 'tr' ? 'Uyum' : 'Collaboration', A: collaborationScore, fullMark: 100 },
    { subject: language === 'tr' ? 'Devamlılık' : 'Attendance', A: attendanceScore, fullMark: 100 },
    { subject: language === 'tr' ? 'Görev Tamamlama' : 'Completion', A: completionRate, fullMark: 100 },
  ];

  const overallScore = Math.round((speedScore + qualityScore + collaborationScore + attendanceScore + completionRate) / 5);

  return (
    <div className="bg-white dark:bg-slate-900 rounded-[48px] border border-slate-100 dark:border-slate-800 shadow-2xl p-8 lg:p-12 overflow-hidden relative">
      <div className="absolute top-0 right-0 p-12 opacity-[0.02] pointer-events-none">
         <Award size={300} />
      </div>

      <div className="flex flex-col lg:flex-row gap-12 items-center relative z-10">
        {/* LEFT: INFO & RADAR */}
        <div className="flex-1 space-y-8 w-full">
           <div className="flex items-center gap-6">
              <div className="w-20 h-20 rounded-[28px] bg-indigo-600 flex items-center justify-center text-white text-3xl font-black shadow-2xl shadow-indigo-200 dark:shadow-none">
                 {user.name.charAt(0)}
              </div>
              <div>
                 <h2 className="text-3xl font-black text-slate-900 dark:text-white tracking-tighter">{user.name}</h2>
                 <p className="text-xs font-black text-slate-400 uppercase tracking-[0.3em] mt-1">{user.role}</p>
              </div>
           </div>

           <div className="grid grid-cols-2 gap-4">
              <div className="p-6 bg-slate-50 dark:bg-slate-800/50 rounded-3xl border border-slate-100 dark:border-slate-800">
                 <Target className="text-indigo-600 mb-2" size={20} />
                 <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest">{language === 'tr' ? 'TAMAMLANAN' : 'COMPLETED'}</p>
                 <h4 className="text-2xl font-black text-slate-900 dark:text-white">{doneTasks.length} / {userTasks.length}</h4>
              </div>
              <div className="p-6 bg-slate-50 dark:bg-slate-800/50 rounded-3xl border border-slate-100 dark:border-slate-800">
                 <Clock className="text-emerald-600 mb-2" size={20} />
                 <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest">{language === 'tr' ? 'AYLIK MESAİ' : 'MONTHLY HOURS'}</p>
                 <h4 className="text-2xl font-black text-slate-900 dark:text-white">{last30Days * 8}h</h4>
              </div>
           </div>

           <div className="h-[300px] w-full">
              <ResponsiveContainer width="100%" height="100%">
                 <RadarChart cx="50%" cy="50%" outerRadius="80%" data={data}>
                    <PolarGrid stroke="var(--chart-grid)" />
                    <PolarAngleAxis dataKey="subject" tick={{ fill: 'var(--chart-text)', fontSize: 10, fontWeight: 800 }} />
                    <PolarRadiusAxis angle={30} domain={[0, 100]} hide />
                    <Radar
                       name="User"
                       dataKey="A"
                       stroke="#6366f1"
                       fill="#6366f1"
                       fillOpacity={0.6}
                    />
                 </RadarChart>
              </ResponsiveContainer>
           </div>
        </div>

        {/* RIGHT: OVERALL SCORE & AI INSIGHT */}
        <div className="lg:w-96 w-full space-y-8">
           <div className="p-10 bg-slate-900 rounded-[40px] text-white text-center relative overflow-hidden shadow-2xl">
              <div className="absolute top-0 left-0 w-full h-1 bg-gradient-to-r from-indigo-500 via-purple-500 to-pink-500"></div>
              <p className="text-[10px] font-black uppercase tracking-[0.4em] text-slate-500 mb-4">Overall Performance</p>
              <div className="text-7xl font-black tracking-tighter italic mb-4">{overallScore}</div>
              <div className="inline-flex px-4 py-1.5 bg-indigo-500/20 text-indigo-400 rounded-full text-[10px] font-black uppercase tracking-widest border border-indigo-500/30">
                 {overallScore > 90 ? 'Elite Talent' : overallScore > 75 ? 'Top Performer' : 'Core Contributor'}
              </div>
           </div>

           <div className="p-8 bg-indigo-50 dark:bg-indigo-900/20 rounded-[40px] border border-indigo-100 dark:border-indigo-900/30">
              <h4 className="text-xs font-black text-indigo-600 dark:text-indigo-400 uppercase tracking-widest mb-4 flex items-center gap-2">
                 <Zap size={16} /> AI Coaching Insight
              </h4>
              <p className="text-sm font-medium text-slate-600 dark:text-slate-300 leading-relaxed italic">
                 {language === 'tr' 
                   ? `"${user.name} özellikle ${doneTasks.length > 5 ? 'hızlı teslimat' : 'detaylı çalışma'} konusunda öne çıkıyor. Collaboration skoru yüksek, bu da ekip projelerinde anahtar rol oynadığını gösteriyor."`
                   : `"${user.name} excels in ${doneTasks.length > 5 ? 'rapid delivery' : 'detailed work'}. High collaboration score indicates a key role in team dynamics."`}
              </p>
           </div>

           <div className="space-y-4">
              <h4 className="text-[10px] font-black text-slate-400 uppercase tracking-widest">{language === 'tr' ? 'GELİŞİM ÖNERİSİ' : 'GROWTH TIP'}</h4>
              <div className="flex items-start gap-4 p-4 bg-amber-50 dark:bg-amber-900/20 rounded-2xl border border-amber-100 dark:border-amber-900/30">
                 <AlertCircle className="text-amber-600 shrink-0" size={18} />
                 <p className="text-xs font-bold text-amber-900 dark:text-amber-400">
                    {language === 'tr' 
                      ? 'Dokümantasyon süresini %15 azaltmak verimliliği artırabilir.' 
                      : 'Reducing documentation time by 15% could boost overall efficiency.'}
                 </p>
              </div>
           </div>
        </div>
      </div>
    </div>
  );
};

export default PerformanceScorecard;
