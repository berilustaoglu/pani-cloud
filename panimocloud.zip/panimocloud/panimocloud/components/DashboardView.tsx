
import React from 'react';
import { 
  BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer,
  PieChart, Pie, Cell, LineChart, Line, Legend, AreaChart, Area
} from 'recharts';
import { Project, Task, Transaction, TaskStatus, Currency, AttendanceRecord, LeaveRequest, User } from '../types';
import { Wallet, Briefcase, CheckSquare, TrendingUp, Zap, Calendar, ArrowUpRight, ArrowDownRight, Clock, UserCheck, AlertTriangle, CalendarCheck, ShieldAlert, ExternalLink } from 'lucide-react';
import { translations } from '../translations';
import WorkloadHeatmap from './WorkloadHeatmap';
import FinancialForecastView from './FinancialForecastView';

interface Props {
  projects: Project[];
  tasks: Task[];
  transactions: Transaction[];
  language: 'tr' | 'en';
  rates: { TRY: number, EUR: number };
  showFinancials: boolean;
  attendance?: AttendanceRecord[];
  leaveRequests?: LeaveRequest[];
  users?: User[];
  onNavigate?: (tab: string, param?: string) => void;
}

const DashboardView: React.FC<Props> = ({ projects, tasks, transactions, language, rates, showFinancials, attendance = [], leaveRequests = [], users = [], onNavigate }) => {
  const t = translations[language];

  const activeProjects = projects.filter(p => p.status === 'Active');

  const convertToUSD = (amount: number, currency: Currency) => {
    if (!rates.TRY || !rates.EUR) return amount;
    switch (currency) {
      case Currency.TRY: return amount / rates.TRY;
      case Currency.EUR: return amount / rates.EUR;
      default: return amount;
    }
  };

  const getCurrencySymbol = (c?: Currency) => {
    switch(c) {
      case Currency.TRY: return '₺';
      case Currency.EUR: return '€';
      default: return '$';
    }
  };

  const isApproaching = (dateStr?: string) => {
    if (!dateStr) return false;
    const deliveryDate = new Date(dateStr);
    const now = new Date();
    const diffTime = deliveryDate.getTime() - now.getTime();
    const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
    return diffDays <= 3;
  };

  // --- ANALYTICS CALCULATIONS ---
  
  // Last 6 months cash flow
  const getMonthlyData = () => {
    const months = [];
    const now = new Date();
    for (let i = 5; i >= 0; i--) {
      const d = new Date(now.getFullYear(), now.getMonth() - i, 1);
      const monthLabel = d.toLocaleString(language === 'tr' ? 'tr-TR' : 'en-US', { month: 'short' });
      const yearMonth = `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}`;
      
      const monthlyIncome = transactions
        .filter(tr => tr.type === 'Income' && tr.date.startsWith(yearMonth))
        .reduce((acc, tr) => acc + convertToUSD(tr.amount, tr.currency || Currency.USD), 0);
        
      const monthlyExpense = transactions
        .filter(tr => tr.type === 'Expense' && tr.date.startsWith(yearMonth))
        .reduce((acc, tr) => acc + convertToUSD(tr.amount, tr.currency || Currency.USD), 0);
        
      months.push({ name: monthLabel, income: Math.round(monthlyIncome), expense: Math.round(monthlyExpense) });
    }
    return months;
  };

  const cashFlowData = getMonthlyData();

  // Expense by Category
  const getCategoryData = () => {
    const catMap: Record<string, number> = {};
    transactions
      .filter(tr => tr.type === 'Expense')
      .forEach(tr => {
        const cat = tr.category || (language === 'tr' ? 'Diğer' : 'Other');
        const amountUSD = convertToUSD(tr.amount, tr.currency || Currency.USD);
        catMap[cat] = (catMap[cat] || 0) + amountUSD;
      });
      
    return Object.entries(catMap)
      .map(([name, value]) => ({ name, value: Math.round(value) }))
      .sort((a, b) => b.value - a.value)
      .slice(0, 5);
  };

  const categoryData = getCategoryData();

  const totalIncomeUSD = transactions
    .filter(tr => tr.type === 'Income')
    .reduce((acc, tr) => acc + convertToUSD(tr.amount, tr.currency || Currency.USD), 0);
    
  const totalExpenseUSD = transactions
    .filter(tr => tr.type === 'Expense')
    .reduce((acc, tr) => acc + convertToUSD(tr.amount, tr.currency || Currency.USD), 0);
    
  const profitUSD = totalIncomeUSD - totalExpenseUSD;

  const taskStats = [
    { name: t.todo, value: tasks.filter(tk => tk.status === TaskStatus.TODO).length },
    { name: t.doing, value: tasks.filter(tk => tk.status === TaskStatus.DOING).length },
    { name: t.done, value: tasks.filter(tk => tk.status === TaskStatus.DONE).length },
    { name: t.blocked, value: tasks.filter(tk => tk.status === TaskStatus.BLOCKED).length },
  ];

  const COLORS = ['#6366f1', '#475569', '#10b981', '#ef4444', '#f59e0b', '#8b5cf6'];

  const stats = [
    { label: t.total_revenue, value: showFinancials ? `$${totalIncomeUSD.toLocaleString(undefined, { maximumFractionDigits: 0 })}` : '**', icon: <ArrowUpRight size={20} />, color: 'bg-slate-900 text-white' },
    { label: language === 'tr' ? 'Toplam Gider' : 'Total Expense', value: showFinancials ? `$${totalExpenseUSD.toLocaleString(undefined, { maximumFractionDigits: 0 })}` : '**', icon: <ArrowDownRight size={20} />, color: 'bg-white text-slate-950 border border-slate-100 shadow-sm' },
    { label: t.net_profit, value: showFinancials ? `$${profitUSD.toLocaleString(undefined, { maximumFractionDigits: 0 })}` : '**', icon: <TrendingUp size={20} />, color: 'bg-white text-slate-950 border border-slate-100 shadow-sm' },
    { label: t.active_projects, value: activeProjects.length, icon: <Briefcase size={20} />, color: 'bg-white text-slate-950 border border-slate-100 shadow-sm' },
  ];

  return (
    <div className="space-y-4 lg:space-y-4 pb-4">
      {/* RISK ALERTS */}
      {projects.filter(p => p.status === 'Active' && p.progress < 50 && p.deliveryDate && new Date(p.deliveryDate) < new Date()).length > 0 && (
        <div className="bg-red-50 dark:bg-red-900/10 border border-red-100 dark:border-red-900/30 p-6 rounded-[32px] flex items-center justify-between gap-6 animate-in slide-in-from-top duration-500">
           <div className="flex items-center gap-4">
              <div className="bg-red-600 text-white p-3 rounded-2xl shadow-lg shadow-red-200 dark:shadow-none"><ShieldAlert size={24} /></div>
              <div>
                 <h4 className="font-black text-red-600 uppercase text-xs tracking-widest">{language === 'tr' ? 'KRİTİK RİSK UYARISI' : 'CRITICAL RISK ALERT'}</h4>
                 <p className="text-sm font-bold text-red-900/70 dark:text-red-400">
                    {language === 'tr' ? 'Teslim tarihi geçmiş ancak tamamlanmamış projeler tespit edildi.' : 'Detected projects past delivery date but not yet completed.'}
                 </p>
              </div>
           </div>
            <button 
              onClick={() => onNavigate?.('projects')}
              className="px-6 py-2 bg-red-600 text-white rounded-xl text-[10px] font-black uppercase tracking-widest hover:bg-red-700 transition-all shadow-lg shadow-red-200 dark:shadow-none"
            >
               {language === 'tr' ? 'HEMEN İNCELE' : 'REVIEW NOW'}
            </button>
        </div>
      )}

      <div className="flex flex-col md:flex-row md:items-end justify-between gap-4">
        <div>
           <h1 className="text-4xl font-black text-slate-900 dark:text-white tracking-tighter italic">PanimoCloud <span className="text-indigo-600">ERP</span></h1>
           <p className="text-xs font-black text-slate-400 uppercase tracking-[0.3em]">{language === 'tr' ? 'STRATEJİK YÖNETİM MERKEZİ' : 'STRATEGIC MANAGEMENT HUB'}</p>
        </div>
        <div className="flex items-center gap-2 px-4 py-2 bg-white dark:bg-slate-900 border border-slate-100 dark:border-slate-800 rounded-2xl shadow-sm self-start">
            <Calendar size={14} className="text-slate-400" />
            <span className="text-xs font-black text-slate-600 dark:text-slate-300 uppercase tracking-wider">{new Date().toLocaleDateString(language === 'tr' ? 'tr-TR' : 'en-US', { day: 'numeric', month: 'long', year: 'numeric' })}</span>
        </div>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 lg:gap-8">
        {stats.map((stat, i) => (
          <div key={i} className={`p-4 lg:p-5 rounded-[32px] flex flex-col gap-4 lg:gap-4 ${i === 0 ? 'bg-slate-900 dark:bg-indigo-600 text-white' : 'bg-white dark:bg-slate-900 text-slate-900 dark:text-white border border-slate-100 dark:border-slate-800 shadow-sm'} transition-transform hover:-translate-y-1 shadow-sm`}>
            <div className={`w-10 h-10 lg:w-12 lg:h-12 rounded-2xl flex items-center justify-center ${i === 0 ? 'bg-white/10' : 'bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-white shadow-inner'}`}>
              {stat.icon}
            </div>
            <div>
              <p className={`text-[9px] lg:text-[10px] font-black uppercase tracking-widest mb-1 ${i === 0 ? 'text-slate-400 dark:text-indigo-100' : 'text-slate-500 dark:text-slate-400'}`}>{stat.label}</p>
              <h3 className="text-xl lg:text-3xl font-black tracking-tighter">{stat.value}</h3>
            </div>
          </div>
        ))}
      </div>

      {/* HR KPI SECTION */}
      {(() => {
        const d = new Date();
        const year = d.getFullYear();
        const month = String(d.getMonth() + 1).padStart(2, '0');
        const day = String(d.getDate()).padStart(2, '0');
        const todayStr = `${year}-${month}-${day}`;
        const activeSessions = attendance.filter(r => !r.clockOut && r.date === todayStr).length;
        const pendingLeaves = leaveRequests.filter(l => l.status === 'Pending').length;
        const overdueTasks = tasks.filter(t => t.deadline && new Date(t.deadline) < new Date() && t.status !== TaskStatus.DONE).length;
        const approvedLeavesToday = leaveRequests.filter(l => l.status === 'Approved' && l.startDate <= todayStr && l.endDate >= todayStr).length;

        const hrStats = [
          { label: language === 'tr' ? 'Şu An Çalışıyor' : 'Currently Working', value: activeSessions, icon: <UserCheck size={20} />, color: 'text-green-600', bg: 'bg-green-50 dark:bg-green-900/20', border: 'border-green-100 dark:border-green-900/30' },
          { label: language === 'tr' ? 'Bekleyen İzin' : 'Pending Leave', value: pendingLeaves, icon: <Calendar size={20} />, color: 'text-amber-600', bg: 'bg-amber-50 dark:bg-amber-900/20', border: 'border-amber-100 dark:border-amber-900/30' },
          { label: language === 'tr' ? 'Geciken Görev' : 'Overdue Tasks', value: overdueTasks, icon: <AlertTriangle size={20} />, color: 'text-red-600', bg: 'bg-red-50 dark:bg-red-900/20', border: 'border-red-100 dark:border-red-900/30' },
          { label: language === 'tr' ? 'Bugün İzinli' : 'On Leave Today', value: approvedLeavesToday, icon: <CalendarCheck size={20} />, color: 'text-indigo-600', bg: 'bg-indigo-50 dark:bg-indigo-900/20', border: 'border-indigo-100 dark:border-indigo-900/30' },
        ];

        return (
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
            {hrStats.map((stat, i) => (
              <div key={i} className={`p-3 rounded-[28px] border flex items-center gap-4 transition-all hover:-translate-y-0.5 hover:shadow-md bg-white dark:bg-slate-900 ${stat.border}`}>
                <div className={`w-12 h-12 rounded-2xl flex items-center justify-center shrink-0 ${stat.bg} ${stat.color}`}>
                  {stat.icon}
                </div>
                <div>
                  <p className="text-[10px] font-black uppercase tracking-widest text-slate-400 mb-1">{stat.label}</p>
                  <p className={`text-2xl font-black ${stat.color}`}>{stat.value}</p>
                </div>
              </div>
            ))}
          </div>
        );
      })()}

      {/* CHARTS SECTION */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-4">
        {/* CASH FLOW */}
        <div className="lg:col-span-8 bg-white dark:bg-slate-900 p-8 rounded-[48px] border border-slate-100 dark:border-slate-800 shadow-sm relative overflow-hidden">
          <div className="flex items-center justify-between mb-4">
             <div className="flex items-center gap-3">
                <div className="p-3 bg-indigo-600 text-white rounded-2xl"><TrendingUp size={18} /></div>
                <h3 className="text-xl font-black text-slate-900 dark:text-white tracking-tight">{language === 'tr' ? 'Nakit Akışı' : 'Cash Flow'}</h3>
             </div>
             <div className="flex items-center gap-4">
                <div className="flex items-center gap-2">
                   <div className="w-3 h-3 rounded-full bg-indigo-600"></div>
                   <span className="text-[10px] font-black text-slate-500 uppercase">{t.income}</span>
                </div>
                <div className="flex items-center gap-2">
                   <div className="w-3 h-3 rounded-full bg-slate-300"></div>
                   <span className="text-[10px] font-black text-slate-500 uppercase">{t.expense}</span>
                </div>
             </div>
          </div>
          <div className="h-[280px]">
             <ResponsiveContainer width="100%" height="100%">
               <AreaChart data={cashFlowData}>
                 <defs>
                   <linearGradient id="colorIncome" x1="0" y1="0" x2="0" y2="1">
                     <stop offset="5%" stopColor="#6366f1" stopOpacity={0.3}/>
                     <stop offset="95%" stopColor="#6366f1" stopOpacity={0}/>
                   </linearGradient>
                 </defs>
                 <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="var(--chart-grid)" />
                 <XAxis dataKey="name" fontSize={10} fontWeight={800} axisLine={false} tickLine={false} tick={{fill: 'var(--chart-text)'}} dy={10} />
                 <YAxis fontSize={10} fontWeight={800} axisLine={false} tickLine={false} tick={{fill: 'var(--chart-text)'}} hide={!showFinancials} />
                 <Tooltip 
                   cursor={{ stroke: '#6366f1', strokeWidth: 1 }}
                   contentStyle={{ borderRadius: '24px', border: 'none', backgroundColor: 'var(--tooltip-bg, #fff)', boxShadow: '0 25px 50px -12px rgba(0, 0, 0, 0.15)', padding: '16px' }}
                   formatter={(value: any) => showFinancials ? `$${value.toLocaleString()}` : '**'}
                 />
                 <Area type="monotone" dataKey="income" stroke="#6366f1" strokeWidth={4} fillOpacity={1} fill="url(#colorIncome)" />
                 <Area type="monotone" dataKey="expense" stroke="#cbd5e1" strokeWidth={4} fill="none" strokeDasharray="8 8" />
               </AreaChart>
             </ResponsiveContainer>
          </div>
        </div>

        {/* EXPENSE CATEGORIES */}
        <div className="lg:col-span-4 bg-white dark:bg-slate-900 p-8 rounded-[48px] border border-slate-100 dark:border-slate-800 shadow-sm flex flex-col">
          <h3 className="text-xl font-black text-slate-900 dark:text-white mb-4">{language === 'tr' ? 'Gider Dağılımı' : 'Expense Distribution'}</h3>
          <div className="flex-1 min-h-[250px]">
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie data={categoryData} cx="50%" cy="50%" innerRadius={60} outerRadius={85} paddingAngle={8} dataKey="value" stroke="none">
                  {categoryData.map((entry, index) => <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />)}
                </Pie>
                <Tooltip formatter={(value: any) => showFinancials ? `$${value.toLocaleString()}` : '**'} />
              </PieChart>
            </ResponsiveContainer>
          </div>
          <div className="mt-4 space-y-2">
            {categoryData.map((stat, i) => (
              <div key={i} className="flex items-center justify-between text-xs font-bold">
                <div className="flex items-center gap-2">
                   <div className="w-2 h-2 rounded-full" style={{ backgroundColor: COLORS[i % COLORS.length] }}></div>
                   <span className="text-slate-500 dark:text-slate-400">{stat.name}</span>
                </div>
                <span className="text-slate-900 dark:text-white">{showFinancials ? `$${stat.value.toLocaleString()}` : '**'}</span>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* NEW ANALYTICS SECTION */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-4">
        <div className="lg:col-span-8">
          <FinancialForecastView transactions={transactions} projects={projects} language={language} rates={rates} />
        </div>
        <div className="lg:col-span-4 space-y-8">
           <WorkloadHeatmap tasks={tasks} users={users} language={language} />
           <div className="bg-white dark:bg-slate-900 p-6 rounded-[40px] border border-slate-100 dark:border-slate-800 shadow-sm flex flex-col h-auto">
              <h3 className="text-sm font-black text-slate-900 dark:text-white mb-4 flex items-center gap-3">
                <div className="w-1 h-6 bg-amber-500 rounded-full" />
                {language === 'tr' ? 'Hızlı Aksiyonlar' : 'Quick Actions'}
              </h3>
              <div className="flex flex-col gap-2">
                 <button 
                   onClick={() => onNavigate?.('proposal')}
                   className="p-3 bg-slate-50 dark:bg-slate-800/50 rounded-2xl border border-slate-100 dark:border-slate-800 hover:border-indigo-500 transition-all text-left group flex items-center gap-3"
                 >
                    <div className="p-2 bg-white dark:bg-slate-900 rounded-lg shadow-sm">
                      <Zap size={14} className="text-indigo-600 group-hover:scale-110 transition-transform" />
                    </div>
                    <h4 className="font-black text-[10px] text-slate-900 dark:text-white uppercase tracking-widest">{language === 'tr' ? 'Teklif Oluştur' : 'Create Proposal'}</h4>
                 </button>
                 <button 
                   onClick={() => onNavigate?.('clientportal')}
                   className="p-3 bg-slate-50 dark:bg-slate-800/50 rounded-2xl border border-slate-100 dark:border-slate-800 hover:border-emerald-500 transition-all text-left group flex items-center gap-3"
                 >
                    <div className="p-2 bg-white dark:bg-slate-900 rounded-lg shadow-sm">
                      <CalendarCheck size={14} className="text-emerald-600 group-hover:scale-110 transition-transform" />
                    </div>
                    <h4 className="font-black text-[10px] text-slate-900 dark:text-white uppercase tracking-widest">{language === 'tr' ? 'Müşteri Özeti' : 'Client Insight'}</h4>
                 </button>
              </div>
           </div>
        </div>
      </div>

      {/* TASK & PROJECT PROGRESS */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-4">
        <div className="lg:col-span-4 bg-white dark:bg-slate-900 p-8 rounded-[48px] border border-slate-100 dark:border-slate-800 shadow-sm">
          <h3 className="text-xl font-black text-slate-900 dark:text-white mb-8">{t.task_dist}</h3>
          <div className="h-64">
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie data={taskStats} cx="50%" cy="50%" innerRadius={60} outerRadius={80} paddingAngle={4} dataKey="value">
                  {taskStats.map((entry, index) => <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />)}
                </Pie>
                <Tooltip />
              </PieChart>
            </ResponsiveContainer>
          </div>
          <div className="grid grid-cols-2 gap-3 mt-6">
            {taskStats.map((stat, i) => (
              <div key={i} className="p-3 rounded-2xl bg-slate-50 dark:bg-slate-800 border border-slate-100 dark:border-slate-800">
                <p className="text-[9px] font-black uppercase text-slate-400 mb-1">{stat.name}</p>
                <span className="text-lg font-black text-slate-900 dark:text-white">{stat.value}</span>
              </div>
            ))}
          </div>
        </div>

        <div className="lg:col-span-8 bg-white dark:bg-slate-900 p-8 rounded-[48px] border border-slate-100 dark:border-slate-800 shadow-sm">
          <h3 className="text-xl font-black text-slate-900 dark:text-white mb-8">{t.project_prog}</h3>
          <div className="h-[280px]">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={activeProjects}>
                <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="var(--chart-grid)" />
                <XAxis dataKey="name" fontSize={9} fontWeight={800} axisLine={false} tickLine={false} tick={{fill: 'var(--chart-text)'}} />
                <YAxis fontSize={9} fontWeight={800} axisLine={false} tickLine={false} tick={{fill: 'var(--chart-text)'}} hide={!showFinancials} />
                <Tooltip cursor={{fill: 'transparent'}} formatter={(value: any) => showFinancials ? value : '**'} />
                <Bar dataKey="progress" fill="#6366f1" radius={[12, 12, 12, 12]} barSize={40} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>
      </div>

      {/* RECENT PROJECTS TABLE */}
      <div className="bg-white dark:bg-slate-900 rounded-[48px] border border-slate-100 dark:border-slate-800 overflow-hidden shadow-sm">
        <div className="p-8 border-b border-slate-50 dark:border-slate-800">
          <h3 className="text-xl font-black text-slate-900 dark:text-white tracking-tight">{t.recent_projects}</h3>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full text-left">
            <thead className="bg-slate-50/50 dark:bg-slate-800/50 text-[10px] uppercase text-slate-400 font-black tracking-[0.2em]">
              <tr>
                <th className="px-10 py-6">{t.projects}</th>
                <th className="px-10 py-6">{t.client}</th>
                <th className="px-10 py-6">{t.delivery_date}</th>
                <th className="px-10 py-6">{t.status}</th>
                <th className="px-10 py-6 text-right">{t.budget}</th>
                <th className="px-10 py-6">{t.progress}</th>
                <th className="px-10 py-6 text-right">Portal</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-50 dark:divide-slate-800 text-sm font-medium">
              {activeProjects.map(p => {
                const approaching = isApproaching(p.deliveryDate);
                return (
                  <tr key={p.id} className="hover:bg-slate-50/50 dark:hover:bg-slate-800/30 transition-colors">
                    <td className="px-10 py-6">
                       <div className="flex items-center gap-4">
                          <div className="w-10 h-10 rounded-xl bg-slate-100 dark:bg-slate-800 flex items-center justify-center font-black text-xs text-slate-950 dark:text-white">
                             {p.name.charAt(0)}
                          </div>
                          <span className="font-black text-slate-900 dark:text-white">{p.name}</span>
                       </div>
                    </td>
                    <td className="px-10 py-6 text-slate-600 dark:text-slate-300 font-bold">{p.client}</td>
                    <td className="px-10 py-6">
                       <div className={`flex items-center gap-2 text-[10px] font-black ${approaching ? 'text-red-600' : 'text-amber-600'}`}>
                          <Calendar size={14} />
                          {p.deliveryDate || '---'}
                       </div>
                    </td>
                    <td className="px-10 py-6">
                      <span className={`px-4 py-1.5 rounded-full text-[9px] font-black uppercase tracking-widest ${p.status === 'Active' ? 'bg-indigo-600 text-white' : 'bg-slate-100 dark:bg-slate-800 text-slate-500'}`}>
                        {p.status === 'Active' ? t.doing : p.status}
                      </span>
                    </td>
                    <td className="px-10 py-6 font-black text-slate-900 dark:text-white text-right text-lg">
                      {showFinancials ? <>${Math.round(convertToUSD(p.budget, p.currency)).toLocaleString()}</> : '**'}
                    </td>
                    <td className="px-10 py-6">
                      <div className="w-40 bg-slate-100 dark:bg-slate-800 rounded-full h-2 overflow-hidden">
                        <div className={`h-full rounded-full transition-all duration-1000 ${approaching ? 'bg-red-500' : 'bg-indigo-600'}`} style={{ width: `${p.progress}%` }}></div>
                      </div>
                    </td>
                    <td className="px-10 py-6 text-right">
                      <button 
                        onClick={() => onNavigate?.('clientportal', p.id)}
                        className="p-2 hover:bg-slate-100 dark:hover:bg-slate-800 rounded-lg text-indigo-600 transition-colors"
                        title={language === 'tr' ? 'Müşteri Portalı Linki' : 'Client Portal Link'}
                      >
                         <ExternalLink size={16} />
                      </button>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};

export default DashboardView;
