import React, { useEffect, useMemo, useState } from 'react';
import { collection, query, orderBy, limit, startAfter, where, getDocs, getCountFromServer, documentId, QueryDocumentSnapshot } from 'firebase/firestore';
import { db, app } from '../firebase';
import { getFunctions, httpsCallable } from 'firebase/functions';
import { doc, setDoc } from 'firebase/firestore';
import { ChevronLeft, ChevronRight, Users, Send, Settings2, History, Plus, Smartphone, CheckCircle2, AlertCircle, MessageSquare, Check, Edit2, Sparkles, FileText, Wallet, Loader2, Eye, EyeOff, RefreshCw, Building2, RotateCcw } from 'lucide-react';
import { Customer, SMSConfig, SMSLog, SMSTemplate } from '../types';
import { askCopilot } from '../services/aiService';
import { PageHeader, KpiGrid, SearchBox, Segmented, Field, EmptyState, DeleteButton, Sheet, Avatar, inputCls, selectSm, cardCls, btnPrimary, btnGhost } from './ui/Kit';
import { toast } from '../services/toast';

interface Props {
  language: 'tr' | 'en';
  customers: Customer[];
  smsConfig: SMSConfig;
  smsLogs?: SMSLog[]; // kullanılmıyor: geçmiş sayfa sayfa sunucudan çekilir
  smsTemplates: SMSTemplate[];
  onAddCustomer: (customer: Customer) => Promise<void>;
  onDeleteCustomer: (id: string) => Promise<void>;
  onSaveConfig: (config: SMSConfig) => Promise<void>;
  onAddLog: (log: SMSLog) => Promise<void>;
  onUpsertTemplate: (template: SMSTemplate) => Promise<void>;
  onDeleteTemplate: (id: string) => Promise<void>;
  onOpenCustomerModal: (customer?: Customer) => void;
}

type Tab = 'send' | 'customers' | 'history' | 'templates' | 'settings';
const PAGE = 10;
const VARS = ['[Müşteri Adı]', '[Firma Adı]', '[Telefon]'];
const cleanPhone = (p: string) => { let c = (p || '').replace(/\D/g, ''); if (c.startsWith('90')) c = c.slice(2); if (c.startsWith('0')) c = c.slice(1); return c; };
/** Türkçe karakter içeren mesajlar 70/67, diğerleri 160/153 karakterlik parçalara bölünür */
const segments = (text: string) => {
  if (!text) return { count: 0, per: 160 };
  const uni = /[^\x00-\x7F£¥èéùìòÇØøÅå_ÆæßÉ¤¡ÄÖÑÜ§¿äöñüà]/.test(text);
  const single = uni ? 70 : 160, multi = uni ? 67 : 153;
  return { count: text.length <= single ? 1 : Math.ceil(text.length / multi), per: text.length <= single ? single : multi };
};
const fill = (msg: string, c?: Customer | null) => !c ? msg : msg.replace(/\[Müşteri Adı\]/g, c.name).replace(/\[Firma Adı\]/g, c.company || '').replace(/\[Telefon\]/g, c.phone);
/** Eski kayıtlar tr-TR yerel biçiminde (gg.aa.yyyy ss:dd) — önce onu dene, sonra ISO */
const parseDate = (s: string) => {
  const m = (s || '').match(/^(\d{1,2})\.(\d{1,2})\.(\d{4})(?:\s+(\d{1,2}):(\d{2}))?/);
  if (m) return new Date(+m[3], +m[2] - 1, +m[1], +(m[4] || 0), +(m[5] || 0));
  const d = new Date(s);
  return isNaN(d.getTime()) ? null : d;
};

const CustomerSMSView: React.FC<Props> = ({ language, customers, smsConfig, smsTemplates, onDeleteCustomer, onSaveConfig, onAddLog, onUpsertTemplate, onDeleteTemplate, onOpenCustomerModal }) => {
  const tr = language === 'tr';
  const [tab, setTab] = useState<Tab>('send');
  const [cfg, setCfg] = useState<SMSConfig>(smsConfig || { usercode: '', password: '', msgheader: '' });
  useEffect(() => { if (smsConfig) setCfg(smsConfig); }, [smsConfig]);
  // Şifre istemcide tutulmaz (sms_secrets, okunamaz). hasPassword yalnızca kayıtlı olduğunu söyler; eski kayıtlarda şifre config içindeydi.
  const [newPw, setNewPw] = useState('');
  const hasPw = !!((cfg as any).hasPassword || cfg.password);
  const configured = !!(cfg.usercode && hasPw && cfg.msgheader);

  const [search, setSearch] = useState('');
  const [gender, setGender] = useState<'All' | 'Male' | 'Female'>('All');
  const [selected, setSelected] = useState<Set<string>>(new Set());
  const [manual, setManual] = useState('');
  const [msg, setMsg] = useState('');
  const [confirm, setConfirm] = useState(false);
  const [progress, setProgress] = useState<{ done: number; total: number } | null>(null);
  const [aiOpen, setAiOpen] = useState(false);
  const [aiPrompt, setAiPrompt] = useState('');
  const [aiBusy, setAiBusy] = useState(false);
  const [tpl, setTpl] = useState<Partial<SMSTemplate> | null>(null);
  const [showPw, setShowPw] = useState(false);
  const [balance, setBalance] = useState<string | null>(null);
  const [balBusy, setBalBusy] = useState(false);
  const [logF, setLogF] = useState<'all' | 'Sent' | 'Failed'>('all');
  const [custPage, setCustPage] = useState(0);
  // Geçmiş: sunucudan 10'ar kayıt. Belge kimliği zaman damgası içerdiği için kimliğe göre azalan sıra = en yeni önce
  const [logs, setLogs] = useState<SMSLog[]>([]);
  const [logPage, setLogPage] = useState(0);
  const [cursors, setCursors] = useState<QueryDocumentSnapshot[]>([]);
  const [hasNext, setHasNext] = useState(false);
  const [logBusy, setLogBusy] = useState(false);
  const [logErr, setLogErr] = useState<string | null>(null);
  const [counts, setCounts] = useState<{ total: number; failed: number; month: number } | null>(null);

  const q = search.trim().toLocaleLowerCase('tr-TR');
  const filtered = useMemo(() => customers.filter(c => (gender === 'All' || c.gender === gender) && (!q || [c.name, c.company, c.phone, c.email].join(' ').toLocaleLowerCase('tr-TR').includes(q))).sort((a, b) => a.name.localeCompare(b.name, 'tr')), [customers, gender, q]);
  const allSel = filtered.length > 0 && filtered.every(c => selected.has(c.id));
  const recipients: { phone: string; customer: Customer | null }[] = [
    ...customers.filter(c => selected.has(c.id)).map(c => ({ phone: c.phone, customer: c })),
    ...manual.split(/[\s,;]+/).map(p => p.trim()).filter(p => cleanPhone(p).length === 10).map(p => ({ phone: p, customer: null })),
  ];
  const seg = segments(fill(msg, recipients[0]?.customer));
  const credits = recipients.reduce((a, r) => a + segments(fill(msg, r.customer)).count, 0);

  const loadLogs = async (page: number, status = logF, cur = cursors) => {
    setLogBusy(true); setLogErr(null);
    try {
      const parts: any[] = [];
      if (status !== 'all') parts.push(where('status', '==', status));
      parts.push(orderBy(documentId(), 'desc'));
      if (page > 0 && cur[page - 1]) parts.push(startAfter(cur[page - 1]));
      parts.push(limit(PAGE + 1));
      const snap = await getDocs(query(collection(db, 'sms_logs'), ...parts));
      const docs = snap.docs.slice(0, PAGE);
      setLogs(docs.map(d => ({ ...(d.data() as SMSLog), id: d.id })));
      setHasNext(snap.docs.length > PAGE);
      const next = cur.slice(0, page); if (docs.length) next[page] = docs[docs.length - 1]; setCursors(next);
      setLogPage(page);
    } catch (e: any) {
      console.error(e);
      setLogErr(e?.code === 'failed-precondition' ? (tr ? 'Bu filtre için Firestore dizini gerekiyor: firebase deploy --only firestore:indexes' : 'Index required.') : (tr ? 'Geçmiş yüklenemedi.' : 'Could not load history.'));
      setLogs([]); setHasNext(false);
    } finally { setLogBusy(false); }
  };
  const loadCounts = async () => {
    try {
      const col = collection(db, 'sms_logs');
      const n = new Date(); const monthStart = 'l' + new Date(n.getFullYear(), n.getMonth(), 1).getTime();
      const [t, fl, m] = await Promise.all([
        getCountFromServer(col),
        getCountFromServer(query(col, where('status', '==', 'Failed'))),
        getCountFromServer(query(col, where(documentId(), '>=', monthStart), where(documentId(), '<', 'm'))),
      ]);
      setCounts({ total: t.data().count, failed: fl.data().count, month: m.data().count });
    } catch (e) { console.error(e); }
  };
  useEffect(() => { loadCounts(); }, []); // eslint-disable-line react-hooks/exhaustive-deps
  useEffect(() => { if (tab === 'history') loadLogs(0, logF, []); }, [tab, logF]); // eslint-disable-line react-hooks/exhaustive-deps
  useEffect(() => { setCustPage(0); }, [search, gender]);
  const failRate = counts?.total ? Math.round((counts.failed / counts.total) * 100) : 0;
  const custPages = Math.max(1, Math.ceil(filtered.length / PAGE));
  const custRows = filtered.slice(custPage * PAGE, custPage * PAGE + PAGE);
  const pager = (o: { page: number; canPrev: boolean; canNext: boolean; onPrev: () => void; onNext: () => void; label: string; busy?: boolean }) => (
    <div className="flex items-center gap-2 px-4 py-2.5 border-t border-slate-100 dark:border-slate-800">
      <span className="text-[11px] text-slate-400 flex-1">{o.label}</span>
      {o.busy && <Loader2 size={14} className="animate-spin text-slate-400" />}
      <button disabled={!o.canPrev || o.busy} onClick={o.onPrev} className="h-8 w-8 rounded-lg border border-slate-200 dark:border-slate-700 flex items-center justify-center text-slate-500 hover:text-indigo-600 disabled:opacity-30"><ChevronLeft size={15} /></button>
      <span className="text-xs font-semibold text-slate-600 dark:text-slate-300 min-w-[24px] text-center">{o.page + 1}</span>
      <button disabled={!o.canNext || o.busy} onClick={o.onNext} className="h-8 w-8 rounded-lg border border-slate-200 dark:border-slate-700 flex items-center justify-center text-slate-500 hover:text-indigo-600 disabled:opacity-30"><ChevronRight size={15} /></button>
    </div>
  );

  const fetchBalance = async () => {
    setBalBusy(true);
    try {
      const res = await httpsCallable<unknown, { balance: string | null }>(getFunctions(app), 'smsBalance')({});
      setBalance(res.data.balance ?? (tr ? 'Alınamadı' : 'Unavailable'));
    } catch { setBalance(tr ? 'Alınamadı' : 'Unavailable'); } finally { setBalBusy(false); }
  };
  useEffect(() => { if (configured) fetchBalance(); }, []); // eslint-disable-line react-hooks/exhaustive-deps

  const send = async () => {
    setConfirm(false);
    let ok = 0, fail = 0;
    const all = recipients.map(r => ({ to: r.phone, message: fill(msg, r.customer) }));
    setProgress({ done: 0, total: all.length });
    const fn = httpsCallable<{ messages: { to: string; message: string }[] }, { results: { to: string; status: 'Sent' | 'Failed' }[] }>(getFunctions(app), 'sendSms');
    try {
      for (let i = 0; i < all.length; i += 20) {
        const chunk = all.slice(i, i + 20);
        const res = await fn({ messages: chunk });
        res.data.results.forEach(r => (r.status === 'Sent' ? ok++ : fail++));
        setProgress(p => p && { ...p, done: Math.min(p.total, p.done + chunk.length) });
      }
    } catch (e: any) {
      toast.error(e?.message || (tr ? 'Gönderim başarısız' : 'Send failed'));
    }
    setProgress(null);
    if (ok + fail === 0) return;
    if (fail === 0) { toast.success(tr ? `${ok} SMS gönderildi` : `${ok} sent`); setMsg(''); setSelected(new Set()); setManual(''); }
    else toast.warning(tr ? `${ok} başarılı, ${fail} başarısız · ayrıntılar Geçmiş sekmesinde` : `${ok} ok, ${fail} failed`);
    fetchBalance(); loadCounts(); if (tab === 'history') loadLogs(0, logF, []);
  };
  const trySend = () => {
    if (!configured) { toast.warning(tr ? 'Önce Ayarlar sekmesinden Netgsm bilgilerini girin' : 'Configure Netgsm first'); setTab('settings'); return; }
    if (!recipients.length) { toast.warning(tr ? 'En az bir alıcı seçin veya numara yazın' : 'Pick recipients'); return; }
    if (!msg.trim()) { toast.warning(tr ? 'Mesaj boş olamaz' : 'Message is empty'); return; }
    setConfirm(true);
  };
  const genAI = async () => {
    if (!aiPrompt.trim()) return;
    setAiBusy(true);
    try { setMsg(String(await askCopilot(`${aiPrompt}\n(Kısa bir SMS metni yaz; en fazla 300 karakter, emoji kullanma. Değişken olarak [Müşteri Adı] kullanabilirsin.)`, { context: 'SMS Mesaj Taslağı Oluşturma' }, language)).trim()); setAiOpen(false); setAiPrompt(''); }
    catch { toast.error(tr ? 'Yapay zekâ taslak üretemedi' : 'AI failed'); } finally { setAiBusy(false); }
  };

  const fmtDate = (s: string) => { const d = parseDate(s); return d ? d.toLocaleString('tr-TR', { day: 'numeric', month: 'short', hour: '2-digit', minute: '2-digit' }) : s; };

  const recipientList = (
    <div className={`${cardCls} lg:col-span-2 overflow-hidden flex flex-col`}>
      <div className="p-3 space-y-2 border-b border-slate-100 dark:border-slate-800">
        <SearchBox value={search} onChange={setSearch} placeholder={tr ? 'Müşteri ara…' : 'Search…'} />
        <div className="flex items-center gap-2">
          <Segmented<'All' | 'Male' | 'Female'> value={gender} onChange={setGender} options={[{ value: 'All', label: tr ? 'Hepsi' : 'All' }, { value: 'Male', label: tr ? 'Erkek' : 'Male' }, { value: 'Female', label: tr ? 'Kadın' : 'Female' }]} />
          <button onClick={() => { const n = new Set(selected); filtered.forEach(c => allSel ? n.delete(c.id) : n.add(c.id)); setSelected(n); }} className="ml-auto text-[11px] font-semibold text-indigo-600 hover:underline">{allSel ? (tr ? 'Seçimi kaldır' : 'Clear') : (tr ? `Tümünü seç (${filtered.length})` : 'Select all')}</button>
        </div>
      </div>
      <div className="flex-1 max-h-[460px] overflow-y-auto custom-scrollbar divide-y divide-slate-100 dark:divide-slate-800">
        {filtered.length === 0 ? <EmptyState icon={Users} text={tr ? 'Müşteri yok' : 'No customers'} /> : filtered.map(c => { const on = selected.has(c.id); return (
          <button key={c.id} onClick={() => { const n = new Set(selected); on ? n.delete(c.id) : n.add(c.id); setSelected(n); }} className={`w-full text-left px-3 py-2.5 flex items-center gap-3 transition-colors ${on ? 'bg-indigo-50/70 dark:bg-indigo-500/10' : 'hover:bg-slate-50/70 dark:hover:bg-white/[0.02]'}`}>
            <span className={`w-5 h-5 rounded-md border flex items-center justify-center shrink-0 transition-colors ${on ? 'bg-indigo-600 border-indigo-600 text-white' : 'border-slate-300 dark:border-slate-600'}`}>{on && <Check size={12} />}</span>
            <div className="min-w-0 flex-1"><p className="text-sm font-semibold text-slate-800 dark:text-slate-100 truncate">{c.name}</p><p className="text-[11px] text-slate-400 truncate">{c.phone}{c.company ? ` · ${c.company}` : ''}</p></div>
          </button>); })}
      </div>
    </div>
  );

  return (
    <div className="space-y-5 pb-10">
      <PageHeader title={tr ? 'Müşteri SMS' : 'Customer SMS'} subtitle={tr ? 'Netgsm üzerinden toplu ve kişiselleştirilmiş SMS gönderimi.' : 'Bulk, personalised SMS via Netgsm.'}
        actions={<button onClick={() => onOpenCustomerModal()} className={btnGhost}><Plus size={15} />{tr ? 'Müşteri ekle' : 'Add customer'}</button>} />

      <KpiGrid items={[
        { label: tr ? 'Müşteri' : 'Customers', value: customers.length, icon: Users, grad: 'from-indigo-500 to-violet-600', sub: `${customers.filter(c => c.gender === 'Female').length} ${tr ? 'kadın' : 'F'} · ${customers.filter(c => c.gender === 'Male').length} ${tr ? 'erkek' : 'M'}`, onClick: () => setTab('customers'), active: tab === 'customers' },
        { label: tr ? 'Bu ay gönderim' : 'This month', value: counts?.month ?? 0, icon: Send, grad: 'from-emerald-500 to-teal-600', sub: counts ? `${counts.total} ${tr ? 'toplam kayıt' : 'total'}` : '…', onClick: () => setTab('history'), active: tab === 'history' },
        { label: tr ? 'Başarısız oranı' : 'Failure rate', value: failRate, format: n => `%${n}`, icon: AlertCircle, grad: 'from-rose-500 to-red-600', bar: failRate, onClick: () => { setTab('history'); setLogF('Failed'); } },
        { label: tr ? 'Netgsm bakiyesi' : 'Balance', value: 0, format: () => balance ?? (configured ? '…' : (tr ? 'Ayarlanmadı' : 'Not set')), icon: Wallet, grad: 'from-amber-500 to-orange-600', sub: configured ? cfg.msgheader : (tr ? 'Ayarlar sekmesi' : 'See settings'), onClick: () => configured ? fetchBalance() : setTab('settings') },
      ]} />

      <div className={`${cardCls} p-2`}>
        <Segmented<Tab> value={tab} onChange={setTab} options={[
          { value: 'send', label: <><Send size={14} />{tr ? 'Gönder' : 'Send'}</> }, { value: 'customers', label: <><Users size={14} />{tr ? 'Müşteriler' : 'Customers'}</> },
          { value: 'history', label: <><History size={14} />{tr ? 'Geçmiş' : 'History'}</> }, { value: 'templates', label: <><FileText size={14} />{tr ? 'Şablonlar' : 'Templates'}</> },
          { value: 'settings', label: <><Settings2 size={14} />{tr ? 'Ayarlar' : 'Settings'}{!configured && <span className="w-1.5 h-1.5 rounded-full bg-rose-500" />}</> },
        ]} />
      </div>

      <div key={tab} className="animate-in fade-in duration-300">
        {tab === 'send' && (
          <div className="grid grid-cols-1 lg:grid-cols-5 gap-4 items-start">
            {recipientList}
            <div className={`${cardCls} lg:col-span-3 p-4 space-y-4`}>
              <Field label={tr ? 'Ek numaralar' : 'Extra numbers'} hint={tr ? 'Virgülle ayırın · 05xx…' : 'Comma separated'}><input className={inputCls()} value={manual} onChange={e => setManual(e.target.value)} placeholder="05xx xxx xx xx, …" /></Field>
              <div className="flex flex-wrap gap-1.5 items-center">
                <span className="text-xs font-semibold text-slate-500 mr-1">{tr ? 'Alıcılar' : 'Recipients'}</span>
                {recipients.length === 0 ? <span className="text-xs text-slate-400">{tr ? 'Henüz seçilmedi' : 'None'}</span> : <>
                  {recipients.slice(0, 6).map((r, i) => <span key={i} className="h-6 px-2 rounded-md bg-indigo-50 dark:bg-indigo-500/10 text-[11px] font-semibold text-indigo-700 dark:text-indigo-300">{r.customer?.name || r.phone}</span>)}
                  {recipients.length > 6 && <span className="text-[11px] text-slate-400">+{recipients.length - 6}</span>}
                </>}
              </div>
              {smsTemplates.length > 0 && <div className="flex flex-wrap gap-1.5">{smsTemplates.map(t => <button key={t.id} onClick={() => setMsg(t.content)} className="h-7 px-2.5 rounded-lg border border-slate-200 dark:border-slate-700 text-[11px] font-semibold text-slate-600 dark:text-slate-300 hover:border-indigo-300 hover:text-indigo-600 inline-flex items-center gap-1"><FileText size={11} />{t.title}</button>)}</div>}
              <div>
                <textarea rows={6} className={inputCls() + ' !h-auto py-3 resize-none'} value={msg} onChange={e => setMsg(e.target.value)} placeholder={tr ? 'Mesajınızı yazın… [Müşteri Adı] gibi değişkenler kişiye göre doldurulur.' : 'Write your message…'} />
                <div className="flex flex-wrap items-center gap-1.5 mt-2">
                  {VARS.map(v => <button key={v} onClick={() => setMsg(m => m + v)} className="h-7 px-2 rounded-lg bg-slate-100 dark:bg-white/5 text-[11px] font-mono text-slate-600 dark:text-slate-300 hover:bg-indigo-50 hover:text-indigo-600">{v}</button>)}
                  <button onClick={() => setAiOpen(true)} className="h-7 px-2 rounded-lg text-[11px] font-semibold text-violet-700 bg-violet-50 hover:bg-violet-100 dark:bg-violet-500/10 dark:text-violet-300 inline-flex items-center gap-1"><Sparkles size={11} />{tr ? 'AI ile yaz' : 'AI draft'}</button>
                  <span className={`ml-auto text-[11px] font-semibold ${seg.count > 1 ? 'text-amber-600' : 'text-slate-400'}`}>{msg.length} {tr ? 'karakter' : 'chars'} · {seg.count} SMS</span>
                </div>
              </div>
              {msg && recipients[0] && (
                <div className="rounded-2xl bg-slate-50 dark:bg-white/[0.03] p-3">
                  <p className="text-[10px] text-slate-400 mb-1.5 flex items-center gap-1"><Smartphone size={11} />{tr ? 'Önizleme' : 'Preview'} · {recipients[0].customer?.name || recipients[0].phone}</p>
                  <div className="max-w-sm rounded-2xl rounded-tl-sm bg-white dark:bg-slate-800 px-3 py-2 text-sm text-slate-700 dark:text-slate-200 shadow-sm whitespace-pre-wrap break-words"><p className="text-[10px] font-bold text-indigo-600 mb-0.5">{cfg.msgheader || 'BAŞLIK'}</p>{fill(msg, recipients[0].customer)}</div>
                </div>
              )}
              <button onClick={trySend} disabled={!!progress} className={btnPrimary + ' w-full !h-12'}>
                {progress ? <><Loader2 size={16} className="animate-spin" />{progress.done}/{progress.total} {tr ? 'gönderiliyor…' : 'sending…'}</> : <><Send size={16} />{recipients.length ? (tr ? `${recipients.length} kişiye gönder · ≈${credits} SMS` : `Send to ${recipients.length}`) : (tr ? 'Gönder' : 'Send')}</>}
              </button>
              {progress && <div className="h-1.5 rounded-full bg-slate-100 dark:bg-slate-800 overflow-hidden"><div className="h-full bg-indigo-500 transition-all" style={{ width: `${(progress.done / progress.total) * 100}%` }} /></div>}
            </div>
          </div>
        )}

        {tab === 'customers' && (
          <div className={`${cardCls} overflow-hidden`}>
            <div className="p-3 flex gap-2 border-b border-slate-100 dark:border-slate-800"><SearchBox value={search} onChange={setSearch} placeholder={tr ? 'Ad, firma, telefon ara…' : 'Search…'} /><button onClick={() => onOpenCustomerModal()} className={btnPrimary}><Plus size={15} />{tr ? 'Yeni' : 'New'}</button></div>
            {filtered.length === 0 ? <EmptyState icon={Users} text={tr ? 'Müşteri bulunamadı' : 'No customers'} /> : (
              <div className="divide-y divide-slate-100 dark:divide-slate-800 pc-stagger">
                {custRows.map(c => { return (
                  <div key={c.id} className="grid grid-cols-12 gap-3 items-center px-4 py-3 hover:bg-slate-50/70 dark:hover:bg-white/[0.02]">
                    <div className="col-span-12 sm:col-span-4 flex items-center gap-3 min-w-0"><Avatar name={c.name} /><div className="min-w-0"><p className="text-sm font-semibold text-slate-800 dark:text-slate-100 truncate">{c.name}</p><p className="text-[11px] text-slate-400 truncate flex items-center gap-1">{c.company && <><Building2 size={10} />{c.company}</>}</p></div></div>
                    <div className="col-span-6 sm:col-span-3 text-xs"><a href={`tel:${c.phone}`} className="text-slate-600 dark:text-slate-300 hover:text-indigo-600">{c.phone}</a>{c.email && <p className="text-[11px] text-slate-400 truncate">{c.email}</p>}</div>
                    <div className="col-span-6 sm:col-span-3 text-[11px] text-slate-400 truncate">{c.gender === 'Female' ? (tr ? 'Kadın' : 'Female') : c.gender === 'Male' ? (tr ? 'Erkek' : 'Male') : '—'}{c.notes ? ` · ${c.notes}` : ''}</div>
                    <div className="col-span-12 sm:col-span-2 flex justify-end items-center gap-1">
                      <button onClick={() => { setSelected(new Set([c.id])); setTab('send'); }} title={tr ? 'SMS gönder' : 'Send SMS'} className="p-1.5 rounded-lg text-slate-400 hover:text-indigo-600 hover:bg-indigo-50 dark:hover:bg-white/5"><Send size={14} /></button>
                      <button onClick={() => onOpenCustomerModal(c)} className="p-1.5 rounded-lg text-slate-400 hover:text-indigo-600 hover:bg-indigo-50 dark:hover:bg-white/5"><Edit2 size={14} /></button>
                      <DeleteButton language={language} onConfirm={async () => { await onDeleteCustomer(c.id); toast(tr ? 'Müşteri silindi' : 'Deleted', 'info'); }} />
                    </div>
                  </div>); })}
              </div>
            )}
            {filtered.length > PAGE && pager({ page: custPage, canPrev: custPage > 0, canNext: custPage < custPages - 1, onPrev: () => setCustPage(custPage - 1), onNext: () => setCustPage(custPage + 1), label: tr ? `${filtered.length} müşteriden ${custPage * PAGE + 1}–${Math.min(filtered.length, (custPage + 1) * PAGE)} · sayfa ${custPage + 1}/${custPages}` : `Page ${custPage + 1}/${custPages}` })}
          </div>
        )}

        {tab === 'history' && (
          <div className={`${cardCls} overflow-hidden`}>
            <div className="p-3 flex flex-col sm:flex-row gap-2 border-b border-slate-100 dark:border-slate-800">
              <Segmented<'all' | 'Sent' | 'Failed'> value={logF} onChange={setLogF} options={[{ value: 'all', label: tr ? 'Tümü' : 'All' }, { value: 'Sent', label: tr ? 'İletilen' : 'Sent' }, { value: 'Failed', label: tr ? 'Başarısız' : 'Failed' }]} />
              <button onClick={() => { loadLogs(0, logF, []); loadCounts(); }} className={btnGhost + ' !h-10 sm:ml-auto'}>{logBusy ? <Loader2 size={14} className="animate-spin" /> : <RefreshCw size={14} />}{tr ? 'Yenile' : 'Refresh'}</button>
            </div>
            {logErr ? <p className="p-6 text-sm text-rose-600">{logErr}</p> : (() => { const rows = logs; return rows.length === 0 ? (logBusy ? <div className="p-4 space-y-3">{[0, 1, 2].map(i => <div key={i} className="h-10 rounded-xl pc-skeleton" />)}</div> : <EmptyState icon={History} text={tr ? 'Kayıt yok' : 'No logs'} />) : (
              <div key={logPage} className={`divide-y divide-slate-100 dark:divide-slate-800 animate-in fade-in duration-200 ${logBusy ? 'opacity-50' : ''}`}>
                {rows.map(l => { const c = customers.find(x => cleanPhone(x.phone) === cleanPhone(l.to)); return (
                  <div key={l.id} className="px-4 py-3 flex gap-3 items-start hover:bg-slate-50/70 dark:hover:bg-white/[0.02]">
                    <span className={`mt-0.5 p-1.5 rounded-lg ${l.status === 'Sent' ? 'bg-emerald-50 text-emerald-600 dark:bg-emerald-500/10' : 'bg-rose-50 text-rose-600 dark:bg-rose-500/10'}`}>{l.status === 'Sent' ? <CheckCircle2 size={14} /> : <AlertCircle size={14} />}</span>
                    <div className="min-w-0 flex-1"><p className="text-xs"><b className="text-slate-800 dark:text-slate-100">{c?.name || l.to}</b>{c && <span className="text-slate-400"> · {l.to}</span>}<span className="text-slate-400"> · {fmtDate(l.date)}</span></p><p className="text-sm text-slate-600 dark:text-slate-300 break-words line-clamp-2">{l.message}</p></div>
                    {l.status === 'Failed' && <button onClick={() => { setMsg(l.message); setManual(c ? '' : l.to); setSelected(c ? new Set([c.id]) : new Set()); setTab('send'); }} title={tr ? 'Yeniden dene' : 'Retry'} className="p-1.5 rounded-lg text-slate-400 hover:text-indigo-600 hover:bg-indigo-50 dark:hover:bg-white/5"><RotateCcw size={14} /></button>}
                  </div>); })}
              </div>
            ); })()}
            {!logErr && (logPage > 0 || hasNext) && pager({ page: logPage, busy: logBusy, canPrev: logPage > 0, canNext: hasNext, onPrev: () => loadLogs(logPage - 1), onNext: () => loadLogs(logPage + 1), label: tr ? `Sayfa ${logPage + 1} · sayfa başına ${PAGE} kayıt${logF === 'all' && counts ? ` · toplam ${counts.total}` : ''}` : `Page ${logPage + 1}` })}
          </div>
        )}

        {tab === 'templates' && (
          <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-3 gap-3 pc-stagger">
            <button onClick={() => setTpl({ title: '', content: '' })} className="rounded-[20px] border-2 border-dashed border-slate-200 dark:border-slate-700 p-6 flex flex-col items-center justify-center gap-2 text-slate-400 hover:text-indigo-600 hover:border-indigo-300 min-h-[140px]"><Plus size={22} /><span className="text-sm font-semibold">{tr ? 'Yeni şablon' : 'New template'}</span></button>
            {smsTemplates.map(t => (
              <div key={t.id} className={`${cardCls} p-4 flex flex-col gap-2 pc-lift`}>
                <div className="flex items-center gap-2"><FileText size={15} className="text-indigo-500" /><p className="text-sm font-bold text-slate-800 dark:text-slate-100 flex-1 truncate">{t.title}</p><span className="text-[10px] text-slate-400">{t.content.length} · {segments(t.content).count} SMS</span></div>
                <p className="text-xs text-slate-500 dark:text-slate-400 whitespace-pre-wrap line-clamp-4 flex-1">{t.content}</p>
                <div className="flex items-center gap-1 pt-2 border-t border-slate-100 dark:border-slate-800">
                  <button onClick={() => { setMsg(t.content); setTab('send'); }} className="flex-1 h-8 rounded-lg text-xs font-semibold text-indigo-700 bg-indigo-50 hover:bg-indigo-100 dark:bg-indigo-500/10 dark:text-indigo-300">{tr ? 'Kullan' : 'Use'}</button>
                  <button onClick={() => setTpl({ ...t })} className="p-2 rounded-lg text-slate-400 hover:text-indigo-600 hover:bg-indigo-50 dark:hover:bg-white/5"><Edit2 size={14} /></button>
                  <DeleteButton language={language} onConfirm={async () => { await onDeleteTemplate(t.id); toast(tr ? 'Şablon silindi' : 'Deleted', 'info'); }} />
                </div>
              </div>
            ))}
          </div>
        )}

        {tab === 'settings' && (
          <div className={`${cardCls} p-5 max-w-xl space-y-4`}>
            <div className="flex items-center gap-3"><span className="p-2 rounded-xl bg-gradient-to-br from-indigo-500 to-violet-600 text-white"><Smartphone size={18} /></span><div><p className="text-sm font-bold text-slate-900 dark:text-white">Netgsm</p><p className="text-[11px] text-slate-400">{configured ? (tr ? 'Bağlantı bilgileri kayıtlı' : 'Configured') : (tr ? 'Gönderim için bilgileri girin' : 'Enter credentials')}</p></div>
              {configured && <button onClick={fetchBalance} className={btnGhost + ' !h-9 ml-auto'}>{balBusy ? <Loader2 size={14} className="animate-spin" /> : <RefreshCw size={14} />}{balance ?? (tr ? 'Bakiye' : 'Balance')}</button>}</div>
            <Field label={tr ? 'Kullanıcı kodu' : 'User code'}><input className={inputCls()} autoComplete="off" value={cfg.usercode} onChange={e => setCfg({ ...cfg, usercode: e.target.value })} /></Field>
            <Field label={tr ? 'API şifresi' : 'API password'}><div className="relative"><input type={showPw ? 'text' : 'password'} autoComplete="new-password" className={inputCls() + ' pr-10'} value={newPw} placeholder={hasPw ? (tr ? 'Kayıtlı · değiştirmek için yeni şifreyi yazın' : 'Saved · type to change') : ''} onChange={e => setNewPw(e.target.value)} /><button type="button" onClick={() => setShowPw(!showPw)} className="absolute right-2 top-1/2 -translate-y-1/2 p-1.5 text-slate-400">{showPw ? <EyeOff size={15} /> : <Eye size={15} />}</button></div></Field>
            <Field label={tr ? 'Mesaj başlığı' : 'Sender ID'} hint={tr ? 'Netgsm\'de onaylı başlık' : 'Approved header'}><input className={inputCls() + ' uppercase'} value={cfg.msgheader} onChange={e => setCfg({ ...cfg, msgheader: e.target.value.toUpperCase() })} placeholder="PANIMO" /></Field>
            <button onClick={async () => {
              try {
                if (newPw) await setDoc(doc(db, 'sms_secrets', 'config'), { password: newPw });
                // Şifre artık okunabilir yapılandırmada tutulmaz (undefined = alan silinir)
                await onSaveConfig({ ...cfg, password: undefined as any, hasPassword: hasPw || !!newPw } as any);
                setNewPw('');
                toast.success(tr ? 'SMS ayarları kaydedildi' : 'Saved'); fetchBalance();
              } catch (e: any) { toast.error(e?.message || 'Hata'); }
            }} className={btnPrimary}>{tr ? 'Kaydet' : 'Save'}</button>
            <p className="text-[11px] text-slate-400 flex gap-1.5"><MessageSquare size={13} className="shrink-0 mt-0.5" />{tr ? 'Netgsm panelinden yalnızca SMS gönderimine yetkili bir API alt kullanıcısı oluşturup onun bilgilerini girmeniz önerilir.' : 'Use a restricted API sub-user.'}</p>
          </div>
        )}
      </div>

      {/* Gönderim onayı */}
      <Sheet open={confirm} language={language} title={tr ? 'Gönderimi onayla' : 'Confirm send'} icon={Send} onClose={() => setConfirm(false)} onSubmit={send} submitLabel={tr ? `${recipients.length} SMS gönder` : 'Send'}>
        <div className="grid grid-cols-3 gap-2 text-center">
          <div className="rounded-xl bg-slate-50 dark:bg-white/[0.03] py-3"><p className="text-xl font-black text-slate-900 dark:text-white">{recipients.length}</p><p className="text-[10px] text-slate-400">{tr ? 'alıcı' : 'recipients'}</p></div>
          <div className="rounded-xl bg-slate-50 dark:bg-white/[0.03] py-3"><p className="text-xl font-black text-slate-900 dark:text-white">≈{credits}</p><p className="text-[10px] text-slate-400">{tr ? 'SMS kredisi' : 'credits'}</p></div>
          <div className="rounded-xl bg-slate-50 dark:bg-white/[0.03] py-3"><p className="text-xl font-black text-slate-900 dark:text-white">{balance ?? '—'}</p><p className="text-[10px] text-slate-400">{tr ? 'bakiye' : 'balance'}</p></div>
        </div>
        <div className="rounded-2xl bg-slate-50 dark:bg-white/[0.03] p-3 text-sm text-slate-700 dark:text-slate-200 whitespace-pre-wrap break-words"><p className="text-[10px] font-bold text-indigo-600 mb-1">{cfg.msgheader}</p>{fill(msg, recipients[0]?.customer)}</div>
        <p className="text-[11px] text-slate-400">{tr ? 'Gönderilen SMS geri alınamaz. Ticari ileti içeriyorsa alıcıların İYS onayı olduğundan emin olun.' : 'SMS cannot be recalled.'}</p>
      </Sheet>

      {/* AI taslak */}
      <Sheet open={aiOpen} language={language} title={tr ? 'AI ile SMS taslağı' : 'AI SMS draft'} icon={Sparkles} tone="from-violet-500 to-purple-600" onClose={() => setAiOpen(false)} onSubmit={genAI} saving={aiBusy} submitLabel={tr ? 'Taslak oluştur' : 'Generate'}>
        <Field label={tr ? 'Nasıl bir mesaj?' : 'What message?'}><textarea autoFocus rows={3} className={inputCls() + ' !h-auto py-2.5 resize-none'} value={aiPrompt} onChange={e => setAiPrompt(e.target.value)} placeholder={tr ? 'Örn: Bayram kutlaması, ödeme hatırlatması, yeni ürün duyurusu…' : 'e.g. payment reminder'} /></Field>
        <div className="flex flex-wrap gap-1.5">{(tr ? ['Ödeme hatırlatması', 'Bayram tebriği', 'Yeni ürün duyurusu', 'Randevu hatırlatma'] : ['Payment reminder', 'Holiday greeting', 'Product launch']).map(s => <button key={s} onClick={() => setAiPrompt(s)} className="h-7 px-2.5 rounded-lg bg-slate-100 dark:bg-white/5 text-[11px] font-semibold text-slate-600 dark:text-slate-300 hover:bg-violet-50 hover:text-violet-700">{s}</button>)}</div>
      </Sheet>

      {/* Şablon formu */}
      <Sheet open={!!tpl} language={language} title={tpl?.id ? (tr ? 'Şablonu düzenle' : 'Edit template') : (tr ? 'Yeni şablon' : 'New template')} icon={FileText} onClose={() => setTpl(null)}
        onSubmit={async () => { if (!tpl?.title?.trim() || !tpl.content?.trim()) { toast.warning(tr ? 'Başlık ve içerik zorunlu' : 'Title and content required'); return; } await onUpsertTemplate({ id: tpl.id || `tmpl_${Date.now()}`, title: tpl.title.trim(), content: tpl.content.trim() }); toast.success(tr ? 'Şablon kaydedildi' : 'Saved'); setTpl(null); }}
        footerLeft={tpl?.content ? <span className="text-slate-400">{tpl.content.length} {tr ? 'karakter' : 'chars'} · {segments(tpl.content).count} SMS</span> : undefined}>
        {tpl && <>
          <Field label={tr ? 'Başlık' : 'Title'} required><input autoFocus className={inputCls()} value={tpl.title || ''} onChange={e => setTpl({ ...tpl, title: e.target.value })} /></Field>
          <Field label={tr ? 'İçerik' : 'Content'} required><textarea rows={5} className={inputCls() + ' !h-auto py-2.5 resize-none'} value={tpl.content || ''} onChange={e => setTpl({ ...tpl, content: e.target.value })} /></Field>
          <div className="flex flex-wrap gap-1.5">{VARS.map(v => <button key={v} type="button" onClick={() => setTpl({ ...tpl, content: (tpl.content || '') + v })} className="h-7 px-2 rounded-lg bg-slate-100 dark:bg-white/5 text-[11px] font-mono text-slate-600 dark:text-slate-300">{v}</button>)}</div>
        </>}
      </Sheet>
    </div>
  );
};

export default CustomerSMSView;
