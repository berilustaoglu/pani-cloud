import React, { useEffect, useMemo, useState } from 'react';
import { Clock, Users, UserCheck, UserX, Timer, Download, MapPin, StopCircle, PlayCircle, Edit2, Settings2, CalendarDays, BarChart3, ListChecks, TrendingUp } from 'lucide-react';
import { AttendanceRecord, User, UserRole } from '../types';
import { PageHeader, KpiGrid, SearchBox, Segmented, Field, EmptyState, Sheet, Avatar, inputCls, selectSm, cardCls, btnPrimary, btnGhost } from './ui/Kit';
import { ProgressRing, GrowBar } from './ui/Motion';
import { localISO } from '../services/insights';
import { toast } from '../services/toast';

interface Props {
  attendance: AttendanceRecord[];
  onUpsertAttendance: (record: AttendanceRecord) => Promise<void>;
  currentUser: User;
  staffList: User[];
  language: 'tr' | 'en';
  onClockIn?: (userId: string, userName: string) => Promise<void>;
  hrSettings?: any;
  onUpdateHrSettings?: (settings: any) => Promise<void>;
}

const toMin = (hhmm?: string) => { if (!hhmm) return 0; const [h, m] = hhmm.split(':').map(Number); return (h || 0) * 60 + (m || 0); };
const nowHHMM = () => new Date().toLocaleTimeString('tr-TR', { hour: '2-digit', minute: '2-digit' });
const fmtDur = (m: number) => `${Math.floor(m / 60)}s ${String(Math.round(m % 60)).padStart(2, '0')}dk`;
/** Kayıt süresi (dk). Açık kayıt bugüne aitse şimdiye kadar geçen süre; gece yarısını aşan kayıtlar desteklenir. */
const durationOf = (r: AttendanceRecord, today: string, nowMin: number) => {
  const end = r.clockOut ? toMin(r.clockOut) : r.date === today ? nowMin : null;
  if (end === null) return 0;
  let d = end - toMin(r.clockIn);
  if (d < 0) d += 1440;
  return d;
};
/** Ayın (bugüne kadarki) hafta içi gün sayısı */
const workdaysInMonth = (monthKey: string, today: string) => {
  const [y, m] = monthKey.split('-').map(Number);
  const last = monthKey === today.slice(0, 7) ? Number(today.slice(8, 10)) : new Date(y, m, 0).getDate();
  let n = 0;
  for (let d = 1; d <= last; d++) { const wd = new Date(y, m - 1, d).getDay(); if (wd !== 0 && wd !== 6) n++; }
  return n;
};

const AttendanceView: React.FC<Props> = ({ attendance, onUpsertAttendance, currentUser, staffList, language, onClockIn, hrSettings, onUpdateHrSettings }) => {
  const tr = language === 'tr';
  const isAdmin = currentUser.role === UserRole.ADMIN;
  const isManager = currentUser.role === UserRole.MANAGER;
  const isAccountant = currentUser.role === UserRole.ACCOUNTANT;
  const canSeeAll = isAdmin || isAccountant || isManager;
  const canEdit = isAdmin || isManager;
  const dailyHours = Number(hrSettings?.dailyWorkHours) || 9;

  const [tick, setTick] = useState(Date.now());
  useEffect(() => { const t = setInterval(() => setTick(Date.now()), 30000); return () => clearInterval(t); }, []);
  const today = localISO();
  const nowMin = useMemo(() => { const d = new Date(tick); return d.getHours() * 60 + d.getMinutes(); }, [tick]);

  const [view, setView] = useState<'today' | 'records' | 'report'>(canSeeAll ? 'today' : 'records');
  const [month, setMonth] = useState(today.slice(0, 7));
  const [search, setSearch] = useState('');
  const [person, setPerson] = useState('all');
  const [edit, setEdit] = useState<AttendanceRecord | null>(null);
  const [hrOpen, setHrOpen] = useState(false);
  const [hr, setHr] = useState({ dailyWorkHours: dailyHours, defaultAnnualLeaveDays: Number(hrSettings?.defaultAnnualLeaveDays) || 14 });
  const [busy, setBusy] = useState(false);

  // Görünürlük: yönetici adminleri göremez, personel yalnızca kendini görür
  const visibleStaff = useMemo(() => staffList.filter(u => isAdmin || isAccountant ? true : isManager ? u.role !== UserRole.ADMIN || u.id === currentUser.id : u.id === currentUser.id), [staffList, isAdmin, isAccountant, isManager, currentUser.id]);
  const visibleIds = useMemo(() => new Set(visibleStaff.map(u => u.id)), [visibleStaff]);
  const visible = useMemo(() => attendance.filter(r => canSeeAll ? (visibleIds.has(r.userId) || isAdmin || isAccountant) : r.userId === currentUser.id), [attendance, canSeeAll, visibleIds, isAdmin, isAccountant, currentUser.id]);

  // ---------- Benim mesaim ----------
  const myOpen = attendance.find(r => r.userId === currentUser.id && !r.clockOut);
  const myTodayMin = attendance.filter(r => r.userId === currentUser.id && r.date === today).reduce((a, r) => a + durationOf(r, today, nowMin), 0);
  const myWeek = useMemo(() => {
    const d = new Date(); const dow = (d.getDay() + 6) % 7;
    return Array.from({ length: 7 }, (_, i) => {
      const day = new Date(d.getFullYear(), d.getMonth(), d.getDate() - dow + i); const iso = localISO(day);
      return { iso, label: day.toLocaleDateString(tr ? 'tr-TR' : 'en-US', { weekday: 'short' }), min: attendance.filter(r => r.userId === currentUser.id && r.date === iso).reduce((a, r) => a + durationOf(r, today, nowMin), 0), future: iso > today };
    });
  }, [attendance, currentUser.id, today, nowMin, tr]);
  const weekTotal = myWeek.reduce((a, d) => a + d.min, 0);

  const clockOut = async (r: AttendanceRecord, who?: string) => {
    setBusy(true);
    try { await onUpsertAttendance({ ...r, clockOut: nowHHMM() }); toast.success(who ? (tr ? `${who} için çıkış yapıldı` : 'Clocked out') : (tr ? 'Mesai sonlandırıldı. İyi dinlenmeler!' : 'Shift ended')); }
    finally { setBusy(false); }
  };
  const clockIn = async () => {
    if (!onClockIn) return;
    setBusy(true);
    try { await onClockIn(currentUser.id, currentUser.name); toast.success(tr ? 'Mesai başladı. Kolay gelsin!' : 'Shift started'); } finally { setBusy(false); }
  };

  // ---------- Bugün ----------
  const todayRows = useMemo(() => visibleStaff.map(u => {
    const recs = attendance.filter(r => r.userId === u.id && r.date === today).sort((a, b) => a.clockIn.localeCompare(b.clockIn));
    const open = recs.find(r => !r.clockOut);
    return { user: u, recs, open, first: recs[0]?.clockIn, last: recs.filter(r => r.clockOut).slice(-1)[0]?.clockOut, min: recs.reduce((a, r) => a + durationOf(r, today, nowMin), 0), state: open ? 'working' : recs.length ? 'left' : 'absent' as 'working' | 'left' | 'absent' };
  }).sort((a, b) => ({ working: 0, left: 1, absent: 2 }[a.state] - { working: 0, left: 1, absent: 2 }[b.state]) || a.user.name.localeCompare(b.user.name, 'tr')), [visibleStaff, attendance, today, nowMin]);
  const workingNow = todayRows.filter(r => r.state === 'working').length;
  const cameToday = todayRows.filter(r => r.state !== 'absent').length;

  // ---------- Kayıtlar ----------
  const q = search.trim().toLocaleLowerCase('tr-TR');
  const records = useMemo(() => visible.filter(r => r.date.startsWith(month) && (person === 'all' || r.userId === person) && (!q || r.userName.toLocaleLowerCase('tr-TR').includes(q)))
    .sort((a, b) => b.date.localeCompare(a.date) || b.clockIn.localeCompare(a.clockIn)), [visible, month, person, q]);

  // ---------- Aylık rapor ----------
  const expectedMonth = workdaysInMonth(month, today) * dailyHours * 60;
  const report = useMemo(() => {
    const map = new Map<string, { id: string; name: string; avatar?: string; days: Set<string>; min: number; overDays: number }>();
    visible.filter(r => r.date.startsWith(month)).forEach(r => {
      const u = staffList.find(s => s.id === r.userId);
      const row = map.get(r.userId) || { id: r.userId, name: r.userName, avatar: u?.avatar, days: new Set<string>(), min: 0, overDays: 0 };
      row.days.add(r.date); row.min += durationOf(r, today, nowMin); map.set(r.userId, row);
    });
    // fazla mesai yapılan gün sayısı
    map.forEach(row => row.days.forEach(d => { const m = visible.filter(r => r.userId === row.id && r.date === d).reduce((a, r) => a + durationOf(r, today, nowMin), 0); if (m > dailyHours * 60) row.overDays++; }));
    return [...map.values()].map(r => ({ ...r, dayCount: r.days.size, diff: r.min - expectedMonth })).sort((a, b) => b.min - a.min);
  }, [visible, month, staffList, today, nowMin, dailyHours, expectedMonth]);
  const monthTotal = report.reduce((a, r) => a + r.min, 0);

  const months = useMemo(() => { const s = new Set(attendance.map(r => r.date.slice(0, 7))); s.add(today.slice(0, 7)); return [...s].sort().reverse(); }, [attendance, today]);
  const monthLabel = (k: string) => { const [y, m] = k.split('-').map(Number); return new Date(y, m - 1, 1).toLocaleDateString(tr ? 'tr-TR' : 'en-US', { month: 'long', year: 'numeric' }); };

  const exportCsv = () => {
    const lines = [
      [tr ? 'PANIMO - Personel Mesai Raporu' : 'Attendance report'], [`${tr ? 'Dönem' : 'Period'}: ${monthLabel(month)}`], [`${tr ? 'Günlük hedef' : 'Daily target'}: ${dailyHours} ${tr ? 'saat' : 'h'}`], [],
      [tr ? 'Personel' : 'Employee', tr ? 'Çalışılan gün' : 'Days', tr ? 'Toplam saat' : 'Hours', tr ? 'Beklenen saat' : 'Expected', tr ? 'Fark (saat)' : 'Diff (h)', tr ? 'Fazla mesai günü' : 'Overtime days'],
      ...report.map(r => [r.name, r.dayCount, (r.min / 60).toFixed(1), (expectedMonth / 60).toFixed(0), (r.diff / 60).toFixed(1), r.overDays]),
      [], [tr ? 'Personel' : 'Employee', tr ? 'Tarih' : 'Date', tr ? 'Giriş' : 'In', tr ? 'Çıkış' : 'Out', tr ? 'Süre' : 'Duration', tr ? 'Konum' : 'Location'],
      ...visible.filter(r => r.date.startsWith(month)).sort((a, b) => a.userName.localeCompare(b.userName, 'tr') || a.date.localeCompare(b.date)).map(r => [r.userName, r.date, r.clockIn, r.clockOut || (tr ? 'Aktif' : 'Active'), fmtDur(durationOf(r, today, nowMin)), r.location ? `${r.location.lat.toFixed(4)},${r.location.lng.toFixed(4)}` : '']),
    ];
    const csv = '﻿' + lines.map(l => l.map(c => `"${String(c).replace(/"/g, '""')}"`).join(';')).join('\n');
    const a = document.createElement('a'); a.href = URL.createObjectURL(new Blob([csv], { type: 'text/csv;charset=utf-8;' })); a.download = `PanimoCloud_Mesai_${month}.csv`; a.click();
    toast.success(tr ? 'Rapor indirildi' : 'Exported');
  };

  const saveEdit = async () => {
    if (!edit) return;
    if (!/^\d{2}:\d{2}$/.test(edit.clockIn)) { toast.error(tr ? 'Giriş saati geçersiz' : 'Invalid time'); return; }
    setBusy(true);
    try { const rec = { ...edit }; if (!rec.clockOut) delete rec.clockOut; await onUpsertAttendance(rec); toast.success(tr ? 'Kayıt düzeltildi' : 'Record updated'); setEdit(null); } finally { setBusy(false); }
  };

  const progress = Math.min(100, (myTodayMin / (dailyHours * 60)) * 100);
  const stateChip = (s: 'working' | 'left' | 'absent') => ({
    working: <span className="inline-flex items-center gap-1.5 text-[11px] font-semibold px-2 py-0.5 rounded-md bg-emerald-50 text-emerald-700 dark:bg-emerald-500/10 dark:text-emerald-300"><span className="w-1.5 h-1.5 rounded-full bg-emerald-500 pc-dot-pulse" />{tr ? 'Çalışıyor' : 'Working'}</span>,
    left: <span className="text-[11px] font-semibold px-2 py-0.5 rounded-md bg-slate-100 text-slate-600 dark:bg-white/5 dark:text-slate-300">{tr ? 'Çıkış yaptı' : 'Left'}</span>,
    absent: <span className="text-[11px] font-semibold px-2 py-0.5 rounded-md bg-rose-50 text-rose-600 dark:bg-rose-500/10 dark:text-rose-300">{tr ? 'Giriş yok' : 'Absent'}</span>,
  }[s]);

  return (
    <div className="space-y-5 pb-10">
      <PageHeader title={tr ? 'Giriş-Çıkış' : 'Attendance'} subtitle={tr ? `Mesai takibi · günlük hedef ${dailyHours} saat` : `Time tracking · ${dailyHours}h daily target`}
        actions={<>{isAdmin && onUpdateHrSettings && <button onClick={() => { setHr({ dailyWorkHours: dailyHours, defaultAnnualLeaveDays: Number(hrSettings?.defaultAnnualLeaveDays) || 14 }); setHrOpen(true); }} className={btnGhost}><Settings2 size={15} />{tr ? 'Mesai ayarları' : 'Settings'}</button>}
          {canSeeAll && <button onClick={exportCsv} className={btnGhost}><Download size={15} />{tr ? 'Excel (CSV)' : 'Export'}</button>}</>} />

      {/* Benim mesaim */}
      <div className={`${cardCls} p-5 sm:p-6 relative overflow-hidden`}>
        <div className={`absolute -top-24 -right-24 w-72 h-72 rounded-full blur-3xl opacity-20 pointer-events-none ${myOpen ? 'bg-emerald-400' : 'bg-indigo-400'}`} />
        <div className="relative flex flex-col md:flex-row items-center gap-6">
          <ProgressRing value={progress} size={128} stroke={10} color={myOpen ? '#10b981' : undefined}>
            <div className="text-center"><p className="text-lg font-black text-slate-900 dark:text-white leading-none">{fmtDur(myTodayMin)}</p><p className="text-[10px] text-slate-400 mt-1">/ {dailyHours} {tr ? 'saat' : 'h'}</p></div>
          </ProgressRing>
          <div className="flex-1 min-w-0 text-center md:text-left">
            <div className="flex items-center gap-2 justify-center md:justify-start">{myOpen ? stateChip('working') : <span className="text-[11px] font-semibold px-2 py-0.5 rounded-md bg-slate-100 text-slate-500 dark:bg-white/5">{tr ? 'Mesai dışı' : 'Off shift'}</span>}</div>
            <h3 className="text-xl font-bold text-slate-900 dark:text-white mt-2">{myOpen ? (tr ? `Mesai ${myOpen.clockIn}'de başladı` : `Started at ${myOpen.clockIn}`) : (tr ? `Merhaba ${currentUser.name.split(' ')[0]}` : `Hi ${currentUser.name.split(' ')[0]}`)}</h3>
            <p className="text-sm text-slate-500 dark:text-slate-400 mt-1">{myOpen ? (progress >= 100 ? (tr ? 'Günlük hedefini tamamladın 🎉' : 'Daily target reached 🎉') : (tr ? `Hedefe ${fmtDur(Math.max(0, dailyHours * 60 - myTodayMin))} kaldı` : `${fmtDur(dailyHours * 60 - myTodayMin)} to go`)) : (tr ? 'Giriş yaptığında mesain otomatik başlar; buradan da başlatabilirsin.' : 'Your shift starts on login, or start it here.')}</p>
            <div className="mt-4 flex items-end gap-1.5 h-14 justify-center md:justify-start">
              {myWeek.map(d => (
                <div key={d.iso} className="flex flex-col items-center gap-1 w-8" title={`${d.iso} · ${fmtDur(d.min)}`}>
                  <div className="w-full h-10 rounded-md bg-slate-100 dark:bg-slate-800 flex items-end overflow-hidden"><div className={`w-full rounded-md transition-all duration-700 ${d.iso === today ? 'bg-gradient-to-t from-indigo-500 to-violet-500' : d.min >= dailyHours * 60 ? 'bg-emerald-400' : 'bg-indigo-300 dark:bg-indigo-500/50'}`} style={{ height: `${Math.min(100, (d.min / (dailyHours * 60)) * 100)}%` }} /></div>
                  <span className={`text-[9px] font-semibold ${d.iso === today ? 'text-indigo-600' : 'text-slate-400'}`}>{d.label}</span>
                </div>
              ))}
              <div className="ml-3 text-left"><p className="text-[10px] text-slate-400">{tr ? 'Bu hafta' : 'This week'}</p><p className="text-sm font-bold text-slate-800 dark:text-slate-100">{fmtDur(weekTotal)}</p></div>
            </div>
          </div>
          <div className="w-full md:w-52 shrink-0">
            {myOpen
              ? <button disabled={busy} onClick={() => clockOut(myOpen)} className="w-full h-12 rounded-2xl bg-rose-600 hover:bg-rose-500 text-white font-semibold inline-flex items-center justify-center gap-2 shadow-lg shadow-rose-500/25 disabled:opacity-60"><StopCircle size={18} />{tr ? 'Mesaiyi bitir' : 'End shift'}</button>
              : <button disabled={busy || !onClockIn} onClick={clockIn} className={`${btnPrimary} w-full !h-12 !rounded-2xl`}><PlayCircle size={18} />{tr ? 'Mesaiyi başlat' : 'Start shift'}</button>}
          </div>
        </div>
      </div>

      {canSeeAll && <KpiGrid items={[
        { label: tr ? 'Şu an çalışan' : 'Working now', value: workingNow, icon: UserCheck, grad: 'from-emerald-500 to-teal-600', sub: `${visibleStaff.length} ${tr ? 'personelden' : 'staff'}`, bar: visibleStaff.length ? (workingNow / visibleStaff.length) * 100 : 0 },
        { label: tr ? 'Bugün gelen' : 'Came today', value: cameToday, icon: Users, grad: 'from-indigo-500 to-violet-600', sub: tr ? `${visibleStaff.length - cameToday} kişi giriş yapmadı` : `${visibleStaff.length - cameToday} absent`, onClick: () => setView('today'), active: view === 'today' },
        { label: tr ? `${monthLabel(month)} toplam` : 'Month total', value: Math.round(monthTotal / 60), format: n => `${n} ${tr ? 'saat' : 'h'}`, icon: Timer, grad: 'from-sky-500 to-blue-600', sub: `${report.length} ${tr ? 'kişi' : 'people'}`, onClick: () => setView('report'), active: view === 'report' },
        { label: tr ? 'Kişi başı ortalama' : 'Avg per person', value: report.length ? Math.round(monthTotal / report.length / 60) : 0, format: n => `${n} ${tr ? 'saat' : 'h'}`, icon: TrendingUp, grad: 'from-amber-500 to-orange-600', sub: `${tr ? 'Beklenen' : 'Expected'} ${Math.round(expectedMonth / 60)} ${tr ? 'saat' : 'h'}` },
      ]} />}

      <div className={`${cardCls} p-3 flex flex-col lg:flex-row gap-2`}>
        <Segmented<'today' | 'records' | 'report'> value={view} onChange={setView} options={[
          ...(canSeeAll ? [{ value: 'today' as const, label: <><Users size={14} />{tr ? 'Bugün' : 'Today'}</> }] : []),
          { value: 'records', label: <><ListChecks size={14} />{tr ? 'Kayıtlar' : 'Records'}</> },
          ...(canSeeAll ? [{ value: 'report' as const, label: <><BarChart3 size={14} />{tr ? 'Aylık rapor' : 'Monthly'}</> }] : []),
        ]} />
        {canSeeAll && view !== 'report' && <SearchBox value={search} onChange={setSearch} placeholder={tr ? 'Personel ara…' : 'Search staff…'} />}
        {view !== 'today' && <>
          <select value={month} onChange={e => setMonth(e.target.value)} className={selectSm}>{months.map(m => <option key={m} value={m}>{monthLabel(m)}</option>)}</select>
          {canSeeAll && view === 'records' && <select value={person} onChange={e => setPerson(e.target.value)} className={selectSm}><option value="all">{tr ? 'Tüm personel' : 'All staff'}</option>{visibleStaff.map(u => <option key={u.id} value={u.id}>{u.name}</option>)}</select>}
        </>}
      </div>

      <div key={view} className={`${cardCls} overflow-hidden animate-in fade-in duration-300`}>
        {view === 'today' && (() => {
          const rows = todayRows.filter(r => !q || r.user.name.toLocaleLowerCase('tr-TR').includes(q));
          return rows.length === 0 ? <EmptyState icon={Users} text={tr ? 'Personel yok' : 'No staff'} /> : (
            <div className="divide-y divide-slate-100 dark:divide-slate-800 pc-stagger">
              {rows.map(r => (
                <div key={r.user.id} className="grid grid-cols-12 gap-3 items-center px-4 py-3 hover:bg-slate-50/70 dark:hover:bg-white/[0.02]">
                  <div className="col-span-12 sm:col-span-4 flex items-center gap-3 min-w-0"><div className="relative"><Avatar name={r.user.name} src={r.user.avatar} />{r.state === 'working' && <span className="absolute -bottom-0.5 -right-0.5 w-3 h-3 rounded-full bg-emerald-500 border-2 border-white dark:border-slate-900" />}</div><div className="min-w-0"><p className="text-sm font-semibold text-slate-800 dark:text-slate-100 truncate">{r.user.name}</p><p className="text-[11px] text-slate-400 truncate">{r.user.jobTitle || r.user.role}</p></div></div>
                  <div className="col-span-4 sm:col-span-2">{stateChip(r.state)}</div>
                  <div className="col-span-4 sm:col-span-2 text-xs text-slate-500"><span className="text-slate-400">{tr ? 'Giriş' : 'In'}</span> <b className="text-slate-700 dark:text-slate-200">{r.first || '—'}</b>{r.last && !r.open && <> · <span className="text-slate-400">{tr ? 'Çıkış' : 'Out'}</span> <b className="text-slate-700 dark:text-slate-200">{r.last}</b></>}</div>
                  <div className="col-span-4 sm:col-span-3"><div className="flex items-center justify-between text-[11px] mb-1"><span className="font-semibold text-slate-700 dark:text-slate-200">{r.min ? fmtDur(r.min) : '—'}</span><span className="text-slate-400">{Math.round((r.min / (dailyHours * 60)) * 100)}%</span></div><GrowBar value={Math.min(100, (r.min / (dailyHours * 60)) * 100)} className={r.min >= dailyHours * 60 ? 'bg-emerald-500' : 'bg-indigo-500'} /></div>
                  <div className="col-span-12 sm:col-span-1 flex justify-end">{canEdit && r.open && r.user.id !== currentUser.id && <button disabled={busy} onClick={() => clockOut(r.open!, r.user.name)} title={tr ? 'Çıkış yaptır' : 'Force clock-out'} className="p-1.5 rounded-lg text-rose-500 hover:bg-rose-50 dark:hover:bg-rose-500/10"><StopCircle size={16} /></button>}</div>
                </div>
              ))}
            </div>
          );
        })()}

        {view === 'records' && (records.length === 0 ? <EmptyState icon={CalendarDays} text={tr ? 'Bu dönemde kayıt yok' : 'No records'} /> : (
          <div className="divide-y divide-slate-100 dark:divide-slate-800 pc-stagger">
            {records.map(r => {
              const m = durationOf(r, today, nowMin); const over = m > dailyHours * 60; const stale = !r.clockOut && r.date !== today;
              return (
                <div key={r.id} className="grid grid-cols-12 gap-3 items-center px-4 py-3 hover:bg-slate-50/70 dark:hover:bg-white/[0.02]">
                  <div className="col-span-12 sm:col-span-4 flex items-center gap-3 min-w-0"><Avatar name={r.userName} src={staffList.find(u => u.id === r.userId)?.avatar} /><div className="min-w-0"><p className="text-sm font-semibold text-slate-800 dark:text-slate-100 truncate">{r.userName}</p><p className="text-[11px] text-slate-400">{new Date(r.date + 'T00:00').toLocaleDateString(tr ? 'tr-TR' : 'en-US', { weekday: 'long', day: 'numeric', month: 'short' })}</p></div></div>
                  <div className="col-span-6 sm:col-span-3 flex items-center gap-1.5 text-xs font-mono">
                    <span className="px-2 py-1 rounded-lg bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-200">{r.clockIn}</span><span className="text-slate-300">→</span>
                    {r.clockOut ? <span className="px-2 py-1 rounded-lg bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-200">{r.clockOut}</span>
                      : stale ? <span className="px-2 py-1 rounded-lg bg-amber-50 text-amber-700 dark:bg-amber-500/10 dark:text-amber-300 font-sans font-semibold text-[11px]">{tr ? 'Çıkış yok' : 'No exit'}</span>
                      : <span className="px-2 py-1 rounded-lg bg-emerald-50 text-emerald-700 dark:bg-emerald-500/10 dark:text-emerald-300 font-sans font-semibold text-[11px]">{tr ? 'Aktif' : 'Active'}</span>}
                  </div>
                  <div className="col-span-3 sm:col-span-2 text-xs"><b className="text-slate-800 dark:text-slate-100">{stale ? '—' : fmtDur(m)}</b>{over && !stale && <span className="ml-1.5 text-[10px] font-semibold text-emerald-600">+{fmtDur(m - dailyHours * 60)}</span>}</div>
                  <div className="col-span-3 sm:col-span-2 text-xs">{r.location ? <a href={`https://www.google.com/maps?q=${r.location.lat},${r.location.lng}`} target="_blank" rel="noreferrer" title={r.location.address || ''} className="inline-flex items-center gap-1 text-slate-500 hover:text-indigo-600"><MapPin size={12} />{tr ? 'Harita' : 'Map'}</a> : <span className="text-slate-300">—</span>}</div>
                  <div className="col-span-12 sm:col-span-1 flex justify-end gap-1">
                    {canEdit && !r.clockOut && r.userId !== currentUser.id && !stale && <button disabled={busy} onClick={() => clockOut(r, r.userName)} title={tr ? 'Çıkış yaptır' : 'Force clock-out'} className="p-1.5 rounded-lg text-rose-500 hover:bg-rose-50 dark:hover:bg-rose-500/10"><StopCircle size={15} /></button>}
                    {canEdit && <button onClick={() => setEdit({ ...r })} title={tr ? 'Düzelt' : 'Edit'} className="p-1.5 rounded-lg text-slate-400 hover:text-indigo-600 hover:bg-indigo-50 dark:hover:bg-white/5"><Edit2 size={14} /></button>}
                  </div>
                </div>
              );
            })}
          </div>
        ))}

        {view === 'report' && (report.length === 0 ? <EmptyState icon={BarChart3} text={tr ? 'Bu ay kayıt yok' : 'No data'} /> : (
          <div>
            <div className="hidden sm:grid grid-cols-12 gap-3 px-4 py-2.5 text-[11px] font-semibold text-slate-400 border-b border-slate-100 dark:border-slate-800">
              <span className="col-span-4">{tr ? 'Personel' : 'Employee'}</span><span className="col-span-1 text-right">{tr ? 'Gün' : 'Days'}</span><span className="col-span-4">{tr ? `Çalışma / beklenen (${Math.round(expectedMonth / 60)} sa)` : 'Worked / expected'}</span><span className="col-span-2 text-right">{tr ? 'Fark' : 'Diff'}</span><span className="col-span-1 text-right">{tr ? 'FM gün' : 'OT days'}</span>
            </div>
            <div className="divide-y divide-slate-100 dark:divide-slate-800 pc-stagger">
              {report.map(r => (
                <div key={r.id} className="grid grid-cols-12 gap-3 items-center px-4 py-3">
                  <div className="col-span-12 sm:col-span-4 flex items-center gap-3 min-w-0"><Avatar name={r.name} src={r.avatar} /><p className="text-sm font-semibold text-slate-800 dark:text-slate-100 truncate">{r.name}</p></div>
                  <div className="col-span-2 sm:col-span-1 text-right text-sm font-bold text-slate-700 dark:text-slate-200">{r.dayCount}</div>
                  <div className="col-span-6 sm:col-span-4"><div className="flex justify-between text-[11px] mb-1"><b className="text-slate-700 dark:text-slate-200">{fmtDur(r.min)}</b><span className="text-slate-400">{expectedMonth ? Math.round((r.min / expectedMonth) * 100) : 0}%</span></div><GrowBar value={expectedMonth ? Math.min(100, (r.min / expectedMonth) * 100) : 0} className={r.diff >= 0 ? 'bg-emerald-500' : 'bg-indigo-500'} /></div>
                  <div className={`col-span-2 sm:col-span-2 text-right text-xs font-bold ${r.diff >= 0 ? 'text-emerald-600' : 'text-rose-500'}`}>{r.diff >= 0 ? '+' : '−'}{fmtDur(Math.abs(r.diff))}</div>
                  <div className="col-span-2 sm:col-span-1 text-right text-xs text-slate-500">{r.overDays}</div>
                </div>
              ))}
            </div>
            <p className="px-4 py-3 text-[11px] text-slate-400 border-t border-slate-100 dark:border-slate-800">{tr ? `Beklenen süre, ${monthLabel(month)} içindeki hafta içi günler × ${dailyHours} saat olarak hesaplanır (içinde bulunulan ay için bugüne kadar).` : 'Expected = weekdays × daily hours.'}</p>
          </div>
        ))}
      </div>

      <Sheet open={!!edit} language={language} title={tr ? 'Kaydı düzelt' : 'Edit record'} subtitle={edit ? `${edit.userName} · ${edit.date}` : ''} icon={Clock} onClose={() => setEdit(null)} onSubmit={saveEdit} saving={busy}
        footerLeft={edit && edit.clockOut ? <span className="text-slate-400">{tr ? 'Süre' : 'Duration'} <b className="text-slate-800 dark:text-slate-100">{fmtDur(durationOf(edit, today, nowMin))}</b></span> : undefined}>
        {edit && <>
          <Field label={tr ? 'Tarih' : 'Date'}><input type="date" className={inputCls()} value={edit.date} max={today} onChange={e => setEdit({ ...edit, date: e.target.value })} /></Field>
          <div className="grid grid-cols-2 gap-4">
            <Field label={tr ? 'Giriş' : 'Clock in'} required><input type="time" className={inputCls()} value={edit.clockIn} onChange={e => setEdit({ ...edit, clockIn: e.target.value })} /></Field>
            <Field label={tr ? 'Çıkış' : 'Clock out'} hint={tr ? 'Boş bırakılırsa oturum açık kalır' : 'Empty = still open'}><input type="time" className={inputCls()} value={edit.clockOut || ''} onChange={e => setEdit({ ...edit, clockOut: e.target.value || undefined })} /></Field>
          </div>
        </>}
      </Sheet>

      <Sheet open={hrOpen} language={language} title={tr ? 'Mesai ayarları' : 'Work settings'} icon={Settings2} onClose={() => setHrOpen(false)} saving={busy}
        onSubmit={async () => { if (!onUpdateHrSettings) return; setBusy(true); try { await onUpdateHrSettings(hr); toast.success(tr ? 'Ayarlar kaydedildi' : 'Saved'); setHrOpen(false); } finally { setBusy(false); } }}>
        <Field label={tr ? 'Günlük beklenen mesai (saat)' : 'Daily hours'}><input type="number" min={1} max={24} className={inputCls()} value={hr.dailyWorkHours} onChange={e => setHr({ ...hr, dailyWorkHours: Number(e.target.value) })} /></Field>
        <Field label={tr ? 'Standart yıllık izin (gün)' : 'Annual leave days'}><input type="number" min={0} className={inputCls()} value={hr.defaultAnnualLeaveDays} onChange={e => setHr({ ...hr, defaultAnnualLeaveDays: Number(e.target.value) })} /></Field>
      </Sheet>
    </div>
  );
};

export default AttendanceView;
