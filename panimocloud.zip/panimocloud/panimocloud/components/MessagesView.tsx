
import React, { useState, useEffect, useRef, useMemo } from 'react';
import { User, ChatMessage } from '../types';
import { translations } from '../translations';
import { Hash, MessageSquare, Send, Search, Plus, Smile, Menu, X, CheckCheck, Vote, CalendarPlus, BarChart2, CalendarDays, Clock, Sparkles, Loader2, Check, Megaphone, Image as ImageIcon } from 'lucide-react';
import { Field, Sheet, Avatar, inputCls } from './ui/Kit';
import { collection, query, onSnapshot, addDoc, updateDoc, doc, arrayUnion, serverTimestamp, writeBatch, where, limit, orderBy } from 'firebase/firestore';
import { db } from '../firebase';
import { draftMessageReply } from '../services/aiService';
import { toast } from '../services/toast';

interface Props {
  currentUser: User;
  users: User[];
  language: 'tr' | 'en';
}

const COMMON_EMOJIS = ["👍", "👋", "❤️", "😂", "😮", "😢", "😡", "🎉", "🔥", "✨", "🚀", "💯", "✅", "❌", "🤔", "👀", "💼", "📅", "🤝", "💻"];

const MessagesView: React.FC<Props> = ({ currentUser, users, language }) => {
  const t = translations[language];
  const tr = language === 'tr';
  const [peopleQuery, setPeopleQuery] = useState('');
  const [lightbox, setLightbox] = useState<string | null>(null);
  
  // Channels
  const [activeChannelId, setActiveChannelId] = useState('general');
  const [allMessages, setAllMessages] = useState<ChatMessage[]>([]);
  const [unreadMessages, setUnreadMessages] = useState<ChatMessage[]>([]);
  const [newMessage, setNewMessage] = useState('');
  const [mobileSidebarOpen, setMobileSidebarOpen] = useState(false);
  
  // Search State
  const [isSearching, setIsSearching] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');

  // UI States
  const [showEmojiPicker, setShowEmojiPicker] = useState(false);
  const [showPlusMenu, setShowPlusMenu] = useState(false);
  
  // Modals for New Features
  const [showPollModal, setShowPollModal] = useState(false);
  const [showEventModal, setShowEventModal] = useState(false);

  // Poll State
  const [pollQuestion, setPollQuestion] = useState('');
  const [pollOptions, setPollOptions] = useState(['', '']);

  // Event State
  const [eventTitle, setEventTitle] = useState('');
  const [eventDate, setEventDate] = useState('');
  const [eventTime, setEventTime] = useState('');

  const [isDrafting, setIsDrafting] = useState(false);

  const fileInputRef = useRef<HTMLInputElement>(null);
  const searchInputRef = useRef<HTMLInputElement>(null);
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const textareaRef = useRef<HTMLTextAreaElement>(null);

  const channels = [
    { id: 'general', name: t.general_channel, icon: <Hash size={18} /> },
    { id: 'announcements', name: t.announcements, icon: <Hash size={18} className="text-red-500" /> },
  ];

  // Focus search input when searching starts
  useEffect(() => {
    if (isSearching && searchInputRef.current) {
        searchInputRef.current.focus();
    }
  }, [isSearching]);

  const getDmChannelId = (uid1: string, uid2: string) => {
    return [uid1, uid2].sort().join('_');
  };

  const hasCleanedUpRef = useRef(false);

  useEffect(() => {
    if (currentUser.role !== 'Admin' || hasCleanedUpRef.current || allMessages.length === 0) return;
    
    hasCleanedUpRef.current = true;
    
    const thirtyDaysAgo = new Date();
    thirtyDaysAgo.setDate(thirtyDaysAgo.getDate() - 30);
    
    const oldMessages = allMessages.filter(m => {
       const msgDate = new Date(m.createdAt);
       return !isNaN(msgDate.getTime()) && msgDate < thirtyDaysAgo;
    });
    
    if (oldMessages.length > 0) {
        const executeCleanup = async () => {
           try {
               let currentBatch = writeBatch(db);
               let count = 0;
               for (const msg of oldMessages) {
                   currentBatch.delete(doc(db, "chat_messages", msg.id));
                   count++;
                   if (count === 500) {
                      await currentBatch.commit();
                      currentBatch = writeBatch(db);
                      count = 0;
                   }
               }
               if (count > 0) {
                  await currentBatch.commit();
               }
               console.log(`Auto-cleaned ${oldMessages.length} messages older than 30 days.`);
           } catch (e) {
               console.error("Auto-cleanup error:", e);
           }
        };
        executeCleanup();
    }
  }, [allMessages, currentUser.role]);

  const otherUsers = users.filter(u => u.id !== currentUser.id);

  const isDm = activeChannelId.includes('_');
  let activeChannelName = '';
  let activeChannelIcon = null;
  let activeUserStatus = 'Offline';

  if (isDm) {
    const otherUserId = activeChannelId.split('_').find(id => id !== currentUser.id);
    const otherUser = users.find(u => u.id === otherUserId);
    activeChannelName = otherUser?.name || 'Unknown User';
    activeChannelIcon = <img src={otherUser?.avatar} className="w-8 h-8 rounded-full border border-gray-200" alt="Avatar" />;
    activeUserStatus = otherUser?.status || 'Offline';
  } else {
    const ch = channels.find(c => c.id === activeChannelId);
    activeChannelName = ch?.name || 'Channel';
    activeChannelIcon = <div className="p-2 bg-indigo-100 text-indigo-600 rounded-lg"><Hash size={18} /></div>;
  }

  // Fetch recent messages globally and filter in memory to avoid composite index requirements
  useEffect(() => {
    if (!currentUser) return;

    // Fetch messages from last 30 days
    const thirtyDaysAgo = new Date();
    thirtyDaysAgo.setDate(thirtyDaysAgo.getDate() - 30);

    const q = query(
      collection(db, "chat_messages"),
      where("createdAt", ">=", thirtyDaysAgo)
    );

    const unsubscribe = onSnapshot(q, (snapshot) => {
      const msgs = snapshot.docs.map(doc => {
        const data = doc.data();
        let createdIso = new Date().toISOString();
        if (data.createdAt && typeof data.createdAt.toDate === 'function') {
          createdIso = data.createdAt.toDate().toISOString();
        } else if (typeof data.createdAt === 'string') {
          createdIso = data.createdAt;
        }

        return {
          id: doc.id,
          ...data,
          createdAt: createdIso
        } as ChatMessage;
      });
      
      msgs.sort((a, b) => new Date(a.createdAt).getTime() - new Date(b.createdAt).getTime());
      setAllMessages(msgs);
      scrollToBottom();
    }, (error) => {
      console.log("Messages listener error:", error.code);
    });

    return () => unsubscribe();
  }, [currentUser]);

  // Handle unread messages from the same allMessages state
  useEffect(() => {
    if (!currentUser) return;
    setUnreadMessages(allMessages.filter(m => 
      m.senderId !== currentUser.id && 
      (!m.readBy || !m.readBy.includes(currentUser.id))
    ));
  }, [allMessages, currentUser.id]);

  // Update read status
  useEffect(() => {
    const markAsRead = async () => {
        const unreadMsgs = allMessages.filter(m => 
            m.channelId === activeChannelId && 
            m.senderId !== currentUser.id && 
            (!m.readBy || !m.readBy.includes(currentUser.id))
        );

        if (unreadMsgs.length > 0) {
            unreadMsgs.forEach(async (msg) => {
                try {
                    const msgRef = doc(db, "chat_messages", msg.id);
                    await updateDoc(msgRef, {
                        readBy: arrayUnion(currentUser.id)
                    });
                } catch (e) {
                    console.error("Error marking read:", e);
                }
            });
        }
    };

    markAsRead();
    scrollToBottom();
    setShowEmojiPicker(false);
    setShowPlusMenu(false);
    setIsSearching(false);
    setSearchQuery('');
  }, [activeChannelId, allMessages.length, currentUser.id]);

  const scrollToBottom = () => {
    setTimeout(() => {
      { const box = messagesEndRef.current?.parentElement; if (box) box.scrollTo({ top: box.scrollHeight, behavior: "smooth" }); }
    }, 150);
  };

  const sendMessageInternal = async (text: string, type: 'text' | 'image' | 'poll' | 'event' = 'text') => {
    if (!text.trim()) return;

    const msg: any = {
      channelId: activeChannelId,
      senderId: currentUser.id,
      senderName: currentUser.name,
      senderAvatar: currentUser.avatar,
      text: text.trim(), 
      type: type,
      createdAt: serverTimestamp(),
      readBy: []
    };

    try {
      await addDoc(collection(db, "chat_messages"), msg);
      scrollToBottom();
    } catch (error) {
      console.error("Error sending message:", error);
    }
  };

  const handleSendMessage = async (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    await sendMessageInternal(newMessage, 'text');
    setNewMessage('');
    setShowEmojiPicker(false);
  };

  const handleFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      if (!file.type.startsWith('image/')) {
        toast(language === 'tr' ? 'Sadece resim dosyaları yüklenebilir.' : 'Only image files are allowed.');
        return;
      }
      const img = new Image(); const url = URL.createObjectURL(file);
      img.onload = () => {
        // Firestore belge sınırı (1 MB) için görseli en fazla 1280px JPEG'e küçült
        const r = Math.min(1, 1280 / Math.max(img.width, img.height));
        const c = document.createElement('canvas'); c.width = Math.round(img.width * r); c.height = Math.round(img.height * r);
        c.getContext('2d')!.drawImage(img, 0, 0, c.width, c.height); URL.revokeObjectURL(url);
        const data = c.toDataURL('image/jpeg', 0.82);
        if (data.length > 900000) { toast.error(language === 'tr' ? 'Görsel çok büyük.' : 'Image too large.'); return; }
        sendMessageInternal(data, 'image');
      };
      img.src = url;
    }
    if (fileInputRef.current) fileInputRef.current.value = '';
    setShowPlusMenu(false);
  };

  const handleEmojiClick = (emoji: string) => {
    setNewMessage(prev => prev + emoji);
  };

  // --- Poll & Event Logic ---

  const handleCreatePoll = async () => {
    if (!pollQuestion.trim() || pollOptions.some(o => !o.trim())) return;
    
    const pollData = {
      question: pollQuestion,
      options: pollOptions.map(o => ({ text: o, votes: [] }))
    };
    
    await sendMessageInternal(JSON.stringify(pollData), 'poll');
    setShowPollModal(false);
    setPollQuestion('');
    setPollOptions(['', '']);
    setShowPlusMenu(false);
  };

  const handleCreateEvent = async () => {
    if (!eventTitle.trim() || !eventDate || !eventTime) return;

    const eventData = {
      title: eventTitle,
      date: eventDate,
      time: eventTime
    };

    await sendMessageInternal(JSON.stringify(eventData), 'event');
    setShowEventModal(false);
    setEventTitle('');
    setEventDate('');
    setEventTime('');
    setShowPlusMenu(false);
  };

  const handleVote = async (message: ChatMessage, optionIndex: number) => {
    try {
      const pollData = JSON.parse(message.text);
      const currentUserId = currentUser.id;
      
      pollData.options.forEach((opt: any) => {
        if (opt.votes.includes(currentUserId)) {
          opt.votes = opt.votes.filter((id: string) => id !== currentUserId);
        }
      });

      if (!pollData.options[optionIndex].votes.includes(currentUserId)) {
        pollData.options[optionIndex].votes.push(currentUserId);
      }

      await updateDoc(doc(db, "chat_messages", message.id), {
        text: JSON.stringify(pollData)
      });
    } catch (e) {
      console.error("Vote failed", e);
    }
  };

  const formatTime = (isoString: string) => {
    if (!isoString) return '';
    const date = new Date(isoString);
    return date.toLocaleTimeString(language === 'tr' ? 'tr-TR' : 'en-US', { hour: '2-digit', minute: '2-digit' });
  };

  const getUnreadCount = (channelId: string) => {
    return unreadMessages.filter(m => m.channelId === channelId).length;
  };

  const currentMessages = useMemo(() => {
    let msgs = allMessages.filter(m => m.channelId === activeChannelId);
    if (searchQuery.trim()) {
      const query = searchQuery.toLowerCase();
      msgs = msgs.filter(m => m.text.toLowerCase().includes(query));
    }
    return msgs;
  }, [allMessages, activeChannelId, searchQuery]);

  const handleDraftReply = async (e: React.MouseEvent) => {
    e.stopPropagation();
    const lastReceived = currentMessages.slice().reverse().find(m => m.senderId !== currentUser.id);
    const contextText = lastReceived ? lastReceived.text : language === 'tr' ? 'Merhaba nasılsın?' : 'Hello, how are you?';
    setIsDrafting(true);
    const draft = await draftMessageReply(contextText, language);
    setNewMessage(draft);
    setIsDrafting(false);
  };

  // --- Mesaj içeriği ---
  const renderMessageContent = (msg: ChatMessage, isMe: boolean) => {
    if (msg.type === 'image') {
      return <img src={msg.text} alt="" className="max-w-[260px] max-h-[320px] rounded-xl cursor-zoom-in hover:opacity-95" onClick={() => setLightbox(msg.text)} />;
    }
    if (msg.type === 'poll') {
      let pollData: any;
      try { pollData = JSON.parse(msg.text); } catch { return <p className="text-xs opacity-70">{tr ? 'Anket okunamadı' : 'Invalid poll'}</p>; }
      const totalVotes = pollData.options.reduce((acc: number, opt: any) => acc + opt.votes.length, 0);
      return (
        <div className="min-w-[220px] text-left">
          <p className="text-[11px] font-semibold opacity-70 flex items-center gap-1 mb-1"><BarChart2 size={12} />{tr ? 'Anket' : 'Poll'}</p>
          <p className="font-semibold text-sm mb-2">{pollData.question}</p>
          <div className="space-y-1.5">
            {pollData.options.map((opt: any, idx: number) => {
              const pct = totalVotes ? (opt.votes.length / totalVotes) * 100 : 0;
              const mine = opt.votes.includes(currentUser.id);
              return (
                <button key={idx} onClick={() => handleVote(msg, idx)} className={`relative w-full text-left px-2.5 py-1.5 rounded-lg overflow-hidden text-xs font-semibold border transition-colors ${mine ? (isMe ? 'border-white/70' : 'border-indigo-400') : 'border-transparent'} ${isMe ? 'bg-white/10 hover:bg-white/20' : 'bg-white dark:bg-slate-900 hover:bg-slate-50'}`}>
                  <span className={`absolute inset-y-0 left-0 transition-all duration-500 ${isMe ? 'bg-white/20' : 'bg-indigo-100 dark:bg-indigo-500/20'}`} style={{ width: `${pct}%` }} />
                  <span className="relative flex justify-between gap-3"><span className="flex items-center gap-1">{mine && <Check size={11} />}{opt.text}</span><span>{opt.votes.length}</span></span>
                </button>
              );
            })}
          </div>
          <p className="text-[10px] mt-1.5 opacity-60 text-right">{totalVotes} {tr ? 'oy' : 'votes'}</p>
        </div>
      );
    }
    if (msg.type === 'event') {
      let ev: any;
      try { ev = JSON.parse(msg.text); } catch { return <p className="text-xs opacity-70">{tr ? 'Etkinlik okunamadı' : 'Invalid event'}</p>; }
      const d = new Date(ev.date);
      return (
        <div className="min-w-[200px] text-left flex gap-3 items-center">
          <div className={`rounded-xl px-3 py-2 flex flex-col items-center ${isMe ? 'bg-white/15' : 'bg-white dark:bg-slate-900'}`}><span className="text-[10px] uppercase opacity-70">{d.toLocaleString(tr ? 'tr-TR' : 'en-US', { month: 'short' })}</span><span className="text-xl font-black leading-none">{d.getDate()}</span></div>
          <div className="min-w-0"><p className="text-[11px] font-semibold opacity-70 flex items-center gap-1"><CalendarDays size={12} />{tr ? 'Etkinlik' : 'Event'}</p><p className="text-sm font-bold">{ev.title}</p><p className="text-xs opacity-80 flex items-center gap-1"><Clock size={11} />{d.toLocaleDateString(tr ? 'tr-TR' : 'en-US', { weekday: 'long' })} · {ev.time}</p></div>
        </div>
      );
    }
    const urlRegex = /(https?:\/\/[^\s]+)/g;
    return (
      <p className="text-sm leading-relaxed whitespace-pre-wrap break-words text-left">
        {msg.text.split(urlRegex).map((part, i) => part.match(urlRegex)
          ? <a key={i} href={part} target="_blank" rel="noopener noreferrer" className={`underline underline-offset-2 ${isMe ? 'text-white' : 'text-indigo-600 dark:text-indigo-300'}`} onClick={e => e.stopPropagation()}>{part}</a>
          : part)}
      </p>
    );
  };

  const preview = (m?: ChatMessage) => !m ? '' : m.type === 'image' ? (tr ? '📷 Görsel' : '📷 Image') : m.type === 'poll' ? (tr ? '📊 Anket' : '📊 Poll') : m.type === 'event' ? (tr ? '📅 Etkinlik' : '📅 Event') : m.text;
  const lastOf = (channelId: string) => { for (let i = allMessages.length - 1; i >= 0; i--) if (allMessages[i].channelId === channelId) return allMessages[i]; return undefined; };
  const relTime = (iso?: string) => {
    if (!iso) return '';
    const d = new Date(iso); const now = new Date();
    if (d.toDateString() === now.toDateString()) return formatTime(iso);
    const y = new Date(now); y.setDate(y.getDate() - 1);
    if (d.toDateString() === y.toDateString()) return tr ? 'Dün' : 'Yesterday';
    return d.toLocaleDateString(tr ? 'tr-TR' : 'en-US', { day: 'numeric', month: 'short' });
  };
  const dayLabel = (iso: string) => {
    const d = new Date(iso); const now = new Date(); const y = new Date(now); y.setDate(y.getDate() - 1);
    if (d.toDateString() === now.toDateString()) return tr ? 'Bugün' : 'Today';
    if (d.toDateString() === y.toDateString()) return tr ? 'Dün' : 'Yesterday';
    return d.toLocaleDateString(tr ? 'tr-TR' : 'en-US', { weekday: 'long', day: 'numeric', month: 'long' });
  };
  const pq = peopleQuery.trim().toLocaleLowerCase('tr-TR');
  const dmList = otherUsers
    .filter(u => !pq || u.name.toLocaleLowerCase('tr-TR').includes(pq))
    .map(u => { const id = getDmChannelId(currentUser.id, u.id); return { u, id, last: lastOf(id), unread: getUnreadCount(id) }; })
    .sort((a, b) => (b.last?.createdAt || '').localeCompare(a.last?.createdAt || '') || a.u.name.localeCompare(b.u.name, 'tr'));
  const otherDmUser = isDm ? users.find(u => u.id === activeChannelId.split('_').find(id => id !== currentUser.id)) : undefined;

  return (
    <div className="flex h-[calc(100dvh-9rem)] min-h-[520px] bg-white dark:bg-slate-900 rounded-[24px] border border-slate-100 dark:border-slate-800 overflow-hidden relative">
      {mobileSidebarOpen && <div className="md:hidden absolute inset-0 z-10 bg-slate-950/40 pc-backdrop" onClick={() => setMobileSidebarOpen(false)} />}
      {/* Kenar çubuğu */}
      <aside className={`absolute md:relative z-20 w-[290px] max-w-[85%] h-full bg-slate-50 dark:bg-slate-950/40 flex flex-col border-r border-slate-100 dark:border-slate-800 transition-transform duration-300 ${mobileSidebarOpen ? 'translate-x-0' : '-translate-x-full md:translate-x-0'}`}>
        <div className="p-4 flex items-center gap-2 border-b border-slate-100 dark:border-slate-800">
          <MessageSquare size={18} className="text-indigo-600" /><h3 className="font-bold text-slate-900 dark:text-white flex-1">{tr ? 'Mesajlar' : 'Messages'}</h3>
          {unreadMessages.length > 0 && <span className="text-[10px] font-bold px-1.5 py-0.5 rounded-full bg-indigo-600 text-white">{unreadMessages.length}</span>}
          <button onClick={() => setMobileSidebarOpen(false)} className="md:hidden p-1.5 text-slate-400"><X size={18} /></button>
        </div>
        <div className="p-3"><div className="relative"><Search size={14} className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" /><input value={peopleQuery} onChange={e => setPeopleQuery(e.target.value)} placeholder={tr ? 'Kişi ara…' : 'Find people…'} className="pc-plain-input w-full h-9 pl-8 pr-3 rounded-xl bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-sm outline-none focus:border-indigo-400" /></div></div>
        <div className="flex-1 overflow-y-auto custom-scrollbar px-2 pb-3 space-y-4">
          <div>
            <p className="px-2 mb-1 text-[11px] font-semibold text-slate-400">{tr ? 'Kanallar' : 'Channels'}</p>
            {channels.map(ch => { const active = activeChannelId === ch.id; const unread = getUnreadCount(ch.id); const last = lastOf(ch.id); return (
              <button key={ch.id} onClick={() => { setActiveChannelId(ch.id); setMobileSidebarOpen(false); }} className={`w-full flex items-center gap-2.5 px-2.5 py-2 rounded-xl text-left transition-colors ${active ? 'bg-white dark:bg-slate-800 shadow-sm' : 'hover:bg-white/70 dark:hover:bg-white/5'}`}>
                <span className={`w-8 h-8 rounded-lg flex items-center justify-center ${ch.id === 'announcements' ? 'bg-rose-50 text-rose-600 dark:bg-rose-500/10' : 'bg-indigo-50 text-indigo-600 dark:bg-indigo-500/10'}`}>{ch.id === 'announcements' ? <Megaphone size={15} /> : <Hash size={15} />}</span>
                <span className="min-w-0 flex-1"><span className={`block text-sm truncate ${unread && !active ? 'font-bold text-slate-900 dark:text-white' : 'font-semibold text-slate-700 dark:text-slate-200'}`}>{ch.name}</span>{last && <span className="block text-[11px] text-slate-400 truncate">{last.senderId === currentUser.id ? (tr ? 'Sen: ' : 'You: ') : `${last.senderName.split(' ')[0]}: `}{preview(last)}</span>}</span>
                {unread > 0 && !active && <span className="text-[10px] font-bold min-w-[18px] h-[18px] px-1 rounded-full bg-indigo-600 text-white flex items-center justify-center">{unread > 9 ? '9+' : unread}</span>}
              </button>); })}
          </div>
          <div>
            <p className="px-2 mb-1 text-[11px] font-semibold text-slate-400">{tr ? 'Direkt mesajlar' : 'Direct messages'}</p>
            {dmList.map(({ u, id, last, unread }) => { const active = activeChannelId === id; return (
              <button key={u.id} onClick={() => { setActiveChannelId(id); setMobileSidebarOpen(false); }} className={`w-full flex items-center gap-2.5 px-2.5 py-2 rounded-xl text-left transition-colors ${active ? 'bg-white dark:bg-slate-800 shadow-sm' : 'hover:bg-white/70 dark:hover:bg-white/5'}`}>
                <span className="relative"><Avatar name={u.name} src={u.avatar} size="w-8 h-8" /><span className={`absolute -bottom-0.5 -right-0.5 w-2.5 h-2.5 rounded-full border-2 border-slate-50 dark:border-slate-900 ${u.status === 'Online' ? 'bg-emerald-500' : u.status === 'Busy' ? 'bg-amber-500' : 'bg-slate-300'}`} /></span>
                <span className="min-w-0 flex-1"><span className="flex items-center gap-1"><span className={`text-sm truncate flex-1 ${unread && !active ? 'font-bold text-slate-900 dark:text-white' : 'font-semibold text-slate-700 dark:text-slate-200'}`}>{u.name}</span>{last && <span className="text-[10px] text-slate-400 shrink-0">{relTime(last.createdAt)}</span>}</span><span className="block text-[11px] text-slate-400 truncate">{last ? `${last.senderId === currentUser.id ? (tr ? 'Sen: ' : 'You: ') : ''}${preview(last)}` : (u.jobTitle || u.role)}</span></span>
                {unread > 0 && !active && <span className="text-[10px] font-bold min-w-[18px] h-[18px] px-1 rounded-full bg-indigo-600 text-white flex items-center justify-center">{unread > 9 ? '9+' : unread}</span>}
              </button>); })}
          </div>
        </div>
      </aside>

      {/* Sohbet alanı */}
      <section className="flex-1 flex flex-col min-w-0">
        <header className="h-16 px-4 border-b border-slate-100 dark:border-slate-800 flex items-center gap-3 shrink-0">
          <button onClick={() => setMobileSidebarOpen(true)} className="md:hidden p-1.5 -ml-1 text-slate-400"><Menu size={20} /></button>
          {isDm ? <span className="relative"><Avatar name={activeChannelName} src={otherDmUser?.avatar} size="w-9 h-9" /><span className={`absolute -bottom-0.5 -right-0.5 w-2.5 h-2.5 rounded-full border-2 border-white dark:border-slate-900 ${activeUserStatus === 'Online' ? 'bg-emerald-500' : 'bg-slate-300'}`} /></span>
            : <span className={`w-9 h-9 rounded-xl flex items-center justify-center ${activeChannelId === 'announcements' ? 'bg-rose-50 text-rose-600 dark:bg-rose-500/10' : 'bg-indigo-50 text-indigo-600 dark:bg-indigo-500/10'}`}>{activeChannelId === 'announcements' ? <Megaphone size={16} /> : <Hash size={16} />}</span>}
          <div className="min-w-0 flex-1">
            <p className="text-sm font-bold text-slate-900 dark:text-white truncate">{activeChannelName}</p>
            <p className="text-[11px] text-slate-400 truncate">{isDm ? (activeUserStatus === 'Online' ? (tr ? 'Çevrim içi' : 'Online') : (otherDmUser?.jobTitle || (tr ? 'Çevrim dışı' : 'Offline'))) : (tr ? `${users.length} üye · son 30 gün` : `${users.length} members`)}</p>
          </div>
          {isSearching ? (
            <div className="flex items-center gap-1.5 h-9 px-2.5 rounded-xl bg-slate-100 dark:bg-slate-800 w-40 sm:w-64 animate-in fade-in slide-in-from-right-2 duration-200">
              <Search size={14} className="text-slate-400" />
              <input ref={searchInputRef} value={searchQuery} onChange={e => setSearchQuery(e.target.value)} placeholder={tr ? 'Sohbette ara…' : 'Search chat…'} className="pc-plain-input flex-1 min-w-0 bg-transparent text-sm outline-none" />
              <button onClick={() => { setIsSearching(false); setSearchQuery(''); }} className="text-slate-400"><X size={14} /></button>
            </div>
          ) : <button onClick={() => setIsSearching(true)} title={tr ? 'Ara' : 'Search'} className="p-2 rounded-xl text-slate-400 hover:text-indigo-600 hover:bg-indigo-50 dark:hover:bg-white/5"><Search size={17} /></button>}
        </header>

        <div className="flex-1 overflow-y-auto custom-scrollbar px-4 sm:px-6 py-4">
          {currentMessages.length === 0 ? (
            <div className="h-full flex flex-col items-center justify-center text-center gap-2 text-slate-400">
              <span className="w-14 h-14 rounded-2xl bg-slate-100 dark:bg-slate-800 flex items-center justify-center">{searchQuery ? <Search size={24} /> : <MessageSquare size={24} />}</span>
              <p className="text-sm font-semibold">{searchQuery ? (tr ? 'Sonuç bulunamadı' : 'No matches') : (tr ? 'Henüz mesaj yok — ilk mesajı sen yaz 👋' : 'No messages yet')}</p>
            </div>
          ) : currentMessages.map((msg, index) => {
            const isMe = msg.senderId === currentUser.id;
            const prev = currentMessages[index - 1];
            const newDay = !prev || new Date(prev.createdAt).toDateString() !== new Date(msg.createdAt).toDateString();
            const showHeader = newDay || !prev || prev.senderId !== msg.senderId || new Date(msg.createdAt).getTime() - new Date(prev.createdAt).getTime() > 5 * 60000;
            let isRead = false;
            if (isDm) { const oid = activeChannelId.split('_').find(id => id !== currentUser.id); isRead = !!(oid && msg.readBy?.includes(oid)); }
            else isRead = !!msg.readBy?.some(id => id !== msg.senderId);
            const bubble = msg.type === 'image' ? 'p-1' : 'px-3.5 py-2';
            return (
              <React.Fragment key={msg.id}>
                {newDay && <div className="flex items-center gap-3 my-4"><span className="flex-1 h-px bg-slate-100 dark:bg-slate-800" /><span className="text-[11px] font-semibold text-slate-400">{dayLabel(msg.createdAt)}</span><span className="flex-1 h-px bg-slate-100 dark:bg-slate-800" /></div>}
                <div className={`flex gap-2.5 group ${showHeader ? 'mt-3' : 'mt-0.5'} ${isMe ? 'flex-row-reverse' : ''} animate-in fade-in slide-in-from-bottom-1 duration-200`}>
                  <div className="w-8 shrink-0">{showHeader && !isMe && <Avatar name={msg.senderName} src={msg.senderAvatar} size="w-8 h-8" />}</div>
                  <div className={`min-w-0 max-w-[78%] flex flex-col ${isMe ? 'items-end' : 'items-start'}`}>
                    {showHeader && !isMe && !isDm && <span className="text-xs font-semibold text-slate-600 dark:text-slate-300 mb-0.5 ml-1">{msg.senderName}</span>}
                    <div className={`${bubble} ${isMe ? 'bg-indigo-600 text-white rounded-2xl rounded-br-md' : 'bg-slate-100 dark:bg-slate-800 text-slate-800 dark:text-slate-100 rounded-2xl rounded-bl-md'}`}>{renderMessageContent(msg, isMe)}</div>
                    <span className="text-[10px] text-slate-400 mt-0.5 px-1 flex items-center gap-1 opacity-0 group-hover:opacity-100 transition-opacity">{formatTime(msg.createdAt)}{isMe && <CheckCheck size={12} className={isRead ? 'text-emerald-500' : 'text-slate-300'} />}</span>
                  </div>
                </div>
              </React.Fragment>
            );
          })}
          <div ref={messagesEndRef} />
        </div>

        {/* Yazma alanı */}
        <div className="p-3 sm:p-4 pt-0 relative shrink-0">
          {showEmojiPicker && (
            <div className="absolute bottom-full right-4 mb-2 z-30 bg-white dark:bg-slate-800 border border-slate-100 dark:border-slate-700 shadow-2xl rounded-2xl p-2 grid grid-cols-5 gap-1 w-64 pc-pop">
              {COMMON_EMOJIS.map(e => <button key={e} onClick={() => handleEmojiClick(e)} className="text-xl p-1.5 rounded-lg hover:bg-slate-100 dark:hover:bg-white/5">{e}</button>)}
            </div>
          )}
          {showPlusMenu && (
            <div className="absolute bottom-full left-4 mb-2 z-30 bg-white dark:bg-slate-800 border border-slate-100 dark:border-slate-700 shadow-2xl rounded-2xl p-1.5 w-52 pc-pop">
              {[[Vote, tr ? 'Anket oluştur' : 'Create poll', () => { setShowPollModal(true); setShowPlusMenu(false); }], [ImageIcon, tr ? 'Görsel gönder' : 'Send image', () => fileInputRef.current?.click()], [CalendarPlus, tr ? 'Etkinlik paylaş' : 'Share event', () => { setShowEventModal(true); setShowPlusMenu(false); }]].map(([I, l, fn]: any) => (
                <button key={l} onClick={fn} className="w-full flex items-center gap-2.5 px-2.5 py-2 rounded-xl text-sm font-semibold text-slate-600 dark:text-slate-300 hover:bg-indigo-50 hover:text-indigo-600 dark:hover:bg-white/5"><I size={16} />{l}</button>
              ))}
            </div>
          )}
          <div className="flex items-end gap-1.5 rounded-2xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800/60 p-1.5 focus-within:border-indigo-400 focus-within:ring-4 focus-within:ring-indigo-500/10 transition-all" onClick={() => textareaRef.current?.focus()}>
            <input type="file" ref={fileInputRef} onChange={handleFileSelect} className="hidden" accept="image/*" />
            <button onClick={e => { e.stopPropagation(); setShowPlusMenu(!showPlusMenu); setShowEmojiPicker(false); }} className={`w-9 h-9 shrink-0 rounded-xl flex items-center justify-center transition-all ${showPlusMenu ? 'bg-slate-900 text-white rotate-45' : 'text-slate-400 hover:text-indigo-600 hover:bg-white dark:hover:bg-white/5'}`}><Plus size={18} /></button>
            <textarea ref={textareaRef} rows={1} value={newMessage}
              onChange={e => { setNewMessage(e.target.value); e.target.style.height = 'auto'; e.target.style.height = Math.min(128, e.target.scrollHeight) + 'px'; }}
              onKeyDown={e => { if (e.key === 'Enter' && !e.shiftKey && !(e.nativeEvent as any).isComposing) { e.preventDefault(); handleSendMessage(); if (textareaRef.current) textareaRef.current.style.height = 'auto'; } }}
              placeholder={activeChannelId === 'announcements' ? (tr ? 'Duyuru yaz…' : 'Write an announcement…') : (tr ? `${activeChannelName} kanalına yaz… (Shift+Enter yeni satır)` : 'Type a message…')}
              className="pc-plain-input flex-1 min-w-0 bg-transparent text-sm text-slate-800 dark:text-slate-100 py-2 px-1 resize-none outline-none max-h-32 custom-scrollbar placeholder:text-slate-400" />
            <button onClick={handleDraftReply} disabled={isDrafting} title={tr ? 'AI yanıt taslağı' : 'AI draft'} className="w-9 h-9 shrink-0 rounded-xl flex items-center justify-center text-slate-400 hover:text-violet-600 disabled:opacity-50">{isDrafting ? <Loader2 size={17} className="animate-spin" /> : <Sparkles size={17} />}</button>
            <button onClick={e => { e.stopPropagation(); setShowEmojiPicker(!showEmojiPicker); setShowPlusMenu(false); }} className={`w-9 h-9 shrink-0 rounded-xl flex items-center justify-center ${showEmojiPicker ? 'text-indigo-600 bg-indigo-50 dark:bg-indigo-500/10' : 'text-slate-400 hover:text-indigo-600'}`}><Smile size={17} /></button>
            <button onClick={e => { e.stopPropagation(); handleSendMessage(); if (textareaRef.current) textareaRef.current.style.height = 'auto'; }} disabled={!newMessage.trim()} className={`w-9 h-9 shrink-0 rounded-xl flex items-center justify-center transition-all ${newMessage.trim() ? 'bg-indigo-600 text-white shadow-md shadow-indigo-500/30 hover:bg-indigo-500 scale-100' : 'bg-slate-200 dark:bg-slate-700 text-slate-400 scale-95'}`}><Send size={16} /></button>
          </div>
        </div>
      </section>

      {lightbox && <div className="fixed inset-0 z-[1200] bg-slate-950/90 flex items-center justify-center p-6 pc-backdrop" onClick={() => setLightbox(null)}><img src={lightbox} alt="" className="max-w-full max-h-full rounded-xl pc-pop" /><button className="absolute top-4 right-4 p-2 rounded-full bg-white/10 text-white"><X size={22} /></button></div>}

      <Sheet open={showPollModal} language={language} title={tr ? 'Anket oluştur' : 'Create poll'} icon={Vote} onClose={() => setShowPollModal(false)} onSubmit={handleCreatePoll} submitLabel={tr ? 'Paylaş' : 'Share'}>
        <Field label={tr ? 'Soru' : 'Question'} required><input autoFocus className={inputCls()} value={pollQuestion} onChange={e => setPollQuestion(e.target.value)} placeholder={tr ? 'Örn: Cuma toplantısı kaçta olsun?' : 'Ask a question'} /></Field>
        <Field label={tr ? 'Seçenekler' : 'Options'}>
          <div className="space-y-2">{pollOptions.map((o, i) => (
            <div key={i} className="flex gap-2"><input className={inputCls()} value={o} placeholder={`${tr ? 'Seçenek' : 'Option'} ${i + 1}`} onChange={e => setPollOptions(pollOptions.map((x, j) => j === i ? e.target.value : x))} />{pollOptions.length > 2 && <button onClick={() => setPollOptions(pollOptions.filter((_, j) => j !== i))} className="p-2 text-slate-400 hover:text-rose-500"><X size={16} /></button>}</div>
          ))}</div>
          {pollOptions.length < 8 && <button onClick={() => setPollOptions([...pollOptions, ''])} className="mt-2 text-xs font-semibold text-indigo-600 hover:underline">+ {tr ? 'Seçenek ekle' : 'Add option'}</button>}
        </Field>
        {(!pollQuestion.trim() || pollOptions.some(o => !o.trim())) && <p className="text-[11px] text-slate-400">{tr ? 'Soru ve tüm seçenekler dolu olmalı.' : 'Fill question and all options.'}</p>}
      </Sheet>

      <Sheet open={showEventModal} language={language} title={tr ? 'Etkinlik paylaş' : 'Share event'} icon={CalendarPlus} tone="from-emerald-500 to-teal-600" onClose={() => setShowEventModal(false)} onSubmit={handleCreateEvent} submitLabel={tr ? 'Paylaş' : 'Share'}>
        <Field label={tr ? 'Başlık' : 'Title'} required><input autoFocus className={inputCls()} value={eventTitle} onChange={e => setEventTitle(e.target.value)} /></Field>
        <div className="grid grid-cols-2 gap-4">
          <Field label={tr ? 'Tarih' : 'Date'} required><input type="date" className={inputCls()} value={eventDate} onChange={e => setEventDate(e.target.value)} /></Field>
          <Field label={tr ? 'Saat' : 'Time'} required><input type="time" className={inputCls()} value={eventTime} onChange={e => setEventTime(e.target.value)} /></Field>
        </div>
      </Sheet>
    </div>
  );
};

export default MessagesView;
