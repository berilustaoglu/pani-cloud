import React, { useEffect, useMemo, useState } from 'react';
import { Sun, Moon, Sunrise, Clock, PlayCircle, StopCircle, CheckCircle2, ListTodo, Video, CalendarDays, Palmtree, FolderOpen, Bell, ChevronRight, AlertTriangle, Loader2, Sparkles } from 'lucide-react';
import { Task, TaskStatus, Project, User, Meeting, AttendanceRecord, LeaveRequest, StaffDocument, SystemNotification } from '../types';
import { cardCls, Avatar } from './ui/Kit';
import { ProgressRing } from './ui/Motion';
import { localISO, dayDiff, suspendedProjectIds } from '../services/insights';
import { countLeaveDays } from './LeaveView';
import { toast } from '../services/toast';

interface Props {
  currentUser: User;
  language: 'tr' | 'en';
  tasks: Task[];
  projects: Project[];
  meetings: Meeting[];
  attendance: AttendanceRecord[];
  leaveRequests: LeaveRequest[];
  staffDocuments: StaffDocument[];
  notifications: SystemNotification[];
  hrSettings?: { dailyWorkHours?: number; defaultAnnualLeaveDays?: number };
  onClockIn?: (userId: string, userName: string) => Promise<void>;
  onUpsertAttendance: (r: AttendanceRecord) => Promise<void>;
  onUpdateTask: (t: Task) => Promise<void>;
  onNavigate: (tab: string) => void;
  tasksTab: string; // çalışan için 'tasks', yönetici için 'mytasks'
}

const toMin = (hhmm?: string) => { if (!hhmm) return 0; const [h, m] = hhmm.split(':').map(Number); return (h || 0) * 60 + (m || 0); };
const fmtDur = (m: number) => `${Math.floor(m / 60)}s ${String(Math.max(0, Math.round(m % 60))).padStart(2, '0')}dk`;

const MyDayView: React.FC<Props> = ({ currentUser, language, tasks, projects, meetings, attendance, leaveRequests, staffDocuments, notifications, hrSettings, onClockIn, onUpsertAttendance, onUpdateTask, onNavigate, tasksTab }) => {
  const tr = language === 'tr';
  const [now, setNow] = useState(new Date());
  useEffect(() => { const t = setInterval(() => setNow(new Date()), 30000); return () => clearInterval(t); }, []);
  const today = localISO(now);
  const nowMin = now.getHours() * 60 + now.getMinutes();
  const [busy, setBusy] = useState<string | null>(null);
  const dailyH = Number(hrSettings?.dailyWorkHours) || 9;

  const hour = now.getHours();
  const greet = hour < 6 ? { t: tr ? 'İyi geceler' : 'Good night', I: Moon } : hour < 12 ? { t: tr ? 'Günaydın' : 'Good morning', I: Sunrise } : hour < 18 ? { t: tr ? 'İyi günler' : 'Good afternoon', I: Sun } : { t: tr ? 'İyi akşamlar' : 'Good evening', I: Moon };
  const firstName = currentUser.name.split(' ')[0];

  // ---------- Mesai ----------
  const myRecs = attendance.filter(a => a.userId === currentUser.id && a.date === today);
  const openRec = myRecs.find(a => !a.clockOut);
  const workedMin = myRecs.reduce((a, r) => { const end = r.clockOut ? toMin(r.clockOut) : nowMin; let d = end - toMin(r.clockIn); if (d < 0) d += 1440; return a + d; }, 0);
  const shiftPct = Math.min(100, (workedMin / (dailyH * 60)) * 100);
  const startShift = async () => { if (!onClockIn) return; setBusy('shift'); try { await onClockIn(currentUser.id, currentUser.name); toast.success(tr ? 'Mesai başladı. Kolay gelsin!' : 'Shift started'); } finally { setBusy(null); } };
  const endShift = async () => { if (!openRec) return; setBusy('shift'); try { await onUpsertAttendance({ ...openRec, clockOut: now.toLocaleTimeString('tr-TR', { hour: '2-digit', minute: '2-digit' }) }); toast.success(tr ? 'Mesai bitti. İyi dinlenmeler!' : 'Shift ended'); } finally { setBusy(null); } };

  // ---------- Görevler ----------
  const held = suspendedProjectIds(projects);
  const mine = tasks.filter(t => t.assignedTo?.includes(currentUser.id) && t.status !== TaskStatus.DONE && !held.has(t.projectId));
  const overdue = mine.filter(t => t.deadline && t.deadline < today);
  const dueToday = mine.filter(t => t.deadline === today);
  const doing = mine.filter(t => t.status === TaskStatus.DOING && !(t.deadline && t.deadline <= today));
  const focus = [...overdue, ...dueToday, ...doing].filter((t, i, a) => a.findIndex(x => x.id === t.id) === i).slice(0, 6);
  const doneToday = tasks.filter(t => t.assignedTo?.includes(currentUser.id) && t.status === TaskStatus.DONE && t.deadline === today).length;
  const projectName = (id: string) => projects.find(p => p.id === id)?.name || (tr ? 'Genel' : 'General');
  const quick = async (t: Task, status: TaskStatus) => {
    setBusy(t.id);
    try { await onUpdateTask({ ...t, status, ...(status === TaskStatus.DOING ? { blockedReason: '' } : {}) }); toast(status === TaskStatus.DONE ? (tr ? `"${t.title}" tamamlandı 🎉` : 'Done 🎉') : (tr ? 'Görev başlatıldı' : 'Started'), status === TaskStatus.DONE ? 'success' : 'info', 2400); }
    finally { setBusy(null); }
  };

  // ---------- Toplantılar ----------
  const myMeetings = useMemo(() => meetings
    .filter(m => m.status !== 'cancelled' && m.status !== 'completed' && (m.createdBy === currentUser.id || m.participants?.includes(currentUser.id)) && m.date >= today)
    .sort((a, b) => (a.date + a.time).localeCompare(b.date + b.time)).slice(0, 3), [meetings, currentUser.id, today]);
  const meetingLabel = (m: Meeting) => {
    if (m.date !== today) { const d = dayDiff(m.date)!; return d === 1 ? (tr ? `Yarın ${m.time}` : `Tomorrow ${m.time}`) : `${new Date(m.date + 'T00:00').toLocaleDateString(tr ? 'tr-TR' : 'en-US', { day: 'numeric', month: 'short' })} ${m.time}`; }
    const diff = toMin(m.time) - nowMin;
    if (diff <= 0 && diff > -(m.durationMinutes || 60)) return tr ? 'Şu an devam ediyor' : 'In progress';
    if (diff > 0 && diff <= 60) return tr ? `${diff} dk sonra` : `in ${diff} min`;
    return `${tr ? 'Bugün' : 'Today'} ${m.time}`;
  };
  const isSoon = (m: Meeting) => m.date === today && toMin(m.time) - nowMin <= 10 && toMin(m.time) - nowMin > -(m.durationMinutes || 60);

  // ---------- İzin ----------
  const year = today.slice(0, 4);
  const allowance = currentUser.annualLeaveAllowance ?? hrSettings?.defaultAnnualLeaveDays ?? 14;
  const usedAnnual = leaveRequests.filter(l => l.userId === currentUser.id && l.status === 'Approved' && l.type === 'Yıllık İzin' && l.startDate.startsWith(year)).reduce((a, l) => a + countLeaveDays(l.startDate, l.endDate, l.includeWeekends), 0);
  const remaining = Math.max(0, allowance - usedAnnual);
  const myPending = leaveRequests.filter(l => l.userId === currentUser.id && l.status === 'Pending');
  const nextLeave = leaveRequests.filter(l => l.userId === currentUser.id && l.status === 'Approved' && l.endDate >= today).sort((a, b) => a.startDate.localeCompare(b.startDate))[0];

  // ---------- Dosyalar & bildirimler ----------
  const newDocs = staffDocuments.filter(d => d.userId === currentUser.id && !d.readAt && d.sharedById !== currentUser.id).sort((a, b) => (b.uploadDate || '').localeCompare(a.uploadDate || ''));
  const unread = notifications.filter(n => !n.readBy?.includes(currentUser.id) && n.createdBy !== currentUser.id).slice(0, 3);

  const summary = (() => {
    const parts: string[] = [];
    if (overdue.length) parts.push(tr ? `${overdue.length} geciken` : `${overdue.length} overdue`);
    if (dueToday.length) parts.push(tr ? `${dueToday.length} bugün teslim` : `${dueToday.length} due today`);
    const mt = myMeetings.filter(m => m.date === today).length;
    if (mt) parts.push(tr ? `${mt} toplantı` : `${mt} meetings`);
    if (!parts.length) return tr ? 'Bugün için acil bir şey görünmüyor. Güzel bir gün geçirmen dileğiyle!' : 'Nothing urgent today.';
    return tr ? `Bugün seni bekleyenler: ${parts.join(', ')}.` : `Today: ${parts.join(', ')}.`;
  })();

  const Section: React.FC<{ title: string; icon: React.ElementType; action?: React.ReactNode; children: React.ReactNode; className?: string }> = ({ title, icon: I, action, children, className = '' }) => (
    <div className={`${cardCls} p-4 ${className}`}>
      <div className="flex items-center gap-2 mb-3"><I size={16} className="text-indigo-500" /><h3 className="font-bold text-slate-900 dark:text-white flex-1">{title}</h3>{action}</div>
      {children}
    </div>
  );
  const linkBtn = (label: string, tab: string) => <button onClick={() => onNavigate(tab)} className="text-xs font-semibold text-indigo-600 hover:underline inline-flex items-center gap-0.5">{label}<ChevronRight size={13} /></button>;

  return (
    <div className="space-y-4 pb-10">
      {/* Karşılama + mesai */}
      <div className="relative overflow-hidden rounded-[24px] bg-gradient-to-br from-indigo-600 via-violet-600 to-fuchsia-600 text-white p-5 sm:p-6 shadow-xl shadow-indigo-500/20">
        <div className="absolute -top-20 -right-16 w-64 h-64 rounded-full bg-white/10 blur-2xl pc-blob" />
        <div className="relative flex flex-col md:flex-row md:items-center gap-5">
          <div className="flex-1 min-w-0">
            <p className="text-sm text-white/80 flex items-center gap-1.5"><greet.I size={15} />{now.toLocaleDateString(tr ? 'tr-TR' : 'en-US', { weekday: 'long', day: 'numeric', month: 'long' })}</p>
            <h1 className="text-2xl sm:text-3xl font-black mt-1">{greet.t}, {firstName}</h1>
            <p className="text-sm text-white/85 mt-2 max-w-xl">{summary}</p>
          </div>
          <div className="flex items-center gap-4 bg-white/10 rounded-2xl p-3 backdrop-blur-sm">
            <ProgressRing value={shiftPct} size={72} stroke={7} color="#ffffff" track="rgba(255,255,255,.2)"><div className="text-center"><p className="text-xs font-black leading-none">{fmtDur(workedMin)}</p><p className="text-[9px] text-white/70">/ {dailyH} {tr ? 'sa' : 'h'}</p></div></ProgressRing>
            <div className="min-w-0">
              <p className="text-[11px] text-white/75">{openRec ? (tr ? `Mesai ${openRec.clockIn}'de başladı` : `Started ${openRec.clockIn}`) : myRecs.length ? (tr ? 'Bugünkü mesai tamamlandı' : 'Shift completed') : (tr ? 'Mesai başlamadı' : 'Not clocked in')}</p>
              {openRec
                ? <button disabled={busy === 'shift'} onClick={endShift} className="mt-1.5 h-9 px-3 rounded-xl bg-white text-rose-600 text-sm font-semibold inline-flex items-center gap-1.5 disabled:opacity-60">{busy === 'shift' ? <Loader2 size={14} className="animate-spin" /> : <StopCircle size={15} />}{tr ? 'Mesaiyi bitir' : 'End shift'}</button>
                : <button disabled={busy === 'shift' || !onClockIn} onClick={startShift} className="mt-1.5 h-9 px-3 rounded-xl bg-white text-indigo-700 text-sm font-semibold inline-flex items-center gap-1.5 disabled:opacity-60">{busy === 'shift' ? <Loader2 size={14} className="animate-spin" /> : <PlayCircle size={15} />}{tr ? 'Mesaiyi başlat' : 'Start shift'}</button>}
            </div>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4 items-start">
        {/* Odak */}
        <Section title={tr ? 'Bugünün odağı' : "Today's focus"} icon={ListTodo} className="lg:col-span-2" action={linkBtn(tr ? `Tüm görevler (${mine.length})` : `All tasks (${mine.length})`, tasksTab)}>
          {focus.length === 0 ? (
            <div className="py-8 text-center"><Sparkles size={28} className="mx-auto text-emerald-500 mb-2" /><p className="text-sm font-semibold text-slate-700 dark:text-slate-200">{mine.length ? (tr ? 'Acil iş yok' : 'Nothing urgent') : (tr ? 'Açık görevin yok 🎉' : 'No open tasks 🎉')}</p>{mine.length > 0 && <p className="text-xs text-slate-400 mt-1">{tr ? `${mine.length} açık görevin var; hepsinin tarihi ileride.` : 'All other tasks are due later.'}</p>}</div>
          ) : (
            <div className="space-y-1.5 pc-stagger">
              {focus.map(t => { const od = t.deadline && t.deadline < today; return (
                <div key={t.id} className="flex items-center gap-3 px-2.5 py-2 rounded-xl hover:bg-slate-50 dark:hover:bg-white/[0.03]">
                  <span className={`w-2 h-2 rounded-full shrink-0 ${od ? 'bg-rose-500' : t.deadline === today ? 'bg-amber-500' : 'bg-sky-500 pc-dot-pulse'}`} />
                  <div className="min-w-0 flex-1"><p className="text-sm font-semibold text-slate-800 dark:text-slate-100 truncate">{t.title}</p><p className={`text-[11px] ${od ? 'text-rose-600' : 'text-slate-400'}`}>{projectName(t.projectId)} · {od ? (tr ? `${-dayDiff(t.deadline)!} gün gecikti` : 'overdue') : t.deadline === today ? (tr ? 'bugün teslim' : 'due today') : (tr ? 'devam ediyor' : 'in progress')}</p></div>
                  {t.status === TaskStatus.TODO && <button disabled={busy === t.id} onClick={() => quick(t, TaskStatus.DOING)} className="h-8 px-2.5 rounded-lg text-[11px] font-semibold text-indigo-700 bg-indigo-50 dark:bg-indigo-500/10 dark:text-indigo-300 disabled:opacity-50">{tr ? 'Başla' : 'Start'}</button>}
                  <button disabled={busy === t.id} onClick={() => quick(t, TaskStatus.DONE)} title={tr ? 'Tamamla' : 'Complete'} className="h-8 w-8 rounded-lg flex items-center justify-center text-emerald-600 bg-emerald-50 hover:bg-emerald-100 dark:bg-emerald-500/10 disabled:opacity-50">{busy === t.id ? <Loader2 size={14} className="animate-spin" /> : <CheckCircle2 size={15} />}</button>
                </div>); })}
            </div>
          )}
          {doneToday > 0 && <p className="text-[11px] text-emerald-600 mt-2">✓ {tr ? `Bugün ${doneToday} görev tamamladın` : `${doneToday} completed today`}</p>}
        </Section>

        <div className="space-y-4">
          {/* Toplantılar */}
          <Section title={tr ? 'Toplantılarım' : 'Meetings'} icon={Video} action={linkBtn(tr ? 'Tümü' : 'All', 'meetings')}>
            {myMeetings.length === 0 ? <p className="text-sm text-slate-400">{tr ? 'Planlı toplantın yok.' : 'No upcoming meetings.'}</p> : (
              <div className="space-y-2">
                {myMeetings.map(m => (
                  <button key={m.id} onClick={() => onNavigate('meetings')} className={`w-full text-left flex items-center gap-3 p-2.5 rounded-xl ${isSoon(m) ? 'bg-emerald-50 dark:bg-emerald-500/10' : 'bg-slate-50 dark:bg-white/[0.03]'}`}>
                    <span className={`w-9 h-9 rounded-lg flex items-center justify-center ${isSoon(m) ? 'bg-emerald-500 text-white' : 'bg-white dark:bg-slate-800 text-slate-500'}`}><Video size={15} /></span>
                    <span className="min-w-0 flex-1"><span className="block text-sm font-semibold text-slate-800 dark:text-slate-100 truncate">{m.title}</span><span className={`block text-[11px] ${isSoon(m) ? 'text-emerald-700 dark:text-emerald-300 font-semibold' : 'text-slate-400'}`}>{meetingLabel(m)}</span></span>
                    {isSoon(m) && <span className="text-[11px] font-bold text-emerald-700 dark:text-emerald-300">{tr ? 'Katıl' : 'Join'}</span>}
                  </button>
                ))}
              </div>
            )}
          </Section>

          {/* İzin */}
          <Section title={tr ? 'İzinlerim' : 'Leave'} icon={Palmtree} action={linkBtn(tr ? 'İzin talep et' : 'Request', 'leave')}>
            <div className="flex items-end gap-2"><p className="text-3xl font-black text-slate-900 dark:text-white">{remaining}</p><p className="text-sm text-slate-500 pb-1">{tr ? `/ ${allowance} gün yıllık izin kaldı` : `/ ${allowance} days left`}</p></div>
            <div className="mt-2 h-1.5 rounded-full bg-slate-100 dark:bg-slate-800 overflow-hidden"><div className="h-full bg-emerald-500 rounded-full transition-all duration-700" style={{ width: `${allowance ? (remaining / allowance) * 100 : 0}%` }} /></div>
            {myPending.length > 0 && <p className="text-xs text-amber-600 mt-2 flex items-center gap-1"><Clock size={12} />{tr ? `${myPending.length} talebin onay bekliyor` : `${myPending.length} pending`}</p>}
            {nextLeave && <p className="text-xs text-slate-500 mt-1 flex items-center gap-1"><CalendarDays size={12} />{nextLeave.startDate <= today ? (tr ? `Şu an izindesin (${nextLeave.endDate}'e kadar)` : 'On leave now') : (tr ? `Sıradaki izin: ${nextLeave.startDate} → ${nextLeave.endDate}` : `Next: ${nextLeave.startDate}`)}</p>}
          </Section>
        </div>

        {/* Dosyalar */}
        <Section title={tr ? 'Yeni dosyalar' : 'New files'} icon={FolderOpen} action={linkBtn(tr ? 'Dosyalarım' : 'My files', 'staffdocs')}>
          {newDocs.length === 0 ? <p className="text-sm text-slate-400">{tr ? 'Açılmamış dosya yok.' : 'No new files.'}</p> : (
            <div className="space-y-1.5">
              {newDocs.slice(0, 3).map(d => (
                <button key={d.id} onClick={() => onNavigate('staffdocs')} className="w-full text-left flex items-center gap-2.5 p-2 rounded-xl hover:bg-slate-50 dark:hover:bg-white/[0.03]">
                  <span className="text-[10px] font-bold w-9 h-9 rounded-lg bg-indigo-50 text-indigo-600 dark:bg-indigo-500/10 flex items-center justify-center uppercase">{(d.fileType || 'doc').slice(0, 4)}</span>
                  <span className="min-w-0 flex-1"><span className="block text-sm font-semibold text-slate-800 dark:text-slate-100 truncate">{d.fileName}</span><span className="block text-[11px] text-slate-400 truncate">{d.sharedByName || (tr ? 'Yönetim' : 'Management')} · {d.projectName}</span></span>
                </button>
              ))}
              {newDocs.length > 3 && <p className="text-[11px] text-slate-400 pl-2">+{newDocs.length - 3} {tr ? 'dosya daha' : 'more'}</p>}
            </div>
          )}
        </Section>

        {/* Bildirimler */}
        <Section title={tr ? 'Son bildirimler' : 'Notifications'} icon={Bell} className="lg:col-span-2">
          {unread.length === 0 ? <p className="text-sm text-slate-400">{tr ? 'Okunmamış bildirimin yok.' : 'All caught up.'}</p> : (
            <div className="space-y-1.5">
              {unread.map(n => (
                <button key={n.id} onClick={() => n.tab && onNavigate(n.tab)} className="w-full text-left flex items-start gap-2.5 p-2 rounded-xl hover:bg-slate-50 dark:hover:bg-white/[0.03]">
                  <span className={`mt-0.5 w-7 h-7 rounded-lg flex items-center justify-center shrink-0 ${n.type === 'error' || n.type === 'warning' ? 'bg-amber-50 text-amber-600 dark:bg-amber-500/10' : 'bg-indigo-50 text-indigo-600 dark:bg-indigo-500/10'}`}>{n.type === 'error' || n.type === 'warning' ? <AlertTriangle size={13} /> : <Bell size={13} />}</span>
                  <span className="min-w-0"><span className="block text-sm font-semibold text-slate-800 dark:text-slate-100">{n.title}</span>{n.description && <span className="block text-xs text-slate-500 truncate">{n.description}</span>}</span>
                </button>
              ))}
            </div>
          )}
        </Section>
      </div>

      <div className="flex items-center gap-2 text-[11px] text-slate-400"><Avatar name={currentUser.name} src={currentUser.avatar} size="w-5 h-5" className="!rounded-full" />{currentUser.jobTitle || currentUser.role}</div>
    </div>
  );
};

export default MyDayView;
