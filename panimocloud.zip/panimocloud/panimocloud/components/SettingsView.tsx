import React, { Suspense, lazy, useEffect, useMemo, useState } from 'react';
import {
  Settings, Briefcase, Save, RotateCcw, Lock, Users, Wallet, Asterisk, Building2, BellRing, ShieldAlert, Database,
  Download, X, Plus, CheckCircle2, Loader2, FileJson, Info, Palette, Sun, Moon, Monitor, Languages, Sparkles, Check, Archive
} from 'lucide-react';
import {
  ProjectFormField, ProjectFormSettings, DEFAULT_PROJECT_FORM_SETTINGS, HRSettings, FinanceSettings, CompanySettings,
  AlertSettings, DEFAULT_ALERT_SETTINGS, DEFAULT_INCOME_CATEGORIES, DEFAULT_EXPENSE_CATEGORIES, Currency
} from '../types';
import { PROJECT_FIELDS, PROJECT_FIELD_GROUPS, isFieldRequired } from '../services/projectFields';
import { toast } from '../services/toast';

const SystemLogsView = lazy(() => import('./SystemLogsView'));

export type SettingsTab = 'appearance' | 'company' | 'projectForm' | 'hr' | 'finance' | 'alerts' | 'logs' | 'archive' | 'data';

type ThemeMode = 'auto' | 'dark' | 'light';

interface Props {
  language: 'tr' | 'en';
  isAdmin?: boolean;
  themeMode?: ThemeMode;
  onThemeModeChange?: (m: ThemeMode) => void;
  isDark?: boolean;
  onLanguageChange?: (l: 'tr' | 'en') => void;
  reduceMotion?: boolean;
  onReduceMotionChange?: (v: boolean) => void;
  initialTab?: SettingsTab;
  onTabChange?: (t: SettingsTab) => void;
  projectFormSettings: ProjectFormSettings;
  onSaveProjectFormSettings: (s: ProjectFormSettings) => Promise<void>;
  hrSettings: HRSettings;
  onSaveHrSettings: (s: HRSettings) => Promise<void>;
  financeSettings: FinanceSettings;
  onSaveFinanceSettings: (s: FinanceSettings) => Promise<void>;
  companySettings: CompanySettings;
  onSaveCompanySettings: (s: CompanySettings) => Promise<void>;
  alertSettings: AlertSettings;
  onSaveAlertSettings: (s: AlertSettings) => Promise<void>;
  getBackupData?: () => Record<string, unknown[]>;
  /** Proje arşivi (tamamlanan işler) — yönetici ve müdürler görür */
  renderArchive?: () => React.ReactNode;
  canSeeArchive?: boolean;
}

const Toggle: React.FC<{ checked: boolean; onChange: (v: boolean) => void; label: string; disabled?: boolean }> = ({ checked, onChange, label, disabled }) => (
  <button type="button" role="switch" aria-checked={checked} aria-label={label} disabled={disabled} onClick={() => onChange(!checked)}
    className={`relative shrink-0 w-11 h-6 rounded-full transition-colors duration-300 disabled:opacity-60 ${checked ? 'bg-indigo-600' : 'bg-slate-200 dark:bg-slate-700'}`}>
    <span className={`absolute top-0.5 left-0.5 w-5 h-5 rounded-full bg-white shadow-md transition-transform duration-300 ${checked ? 'translate-x-5' : 'translate-x-0'}`} style={{ transitionTimingFunction: 'cubic-bezier(.34,1.56,.64,1)' }} />
  </button>
);

const inputCls = 'w-full h-10 px-3 rounded-xl bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-sm font-medium text-slate-900 dark:text-white outline-none focus:border-indigo-500 focus:ring-4 focus:ring-indigo-500/10';
const Card: React.FC<{ title: string; desc?: string; icon: React.ElementType; children: React.ReactNode; right?: React.ReactNode }> = ({ title, desc, icon: Icon, children, right }) => (
  <section className="bg-white dark:bg-slate-900 border border-slate-100 dark:border-slate-800 rounded-[24px] p-5 sm:p-6">
    <div className="flex flex-col md:flex-row md:items-center justify-between gap-3 mb-5">
      <div>
        <h3 className="font-bold text-slate-900 dark:text-white flex items-center gap-2"><Icon size={18} className="text-indigo-500" /> {title}</h3>
        {desc && <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">{desc}</p>}
      </div>
      {right}
    </div>
    {children}
  </section>
);
const Labeled: React.FC<{ label: string; hint?: string; children: React.ReactNode; className?: string }> = ({ label, hint, children, className = '' }) => (
  <label className={`block ${className}`}>
    <span className="text-xs font-semibold text-slate-600 dark:text-slate-300">{label}</span>
    <div className="mt-1">{children}</div>
    {hint && <span className="block text-[11px] text-slate-400 mt-1">{hint}</span>}
  </label>
);

const same = (a: unknown, b: unknown) => JSON.stringify(a) === JSON.stringify(b);

const SettingsView: React.FC<Props> = (props) => {
  const { language, initialTab = 'appearance', onTabChange, isAdmin = true, renderArchive, canSeeArchive = isAdmin } = props;
  const tr = language === 'tr';
  // Yönetici olmayanlar sadece kişisel Görünüm sekmesini görür
  const safeTab = (t: SettingsTab): SettingsTab => (t === 'archive' ? (canSeeArchive && renderArchive ? t : 'appearance') : (isAdmin || t === 'appearance' ? t : 'appearance'));
  const [tab, setTab] = useState<SettingsTab>(safeTab(initialTab));
  useEffect(() => { setTab(safeTab(initialTab)); }, [initialTab, isAdmin]);
  const go = (t: SettingsTab) => { setTab(t); onTabChange?.(t); };

  // Yerel taslaklar
  const normFin = (f: FinanceSettings): FinanceSettings => ({
    defaultTaxRate: f.defaultTaxRate ?? 20, defaultCurrency: f.defaultCurrency || Currency.TRY, reportingCurrency: f.reportingCurrency || Currency.TRY,
    incomeCategories: f.incomeCategories?.length ? f.incomeCategories : DEFAULT_INCOME_CATEGORIES,
    expenseCategories: f.expenseCategories?.length ? f.expenseCategories : DEFAULT_EXPENSE_CATEGORIES,
  });
  const [required, setRequired] = useState(props.projectFormSettings.required);
  const [hr, setHr] = useState<HRSettings>(props.hrSettings);
  const [fin, setFin] = useState<FinanceSettings>(normFin(props.financeSettings));
  const [company, setCompany] = useState<CompanySettings>(props.companySettings);
  const [alerts, setAlerts] = useState<AlertSettings>({ ...DEFAULT_ALERT_SETTINGS, ...props.alertSettings });
  const [saving, setSaving] = useState(false);
  const [newIncomeCat, setNewIncomeCat] = useState('');
  const [newExpenseCat, setNewExpenseCat] = useState('');

  useEffect(() => { setRequired(props.projectFormSettings.required); }, [props.projectFormSettings]);
  useEffect(() => { setHr(props.hrSettings); }, [props.hrSettings]);
  useEffect(() => { setFin(normFin(props.financeSettings)); }, [props.financeSettings]);
  useEffect(() => { setCompany(props.companySettings); }, [props.companySettings]);
  useEffect(() => { setAlerts({ ...DEFAULT_ALERT_SETTINGS, ...props.alertSettings }); }, [props.alertSettings]);

  const dirty = useMemo(() => ({
    projectForm: PROJECT_FIELDS.some(f => !!required[f.key] !== isFieldRequired(props.projectFormSettings, f.key)),
    hr: hr.dailyWorkHours !== props.hrSettings.dailyWorkHours || hr.defaultAnnualLeaveDays !== props.hrSettings.defaultAnnualLeaveDays,
    finance: !same(fin, normFin(props.financeSettings)),
    company: !same(company, props.companySettings),
    alerts: !same(alerts, { ...DEFAULT_ALERT_SETTINGS, ...props.alertSettings }),
  }), [required, hr, fin, company, alerts, props]);
  const anyDirty = Object.values(dirty).some(Boolean);

  const discard = () => {
    setRequired(props.projectFormSettings.required); setHr(props.hrSettings); setFin(normFin(props.financeSettings));
    setCompany(props.companySettings); setAlerts({ ...DEFAULT_ALERT_SETTINGS, ...props.alertSettings });
  };

  const save = async () => {
    if (company.email && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(company.email)) { go('company'); toast.warning(tr ? 'Şirket e-posta adresi geçersiz' : 'Invalid company email'); return; }
    setSaving(true);
    try {
      if (dirty.projectForm) await props.onSaveProjectFormSettings({ required: Object.fromEntries(PROJECT_FIELDS.map(f => [f.key, !!required[f.key]])) });
      if (dirty.hr) await props.onSaveHrSettings(hr);
      if (dirty.finance) await props.onSaveFinanceSettings(fin);
      if (dirty.company) await props.onSaveCompanySettings(company);
      if (dirty.alerts) await props.onSaveAlertSettings(alerts);
      toast.success(tr ? 'Ayarlar kaydedildi' : 'Settings saved');
    } catch (e: any) {
      toast.error((tr ? 'Kaydetme hatası: ' : 'Save error: ') + (e?.message || ''));
    } finally { setSaving(false); }
  };

  const exportBackup = () => {
    if (!props.getBackupData) return;
    const data = props.getBackupData();
    const payload = { exportedAt: new Date().toISOString(), app: 'PanimoCloud ERP', collections: data };
    const blob = new Blob([JSON.stringify(payload, null, 2)], { type: 'application/json' });
    const a = document.createElement('a');
    a.href = URL.createObjectURL(blob);
    a.download = `panimocloud-yedek-${new Date().toISOString().slice(0, 10)}.json`;
    a.click();
    URL.revokeObjectURL(a.href);
    toast.success(tr ? 'Yedek dosyası indirildi' : 'Backup downloaded');
  };

  const allTabs: { key: SettingsTab; label: string; icon: React.ElementType; dirty?: boolean }[] = [
    { key: 'appearance', label: tr ? 'Görünüm' : 'Appearance', icon: Palette },
    { key: 'company', label: tr ? 'Şirket' : 'Company', icon: Building2, dirty: dirty.company },
    { key: 'projectForm', label: tr ? 'Proje Formu' : 'Project Form', icon: Briefcase, dirty: dirty.projectForm },
    { key: 'hr', label: tr ? 'İnsan Kaynakları' : 'HR', icon: Users, dirty: dirty.hr },
    { key: 'finance', label: tr ? 'Finans' : 'Finance', icon: Wallet, dirty: dirty.finance },
    { key: 'alerts', label: tr ? 'Uyarı Eşikleri' : 'Alert Thresholds', icon: BellRing, dirty: dirty.alerts },
    { key: 'archive', label: tr ? 'Proje Arşivi' : 'Project Archive', icon: Archive },
    { key: 'logs', label: tr ? 'Sistem Kayıtları' : 'System Logs', icon: ShieldAlert },
    { key: 'data', label: tr ? 'Veri & Yedek' : 'Data & Backup', icon: Database },
  ];
  const tabs = allTabs.filter(t => t.key === 'archive' ? (canSeeArchive && !!renderArchive) : (isAdmin || t.key === 'appearance'));

  // ---------- Sekme içerikleri ----------
  const renderAppearance = () => {
    const mode = props.themeMode || 'auto';
    const themes: { key: ThemeMode; label: string; desc: string; icon: React.ElementType }[] = [
      { key: 'auto', label: tr ? 'Otomatik' : 'Automatic', desc: tr ? 'Cihazın ayarını takip eder' : 'Follows your device', icon: Monitor },
      { key: 'light', label: tr ? 'Aydınlık' : 'Light', desc: tr ? 'Her zaman açık tema' : 'Always light', icon: Sun },
      { key: 'dark', label: tr ? 'Karanlık' : 'Dark', desc: tr ? 'Her zaman koyu tema' : 'Always dark', icon: Moon },
    ];
    // Küçük arayüz önizlemesi
    const preview = (dark: boolean, split = false) => (
      <div className={`relative h-20 rounded-xl overflow-hidden border ${dark ? 'bg-[#020617] border-slate-700' : 'bg-slate-50 border-slate-200'}`}>
        {split && <div className="absolute inset-y-0 right-0 w-1/2 bg-[#020617]" />}
        <div className={`absolute left-2 top-2 bottom-2 w-6 rounded-md ${dark ? 'bg-slate-800' : 'bg-white shadow-sm'}`} />
        <div className="absolute left-10 top-2 right-2 h-3 rounded bg-indigo-500/80" />
        <div className={`absolute left-10 top-7 w-1/3 h-9 rounded-md ${dark ? 'bg-slate-800' : 'bg-white shadow-sm'}`} />
        <div className={`absolute right-2 top-7 w-1/3 h-9 rounded-md ${split || dark ? 'bg-slate-800' : 'bg-white shadow-sm'}`} />
      </div>
    );
    const checkMark = <span className="w-5 h-5 rounded-full bg-indigo-600 text-white flex items-center justify-center animate-in zoom-in-50 duration-200"><Check size={12} strokeWidth={3} /></span>;
    return (
      <div className="space-y-4">
        <Card icon={Palette} title={tr ? 'Tema' : 'Theme'}
          desc={mode === 'auto' ? (tr ? `Şu an cihaz ayarına göre ${props.isDark ? 'koyu' : 'açık'} tema kullanılıyor.` : `Currently ${props.isDark ? 'dark' : 'light'} based on your device.`) : undefined}>
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
            {themes.map(t => {
              const Icon = t.icon; const on = mode === t.key;
              return (
                <button key={t.key} onClick={() => props.onThemeModeChange?.(t.key)}
                  className={`text-left p-3 rounded-2xl border-2 transition-all ${on ? 'border-indigo-500 ring-4 ring-indigo-500/10' : 'border-slate-200 dark:border-slate-700 hover:border-slate-300'}`}>
                  {preview(t.key === 'dark', t.key === 'auto')}
                  <div className="flex items-center gap-2 mt-3">
                    <Icon size={16} className={on ? 'text-indigo-600' : 'text-slate-400'} />
                    <div className="flex-1"><p className="text-sm font-semibold text-slate-800 dark:text-slate-100">{t.label}</p><p className="text-[11px] text-slate-400">{t.desc}</p></div>
                    {on && checkMark}
                  </div>
                </button>
              );
            })}
          </div>
        </Card>
        <Card icon={Languages} title={tr ? 'Dil' : 'Language'}>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            {([['tr', 'Türkçe', 'Arayüz Türkçe', '🇹🇷'], ['en', 'English', 'Interface in English', '🇬🇧']] as const).map(([k, l, d, flag]) => {
              const on = language === k;
              return (
                <button key={k} onClick={() => props.onLanguageChange?.(k)}
                  className={`flex items-center gap-3 p-4 rounded-2xl border-2 text-left transition-all ${on ? 'border-indigo-500 ring-4 ring-indigo-500/10' : 'border-slate-200 dark:border-slate-700 hover:border-slate-300'}`}>
                  <span className="text-2xl">{flag}</span>
                  <div className="flex-1"><p className="text-sm font-semibold text-slate-800 dark:text-slate-100">{l}</p><p className="text-[11px] text-slate-400">{d}</p></div>
                  {on && checkMark}
                </button>
              );
            })}
          </div>
        </Card>
        <Card icon={Sparkles} title={tr ? 'Hareket ve animasyon' : 'Motion & animation'}>
          <label className="flex items-center gap-4 cursor-pointer">
            <div className="flex-1">
              <p className="text-sm font-semibold text-slate-800 dark:text-slate-100">{tr ? 'Animasyonları azalt' : 'Reduce motion'}</p>
              <p className="text-[11px] text-slate-400">{tr ? 'Geçiş ve hareket efektlerini kapatır; daha sakin bir arayüz ve daha az pil tüketimi.' : 'Turns off transitions and motion effects.'}</p>
            </div>
            <Toggle checked={!!props.reduceMotion} onChange={v => props.onReduceMotionChange?.(v)} label="reduce-motion" />
          </label>
        </Card>
        <p className="text-[11px] text-slate-400 flex items-center gap-1.5"><CheckCircle2 size={13} className="text-emerald-500" /> {tr ? 'Görünüm tercihleri anında uygulanır ve otomatik kaydedilir.' : 'Applied instantly and saved automatically.'}</p>
      </div>
    );
  };

  const renderCompany = () => (
    <Card icon={Building2} title={tr ? 'Şirket bilgileri' : 'Company information'} desc={tr ? 'Teklif, fatura ve müşteri portalında kullanılacak resmi bilgiler.' : 'Official details used on proposals, invoices and the client portal.'}>
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
        <Labeled label={tr ? 'Marka adı' : 'Brand name'}><input className={inputCls} value={company.name || ''} onChange={e => setCompany({ ...company, name: e.target.value })} placeholder="PanimoSoft" /></Labeled>
        <Labeled label={tr ? 'Ticari unvan' : 'Legal name'}><input className={inputCls} value={company.legalName || ''} onChange={e => setCompany({ ...company, legalName: e.target.value })} placeholder="Panimo Yazılım Ltd. Şti." /></Labeled>
        <Labeled label={tr ? 'Vergi dairesi' : 'Tax office'}><input className={inputCls} value={company.taxOffice || ''} onChange={e => setCompany({ ...company, taxOffice: e.target.value })} /></Labeled>
        <Labeled label={tr ? 'Vergi numarası' : 'Tax number'}><input className={inputCls} inputMode="numeric" value={company.taxNumber || ''} onChange={e => setCompany({ ...company, taxNumber: e.target.value.replace(/[^\d]/g, '').slice(0, 11) })} /></Labeled>
        <Labeled label={tr ? 'Telefon' : 'Phone'}><input className={inputCls} type="tel" value={company.phone || ''} onChange={e => setCompany({ ...company, phone: e.target.value })} /></Labeled>
        <Labeled label={tr ? 'E-posta' : 'Email'}><input className={inputCls} type="email" value={company.email || ''} onChange={e => setCompany({ ...company, email: e.target.value })} /></Labeled>
        <Labeled label={tr ? 'Web sitesi' : 'Website'}><input className={inputCls} type="url" value={company.website || ''} onChange={e => setCompany({ ...company, website: e.target.value })} placeholder="https://" /></Labeled>
        <Labeled label="IBAN"><input className={inputCls + ' font-mono'} value={company.iban || ''} onChange={e => setCompany({ ...company, iban: e.target.value.toUpperCase() })} placeholder="TR00 0000 …" /></Labeled>
        <Labeled label={tr ? 'Adres' : 'Address'} className="sm:col-span-2"><textarea rows={2} className={inputCls + ' h-auto py-2.5 resize-none'} value={company.address || ''} onChange={e => setCompany({ ...company, address: e.target.value })} /></Labeled>
        <Labeled label={tr ? 'Logo bağlantısı' : 'Logo URL'} className="sm:col-span-2" hint={tr ? 'Görsel bağlantısı (PNG/SVG).' : 'Image URL (PNG/SVG).'}>
          <div className="flex items-center gap-3">
            <input className={inputCls} type="url" value={company.logoUrl || ''} onChange={e => setCompany({ ...company, logoUrl: e.target.value })} placeholder="https://…/logo.png" />
            {company.logoUrl && <img src={company.logoUrl} alt="" className="w-10 h-10 rounded-xl object-contain bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700" />}
          </div>
        </Labeled>
      </div>
    </Card>
  );

  const renderProjectForm = () => {
    const groups = Object.keys(PROJECT_FIELD_GROUPS) as (keyof typeof PROJECT_FIELD_GROUPS)[];
    const requiredCount = PROJECT_FIELDS.filter(f => required[f.key]).length;
    return (
      <Card icon={Briefcase} title={tr ? 'Proje formu — zorunlu alanlar' : 'Project form — required fields'}
        desc={tr ? `Açık olan alanlar doldurulmadan proje kaydedilemez. Şu an ${requiredCount + 1} alan zorunlu.` : `${requiredCount + 1} fields required.`}
        right={<div className="flex gap-2">
          <button onClick={() => setRequired(Object.fromEntries(PROJECT_FIELDS.map(f => [f.key, true])))} className="h-9 px-3 rounded-xl text-xs font-semibold border border-slate-200 dark:border-slate-700 text-slate-600 dark:text-slate-300 hover:text-indigo-600">{tr ? 'Tümünü zorunlu yap' : 'Require all'}</button>
          <button onClick={() => setRequired({})} className="h-9 px-3 rounded-xl text-xs font-semibold border border-slate-200 dark:border-slate-700 text-slate-600 dark:text-slate-300 hover:text-indigo-600">{tr ? 'Tümünü kapat' : 'Clear all'}</button>
          <button onClick={() => setRequired(DEFAULT_PROJECT_FORM_SETTINGS.required)} title={tr ? 'Varsayılana dön' : 'Reset'} className="h-9 w-9 inline-flex items-center justify-center rounded-xl border border-slate-200 dark:border-slate-700 text-slate-500 hover:text-indigo-600"><RotateCcw size={15} /></button>
        </div>}>
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
          {groups.map(g => (
            <div key={g} className="rounded-2xl border border-slate-100 dark:border-slate-800 p-2">
              <p className="px-3 pt-2 pb-1 text-[10px] font-black uppercase tracking-[0.2em] text-slate-400">{tr ? PROJECT_FIELD_GROUPS[g].tr : PROJECT_FIELD_GROUPS[g].en}</p>
              {g === 'general' && (
                <div className="flex items-center gap-3 px-3 py-2.5 rounded-xl opacity-70">
                  <div className="flex-1 min-w-0"><p className="text-sm font-semibold text-slate-800 dark:text-slate-100 flex items-center gap-1.5">{tr ? 'Proje Adı' : 'Project Name'} <Lock size={12} className="text-slate-400" /></p><p className="text-[11px] text-slate-400">{tr ? 'Her zaman zorunlu' : 'Always required'}</p></div>
                  <Toggle checked disabled onChange={() => {}} label="name" />
                </div>
              )}
              {PROJECT_FIELDS.filter(f => f.group === g).map(f => {
                const on = !!required[f.key];
                const changed = on !== isFieldRequired(props.projectFormSettings, f.key);
                return (
                  <label key={f.key} className={`flex items-center gap-3 px-3 py-2.5 rounded-xl cursor-pointer transition-colors ${on ? 'bg-indigo-50/50 dark:bg-indigo-500/5' : 'hover:bg-slate-50 dark:hover:bg-white/[0.03]'}`}>
                    <div className="flex-1 min-w-0">
                      <p className="text-sm font-semibold text-slate-800 dark:text-slate-100 flex items-center gap-1.5">{tr ? f.tr : f.en}{on && <Asterisk size={12} className="text-rose-500 animate-in zoom-in-50 duration-200" />}{changed && <span className="w-1.5 h-1.5 rounded-full bg-amber-400" />}</p>
                      <p className="text-[11px] text-slate-400 truncate">{tr ? f.hintTr : f.hintEn}</p>
                    </div>
                    <Toggle checked={on} onChange={v => setRequired(prev => ({ ...prev, [f.key]: v }))} label={f.tr} />
                  </label>
                );
              })}
            </div>
          ))}
        </div>
      </Card>
    );
  };

  const renderHr = () => (
    <Card icon={Users} title={tr ? 'İnsan kaynakları' : 'Human resources'} desc={tr ? 'Mesai hesaplamaları ve izin hakları için kullanılır.' : 'Used for attendance and leave calculations.'}>
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 max-w-2xl">
        <Labeled label={tr ? 'Günlük çalışma saati' : 'Daily work hours'} hint={tr ? 'Fazla mesai bu sürenin üstünden hesaplanır.' : 'Overtime is calculated above this.'}>
          <input type="number" min={1} max={24} className={inputCls} value={hr.dailyWorkHours} onChange={e => setHr({ ...hr, dailyWorkHours: Number(e.target.value) })} />
        </Labeled>
        <Labeled label={tr ? 'Varsayılan yıllık izin (gün)' : 'Default annual leave (days)'} hint={tr ? 'Yeni personele otomatik tanımlanır.' : 'Assigned to new staff.'}>
          <input type="number" min={0} max={60} className={inputCls} value={hr.defaultAnnualLeaveDays} onChange={e => setHr({ ...hr, defaultAnnualLeaveDays: Number(e.target.value) })} />
        </Labeled>
      </div>
    </Card>
  );

  const catEditor = (kind: 'incomeCategories' | 'expenseCategories', value: string, setValue: (v: string) => void, color: string) => {
    const list = fin[kind] || [];
    const add = () => { const v = value.trim(); if (v && !list.includes(v)) setFin({ ...fin, [kind]: [...list, v] }); setValue(''); };
    return (
      <div>
        <div className="flex flex-wrap gap-1.5 mb-2">
          {list.map(c => (
            <span key={c} className={`inline-flex items-center gap-1 h-8 pl-2.5 pr-1.5 rounded-lg text-xs font-semibold ${color}`}>
              {c}<button type="button" onClick={() => setFin({ ...fin, [kind]: list.filter(x => x !== c) })} className="p-0.5 rounded hover:bg-black/10"><X size={12} /></button>
            </span>
          ))}
        </div>
        <div className="flex gap-2">
          <input className={inputCls} value={value} onChange={e => setValue(e.target.value)} onKeyDown={e => { if (e.key === 'Enter') { e.preventDefault(); add(); } }} placeholder={tr ? 'Yeni kategori' : 'New category'} />
          <button type="button" onClick={add} className="h-10 px-3 rounded-xl text-sm font-semibold bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-200 hover:bg-indigo-50 hover:text-indigo-600 inline-flex items-center gap-1"><Plus size={14} /> {tr ? 'Ekle' : 'Add'}</button>
        </div>
      </div>
    );
  };

  const renderFinance = () => (
    <div className="space-y-4">
      <Card icon={Wallet} title={tr ? 'Varsayılanlar' : 'Defaults'}>
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
          <Labeled label={tr ? 'Varsayılan KDV oranı (%)' : 'Default VAT (%)'} hint={tr ? 'Yeni proje, ek iş ve kayıtlarda.' : 'For new records.'}>
            <input type="number" min={0} max={100} className={inputCls} value={fin.defaultTaxRate} onChange={e => setFin({ ...fin, defaultTaxRate: Number(e.target.value) })} />
          </Labeled>
          <Labeled label={tr ? 'Varsayılan para birimi' : 'Default currency'}>
            <select className={inputCls} value={fin.defaultCurrency} onChange={e => setFin({ ...fin, defaultCurrency: e.target.value as Currency })}>{Object.values(Currency).map(c => <option key={c} value={c}>{c}</option>)}</select>
          </Labeled>
          <Labeled label={tr ? 'Raporlama para birimi' : 'Reporting currency'} hint={tr ? 'Muhasebe toplamları bu birimde gösterilir.' : 'Accounting totals use this.'}>
            <select className={inputCls} value={fin.reportingCurrency} onChange={e => setFin({ ...fin, reportingCurrency: e.target.value as Currency })}>{Object.values(Currency).map(c => <option key={c} value={c}>{c}</option>)}</select>
          </Labeled>
        </div>
      </Card>
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        <Card icon={Wallet} title={tr ? 'Gelir kategorileri' : 'Income categories'} right={<button onClick={() => setFin({ ...fin, incomeCategories: DEFAULT_INCOME_CATEGORIES })} className="text-xs font-semibold text-slate-500 hover:text-indigo-600 inline-flex items-center gap-1"><RotateCcw size={12} /> {tr ? 'Varsayılan' : 'Default'}</button>}>
          {catEditor('incomeCategories', newIncomeCat, setNewIncomeCat, 'bg-emerald-50 text-emerald-700 dark:bg-emerald-500/10 dark:text-emerald-300')}
        </Card>
        <Card icon={Wallet} title={tr ? 'Gider kategorileri' : 'Expense categories'} right={<button onClick={() => setFin({ ...fin, expenseCategories: DEFAULT_EXPENSE_CATEGORIES })} className="text-xs font-semibold text-slate-500 hover:text-indigo-600 inline-flex items-center gap-1"><RotateCcw size={12} /> {tr ? 'Varsayılan' : 'Default'}</button>}>
          {catEditor('expenseCategories', newExpenseCat, setNewExpenseCat, 'bg-rose-50 text-rose-700 dark:bg-rose-500/10 dark:text-rose-300')}
        </Card>
      </div>
    </div>
  );

  const renderAlerts = () => {
    const rows: { key: keyof AlertSettings; label: string; hint: string }[] = [
      { key: 'deliveryRiskDays', label: tr ? 'Teslim riski' : 'Delivery risk', hint: tr ? 'Teslime bu kadar gün kala ilerleme %80 altındaysa uyar' : 'Warn when this many days left and progress < 80%' },
      { key: 'invoiceUnpaidDays', label: tr ? 'Ödenmemiş fatura' : 'Unpaid invoice', hint: tr ? 'Gönderilen fatura bu kadar gün ödenmezse uyar' : 'Warn when a sent invoice is unpaid this long' },
      { key: 'dealIdleDays', label: tr ? 'Hareketsiz fırsat' : 'Stalled deal', hint: tr ? 'Fırsat bu kadar gün güncellenmezse uyar' : 'Warn when a deal is idle this long' },
      { key: 'subscriptionWarnDays', label: tr ? 'Abonelik ödemesi' : 'Subscription payment', hint: tr ? 'Ödeme gününe bu kadar kala uyar' : 'Warn this many days before billing' },
      { key: 'licenseWarnDays', label: tr ? 'Lisans yenileme' : 'License renewal', hint: tr ? 'Lisans bitişine bu kadar kala uyar' : 'Warn this many days before expiry' },
      { key: 'ticketNoReplyDays', label: tr ? 'Yanıtsız talep' : 'Unanswered ticket', hint: tr ? 'Talep bu kadar gün yanıtsız kalırsa uyar' : 'Warn when unanswered this long' },
    ];
    return (
      <Card icon={BellRing} title={tr ? 'Yönetim Merkezi uyarı eşikleri' : 'Operations Center thresholds'} desc={tr ? 'Aksiyon Merkezi\'nde hangi durumların uyarı olarak görüneceğini belirler.' : 'Controls when items appear in the Action Center.'}
        right={<button onClick={() => setAlerts(DEFAULT_ALERT_SETTINGS)} className="h-9 px-3 rounded-xl text-xs font-semibold border border-slate-200 dark:border-slate-700 text-slate-600 dark:text-slate-300 hover:text-indigo-600 inline-flex items-center gap-1"><RotateCcw size={13} /> {tr ? 'Varsayılan' : 'Default'}</button>}>
        <div className="divide-y divide-slate-100 dark:divide-slate-800">
          {rows.map(r => (
            <div key={r.key} className="flex items-center gap-4 py-3">
              <div className="flex-1 min-w-0">
                <p className="text-sm font-semibold text-slate-800 dark:text-slate-100 flex items-center gap-2">{r.label}{alerts[r.key] !== DEFAULT_ALERT_SETTINGS[r.key] && <span className="text-[10px] font-semibold px-1.5 rounded bg-indigo-50 dark:bg-indigo-500/10 text-indigo-600">{tr ? 'özel' : 'custom'}</span>}</p>
                <p className="text-[11px] text-slate-400">{r.hint}</p>
              </div>
              <input type="range" min={1} max={r.key === 'licenseWarnDays' || r.key === 'invoiceUnpaidDays' ? 90 : 30} value={alerts[r.key] as number} onChange={e => setAlerts({ ...alerts, [r.key]: Number(e.target.value) })} className="hidden sm:block w-40 accent-indigo-600" />
              <div className="relative w-24 shrink-0">
                <input type="number" min={1} max={365} className={inputCls + ' pr-10 text-right font-bold'} value={alerts[r.key] as number} onChange={e => setAlerts({ ...alerts, [r.key]: Math.max(1, Number(e.target.value) || 1) })} />
                <span className="absolute right-3 top-1/2 -translate-y-1/2 text-xs text-slate-400">{tr ? 'gün' : 'd'}</span>
              </div>
            </div>
          ))}
        </div>
      </Card>
    );
  };

  const renderData = () => {
    const data = props.getBackupData?.() || {};
    const entries = Object.entries(data);
    const total = entries.reduce((s, [, v]) => s + v.length, 0);
    return (
      <div className="space-y-4">
        <Card icon={Database} title={tr ? 'Veri yedeği' : 'Data backup'} desc={tr ? 'Yüklenmiş tüm kayıtları tek bir JSON dosyası olarak indirir.' : 'Downloads all loaded records as a single JSON file.'}
          right={<button onClick={exportBackup} className="h-10 px-4 rounded-xl text-sm font-semibold text-white bg-indigo-600 hover:bg-indigo-500 inline-flex items-center gap-2 shadow-lg shadow-indigo-500/25"><Download size={16} /> {tr ? 'Yedeği indir' : 'Download backup'}</button>}>
          <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-2 pc-stagger">
            {entries.map(([k, v]) => (
              <div key={k} className="flex items-center gap-2 p-3 rounded-xl bg-slate-50 dark:bg-white/[0.03]">
                <FileJson size={15} className="text-indigo-500 shrink-0" />
                <span className="text-xs font-semibold text-slate-600 dark:text-slate-300 truncate flex-1">{k}</span>
                <span className="text-xs font-bold text-slate-900 dark:text-white">{v.length}</span>
              </div>
            ))}
          </div>
          <p className="text-[11px] text-slate-400 mt-4 flex items-start gap-1.5"><Info size={13} className="shrink-0 mt-0.5" />
            {tr ? `Toplam ${total} kayıt. Not: Bazı listeler performans için sınırlı yüklenir (ör. son 500 finans işlemi); tam arşiv için Firebase konsolundan dışa aktarım önerilir. Dosya hassas veriler içerir, güvenli saklayın.` : `${total} records. Some lists are partially loaded for performance; use the Firebase console for full exports. The file contains sensitive data.`}
          </p>
        </Card>
      </div>
    );
  };

  const renderLogs = () => (
    <Suspense fallback={<div className="py-16 flex justify-center"><Loader2 className="animate-spin text-indigo-500" /></div>}>
      <SystemLogsView language={language} />
    </Suspense>
  );

  const content: Record<SettingsTab, () => React.ReactNode> = {
    appearance: renderAppearance,
    company: renderCompany, projectForm: renderProjectForm, hr: renderHr, finance: renderFinance, alerts: renderAlerts, logs: renderLogs, data: renderData,
    archive: () => renderArchive?.() ?? null,
  };

  return (
    <div className="space-y-5 pb-24">
      <div>
        <h1 className="text-2xl lg:text-3xl font-black text-slate-900 dark:text-white tracking-tight flex items-center gap-3">
          <span className="p-2.5 rounded-2xl bg-gradient-to-br from-indigo-500 to-violet-600 text-white shadow-lg shadow-indigo-500/30"><Settings size={20} /></span>
          {tr ? 'Ayarlar' : 'Settings'}
        </h1>
        <p className="text-sm text-slate-500 dark:text-slate-400 mt-2">
          {tab === 'archive'
            ? (tr ? 'Tamamlanan projeler ve ek işler. Kartı açıp gerekirse işi yeniden aktif edebilirsiniz.' : 'Completed projects and extra jobs.')
            : tab === 'appearance'
            ? (tr ? 'Görünüm tercihleri sadece sizin için ve bu cihazda geçerlidir.' : 'Appearance preferences apply only to you on this device.')
            : (tr ? 'Buradaki değişiklikler tüm kullanıcılar için geçerlidir.' : 'Changes here apply to all users.')}
        </p>
      </div>

      <div className="flex flex-col lg:flex-row gap-5">
        <nav className="lg:w-60 shrink-0 flex lg:flex-col gap-1 overflow-x-auto lg:overflow-visible p-1 lg:p-0 rounded-2xl bg-slate-100 dark:bg-white/[0.03] lg:bg-transparent lg:dark:bg-transparent">
          {tabs.map(t => {
            const Icon = t.icon;
            const active = tab === t.key;
            return (
              <button key={t.key} onClick={() => go(t.key)}
                className={`shrink-0 relative flex items-center gap-2.5 h-10 lg:h-11 px-3 rounded-xl text-sm font-semibold transition-all ${active ? 'bg-white dark:bg-slate-900 text-indigo-600 dark:text-indigo-300 shadow-sm lg:border lg:border-slate-100 lg:dark:border-slate-800' : 'text-slate-500 hover:text-slate-800 dark:hover:text-slate-200 lg:hover:bg-white/60 lg:dark:hover:bg-white/5'}`}>
                <Icon size={16} />{t.label}
                {t.dirty && <span className="w-2 h-2 rounded-full bg-amber-400 lg:ml-auto" title={tr ? 'Kaydedilmedi' : 'Unsaved'} />}
              </button>
            );
          })}
        </nav>
        <div key={tab} className="flex-1 min-w-0 animate-in fade-in slide-in-from-bottom-2 duration-300">{content[tab]()}</div>
      </div>

      <div className={`fixed bottom-4 left-1/2 -translate-x-1/2 z-40 transition-all duration-300 ${anyDirty ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-6 pointer-events-none'}`}>
        <div className="flex items-center gap-3 pl-4 pr-2 py-2 rounded-2xl bg-slate-900 text-white shadow-2xl shadow-slate-900/30 border border-white/10">
          <span className="text-sm font-semibold whitespace-nowrap">{tr ? 'Kaydedilmemiş değişiklikler' : 'Unsaved changes'}</span>
          <button onClick={discard} className="h-9 px-3 rounded-xl text-sm font-semibold text-slate-300 hover:bg-white/10">{tr ? 'Vazgeç' : 'Discard'}</button>
          <button onClick={save} disabled={saving} className="h-9 px-4 rounded-xl text-sm font-semibold bg-indigo-600 hover:bg-indigo-500 disabled:opacity-60 inline-flex items-center gap-2">
            {saving ? <Loader2 size={16} className="animate-spin" /> : <Save size={16} />} {tr ? 'Kaydet' : 'Save'}
          </button>
        </div>
      </div>
    </div>
  );
};

export default SettingsView;
