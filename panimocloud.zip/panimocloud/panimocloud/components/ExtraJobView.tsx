import React, { useEffect, useMemo, useState } from 'react';
import {
  Plus, Search, LayoutGrid, List, Columns3, Archive, Edit2, Trash2, X, Timer, Wallet, Banknote, AlertTriangle,
  CheckCircle2, Briefcase, ArrowUpDown, SlidersHorizontal, ChevronRight, CircleDollarSign
} from 'lucide-react';
import { ExtraJob, User, ExtraJobStatus, Currency, Customer, ProjectPriority } from '../types';
import ExtraJobForm from './ExtraJobForm';
import { STATUS_META, PAYMENT_META, EXTRA_JOB_CATEGORIES, jobTotal, jobPaid, jobDaysLeft, isJobOverdue, isJobOpen } from '../services/extraJobMetrics';
import { PRIORITY_META, PRIORITY_ORDER, daysLeftText } from '../services/projectMetrics';
import { toTRY, formatTRY, localISO } from '../services/insights';
import { AnimatedNumber, GrowBar } from './ui/Motion';
import { toast } from '../services/toast';

interface Props {
  extraJobs: ExtraJob[];
  users: User[];
  customers?: Customer[];
  onUpsertExtraJob: (job: ExtraJob) => Promise<void> | void;
  onDeleteExtraJob: (id: string) => Promise<void> | void;
  onAddTransaction: (tx: any) => Promise<void> | void;
  language: 'tr' | 'en';
  currentUser: User;
  onOpenArchive?: () => void;
  financeSettings?: any;
  rates?: { TRY: number; EUR: number };
}

type Tab = 'open' | 'done' | 'cancelled' | 'all';
type View = 'board' | 'grid' | 'list';
type Sort = 'deadline' | 'newest' | 'amount' | 'remaining' | 'priority' | 'title';

const sym = (c?: Currency) => (c === Currency.TRY ? '₺' : c === Currency.EUR ? '€' : '$');
const money = (n: number, c?: Currency) => `${sym(c)}${Math.round(n).toLocaleString('tr-TR')}`;
const round2 = (n: number) => Math.round(n * 100) / 100;
const pref = <T,>(k: string, d: T): T => { try { const v = localStorage.getItem(k); return v ? JSON.parse(v) : d; } catch { return d; } };

const ExtraJobView: React.FC<Props> = ({ extraJobs, users, customers = [], onUpsertExtraJob, onDeleteExtraJob, onAddTransaction, language, onOpenArchive, financeSettings, rates = { TRY: 34, EUR: 0.92 } }) => {
  const tr = language === 'tr';
  const [tab, setTab] = useState<Tab>(() => pref('pc-ej-tab', 'open'));
  const [view, setView] = useState<View>(() => pref('pc-ej-view', 'board'));
  const [sort, setSort] = useState<Sort>(() => pref('pc-ej-sort', 'deadline'));
  const [search, setSearch] = useState('');
  const [payF, setPayF] = useState('all');
  const [assigneeF, setAssigneeF] = useState('all');
  const [catF, setCatF] = useState('all');
  const [overdueOnly, setOverdueOnly] = useState(false);
  const [showFilters, setShowFilters] = useState(false);
  const [showModal, setShowModal] = useState(false);
  const [editingJob, setEditingJob] = useState<ExtraJob | null>(null);
  const [confirmDelete, setConfirmDelete] = useState<string | null>(null);
  const [dragId, setDragId] = useState<string | null>(null);
  const [dropCol, setDropCol] = useState<ExtraJobStatus | null>(null);
  const [expandedCols, setExpandedCols] = useState<ExtraJobStatus[]>([]);
  const BOARD_LIMIT = 3;

  useEffect(() => { try { localStorage.setItem('pc-ej-tab', JSON.stringify(tab)); localStorage.setItem('pc-ej-view', JSON.stringify(view)); localStorage.setItem('pc-ej-sort', JSON.stringify(sort)); } catch {} }, [tab, view, sort]);

  const userById = useMemo(() => new Map(users.map(u => [u.id, u])), [users]);

  // ---------- Kaydetme + finans entegrasyonu ----------
  const handleSaveJob = async (job: ExtraJob, previous: ExtraJob | null) => {
    const prevIds = new Set((previous?.payments || []).map(p => p.id));
    const newPayments = (job.payments || []).filter(p => !prevIds.has(p.id));
    await onUpsertExtraJob(job);
    const rate = Number(job.taxRate || 0);
    for (const p of newPayments) {
      await onAddTransaction({
        id: `tx_ej_${job.id}_${p.id}`,
        type: 'Income',
        amount: p.amount,
        currency: job.currency,
        taxRate: rate,
        taxAmount: round2((p.amount * rate) / (100 + rate)),
        totalAmountWithTax: p.amount,
        category: 'Ek İş (Freelance)',
        date: p.date,
        description: `${job.title} - ${job.clientName} (Ek İş Tahsilatı${p.note ? `: ${p.note}` : ''})`,
      });
    }
    toast.success(previous ? (tr ? 'Ek iş güncellendi' : 'Job updated') : (tr ? 'Ek iş eklendi' : 'Job added'));
    if (newPayments.length) toast.info(tr ? `${newPayments.length} tahsilat finansa gelir olarak işlendi` : `${newPayments.length} payment(s) posted to finance`);
    setShowModal(false);
    setEditingJob(null);
  };

  const changeStatus = async (job: ExtraJob, status: ExtraJobStatus) => {
    if (job.status === status) return;
    await onUpsertExtraJob({ ...job, status, updatedAt: new Date().toISOString() });
    toast(tr ? `"${job.title}" → ${STATUS_META[status].tr}` : `"${job.title}" → ${STATUS_META[status].en}`, status === 'Tamamlandı' ? 'success' : 'info', 2500);
  };

  const doDelete = async (job: ExtraJob) => {
    await onDeleteExtraJob(job.id);
    setConfirmDelete(null);
    toast(tr ? 'Ek iş silindi' : 'Job deleted', 'info');
  };

  const openEdit = (job: ExtraJob | null) => { setEditingJob(job); setShowModal(true); };

  // ---------- Filtre + sıralama ----------
  const filtered = useMemo(() => {
    const q = search.trim().toLocaleLowerCase('tr-TR');
    const list = extraJobs.filter(j => {
      if (view !== 'board') {
        if (tab === 'open' && !isJobOpen(j)) return false;
        if (tab === 'done' && j.status !== 'Tamamlandı') return false;
        if (tab === 'cancelled' && j.status !== 'İptal') return false;
      }
      if (payF !== 'all' && j.paymentStatus !== payF) return false;
      if (assigneeF !== 'all' && !(j.assignedTo || []).includes(assigneeF)) return false;
      if (catF !== 'all' && (j.category || '') !== catF) return false;
      if (overdueOnly && !isJobOverdue(j)) return false;
      if (q && ![j.title, j.clientName, j.description, j.category, j.notes].join(' ').toLocaleLowerCase('tr-TR').includes(q)) return false;
      return true;
    });
    const tt = (j: ExtraJob) => toTRY(jobTotal(j), j.currency, rates);
    return list.sort((a, b) => {
      switch (sort) {
        case 'deadline': return (a.deadline || '9999').localeCompare(b.deadline || '9999');
        case 'newest': return (b.createdAt || '').localeCompare(a.createdAt || '');
        case 'amount': return tt(b) - tt(a);
        case 'remaining': return toTRY(jobTotal(b) - jobPaid(b), b.currency, rates) - toTRY(jobTotal(a) - jobPaid(a), a.currency, rates);
        case 'priority': return (PRIORITY_ORDER[a.priority as ProjectPriority] ?? 9) - (PRIORITY_ORDER[b.priority as ProjectPriority] ?? 9);
        case 'title': return a.title.localeCompare(b.title, 'tr');
      }
    });
  }, [extraJobs, tab, view, payF, assigneeF, catF, overdueOnly, search, sort, rates]);

  const counts = useMemo(() => ({
    open: extraJobs.filter(isJobOpen).length,
    done: extraJobs.filter(j => j.status === 'Tamamlandı').length,
    cancelled: extraJobs.filter(j => j.status === 'İptal').length,
    all: extraJobs.length,
  }), [extraJobs]);

  const kpi = useMemo(() => {
    const month = localISO().slice(0, 7);
    const live = extraJobs.filter(j => j.status !== 'İptal');
    const receivable = live.reduce((s, j) => s + toTRY(Math.max(0, jobTotal(j) - jobPaid(j)), j.currency, rates), 0);
    const totalValue = live.reduce((s, j) => s + toTRY(jobTotal(j), j.currency, rates), 0);
    const collectedMonth = extraJobs.reduce((s, j) => s + (j.payments || []).filter(p => p.date?.startsWith(month)).reduce((a, p) => a + toTRY(p.amount, j.currency, rates), 0), 0);
    return {
      open: counts.open,
      overdue: extraJobs.filter(isJobOverdue).length,
      doneMonth: extraJobs.filter(j => j.status === 'Tamamlandı' && (j.updatedAt || '').startsWith(month)).length,
      receivable,
      collectedPct: totalValue ? Math.round(((totalValue - receivable) / totalValue) * 100) : 0,
      collectedMonth,
      unpaidDone: extraJobs.filter(j => j.status === 'Tamamlandı' && j.paymentStatus !== 'Ödendi').length,
    };
  }, [extraJobs, counts, rates]);

  const filterCount = [payF !== 'all', assigneeF !== 'all', catF !== 'all', overdueOnly].filter(Boolean).length;
  const clear = () => { setPayF('all'); setAssigneeF('all'); setCatF('all'); setOverdueOnly(false); setSearch(''); };
  const selectCls = 'h-10 px-3 rounded-xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700 text-xs font-semibold text-slate-700 dark:text-slate-200 outline-none focus:border-indigo-500 cursor-pointer';

  // ---------- Parçalar ----------
  const avatars = (ids: string[]) => {
    const people = ids.map(id => userById.get(id)).filter(Boolean) as User[];
    if (!people.length) return <span className="text-[11px] text-slate-400">{tr ? 'Atanmadı' : 'Unassigned'}</span>;
    return (
      <div className="flex -space-x-1.5">
        {people.slice(0, 4).map(u => u.avatar
          ? <img key={u.id} src={u.avatar} alt={u.name} title={u.name} className="w-6 h-6 rounded-full object-cover ring-2 ring-white dark:ring-slate-900" />
          : <span key={u.id} title={u.name} className="w-6 h-6 rounded-full ring-2 ring-white dark:ring-slate-900 bg-gradient-to-br from-indigo-500 to-violet-500 text-white text-[9px] font-bold flex items-center justify-center">{u.name?.[0]}</span>)}
        {people.length > 4 && <span className="w-6 h-6 rounded-full ring-2 ring-white dark:ring-slate-900 bg-slate-100 dark:bg-slate-800 text-[9px] font-bold flex items-center justify-center">+{people.length - 4}</span>}
      </div>
    );
  };

  const deadlineText = (j: ExtraJob) => {
    const d = jobDaysLeft(j);
    if (!j.deadline) return <span className="text-slate-400">{tr ? 'Tarih yok' : 'No date'}</span>;
    if (!isJobOpen(j)) return <span className="text-slate-400">{new Date(j.deadline).toLocaleDateString(tr ? 'tr-TR' : 'en-US', { day: 'numeric', month: 'short' })}</span>;
    const cls = d! < 0 ? 'text-rose-600 dark:text-rose-400' : d! <= 3 ? 'text-amber-600 dark:text-amber-400' : 'text-slate-600 dark:text-slate-300';
    return <span className={cls}>{daysLeftText(d, language)}</span>;
  };

  const actions = (j: ExtraJob, always = false) => (
    confirmDelete === j.id ? (
      <div className="flex items-center gap-1 animate-in fade-in zoom-in-95 duration-150" onClick={e => e.stopPropagation()}>
        <button onClick={() => setConfirmDelete(null)} className="h-7 px-2 rounded-lg text-[11px] font-semibold text-slate-500 hover:bg-slate-100 dark:hover:bg-white/5">{tr ? 'Vazgeç' : 'Cancel'}</button>
        <button onClick={() => doDelete(j)} className="h-7 px-2 rounded-lg text-[11px] font-semibold text-white bg-rose-600 hover:bg-rose-500">{tr ? 'Sil' : 'Delete'}</button>
      </div>
    ) : (
      <div className={`flex items-center gap-0.5 transition-opacity ${always ? '' : 'opacity-0 group-hover:opacity-100'}`} onClick={e => e.stopPropagation()}>
        <button onClick={() => openEdit(j)} title={tr ? 'Düzenle' : 'Edit'} className="p-1.5 rounded-lg text-slate-400 hover:text-indigo-600 hover:bg-indigo-50 dark:hover:bg-white/5"><Edit2 size={14} /></button>
        <button onClick={() => setConfirmDelete(j.id)} title={tr ? 'Sil' : 'Delete'} className="p-1.5 rounded-lg text-slate-400 hover:text-rose-600 hover:bg-rose-50 dark:hover:bg-white/5"><Trash2 size={14} /></button>
      </div>
    )
  );

  const payBar = (j: ExtraJob) => {
    const total = jobTotal(j), paid = jobPaid(j);
    const pct = total ? Math.min(100, (paid / total) * 100) : 0;
    return (
      <div>
        <div className="flex items-center justify-between text-[11px] mb-1">
          <span className={`font-semibold px-1.5 py-0.5 rounded-md ${PAYMENT_META[j.paymentStatus].chip}`}>{tr ? PAYMENT_META[j.paymentStatus].tr : PAYMENT_META[j.paymentStatus].en}</span>
          <span className="text-slate-500">{money(paid, j.currency)} / <b className="text-slate-900 dark:text-white">{money(total, j.currency)}</b></span>
        </div>
        <div className="h-1.5 rounded-full bg-slate-100 dark:bg-white/5"><div className="h-full rounded-full bg-gradient-to-r from-emerald-400 to-teal-500 pc-grow-x" style={{ width: `${pct}%` }} /></div>
      </div>
    );
  };

  const card = (j: ExtraJob, compact = false) => {
    const overdue = isJobOverdue(j);
    return (
      <div
        draggable={view === 'board'}
        onDragStart={e => { setDragId(j.id); e.dataTransfer.effectAllowed = 'move'; }}
        onDragEnd={() => { setDragId(null); setDropCol(null); }}
        onClick={() => openEdit(j)}
        className={`group relative bg-white dark:bg-slate-900 border rounded-2xl p-4 cursor-pointer transition-all hover:shadow-lg hover:shadow-slate-200/60 dark:hover:shadow-none ${overdue ? 'border-rose-200 dark:border-rose-500/30' : 'border-slate-100 dark:border-slate-800 hover:border-indigo-200 dark:hover:border-indigo-500/30'} ${dragId === j.id ? 'opacity-40 scale-95' : ''}`}
      >
        <div className="absolute top-3 right-3 z-10">{actions(j)}</div>
        {(!compact || j.category || j.priority || overdue) && (
          <div className="flex flex-wrap gap-1 pr-16 mb-2">
            {!compact && <span className={`inline-flex items-center gap-1 text-[10px] font-semibold px-1.5 py-0.5 rounded-md ${STATUS_META[j.status].chip}`}><span className={`w-1.5 h-1.5 rounded-full ${STATUS_META[j.status].dot}`} />{tr ? STATUS_META[j.status].tr : STATUS_META[j.status].en}</span>}
            {j.category && <span className="text-[10px] font-semibold px-1.5 py-0.5 rounded-md bg-slate-100 dark:bg-white/5 text-slate-600 dark:text-slate-300">{j.category}</span>}
            {j.priority && <span className={`inline-flex items-center gap-1 text-[10px] font-semibold px-1.5 py-0.5 rounded-md ${PRIORITY_META[j.priority].chip}`}><span className={`w-1.5 h-1.5 rounded-full ${PRIORITY_META[j.priority].dot}`} />{tr ? PRIORITY_META[j.priority].tr : PRIORITY_META[j.priority].en}</span>}
            {overdue && <span className="text-[10px] font-semibold px-1.5 py-0.5 rounded-md bg-rose-50 text-rose-700 dark:bg-rose-500/10 dark:text-rose-300 inline-flex items-center gap-1"><AlertTriangle size={10} />{tr ? 'Gecikti' : 'Late'}</span>}
          </div>
        )}
        <h3 className="pr-14 font-bold text-slate-900 dark:text-white leading-snug line-clamp-2">{j.title}</h3>
        <p className="text-xs text-slate-500 dark:text-slate-400 truncate">{j.clientName}</p>
        {!compact && j.description && <p className="text-xs text-slate-500 dark:text-slate-400 mt-2 line-clamp-2">{j.description}</p>}
        <div className="mt-3">{payBar(j)}</div>
        <div className="flex items-center justify-between mt-3 text-[11px] font-semibold">
          <span className="inline-flex items-center gap-1"><Timer size={12} className="text-slate-400" />{deadlineText(j)}</span>
          {avatars(j.assignedTo || [])}
        </div>
        {view === 'board' && isJobOpen(j) && (
          <button onClick={e => { e.stopPropagation(); changeStatus(j, j.status === 'Bekliyor' ? 'Yapılıyor' : 'Tamamlandı'); }}
            className="mt-3 w-full h-8 rounded-lg text-[11px] font-semibold border border-dashed border-slate-200 dark:border-slate-700 text-slate-500 hover:text-indigo-600 hover:border-indigo-300 inline-flex items-center justify-center gap-1 opacity-100 lg:opacity-0 lg:group-hover:opacity-100 transition-opacity">
            {j.status === 'Bekliyor' ? (tr ? 'Başlat' : 'Start') : (tr ? 'Tamamlandı işaretle' : 'Mark done')} <ChevronRight size={12} />
          </button>
        )}
      </div>
    );
  };

  const board = () => {
    const cols: ExtraJobStatus[] = ['Bekliyor', 'Yapılıyor', 'Tamamlandı', 'İptal'];
    return (
      <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-4 gap-4 items-start">
        {cols.map(s => {
          const items = filtered.filter(j => j.status === s);
          const sum = items.reduce((a, j) => a + toTRY(jobTotal(j), j.currency, rates), 0);
          const isDrop = dropCol === s && dragId && extraJobs.find(x => x.id === dragId)?.status !== s;
          return (
            <div key={s}
              onDragOver={e => { if (dragId) { e.preventDefault(); setDropCol(s); } }}
              onDragLeave={() => setDropCol(c => (c === s ? null : c))}
              onDrop={e => { e.preventDefault(); const job = extraJobs.find(x => x.id === dragId); if (job) changeStatus(job, s); setDragId(null); setDropCol(null); }}
              className={`rounded-[20px] p-3 transition-all duration-200 ${isDrop ? 'bg-indigo-50 dark:bg-indigo-500/10 ring-2 ring-indigo-400 scale-[1.01]' : 'bg-slate-100/70 dark:bg-white/[0.03]'}`}
            >
              <div className="flex items-center justify-between px-1 mb-3">
                <div className="flex items-center gap-2">
                  <span className={`w-2.5 h-2.5 rounded-full bg-gradient-to-br ${STATUS_META[s].col}`} />
                  <p className="text-sm font-bold text-slate-800 dark:text-slate-100">{tr ? STATUS_META[s].tr : STATUS_META[s].en}</p>
                  <span className="text-[11px] font-semibold px-1.5 rounded-md bg-white dark:bg-slate-800 text-slate-500">{items.length}</span>
                </div>
                <span className="text-[11px] font-semibold text-slate-400">{formatTRY(sum)}</span>
              </div>
              <div className="space-y-2.5 min-h-[80px] pc-stagger">
                {(expandedCols.includes(s) ? items : items.slice(0, BOARD_LIMIT)).map(j => <React.Fragment key={j.id}>{card(j, true)}</React.Fragment>)}
                {items.length > BOARD_LIMIT && (
                  <button onClick={() => setExpandedCols(c => (c.includes(s) ? c.filter(x => x !== s) : [...c, s]))}
                    className="w-full h-9 rounded-xl text-xs font-semibold text-slate-500 hover:text-indigo-600 bg-white/70 dark:bg-slate-800/60 hover:bg-white dark:hover:bg-slate-800 border border-dashed border-slate-200 dark:border-slate-700 inline-flex items-center justify-center gap-1 transition-colors">
                    {expandedCols.includes(s)
                      ? (tr ? 'Daha az göster' : 'Show less')
                      : (tr ? `+${items.length - BOARD_LIMIT} iş daha göster` : `Show ${items.length - BOARD_LIMIT} more`)}
                    <ChevronRight size={12} className={`transition-transform ${expandedCols.includes(s) ? '-rotate-90' : 'rotate-90'}`} />
                  </button>
                )}
                {!items.length && <div className="h-20 rounded-xl border-2 border-dashed border-slate-200 dark:border-slate-700 flex items-center justify-center text-[11px] text-slate-400">{dragId ? (tr ? 'Buraya bırak' : 'Drop here') : (tr ? 'Boş' : 'Empty')}</div>}
              </div>
              {s === 'Bekliyor' && (
                <button onClick={() => openEdit(null)} className="mt-2.5 w-full h-9 rounded-xl text-xs font-semibold text-slate-500 hover:text-indigo-600 hover:bg-white dark:hover:bg-slate-800 inline-flex items-center justify-center gap-1"><Plus size={14} /> {tr ? 'Ek iş ekle' : 'Add job'}</button>
              )}
            </div>
          );
        })}
      </div>
    );
  };

  const row = (j: ExtraJob) => {
    const total = jobTotal(j), paid = jobPaid(j);
    return (
      <div onClick={() => openEdit(j)} className="group grid grid-cols-12 items-center gap-3 px-4 py-3 rounded-2xl bg-white dark:bg-slate-900 border border-slate-100 dark:border-slate-800 hover:border-indigo-200 dark:hover:border-indigo-500/30 hover:shadow-md cursor-pointer transition-all">
        <div className="col-span-12 md:col-span-4 min-w-0">
          <p className="font-bold text-slate-900 dark:text-white truncate">{j.title}</p>
          <p className="text-xs text-slate-500 truncate">{j.clientName}{j.category ? ` · ${j.category}` : ''}</p>
        </div>
        <div className="col-span-4 md:col-span-2"><span className={`inline-flex items-center gap-1 text-[11px] font-semibold px-2 py-0.5 rounded-md ${STATUS_META[j.status].chip}`}><span className={`w-1.5 h-1.5 rounded-full ${STATUS_META[j.status].dot}`} />{tr ? STATUS_META[j.status].tr : STATUS_META[j.status].en}</span></div>
        <div className="col-span-4 md:col-span-2 text-xs font-semibold">{deadlineText(j)}</div>
        <div className="hidden md:block md:col-span-1">{avatars(j.assignedTo || [])}</div>
        <div className="col-span-4 md:col-span-2 text-right">
          <p className="text-sm font-bold text-slate-900 dark:text-white">{money(total, j.currency)}</p>
          <p className={`text-[11px] font-semibold ${paid >= total - 0.01 ? 'text-emerald-600' : paid > 0 ? 'text-orange-500' : 'text-rose-500'}`}>{paid >= total - 0.01 ? (tr ? 'Ödendi' : 'Paid') : `${tr ? 'Kalan' : 'Left'} ${money(total - paid, j.currency)}`}</p>
        </div>
        <div className="hidden md:flex md:col-span-1 justify-end">{actions(j)}</div>
      </div>
    );
  };

  const kpis = [
    { icon: Briefcase, label: tr ? 'Açık İş' : 'Open Jobs', value: kpi.open, sub: kpi.overdue ? `${kpi.overdue} ${tr ? 'gecikmiş' : 'overdue'}` : (tr ? 'Gecikme yok' : 'No delays'), grad: 'from-indigo-500 to-violet-600', bar: counts.all ? (kpi.open / counts.all) * 100 : 0, onClick: () => { setTab('open'); setOverdueOnly(kpi.overdue > 0); } },
    { icon: CheckCircle2, label: tr ? 'Bu Ay Tamamlanan' : 'Done This Month', value: kpi.doneMonth, sub: kpi.unpaidDone ? `${kpi.unpaidDone} ${tr ? 'tahsilat bekliyor' : 'awaiting payment'}` : (tr ? 'Hepsi tahsil edildi' : 'All collected'), grad: 'from-emerald-500 to-teal-600', bar: counts.done ? (kpi.doneMonth / counts.done) * 100 : 0, onClick: () => { setTab('done'); setView(v => (v === 'board' ? 'grid' : v)); setPayF(kpi.unpaidDone ? 'Ödenmedi' : 'all'); } },
    { icon: Wallet, label: tr ? 'Bekleyen Tahsilat' : 'Receivable', value: kpi.receivable, money: true, sub: `${tr ? 'Tahsil edilen' : 'Collected'} %${kpi.collectedPct}`, grad: 'from-orange-500 to-rose-500', bar: kpi.collectedPct },
    { icon: CircleDollarSign, label: tr ? 'Bu Ay Tahsil Edilen' : 'Collected This Month', value: kpi.collectedMonth, money: true, sub: tr ? 'Ödeme kayıtlarından' : 'From payment records', grad: 'from-sky-500 to-blue-600', bar: kpi.receivable + kpi.collectedMonth ? (kpi.collectedMonth / (kpi.receivable + kpi.collectedMonth)) * 100 : 0 },
  ];

  const tabs: { key: Tab; label: string }[] = [
    { key: 'open', label: tr ? 'Açık' : 'Open' }, { key: 'done', label: tr ? 'Tamamlanan' : 'Done' },
    { key: 'cancelled', label: tr ? 'İptal' : 'Cancelled' }, { key: 'all', label: tr ? 'Tümü' : 'All' },
  ];

  return (
    <div className="space-y-5">
      <div className="flex flex-col lg:flex-row lg:items-end justify-between gap-4">
        <div>
          <h2 className="text-2xl lg:text-3xl font-black text-slate-900 dark:text-white tracking-tight">{tr ? 'Ek İşler' : 'Extra Jobs'}</h2>
          <p className="text-sm text-slate-500 dark:text-slate-400">{tr ? 'Proje dışı, freelance ve kısa süreli işlerin takibi ve tahsilatı.' : 'Track and collect freelance and short jobs.'}</p>
        </div>
        <div className="flex flex-wrap gap-2">
          {onOpenArchive && <button onClick={onOpenArchive} className="h-10 px-3 rounded-xl border border-slate-200 dark:border-slate-700 text-slate-600 dark:text-slate-300 text-sm font-semibold inline-flex items-center gap-2 hover:border-indigo-300 hover:text-indigo-600"><Archive size={16} /> <span className="hidden sm:inline">{tr ? 'Arşiv' : 'Archive'}</span></button>}
          <button onClick={() => openEdit(null)} className="h-10 px-4 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white text-sm font-semibold inline-flex items-center gap-2 shadow-lg shadow-indigo-500/25"><Plus size={16} /> {tr ? 'Yeni Ek İş' : 'New Job'}</button>
        </div>
      </div>

      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 pc-stagger">
        {kpis.map((k: any) => {
          const Icon = k.icon;
          return (
            <button key={k.label} onClick={k.onClick} className={`text-left bg-white dark:bg-slate-900 border border-slate-100 dark:border-slate-800 rounded-[20px] p-4 min-w-0 ${k.onClick ? 'pc-lift' : 'cursor-default'}`}>
              <div className="flex items-center gap-2.5"><span className={`p-2 rounded-xl bg-gradient-to-br ${k.grad} text-white shadow-md`}><Icon size={16} /></span><span className="text-[11px] font-semibold text-slate-500 dark:text-slate-400 truncate">{k.label}</span></div>
              <p className="text-xl sm:text-2xl font-black text-slate-900 dark:text-white mt-2 truncate"><AnimatedNumber value={k.value} format={k.money ? formatTRY : undefined} /></p>
              <p className="text-[11px] text-slate-400 truncate">{k.sub}</p>
              <div className="mt-2.5"><GrowBar value={k.bar} className={`bg-gradient-to-r ${k.grad}`} /></div>
            </button>
          );
        })}
      </div>

      <div className="bg-white dark:bg-slate-900 border border-slate-100 dark:border-slate-800 rounded-[20px] p-3 space-y-3">
        <div className="flex flex-col xl:flex-row xl:items-center gap-3">
          {view !== 'board' ? (
            <div className="flex gap-1 p-1 rounded-xl bg-slate-100 dark:bg-slate-800/60 overflow-x-auto">
              {tabs.map(tb => (
                <button key={tb.key} onClick={() => setTab(tb.key)} className={`shrink-0 inline-flex items-center gap-1.5 h-8 px-3 rounded-lg text-xs font-semibold transition-all ${tab === tb.key ? 'bg-white dark:bg-slate-900 text-indigo-600 dark:text-indigo-300 shadow-sm' : 'text-slate-500 hover:text-slate-700'}`}>
                  {tb.label}<span className={`min-w-[18px] h-[18px] px-1 rounded-full text-[10px] flex items-center justify-center ${tab === tb.key ? 'bg-indigo-100 dark:bg-indigo-500/20' : 'bg-slate-200/70 dark:bg-white/10'}`}>{counts[tb.key]}</span>
                </button>
              ))}
            </div>
          ) : (
            <p className="text-xs text-slate-500 px-2 inline-flex items-center gap-1.5"><Columns3 size={14} /> {tr ? 'Kartları sürükleyerek durum değiştirin' : 'Drag cards to change status'}</p>
          )}
          <div className="relative flex-1">
            <Search size={16} className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
            <input value={search} onChange={e => setSearch(e.target.value)} placeholder={tr ? 'İş, müşteri, kategori ara…' : 'Search job, client, category…'} className="w-full h-10 pl-9 pr-8 rounded-xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700 text-sm outline-none focus:border-indigo-500" />
            {search && <button onClick={() => setSearch('')} className="absolute right-2 top-1/2 -translate-y-1/2 p-1 text-slate-400 hover:text-slate-700"><X size={14} /></button>}
          </div>
          <div className="flex flex-wrap items-center gap-2">
            <button onClick={() => setShowFilters(v => !v)} className={`h-10 px-3 rounded-xl border text-xs font-semibold inline-flex items-center gap-2 ${showFilters || filterCount ? 'border-indigo-300 text-indigo-600 bg-indigo-50/60 dark:bg-indigo-500/10' : 'border-slate-200 dark:border-slate-700 text-slate-600 dark:text-slate-300'}`}>
              <SlidersHorizontal size={15} /> {tr ? 'Filtreler' : 'Filters'}{filterCount > 0 && <span className="w-5 h-5 rounded-full bg-indigo-600 text-white text-[10px] flex items-center justify-center animate-in zoom-in-50">{filterCount}</span>}
            </button>
            <div className="relative">
              <ArrowUpDown size={14} className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400 pointer-events-none" />
              <select value={sort} onChange={e => setSort(e.target.value as Sort)} className={selectCls + ' pl-8'}>
                <option value="deadline">{tr ? 'Teslim tarihi' : 'Deadline'}</option>
                <option value="remaining">{tr ? 'Kalan tahsilat' : 'Remaining'}</option>
                <option value="amount">{tr ? 'Tutar' : 'Amount'}</option>
                <option value="priority">{tr ? 'Öncelik' : 'Priority'}</option>
                <option value="newest">{tr ? 'En yeni' : 'Newest'}</option>
                <option value="title">{tr ? 'Ad (A-Z)' : 'Title'}</option>
              </select>
            </div>
            <div className="flex p-1 rounded-xl bg-slate-100 dark:bg-slate-800/60">
              {([['board', Columns3, tr ? 'Pano' : 'Board'], ['grid', LayoutGrid, tr ? 'Kart' : 'Cards'], ['list', List, tr ? 'Liste' : 'List']] as const).map(([k, Icon, l]) => (
                <button key={k} title={l} onClick={() => setView(k)} className={`p-2 rounded-lg transition-all ${view === k ? 'bg-white dark:bg-slate-900 text-indigo-600 shadow-sm' : 'text-slate-400 hover:text-slate-600'}`}><Icon size={16} /></button>
              ))}
            </div>
          </div>
        </div>
        {showFilters && (
          <div className="flex flex-wrap items-center gap-2 pt-3 border-t border-slate-100 dark:border-slate-800 animate-in fade-in slide-in-from-top-2 duration-300">
            <select value={payF} onChange={e => setPayF(e.target.value)} className={selectCls}>
              <option value="all">{tr ? 'Tüm ödeme durumları' : 'All payment states'}</option>
              {Object.keys(PAYMENT_META).map(k => <option key={k} value={k}>{tr ? (PAYMENT_META as any)[k].tr : (PAYMENT_META as any)[k].en}</option>)}
            </select>
            <select value={catF} onChange={e => setCatF(e.target.value)} className={selectCls}>
              <option value="all">{tr ? 'Tüm kategoriler' : 'All categories'}</option>
              {EXTRA_JOB_CATEGORIES.map(c => <option key={c} value={c}>{c}</option>)}
            </select>
            <select value={assigneeF} onChange={e => setAssigneeF(e.target.value)} className={selectCls}>
              <option value="all">{tr ? 'Tüm personel' : 'All staff'}</option>
              {users.map(u => <option key={u.id} value={u.id}>{u.name}</option>)}
            </select>
            <button onClick={() => setOverdueOnly(v => !v)} className={`h-10 px-3 rounded-xl border text-xs font-semibold inline-flex items-center gap-1.5 ${overdueOnly ? 'border-rose-300 bg-rose-50 text-rose-600 dark:bg-rose-500/10' : 'border-slate-200 dark:border-slate-700 text-slate-600 dark:text-slate-300'}`}><AlertTriangle size={14} /> {tr ? 'Sadece gecikenler' : 'Overdue only'}</button>
            {(filterCount > 0 || search) && <button onClick={clear} className="ml-auto text-xs font-semibold text-slate-500 hover:text-rose-600 inline-flex items-center gap-1"><X size={13} /> {tr ? 'Temizle' : 'Clear'}</button>}
          </div>
        )}
      </div>

      <div key={`${view}-${tab}`}>
        {view === 'board' ? board() : filtered.length === 0 ? (
          <div className="py-16 rounded-[24px] border border-dashed border-slate-200 dark:border-slate-700 flex flex-col items-center text-center text-slate-400 animate-in fade-in zoom-in-95">
            <Banknote size={40} className="mb-3 opacity-40 pc-float" />
            <p className="text-sm font-semibold">{filterCount || search ? (tr ? 'Filtrelere uyan iş yok.' : 'No jobs match the filters.') : (tr ? 'Bu sekmede iş yok.' : 'No jobs here.')}</p>
            {(filterCount > 0 || search) ? <button onClick={clear} className="mt-3 text-xs font-semibold text-indigo-600 hover:underline">{tr ? 'Filtreleri temizle' : 'Clear filters'}</button>
              : <button onClick={() => openEdit(null)} className="mt-3 text-xs font-semibold text-indigo-600 hover:underline">{tr ? 'Yeni ek iş ekle' : 'Add a job'}</button>}
          </div>
        ) : view === 'grid' ? (
          <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-3 gap-4 pc-stagger">{filtered.map(j => <React.Fragment key={j.id}>{card(j)}</React.Fragment>)}</div>
        ) : (
          <div className="space-y-2 pc-stagger">
            <div className="hidden md:grid grid-cols-12 gap-3 px-4 text-[10px] font-black uppercase tracking-widest text-slate-400">
              <span className="col-span-4">{tr ? 'İş' : 'Job'}</span><span className="col-span-2">{tr ? 'Durum' : 'Status'}</span><span className="col-span-2">{tr ? 'Teslim' : 'Deadline'}</span><span className="col-span-1">{tr ? 'Ekip' : 'Team'}</span><span className="col-span-2 text-right">{tr ? 'Tutar' : 'Amount'}</span><span className="col-span-1" />
            </div>
            {filtered.map(j => <React.Fragment key={j.id}>{row(j)}</React.Fragment>)}
          </div>
        )}
      </div>

      <ExtraJobForm
        show={showModal}
        job={editingJob}
        users={users}
        customers={customers}
        onClose={() => { setShowModal(false); setEditingJob(null); }}
        onSave={handleSaveJob}
        language={language}
        financeSettings={financeSettings}
      />
    </div>
  );
};

export default ExtraJobView;
