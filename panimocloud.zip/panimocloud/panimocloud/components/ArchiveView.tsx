import React, { useEffect, useMemo, useState } from 'react';
import { Archive, Briefcase, Zap, CheckCircle2, Calendar, Wallet, Users, Tag, FileText, ExternalLink, RotateCcw, Clock, TrendingUp, Building2, ChevronRight, ChevronLeft } from 'lucide-react';
import { Project, ExtraJob, User } from '../types';
import { PageHeader, KpiGrid, SearchBox, Segmented, EmptyState, Sheet, Avatar, selectSm, cardCls, btnGhost, money } from './ui/Kit';
import { GrowBar } from './ui/Motion';
import { toTRY, formatTRY } from '../services/insights';
import { toast } from '../services/toast';

interface Props {
  projects: Project[];
  extraJobs: ExtraJob[];
  language: 'tr' | 'en';
  users?: User[];
  rates?: { TRY: number; EUR: number };
  onUpsertProject?: (p: Project) => Promise<void>;
  onUpsertExtraJob?: (j: ExtraJob) => Promise<void>;
  canEdit?: boolean;
  /** Ayarlar içinde gösterildiğinde sayfa başlığını gizle */
  embedded?: boolean;
}

type Item = {
  id: string; kind: 'project' | 'extrajob'; title: string; client: string; amount: number; currency: any; finished: string; started?: string;
  collected: number; total: number; tags: string[]; team: string[]; description?: string; raw: Project | ExtraJob;
};

const daysBetween = (a?: string, b?: string) => { if (!a || !b) return null; const d = Math.round((new Date(b).getTime() - new Date(a).getTime()) / 86400000); return isNaN(d) ? null : d; };

const ArchiveView: React.FC<Props> = ({ projects, extraJobs, language, users = [], rates = { TRY: 1, EUR: 1 }, onUpsertProject, onUpsertExtraJob, canEdit, embedded }) => {
  const tr = language === 'tr';
  const [kind, setKind] = useState<'all' | 'project' | 'extrajob'>('all');
  const [search, setSearch] = useState('');
  const [year, setYear] = useState('all');
  const [client, setClient] = useState('all');
  const [sel, setSel] = useState<Item | null>(null);
  const [page, setPage] = useState(0);
  const PAGE = 5;

  const items = useMemo<Item[]>(() => [
    ...projects.filter(p => p.status === 'Completed').map(p => {
      const total = p.totalAmountWithTax || p.budget || 0;
      const collected = (p.installments || []).reduce((a, i) => a + (i.isPaid ? (i.paidAmount ?? i.amount) : (i.paidAmount || 0)), 0);
      return { id: p.id, kind: 'project' as const, title: p.name, client: p.client, amount: p.budget || 0, currency: p.currency, finished: p.deliveryDate || '', started: p.startDate, collected, total, tags: p.tags || [], team: [p.projectManagerId, ...(p.teamMemberIds || [])].filter(Boolean) as string[], description: p.description, raw: p };
    }),
    ...extraJobs.filter(j => j.status === 'Tamamlandı').map(j => {
      const total = j.totalAmountWithTax || j.price || 0;
      const collected = (j.payments || []).reduce((a, p) => a + p.amount, 0) || (j.paymentStatus === 'Ödendi' ? total : 0);
      return { id: j.id, kind: 'extrajob' as const, title: j.title, client: j.clientName, amount: j.price || 0, currency: j.currency, finished: (j.updatedAt || '').slice(0, 10), started: j.startDate || (j.createdAt || '').slice(0, 10), collected, total, tags: j.category ? [j.category] : [], team: j.assignedTo || [], description: j.description, raw: j };
    }),
  ], [projects, extraJobs]);

  const years = useMemo(() => [...new Set(items.map(i => i.finished.slice(0, 4)).filter(Boolean))].sort().reverse(), [items]);
  const clients = useMemo(() => [...new Set(items.map(i => i.client).filter(Boolean))].sort((a, b) => a.localeCompare(b, 'tr')), [items]);

  const q = search.trim().toLocaleLowerCase('tr-TR');
  const list = useMemo(() => items.filter(i =>
    (kind === 'all' || i.kind === kind) && (year === 'all' || i.finished.startsWith(year)) && (client === 'all' || i.client === client) &&
    (!q || [i.title, i.client, i.description, ...i.tags].join(' ').toLocaleLowerCase('tr-TR').includes(q))
  ).sort((a, b) => (b.finished || '').localeCompare(a.finished || '')), [items, kind, year, client, q]);

  useEffect(() => { setPage(0); }, [kind, search, year, client]);
  const pages = Math.max(1, Math.ceil(list.length / PAGE));
  const curPage = Math.min(page, pages - 1);
  const pageItems = list.slice(curPage * PAGE, curPage * PAGE + PAGE);
  const yearTotals = useMemo(() => { const m = new Map<string, { n: number; v: number }>(); list.forEach(i => { const k = i.finished.slice(0, 4) || (tr ? 'Tarihsiz' : 'Undated'); const t = m.get(k) || { n: 0, v: 0 }; m.set(k, { n: t.n + 1, v: t.v + toTRY(i.amount, i.currency, rates) }); }); return m; }, [list, rates, tr]);
  const grouped = useMemo(() => {
    const m = new Map<string, Item[]>();
    pageItems.forEach(i => { const k = i.finished.slice(0, 4) || (tr ? 'Tarihsiz' : 'Undated'); m.set(k, [...(m.get(k) || []), i]); });
    return [...m.entries()];
  }, [pageItems, tr]);

  const stats = useMemo(() => {
    const T = (i: Item, n: number) => toTRY(n, i.currency, rates);
    const thisYear = String(new Date().getFullYear());
    const durations = list.map(i => daysBetween(i.started, i.finished)).filter((d): d is number => d !== null && d >= 0);
    return {
      value: list.reduce((a, i) => a + T(i, i.amount), 0),
      open: list.reduce((a, i) => a + T(i, Math.max(0, i.total - i.collected)), 0),
      thisYear: items.filter(i => i.finished.startsWith(thisYear)).length,
      avgDays: durations.length ? Math.round(durations.reduce((a, d) => a + d, 0) / durations.length) : 0,
      clients: new Set(list.map(i => i.client)).size,
    };
  }, [list, items, rates]);

  const userName = (id: string) => users.find(u => u.id === id);
  const reopen = async (i: Item) => {
    if (i.kind === 'project' && onUpsertProject) await onUpsertProject({ ...(i.raw as Project), status: 'Active' });
    else if (i.kind === 'extrajob' && onUpsertExtraJob) await onUpsertExtraJob({ ...(i.raw as ExtraJob), status: 'Yapılıyor', updatedAt: new Date().toISOString() });
    else return;
    toast.success(tr ? `"${i.title}" yeniden aktif edildi` : 'Reopened');
    setSel(null);
  };

  const row = (i: Item) => {
    const pct = i.total ? Math.min(100, (i.collected / i.total) * 100) : 0;
    const dur = daysBetween(i.started, i.finished);
    return (
      <button key={i.kind + i.id} onClick={() => setSel(i)} className="w-full text-left grid grid-cols-12 gap-3 items-center px-4 py-3 hover:bg-slate-50/70 dark:hover:bg-white/[0.02] group">
        <div className="col-span-12 md:col-span-5 flex items-center gap-3 min-w-0">
          <span className={`w-10 h-10 shrink-0 rounded-xl text-white flex items-center justify-center bg-gradient-to-br ${i.kind === 'project' ? 'from-blue-500 to-indigo-600' : 'from-violet-500 to-purple-600'} group-hover:scale-105 transition-transform`}>{i.kind === 'project' ? <Briefcase size={17} /> : <Zap size={17} />}</span>
          <div className="min-w-0"><p className="text-sm font-semibold text-slate-800 dark:text-slate-100 truncate group-hover:text-indigo-600">{i.title}</p><p className="text-[11px] text-slate-400 truncate">{i.client || '—'}{i.tags.length ? ` · ${i.tags.slice(0, 2).join(', ')}` : ''}</p></div>
        </div>
        <div className="col-span-4 md:col-span-2 text-xs text-slate-500"><p className="flex items-center gap-1"><Calendar size={11} />{i.finished || '—'}</p>{dur !== null && dur >= 0 && <p className="text-[10px] text-slate-400">{dur} {tr ? 'günde bitti' : 'days'}</p>}</div>
        <div className="col-span-4 md:col-span-3"><div className="flex justify-between text-[10px] mb-1"><span className="text-slate-400">{tr ? 'Tahsilat' : 'Collected'}</span><span className={pct >= 99.5 ? 'text-emerald-600 font-semibold' : 'text-amber-600 font-semibold'}>%{Math.round(pct)}</span></div><GrowBar value={pct} className={pct >= 99.5 ? 'bg-emerald-500' : 'bg-amber-500'} /></div>
        <div className="col-span-4 md:col-span-2 flex items-center justify-end gap-2"><span className="text-sm font-bold text-slate-900 dark:text-white">{money(i.amount, i.currency)}</span><ChevronRight size={16} className="text-slate-300 group-hover:text-indigo-500 group-hover:translate-x-0.5 transition-transform" /></div>
      </button>
    );
  };

  const docs = sel?.kind === 'project' ? [...((sel.raw as Project).contracts || []), ...((sel.raw as Project).documents || [])] : [];

  return (
    <div className="space-y-5 pb-10">
      {!embedded && <PageHeader title={tr ? 'İş Arşivi' : 'Archive'} subtitle={tr ? 'Tamamlanan projeler ve ek işlerin kalıcı kaydı.' : 'Completed projects and extra jobs.'} />}

      <KpiGrid items={[
        { label: tr ? 'Tamamlanan iş' : 'Completed', value: list.length, icon: CheckCircle2, grad: 'from-emerald-500 to-teal-600', sub: tr ? `Bu yıl ${stats.thisYear}` : `${stats.thisYear} this year` },
        { label: tr ? 'Toplam iş hacmi' : 'Total value', value: stats.value, format: formatTRY, icon: TrendingUp, grad: 'from-indigo-500 to-violet-600', sub: `${stats.clients} ${tr ? 'müşteri' : 'clients'}` },
        { label: tr ? 'Açık alacak' : 'Outstanding', value: stats.open, format: formatTRY, icon: Wallet, grad: 'from-amber-500 to-orange-600', sub: tr ? 'Tamamlanmış işlerden' : 'From completed work' },
        { label: tr ? 'Ortalama süre' : 'Avg duration', value: stats.avgDays, format: n => `${n} ${tr ? 'gün' : 'days'}`, icon: Clock, grad: 'from-sky-500 to-blue-600', sub: tr ? 'Başlangıç → teslim' : 'Start → delivery' },
      ]} />

      <div className={`${cardCls} p-3 flex flex-col lg:flex-row gap-2`}>
        <Segmented<'all' | 'project' | 'extrajob'> value={kind} onChange={setKind} options={[
          { value: 'all', label: <>{tr ? 'Tümü' : 'All'} <span className="text-[10px] opacity-60">{items.length}</span></> },
          { value: 'project', label: <><Briefcase size={14} />{tr ? 'Projeler' : 'Projects'}</> },
          { value: 'extrajob', label: <><Zap size={14} />{tr ? 'Ek işler' : 'Extra jobs'}</> },
        ]} />
        <SearchBox value={search} onChange={setSearch} placeholder={tr ? 'İş, müşteri, etiket ara…' : 'Search…'} />
        <select value={year} onChange={e => setYear(e.target.value)} className={selectSm}><option value="all">{tr ? 'Tüm yıllar' : 'All years'}</option>{years.map(y => <option key={y} value={y}>{y}</option>)}</select>
        <select value={client} onChange={e => setClient(e.target.value)} className={selectSm}><option value="all">{tr ? 'Tüm müşteriler' : 'All clients'}</option>{clients.map(c => <option key={c} value={c}>{c}</option>)}</select>
      </div>

      {list.length === 0 ? <div className={cardCls}><EmptyState icon={Archive} text={tr ? 'Eşleşen tamamlanmış iş yok' : 'Nothing found'} /></div> : (
        <div className="space-y-4">
          {grouped.map(([y, arr]) => (
            <div key={y} className={`${cardCls} overflow-hidden animate-in fade-in duration-300`}>
              <div className="px-4 py-2.5 flex items-center gap-2 bg-slate-50/70 dark:bg-white/[0.02] border-b border-slate-100 dark:border-slate-800"><span className="text-sm font-bold text-slate-800 dark:text-slate-100">{y}</span><span className="text-[11px] text-slate-400">{yearTotals.get(y)?.n ?? arr.length} {tr ? 'iş' : 'items'} · {formatTRY(yearTotals.get(y)?.v ?? 0)}</span></div>
              <div className="divide-y divide-slate-100 dark:divide-slate-800 pc-stagger">{arr.map(row)}</div>
            </div>
          ))}
          {list.length > PAGE && (
            <div className={`${cardCls} px-4 py-2.5 flex items-center gap-2`}>
              <span className="text-[11px] text-slate-400 flex-1">{tr ? `${list.length} işten ${curPage * PAGE + 1}–${Math.min(list.length, (curPage + 1) * PAGE)} · sayfa ${curPage + 1}/${pages}` : `Page ${curPage + 1}/${pages}`}</span>
              <button disabled={curPage === 0} onClick={() => setPage(curPage - 1)} className="h-8 w-8 rounded-lg border border-slate-200 dark:border-slate-700 flex items-center justify-center text-slate-500 hover:text-indigo-600 disabled:opacity-30"><ChevronLeft size={15} /></button>
              <span className="text-xs font-semibold text-slate-600 dark:text-slate-300 min-w-[24px] text-center">{curPage + 1}</span>
              <button disabled={curPage >= pages - 1} onClick={() => setPage(curPage + 1)} className="h-8 w-8 rounded-lg border border-slate-200 dark:border-slate-700 flex items-center justify-center text-slate-500 hover:text-indigo-600 disabled:opacity-30"><ChevronRight size={15} /></button>
            </div>
          )}
        </div>
      )}

      <Sheet open={!!sel} language={language} hideFooter={false} title={sel?.title || ''} subtitle={sel ? `${sel.kind === 'project' ? (tr ? 'Proje' : 'Project') : (tr ? 'Ek iş' : 'Extra job')} · ${tr ? 'tamamlandı' : 'completed'} ${sel.finished}` : ''}
        icon={sel?.kind === 'extrajob' ? Zap : Briefcase} tone={sel?.kind === 'extrajob' ? 'from-violet-500 to-purple-600' : 'from-blue-500 to-indigo-600'} onClose={() => setSel(null)}
        footerLeft={sel && canEdit && (sel.kind === 'project' ? onUpsertProject : onUpsertExtraJob) ? <button onClick={() => reopen(sel)} className={btnGhost + ' !h-9'}><RotateCcw size={14} />{tr ? 'Yeniden aç' : 'Reopen'}</button> : undefined}>
        {sel && <>
          <div className="grid grid-cols-2 gap-2">
            {[
              [Building2, tr ? 'Müşteri' : 'Client', sel.client || '—'],
              [Wallet, tr ? 'Bedel' : 'Amount', money(sel.amount, sel.currency)],
              [Calendar, tr ? 'Başlangıç → teslim' : 'Start → end', `${sel.started || '—'} → ${sel.finished || '—'}`],
              [CheckCircle2, tr ? 'Tahsil edilen' : 'Collected', `${money(sel.collected, sel.currency)} / ${money(sel.total, sel.currency)}`],
            ].map(([I, l, v]: any) => (
              <div key={l} className="rounded-xl bg-slate-50 dark:bg-white/[0.03] px-3 py-2.5"><p className="text-[10px] text-slate-400 flex items-center gap-1"><I size={11} />{l}</p><p className="text-sm font-semibold text-slate-800 dark:text-slate-100 mt-0.5 break-words">{v}</p></div>
            ))}
          </div>
          {sel.total - sel.collected > 1 && <p className="text-xs font-semibold text-amber-700 bg-amber-50 dark:bg-amber-500/10 dark:text-amber-300 rounded-xl px-3 py-2">{tr ? `Bu işten ${money(sel.total - sel.collected, sel.currency)} alacak hâlâ açık.` : 'Outstanding balance remains.'}</p>}
          {sel.description && <div><p className="text-xs font-semibold text-slate-500 mb-1.5">{tr ? 'Açıklama' : 'Description'}</p><p className="text-sm text-slate-600 dark:text-slate-300 whitespace-pre-wrap leading-relaxed">{sel.description}</p></div>}
          {sel.tags.length > 0 && <div className="flex flex-wrap gap-1.5">{sel.tags.map(t => <span key={t} className="text-[11px] font-semibold px-2 py-0.5 rounded-md bg-slate-100 dark:bg-white/5 text-slate-600 dark:text-slate-300 inline-flex items-center gap-1"><Tag size={10} />{t}</span>)}</div>}
          {sel.team.length > 0 && <div><p className="text-xs font-semibold text-slate-500 mb-1.5 flex items-center gap-1"><Users size={12} />{tr ? 'Ekip' : 'Team'}</p><div className="flex flex-wrap gap-1.5">{sel.team.map(id => { const u = userName(id); return <span key={id} className="h-8 pl-1 pr-2.5 rounded-full bg-slate-100 dark:bg-white/5 text-xs font-semibold text-slate-700 dark:text-slate-200 inline-flex items-center gap-1.5"><Avatar name={u?.name || '?'} src={u?.avatar} size="w-6 h-6" className="!rounded-full" />{u?.name || id}</span>; })}</div></div>}
          {docs.length > 0 && <div><p className="text-xs font-semibold text-slate-500 mb-1.5 flex items-center gap-1"><FileText size={12} />{tr ? 'Belgeler' : 'Documents'} ({docs.length})</p><div className="space-y-1">{docs.map(d => (
            <a key={d.id} href={d.url || undefined} target="_blank" rel="noreferrer" className={`flex items-center gap-2 px-3 py-2 rounded-xl bg-slate-50 dark:bg-white/[0.03] text-sm ${d.url ? 'hover:text-indigo-600' : 'pointer-events-none opacity-60'}`}><FileText size={14} className="text-slate-400" /><span className="flex-1 truncate">{d.name}</span><span className="text-[10px] text-slate-400">{d.type === 'contract' ? (tr ? 'Sözleşme' : 'Contract') : d.fileType}</span>{d.url && <ExternalLink size={12} />}</a>
          ))}</div></div>}
        </>}
      </Sheet>
    </div>
  );
};

export default ArchiveView;
