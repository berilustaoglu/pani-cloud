
import React, { useEffect, useRef, useState } from 'react';
import { ScreenRequest } from '../types';
import { Video, X, ShieldAlert, MonitorUp, Loader2, Info } from 'lucide-react';
import { doc, updateDoc, onSnapshot, collection, addDoc, query } from 'firebase/firestore';
import { db } from '../firebase';
import { toast } from '../services/toast';

interface Props {
    request: ScreenRequest;
    language: 'tr' | 'en';
}

const ScreenShareModal: React.FC<Props> = ({ request, language }) => {
    const [stream, setStream] = useState<MediaStream | null>(null);
    const [isActive, setIsActive] = useState(false);
    const [isConnecting, setIsConnecting] = useState(false);
    const peerConnection = useRef<RTCPeerConnection | null>(null);
    const iceQueue = useRef<RTCIceCandidateInit[]>([]);
    const [localCandidates, setLocalCandidates] = useState(0);
    const [remoteCandidates, setRemoteCandidates] = useState(0);

    const startSharing = async () => {
        try {
            setIsConnecting(true);
            const mediaStream = await navigator.mediaDevices.getDisplayMedia({
                video: {
                    frameRate: { max: 30 },
                    width: { max: 1920 },
                    height: { max: 1080 }
                },
                audio: true
            });
            setStream(mediaStream);
            setIsActive(true);

            const pc = new RTCPeerConnection({
                iceServers: [
                    { urls: 'stun:stun.l.google.com:19302' },
                    { urls: 'stun:stun1.l.google.com:19302' },
                    { urls: 'stun:stun2.l.google.com:19302' },
                    { urls: 'stun:stun3.l.google.com:19302' }
                ],
                iceCandidatePoolSize: 10
            });
            peerConnection.current = pc;

            mediaStream.getTracks().forEach(track => {
                console.log(`Adding ${track.kind} track to peer connection. ReadyState: ${track.readyState}`);
                pc.addTrack(track, mediaStream);

                track.onended = () => {
                    console.log(`${track.kind} track ended on staff side`);
                    stopSharing();
                };

                track.onmute = () => console.log(`${track.kind} track muted on staff side`);
                track.onunmute = () => console.log(`${track.kind} track unmuted on staff side`);
            });

            pc.onicecandidate = async (event) => {
                if (event.candidate) {
                    setLocalCandidates(prev => prev + 1);
                    try {
                        await addDoc(collection(db, "screen_requests", request.id, "candidates"), {
                            candidate: event.candidate.toJSON(),
                            from: 'staff',
                            timestamp: Date.now()
                        });
                    } catch (e) {
                        console.error("Error sending staff ICE candidate:", e);
                    }
                }
            };

            pc.oniceconnectionstatechange = () => {
                console.log("Staff ICE state:", pc.iceConnectionState);
            };

            const offer = await pc.createOffer();
            await pc.setLocalDescription(offer);

            // Update status to Accepted and send Offer
            await updateDoc(doc(db, "screen_requests", request.id), {
                status: 'Accepted',
                offer: JSON.stringify(offer),
                lastActive: Date.now()
            });

            // Listen for Answer and Candidates from Admin
            const unsub = onSnapshot(doc(db, "screen_requests", request.id), async (snapshot) => {
                const data = snapshot.data();
                if (data?.answer && !pc.remoteDescription) {
                    try {
                        console.log("Setting remote description (Answer) on staff side");
                        const answer = JSON.parse(data.answer);
                        await pc.setRemoteDescription(new RTCSessionDescription(answer));

                        // Process queued ICE candidates from Admin
                        while (iceQueue.current.length > 0) {
                            const cand = iceQueue.current.shift()!;
                            await pc.addIceCandidate(new RTCIceCandidate(cand));
                        }
                        setIsConnecting(false);
                    } catch (e) {
                        console.error("Error setting answer on staff side:", e);
                    }
                }
            });

            const unsubCandidates = onSnapshot(query(collection(db, "screen_requests", request.id, "candidates")), (snapshot) => {
                snapshot.docChanges().forEach(async (change) => {
                    if (change.type === 'added') {
                        const data = change.doc.data();
                        if (data.from === 'admin') {
                            setRemoteCandidates(prev => prev + 1);
                            if (pc.remoteDescription) {
                                try {
                                    await pc.addIceCandidate(new RTCIceCandidate(data.candidate));
                                } catch (e) {
                                    console.warn("ICE error from admin on staff side:", e);
                                }
                            } else {
                                iceQueue.current.push(data.candidate);
                            }
                        }
                    }
                });
            });

            (pc as any)._unsub = unsub;
            (pc as any)._unsubC = unsubCandidates;

            // AUTO-RECOVERY LISTENER
            const unsubAutoRecovery = onSnapshot(doc(db, "screen_requests", request.id), async (snapshot) => {
                const data = snapshot.data();
                if (data?.renegotiate && (!pc.remoteDescription || pc.connectionState === 'failed' || pc.connectionState === 'disconnected' || pc.connectionState === 'new')) {
                    console.log("Auto-Recovery signal received on staff side. Restarting broadcast...");

                    // Stop current listeners and close connection
                    (pc as any)._unsub?.();
                    (pc as any)._unsubC?.();
                    pc.close();

                    if (peerConnection.current === pc) {
                        peerConnection.current = null;
                    }

                    unsubAutoRecovery(); // Stop this recovery listener too

                    // Reset renegotiate flag in DB so it doesn't loop
                    await updateDoc(doc(db, "screen_requests", request.id), {
                        renegotiate: null
                    });

                    // Small delay before restart to let Firestore state settle
                    setTimeout(() => {
                        if (stream && stream.active) {
                            // If stream is still active, just restart the WebRTC part
                            startSharing();
                        } else {
                            // Full reset if stream was lost
                            setIsActive(false);
                            setIsConnecting(false);
                        }
                    }, 1000);
                }
            });

        } catch (err: any) {
            console.error("Screen share error:", err);
            setIsConnecting(false);
            const msg = err.name === 'NotAllowedError'
                ? (language === 'tr' ? 'Ekran paylaşımı izni reddedildi.' : 'Screen share permission denied.')
                : (language === 'tr' ? `Hata: ${err.message}` : `Error: ${err.message}`);
            toast(msg);
        }
    };

    const stopSharing = async () => {
        if (stream) {
            stream.getTracks().forEach(track => track.stop());
            setStream(null);
        }
        if (peerConnection.current) {
            (peerConnection.current as any)._unsub?.();
            (peerConnection.current as any)._unsubC?.();
            peerConnection.current.close();
            peerConnection.current = null;
        }
        setIsActive(false);
        setIsConnecting(false);

        // Reset request status
        await updateDoc(doc(db, "screen_requests", request.id), {
            status: 'Expired'
        });
    };

    const rejectRequest = async () => {
        await updateDoc(doc(db, "screen_requests", request.id), {
            status: 'Rejected'
        });
    };

    useEffect(() => {
        return () => {
            if (peerConnection.current) {
                (peerConnection.current as any)._unsub?.();
                (peerConnection.current as any)._unsubC?.();
                peerConnection.current.close();
            }
        };
    }, []);

    if (isActive) {
        return (
            <div className="fixed bottom-8 right-8 z-[7000] bg-slate-900/90 backdrop-blur-xl border border-white/10 p-6 rounded-[35px] shadow-2xl w-80 animate-in slide-in-from-bottom duration-500">
                <div className="flex items-center gap-4 mb-6">
                    <div className="p-3 bg-red-600 text-white rounded-2xl animate-pulse">
                        <Video size={24} />
                    </div>
                    <div>
                        <h3 className="text-white font-black text-sm uppercase tracking-tight">
                            {language === 'tr' ? 'EKRANINIZ PAYLAŞILIYOR' : 'SCREEN SHARING ACTIVE'}
                        </h3>
                        <p className="text-white/40 text-[9px] font-black uppercase tracking-widest mt-1">
                            {isConnecting ? (language === 'tr' ? 'BAĞLANTI KURULUYOR...' : 'CONNECTING...') : (language === 'tr' ? 'YAYIN CANLI' : 'STREAM IS LIVE')}
                        </p>
                        <div className="flex gap-2 mt-2">
                            <span className="text-[8px] font-black text-indigo-400 bg-indigo-500/10 px-1.5 py-0.5 rounded">ICE: {localCandidates} / {remoteCandidates}</span>
                        </div>
                    </div>
                </div>
                <button
                    onClick={stopSharing}
                    className="w-full py-4 bg-red-600 text-white rounded-2xl text-[10px] font-black uppercase tracking-[0.2em] shadow-lg shadow-red-900/20 hover:bg-red-700 transition-all"
                >
                    {language === 'tr' ? 'PAYLAŞIMI DURDUR' : 'STOP SHARING'}
                </button>
            </div>
        );
    }

    return (
        <div className="fixed inset-0 z-[7000] flex items-center justify-center p-6 bg-slate-950/80 backdrop-blur-md">
            <div className="bg-white w-full max-w-md rounded-[45px] p-10 shadow-2xl border border-slate-100 animate-in zoom-in duration-300">
                <div className="flex justify-between items-start mb-8">
                    <div className="p-5 bg-red-600 text-white rounded-[25px] shadow-xl shadow-red-100">
                        <MonitorUp size={32} />
                    </div>
                    <button onClick={rejectRequest} className="p-3 bg-slate-100 text-slate-400 rounded-2xl hover:bg-slate-200 transition-all">
                        <X size={20} />
                    </button>
                </div>

                <div className="mb-10">
                    <h2 className="text-3xl font-black text-slate-900 tracking-tight mb-3">
                        {language === 'tr' ? 'Canlı İzleme Talebi' : 'Live Viewing Request'}
                    </h2>
                    <p className="text-slate-400 font-bold leading-relaxed">
                        {language === 'tr' ? 'Sistem yöneticisi ekranınızı canlı olarak izlemek istiyor. Paylaşımı başlatmak için onay verin.' : 'System administrator wants to view your screen live. Approve to start sharing.'}
                    </p>
                    <div className="mt-4 p-4 bg-amber-50 rounded-2xl border border-amber-100 flex items-start gap-3">
                         <Info size={20} className="text-amber-600 shrink-0 mt-0.5" />
                         <p className="text-[10px] font-bold text-amber-800 leading-normal">
                            {language === 'tr' 
                                ? 'ÖNEMLİ: Ses paylaşmak için ekran seçme penceresindeki "Sistem sesini paylaş" (Share system audio) kutucuğunu işaretlemeyi unutmayın.' 
                                : 'IMPORTANT: To share audio, remember to check the "Share system audio" box in the browser selection window.'}
                         </p>
                    </div>
                </div>

                <div className="flex flex-col gap-4">
                    <button
                        onClick={startSharing}
                        disabled={isConnecting}
                        className="w-full py-5 bg-red-600 text-white rounded-[25px] text-[12px] font-black uppercase tracking-[0.3em] shadow-xl shadow-red-100 hover:bg-red-700 transition-all flex items-center justify-center gap-3 disabled:opacity-50"
                    >
                        {isConnecting ? <Loader2 className="animate-spin" size={20} /> : <Video size={20} />}
                        {language === 'tr' ? 'EKRANI PAYLAŞ' : 'SHARE SCREEN'}
                    </button>
                    <button
                        onClick={rejectRequest}
                        disabled={isConnecting}
                        className="w-full py-5 border-2 border-slate-100 text-slate-400 rounded-[25px] text-[12px] font-black uppercase tracking-[0.3em] hover:bg-slate-50 transition-all"
                    >
                        {language === 'tr' ? 'REDDET' : 'REJECT'}
                    </button>
                </div>

                <div className="mt-8 flex items-center gap-3 p-4 bg-slate-50 rounded-2xl">
                    <ShieldAlert className="text-slate-300" size={16} />
                    <p className="text-[9px] font-black text-slate-400 uppercase tracking-widest leading-none">
                        {language === 'tr' ? 'Uçtan uca şifreli güvenli bağlantı' : 'End-to-end encrypted secure connection'}
                    </p>
                </div>
            </div>
        </div>
    );
};

export default ScreenShareModal;
