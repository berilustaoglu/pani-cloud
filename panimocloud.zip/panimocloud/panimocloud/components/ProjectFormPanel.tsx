import React, { useEffect, useMemo, useRef, useState } from 'react';
import {
  X, Check, ChevronLeft, ChevronRight, Settings as SettingsIcon, Sparkles, CalendarRange, Users, Contact, Wallet,
  FolderOpen, ClipboardCheck, AlertCircle, Upload, FileText, Trash2, Plus, Tag, Link2, Mail, Phone, UserCog,
  Timer, BookUser, Save, RotateCcw, Divide, Bot, Loader2
} from 'lucide-react';
import ModalPortal from './ModalPortal';
import ProjectHoldSheet, { CLEAR_HOLD } from './ProjectHoldSheet';
import {
  Project, ProjectFormSettings, ProjectPriority, ProjectType, PaymentType, Currency, Installment, ProjectDocument, User, Customer
} from '../types';
import { isFieldRequired, validateProjectFieldsDetailed, ProjectErrorKey, PROJECT_FIELDS } from '../services/projectFields';
import { TYPE_META, PRIORITY_META } from '../services/projectMetrics';
import { toast } from '../services/toast';

interface Props {
  open: boolean;
  initial: Partial<Project>;
  isEditing: boolean;
  users: User[];
  customers: Customer[];
  settings?: ProjectFormSettings;
  language: 'tr' | 'en';
  showFinancials: boolean;
  onClose: () => void;
  onSubmit: (p: Partial<Project>) => Promise<void>;
  onOpenSettings?: () => void;
}

type StepKey = 'basics' | 'plan' | 'client' | 'budget' | 'files' | 'review';
const DRAFT_KEY = 'pc-project-draft';

const STEP_FIELDS: Record<StepKey, ProjectErrorKey[]> = {
  basics: ['name', 'projectType', 'priority', 'description'],
  plan: ['startDate', 'deliveryDate', 'progress', 'projectManager', 'team', 'estimatedHours', 'tags', 'repoUrl'],
  client: ['client', 'clientContactName', 'clientEmail', 'clientPhone'],
  budget: ['budget', 'payments'],
  files: ['contract', 'gdd'],
  review: [],
};

const sym = (c?: Currency) => (c === Currency.TRY ? '₺' : c === Currency.EUR ? '€' : '$');
const fmtMoney = (n: number, c?: Currency) => `${sym(c)}${(Number(n) || 0).toLocaleString('tr-TR', { maximumFractionDigits: 2 })}`;
const todayISO = () => new Date().toISOString().split('T')[0];
const addMonths = (iso: string, m: number) => { const [y, mo, d] = iso.split('-').map(Number); const dt = new Date(y, mo - 1 + m, d); return `${dt.getFullYear()}-${String(dt.getMonth() + 1).padStart(2, '0')}-${String(dt.getDate()).padStart(2, '0')}`; };
const round2 = (n: number) => Math.round(n * 100) / 100;
const totalOf = (p: Partial<Project>) => (p.totalAmountWithTax && p.totalAmountWithTax > 0 ? p.totalAmountWithTax : (p.budget || 0));

/** Toplamı tam tutturacak şekilde (son kalem yuvarlama farkını alır) dağıtır. */
const distribute = (total: number, weights: number[]) => {
  const sum = weights.reduce((a, b) => a + b, 0) || 1;
  const parts = weights.map(w => round2((total * w) / sum));
  const diff = round2(total - parts.reduce((a, b) => a + b, 0));
  if (parts.length) parts[parts.length - 1] = round2(parts[parts.length - 1] + diff);
  return parts;
};

const buildPlan = (p: Partial<Project>, type: PaymentType, count: number, tr: boolean): Installment[] => {
  const total = totalOf(p);
  const start = p.startDate || todayISO();
  if (type === PaymentType.MILESTONE) {
    const [a, b] = distribute(total, [30, 70]);
    return [
      { id: `ms-pre-${Date.now()}`, amount: a, dueDate: start, isPaid: false, label: tr ? 'Ön Ödeme' : 'Prepayment' },
      { id: `ms-final-${Date.now()}`, amount: b, dueDate: p.deliveryDate || addMonths(start, 3), isPaid: false, label: tr ? 'Son Ödeme' : 'Final Payment' },
    ];
  }
  if (type === PaymentType.INSTALLMENT) {
    const n = Math.max(1, Math.min(36, count));
    const parts = distribute(total, Array(n).fill(1));
    return parts.map((amount, i) => ({ id: `inst-${Date.now()}-${i}`, amount, dueDate: addMonths(start, i + 1), isPaid: false, label: tr ? `${i + 1}. Taksit` : `Installment ${i + 1}` }));
  }
  return [];
};

const inputBase = 'w-full h-11 px-3.5 rounded-xl bg-white dark:bg-slate-800 border text-sm font-medium text-slate-900 dark:text-white outline-none transition-all placeholder:text-slate-400 focus:ring-4';
const inputCls = (err?: string) => `${inputBase} ${err ? 'border-rose-300 focus:border-rose-400 focus:ring-rose-500/10' : 'border-slate-200 dark:border-slate-700 focus:border-indigo-500 focus:ring-indigo-500/10'}`;

const Field: React.FC<{
  label: string; field?: ProjectErrorKey; always?: boolean; settings?: ProjectFormSettings; language: 'tr' | 'en';
  error?: string; hint?: string; children: React.ReactNode; className?: string;
}> = ({ label, field, always, settings, language, error, hint, children, className = '' }) => {
  const required = always || (field && field !== 'name' && field !== 'progress' && field !== 'payments' ? isFieldRequired(settings, field as any) : false);
  return (
    <div className={className}>
      <label className="flex items-center gap-1 text-xs font-semibold text-slate-600 dark:text-slate-300 mb-1.5">
        {label}
        {required ? <span className="text-rose-500">*</span> : <span className="font-normal text-slate-400">({language === 'tr' ? 'isteğe bağlı' : 'optional'})</span>}
      </label>
      {children}
      {error
        ? <p className="mt-1 text-[11px] font-semibold text-rose-600 flex items-center gap-1 animate-in fade-in slide-in-from-top-2 duration-200"><AlertCircle size={12} /> {error}</p>
        : hint ? <p className="mt-1 text-[11px] text-slate-400">{hint}</p> : null}
    </div>
  );
};

const ProjectFormPanel: React.FC<Props> = ({ open, initial, isEditing, users, customers, settings, language, showFinancials, onClose, onSubmit, onOpenSettings }) => {
  const tr = language === 'tr';
  const [p, setP] = useState<Partial<Project>>(initial);
  const [step, setStep] = useState<StepKey>('basics');
  const [dir, setDir] = useState<1 | -1>(1);
  const [touched, setTouched] = useState(false);
  const [saving, setSaving] = useState(false);
  const [count, setCount] = useState(1);
  const [tagInput, setTagInput] = useState('');
  const [draftAvailable, setDraftAvailable] = useState<Partial<Project> | null>(null);
  const [confirmClose, setConfirmClose] = useState(false);
  const initialJson = useRef('');
  const contentRef = useRef<HTMLDivElement>(null);

  // Panel her açıldığında durumu sıfırla
  useEffect(() => {
    if (!open) return;
    setP(initial);
    initialJson.current = JSON.stringify(initial);
    setStep('basics'); setDir(1); setTouched(false); setSaving(false); setConfirmClose(false); setTagInput('');
    setCount(initial.paymentType === PaymentType.INSTALLMENT ? Math.max(1, initial.installments?.length || 1) : 3);
    if (!isEditing) {
      try {
        const raw = localStorage.getItem(DRAFT_KEY);
        const d = raw ? JSON.parse(raw) : null;
        setDraftAvailable(d && d.name ? d : null);
      } catch { setDraftAvailable(null); }
    } else setDraftAvailable(null);
  }, [open]);

  const dirty = open && JSON.stringify(p) !== initialJson.current;

  // Yeni projede taslağı otomatik kaydet
  useEffect(() => {
    if (!open || isEditing || !dirty || draftAvailable) return;
    const t = setTimeout(() => { try { localStorage.setItem(DRAFT_KEY, JSON.stringify(p)); } catch {} }, 400);
    return () => clearTimeout(t);
  }, [p, open, isEditing, dirty, draftAvailable]);

  // ---------- Doğrulama ----------
  const errors = useMemo(() => {
    const list = validateProjectFieldsDetailed(p, settings, language);
    if (p.paymentType && p.paymentType !== PaymentType.CASH) {
      const sum = (p.installments || []).reduce((s, i) => s + (Number(i.amount) || 0), 0);
      const diff = round2(totalOf(p) - sum);
      if (Math.abs(diff) > 0.1) list.push({ field: 'payments', message: tr ? `Ödeme planı toplamı ${fmtMoney(Math.abs(diff), p.currency)} ${diff > 0 ? 'eksik' : 'fazla'}.` : `Payment plan is ${fmtMoney(Math.abs(diff), p.currency)} ${diff > 0 ? 'short' : 'over'}.` });
      if ((p.installments || []).some(i => !i.dueDate)) list.push({ field: 'payments', message: tr ? 'Tüm ödemelerin tarihi olmalı.' : 'All payments need a date.' });
    }
    return list;
  }, [p, settings, language]);
  const errOf = (f: ProjectErrorKey) => (touched ? errors.find(e => e.field === f)?.message : undefined);
  const stepErrors = (s: StepKey) => errors.filter(e => STEP_FIELDS[s].includes(e.field)).length;

  const requiredKeys: ProjectErrorKey[] = ['name', ...PROJECT_FIELDS.filter(f => isFieldRequired(settings, f.key)).map(f => f.key)];
  const requiredDone = requiredKeys.filter(k => !errors.some(e => e.field === k)).length;

  // ---------- Yardımcılar ----------
  const set = (patch: Partial<Project>) => setP(prev => ({ ...prev, ...patch }));
  const [holdOpen, setHoldOpen] = useState(false);
  const recalcMoney = (budget: number, rate: number) => {
    setP(prev => {
      const tax = round2((budget * rate) / 100);
      const next: Partial<Project> = { ...prev, budget, taxRate: rate, taxAmount: tax, totalAmountWithTax: round2(budget + tax) };
      if (!isEditing && next.paymentType && next.paymentType !== PaymentType.CASH && next.installments?.length) {
        const weights = next.paymentType === PaymentType.MILESTONE && next.installments.length === 2 ? [30, 70] : next.installments.map(() => 1);
        const parts = distribute(totalOf(next), weights);
        next.installments = next.installments.map((i, idx) => ({ ...i, amount: parts[idx] }));
      }
      return next;
    });
  };
  const setPaymentType = (type: PaymentType) => setP(prev => ({ ...prev, paymentType: type, installments: buildPlan(prev, type, count, tr) }));
  const setInstallments = (list: Installment[]) => set({ installments: list });
  const updateInst = (idx: number, patch: Partial<Installment>) => setInstallments((p.installments || []).map((i, k) => (k === idx ? { ...i, ...patch } : i)));
  const equalize = () => {
    const list = p.installments || [];
    const parts = distribute(totalOf(p), list.map(() => 1));
    setInstallments(list.map((i, k) => ({ ...i, amount: parts[k] })));
  };

  const pickFile = (accept: string, cb: (f: File) => void) => {
    const input = document.createElement('input');
    input.type = 'file';
    input.accept = accept;
    input.onchange = (e: any) => { const f = e.target.files?.[0]; if (f) cb(f); };
    input.click();
  };
  const toDoc = (f: File, type: 'contract' | 'document'): ProjectDocument => ({
    id: `doc-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`, name: f.name, type, fileType: f.name.split('.').pop() || 'file',
    uploadDate: todayISO(), url: URL.createObjectURL(f),
  });

  const addTag = () => {
    const v = tagInput.trim().replace(/^#/, '').replace(/,$/, '');
    if (v && !(p.tags || []).includes(v)) set({ tags: [...(p.tags || []), v] });
    setTagInput('');
  };

  const pickCustomer = (id: string) => {
    const c = customers.find(x => x.id === id);
    if (!c) { set({ customerId: undefined }); return; }
    setP(prev => ({
      ...prev, customerId: c.id,
      client: prev.client || c.company || c.name,
      clientContactName: prev.clientContactName || c.name,
      clientEmail: prev.clientEmail || c.email || '',
      clientPhone: prev.clientPhone || c.phone || '',
    }));
  };

  // ---------- Adımlar ----------
  const steps: { key: StepKey; label: string; desc: string; icon: React.ElementType }[] = [
    { key: 'basics', label: tr ? 'Temel Bilgiler' : 'Basics', desc: tr ? 'Ad, tip, öncelik' : 'Name, type, priority', icon: Sparkles },
    { key: 'plan', label: tr ? 'Plan & Ekip' : 'Plan & Team', desc: tr ? 'Tarihler, ekip, etiketler' : 'Dates, team, tags', icon: CalendarRange },
    { key: 'client', label: tr ? 'Müşteri' : 'Client', desc: tr ? 'Firma ve yetkili' : 'Company & contact', icon: Contact },
    { key: 'budget', label: tr ? 'Bütçe & Ödeme' : 'Budget & Payment', desc: tr ? 'Tutar, KDV, plan' : 'Amount, VAT, plan', icon: Wallet },
    { key: 'files', label: tr ? 'Dosyalar' : 'Files', desc: tr ? 'Sözleşme, GDD' : 'Contract, GDD', icon: FolderOpen },
    { key: 'review', label: tr ? 'Özet' : 'Review', desc: tr ? 'Kontrol et ve kaydet' : 'Check & save', icon: ClipboardCheck },
  ];
  const idx = steps.findIndex(s => s.key === step);
  const goTo = (s: StepKey) => { setDir(steps.findIndex(x => x.key === s) >= idx ? 1 : -1); setStep(s); contentRef.current?.scrollTo({ top: 0 }); };
  const next = () => { if (idx < steps.length - 1) goTo(steps[idx + 1].key); };
  const prev = () => { if (idx > 0) goTo(steps[idx - 1].key); };

  const submit = async () => {
    setTouched(true);
    if (errors.length) {
      const first = steps.find(s => stepErrors(s.key) > 0);
      if (first) goTo(first.key);
      toast.warning(tr ? `${errors.length} alanı tamamlayın` : `Complete ${errors.length} field(s)`);
      return;
    }
    setSaving(true);
    try {
      await onSubmit(p);
      if (!isEditing) { try { localStorage.removeItem(DRAFT_KEY); } catch {} }
      toast.success(isEditing ? (tr ? 'Proje güncellendi' : 'Project updated') : (tr ? 'Proje oluşturuldu' : 'Project created'));
    } catch (e: any) {
      toast.error((tr ? 'Kaydedilemedi: ' : 'Save failed: ') + (e?.message || ''));
    } finally {
      setSaving(false);
    }
  };

  const requestClose = () => {
    if (isEditing && dirty && !confirmClose) { setConfirmClose(true); return; }
    if (!isEditing && dirty) toast.info(tr ? 'Taslak kaydedildi, daha sonra devam edebilirsiniz' : 'Draft saved');
    onClose();
  };

  useEffect(() => {
    if (!open) return;
    const onKey = (e: KeyboardEvent) => {
      if (e.key === 'Escape') { e.preventDefault(); requestClose(); }
      if ((e.ctrlKey || e.metaKey) && e.key === 'Enter') { e.preventDefault(); submit(); }
    };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  });

  if (!open) return null;

  const type = TYPE_META[p.projectType || ProjectType.OTHER] || TYPE_META[ProjectType.OTHER];
  const team = (p.teamMemberIds || []).map(id => users.find(u => u.id === id)).filter(Boolean) as User[];
  const installmentsSum = (p.installments || []).reduce((s, i) => s + (Number(i.amount) || 0), 0);
  const remaining = round2(totalOf(p) - installmentsSum);
  const durationDays = p.startDate && p.deliveryDate && p.deliveryDate >= p.startDate
    ? Math.round((new Date(p.deliveryDate).getTime() - new Date(p.startDate).getTime()) / 86400000) : null;

  // ---------- Adım içerikleri ----------
  const renderBasics = () => (
    <div className="space-y-6">
      <Field label={tr ? 'Proje adı' : 'Project name'} always language={language} error={errOf('name')}>
        <input autoFocus className={inputCls(errOf('name')) + ' h-12 text-base font-semibold'} value={p.name || ''} onChange={e => set({ name: e.target.value })} placeholder={tr ? 'Örn: Mobil Oyun v2' : 'e.g. Mobile Game v2'} />
      </Field>

      <Field label={tr ? 'Proje tipi' : 'Project type'} field="projectType" settings={settings} language={language} error={errOf('projectType')}>
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
          {Object.values(ProjectType).map(v => {
            const m = TYPE_META[v]; const on = p.projectType === v;
            return (
              <button key={v} type="button" onClick={() => set({ projectType: v })}
                className={`relative flex items-center gap-2 p-3 rounded-xl border text-left text-sm font-semibold transition-all ${on ? 'border-indigo-500 bg-indigo-50 dark:bg-indigo-500/10 text-indigo-700 dark:text-indigo-200 ring-4 ring-indigo-500/10' : 'border-slate-200 dark:border-slate-700 text-slate-600 dark:text-slate-300 hover:border-slate-300'}`}>
                <span className={`w-8 h-8 shrink-0 rounded-lg bg-gradient-to-br ${m.grad} flex items-center justify-center text-base`}>{m.emoji}</span>
                <span className="truncate">{tr ? m.tr : m.en}</span>
                {on && <Check size={14} className="absolute top-2 right-2 text-indigo-600 animate-in zoom-in-50 duration-200" />}
              </button>
            );
          })}
        </div>
      </Field>

      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
        <Field label={tr ? 'Öncelik' : 'Priority'} field="priority" settings={settings} language={language} error={errOf('priority')}>
          <div className="grid grid-cols-4 gap-1 p-1 rounded-xl bg-slate-100 dark:bg-slate-800">
            {(['Low', 'Medium', 'High', 'Critical'] as ProjectPriority[]).map(k => {
              const on = p.priority === k;
              return (
                <button key={k} type="button" onClick={() => set({ priority: on ? undefined : k })}
                  className={`h-9 rounded-lg text-xs font-semibold inline-flex items-center justify-center gap-1.5 transition-all ${on ? 'bg-white dark:bg-slate-900 shadow-sm text-slate-900 dark:text-white' : 'text-slate-500 hover:text-slate-700'}`}>
                  <span className={`w-1.5 h-1.5 rounded-full ${PRIORITY_META[k].dot}`} />{tr ? PRIORITY_META[k].tr : PRIORITY_META[k].en}
                </button>
              );
            })}
          </div>
        </Field>
        <Field label={tr ? 'Durum' : 'Status'} always language={language}>
          <div className="grid grid-cols-3 gap-1 p-1 rounded-xl bg-slate-100 dark:bg-slate-800">
            {([['Active', tr ? 'Aktif' : 'Active'], ['On Hold', tr ? 'Askıda' : 'On hold'], ['Completed', tr ? 'Tamamlandı' : 'Done']] as const).map(([k, l]) => (
              <button key={k} type="button" onClick={() => k === 'On Hold' ? setHoldOpen(true) : set({ status: k as any, ...(p.status === 'On Hold' ? CLEAR_HOLD : {}) })}
                className={`h-9 rounded-lg text-xs font-semibold transition-all ${p.status === k ? 'bg-white dark:bg-slate-900 shadow-sm text-slate-900 dark:text-white' : 'text-slate-500 hover:text-slate-700'}`}>{l}</button>
            ))}
          </div>
          {p.status === 'On Hold' && (
            <button type="button" onClick={() => setHoldOpen(true)} className="mt-1.5 text-[11px] font-semibold text-amber-700 dark:text-amber-300 hover:underline">
              {p.holdUntil ? (tr ? `${new Date(p.holdUntil + 'T00:00').toLocaleDateString('tr-TR', { day: 'numeric', month: 'long' })} tarihine kadar · süreyi değiştir` : `Until ${p.holdUntil} · change`) : (tr ? 'Süresiz · süre belirle' : 'Indefinite · set duration')}
            </button>
          )}
          <ProjectHoldSheet open={holdOpen} project={p as Project} language={language} showFinancials={showFinancials} onClose={() => setHoldOpen(false)} onConfirm={patch => set(patch)} />
        </Field>
      </div>

      <Field label={tr ? 'Açıklama / kapsam' : 'Description / scope'} field="description" settings={settings} language={language} error={errOf('description')} hint={`${(p.description || '').length}/1000`}>
        <textarea rows={4} maxLength={1000} className={inputCls(errOf('description')) + ' h-auto py-3 resize-none'} value={p.description || ''} onChange={e => set({ description: e.target.value })} placeholder={tr ? 'Projenin amacı, kapsamı ve teslim edilecekler…' : 'Goal, scope and deliverables…'} />
      </Field>
    </div>
  );

  const renderPlan = () => (
    <div className="space-y-6">
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
        <Field label={tr ? 'Başlangıç tarihi' : 'Start date'} field="startDate" settings={settings} language={language} error={errOf('startDate')}>
          <input type="date" className={inputCls(errOf('startDate'))} value={p.startDate || ''} onChange={e => set({ startDate: e.target.value })} />
        </Field>
        <Field label={tr ? 'Teslim tarihi' : 'Delivery date'} field="deliveryDate" settings={settings} language={language} error={errOf('deliveryDate')}
          hint={durationDays !== null ? (tr ? `Süre: ${durationDays} gün (~${Math.max(1, Math.round(durationDays / 7))} hafta)` : `Duration: ${durationDays} days`) : undefined}>
          <input type="date" min={p.startDate || undefined} className={inputCls(errOf('deliveryDate'))} value={p.deliveryDate || ''} onChange={e => set({ deliveryDate: e.target.value })} />
        </Field>
      </div>
      <div className="flex flex-wrap gap-2 -mt-3">
        {[[4, tr ? '+1 ay' : '+1 mo'], [13, tr ? '+3 ay' : '+3 mo'], [26, tr ? '+6 ay' : '+6 mo']].map(([w, l]) => (
          <button key={l as string} type="button" onClick={() => { const s = p.startDate || todayISO(); set({ startDate: s, deliveryDate: addMonths(s, Math.round((w as number) / 4.33)) }); }}
            className="h-7 px-2.5 rounded-lg text-[11px] font-semibold bg-slate-100 dark:bg-white/5 text-slate-600 dark:text-slate-300 hover:bg-indigo-50 hover:text-indigo-600">{tr ? 'Teslim:' : 'Due:'} {l}</button>
        ))}
      </div>

      <Field label={`${tr ? 'Mevcut ilerleme' : 'Current progress'} · %${p.progress || 0}`} always language={language} error={errOf('progress')}>
        <input type="range" min={0} max={100} step={5} value={p.progress || 0} onChange={e => set({ progress: Number(e.target.value) })} className="w-full accent-indigo-600" />
      </Field>

      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
        <Field label={tr ? 'Proje yöneticisi' : 'Project manager'} field="projectManager" settings={settings} language={language} error={errOf('projectManager')}>
          <div className="relative">
            <UserCog size={16} className="absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-400 pointer-events-none" />
            <select className={inputCls(errOf('projectManager')) + ' pl-10'} value={p.projectManagerId || ''} onChange={e => set({ projectManagerId: e.target.value || undefined })}>
              <option value="">{tr ? 'Seçiniz' : 'Select'}</option>
              {users.map(u => <option key={u.id} value={u.id}>{u.name}{u.jobTitle ? ` — ${u.jobTitle}` : ''}</option>)}
            </select>
          </div>
        </Field>
        <Field label={tr ? 'Tahmini efor (saat)' : 'Estimated hours'} field="estimatedHours" settings={settings} language={language} error={errOf('estimatedHours')}
          hint={p.estimatedHours && durationDays ? (tr ? `≈ ${(p.estimatedHours / Math.max(1, durationDays / 7)).toFixed(1)} saat/hafta` : `≈ ${(p.estimatedHours / Math.max(1, durationDays / 7)).toFixed(1)} h/week`) : undefined}>
          <div className="relative">
            <Timer size={16} className="absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-400 pointer-events-none" />
            <input type="number" min={0} className={inputCls(errOf('estimatedHours')) + ' pl-10'} value={p.estimatedHours || ''} onChange={e => set({ estimatedHours: Number(e.target.value) || undefined })} placeholder="120" />
          </div>
        </Field>
      </div>

      <Field label={`${tr ? 'Proje ekibi' : 'Project team'} (${team.length})`} field="team" settings={settings} language={language} error={errOf('team')}>
        <div className="flex flex-wrap gap-2">
          {users.length === 0 && <p className="text-xs text-slate-400 flex items-center gap-2"><Users size={14} /> {tr ? 'Personel bulunamadı' : 'No staff'}</p>}
          {users.map(u => {
            const on = (p.teamMemberIds || []).includes(u.id);
            return (
              <button key={u.id} type="button" onClick={() => set({ teamMemberIds: on ? (p.teamMemberIds || []).filter(x => x !== u.id) : [...(p.teamMemberIds || []), u.id] })}
                className={`inline-flex items-center gap-2 pl-1 pr-3 h-9 rounded-full border text-xs font-semibold transition-all ${on ? 'bg-indigo-600 border-indigo-600 text-white shadow-md shadow-indigo-500/20' : 'border-slate-200 dark:border-slate-700 text-slate-600 dark:text-slate-300 hover:border-indigo-300'}`}>
                {u.avatar ? <img src={u.avatar} alt="" className="w-7 h-7 rounded-full object-cover" /> : <span className={`w-7 h-7 rounded-full flex items-center justify-center text-[11px] font-bold ${on ? 'bg-white/20' : 'bg-indigo-50 text-indigo-600 dark:bg-indigo-500/10'}`}>{u.name?.[0]}</span>}
                {u.name}
                {on && <Check size={13} className="animate-in zoom-in-50 duration-200" />}
              </button>
            );
          })}
        </div>
      </Field>

      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
        <Field label={tr ? 'Etiketler' : 'Tags'} field="tags" settings={settings} language={language} error={errOf('tags')} hint={tr ? 'Enter veya virgül ile ekleyin' : 'Press Enter or comma'}>
          <div className={`flex flex-wrap items-center gap-1.5 min-h-[44px] px-2 py-1.5 rounded-xl bg-white dark:bg-slate-800 border ${errOf('tags') ? 'border-rose-300' : 'border-slate-200 dark:border-slate-700'} focus-within:border-indigo-500 focus-within:ring-4 focus-within:ring-indigo-500/10`}>
            <Tag size={14} className="text-slate-400 ml-1" />
            {(p.tags || []).map(t => (
              <span key={t} className="inline-flex items-center gap-1 h-7 px-2 rounded-lg bg-indigo-50 dark:bg-indigo-500/10 text-indigo-700 dark:text-indigo-300 text-xs font-semibold animate-in zoom-in-95 duration-200">
                #{t}<button type="button" onClick={() => set({ tags: (p.tags || []).filter(x => x !== t) })} className="hover:text-rose-500"><X size={11} /></button>
              </span>
            ))}
            <input className="pc-plain-input flex-1 min-w-[90px] outline-none text-sm py-1" value={tagInput} onChange={e => setTagInput(e.target.value)} onBlur={addTag}
              onKeyDown={e => { if (e.key === 'Enter' || e.key === ',') { e.preventDefault(); addTag(); } else if (e.key === 'Backspace' && !tagInput && (p.tags || []).length) set({ tags: (p.tags || []).slice(0, -1) }); }}
              placeholder={(p.tags || []).length ? '' : 'unity, mobil…'} />
          </div>
        </Field>
        <Field label={tr ? 'Repo / proje linki' : 'Repo / project link'} field="repoUrl" settings={settings} language={language} error={errOf('repoUrl')}>
          <div className="relative">
            <Link2 size={16} className="absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-400 pointer-events-none" />
            <input type="url" className={inputCls(errOf('repoUrl')) + ' pl-10'} value={p.repoUrl || ''} onChange={e => set({ repoUrl: e.target.value })} placeholder="https://github.com/…" />
          </div>
        </Field>
      </div>
    </div>
  );

  const renderClient = () => (
    <div className="space-y-6">
      {customers.length > 0 && (
        <div className="p-4 rounded-2xl bg-indigo-50/60 dark:bg-indigo-500/10 border border-indigo-100 dark:border-indigo-500/20">
          <label className="flex items-center gap-2 text-xs font-semibold text-indigo-700 dark:text-indigo-300 mb-2"><BookUser size={15} /> {tr ? 'Kayıtlı müşteriden doldur' : 'Fill from saved customer'}</label>
          <select className={inputCls()} value={p.customerId || ''} onChange={e => pickCustomer(e.target.value)}>
            <option value="">{tr ? '— Müşteri seç —' : '— Select customer —'}</option>
            {customers.map(c => <option key={c.id} value={c.id}>{c.company ? `${c.company} · ${c.name}` : c.name}</option>)}
          </select>
          <p className="text-[11px] text-indigo-600/70 dark:text-indigo-300/70 mt-1.5">{tr ? 'Boş alanlar müşteri kaydından otomatik doldurulur.' : 'Empty fields are filled automatically.'}</p>
        </div>
      )}
      <Field label={tr ? 'Müşteri / firma' : 'Client / company'} field="client" settings={settings} language={language} error={errOf('client')}>
        <input className={inputCls(errOf('client'))} value={p.client || ''} onChange={e => set({ client: e.target.value })} placeholder={tr ? 'Firma adı' : 'Company name'} />
      </Field>
      <Field label={tr ? 'Yetkili kişi' : 'Contact person'} field="clientContactName" settings={settings} language={language} error={errOf('clientContactName')}>
        <div className="relative"><Contact size={16} className="absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-400 pointer-events-none" />
          <input className={inputCls(errOf('clientContactName')) + ' pl-10'} value={p.clientContactName || ''} onChange={e => set({ clientContactName: e.target.value })} /></div>
      </Field>
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
        <Field label={tr ? 'E-posta' : 'Email'} field="clientEmail" settings={settings} language={language} error={errOf('clientEmail')}>
          <div className="relative"><Mail size={16} className="absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-400 pointer-events-none" />
            <input type="email" className={inputCls(errOf('clientEmail')) + ' pl-10'} value={p.clientEmail || ''} onChange={e => set({ clientEmail: e.target.value })} placeholder="ornek@firma.com" /></div>
        </Field>
        <Field label={tr ? 'Telefon' : 'Phone'} field="clientPhone" settings={settings} language={language} error={errOf('clientPhone')}>
          <div className="relative"><Phone size={16} className="absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-400 pointer-events-none" />
            <input type="tel" className={inputCls(errOf('clientPhone')) + ' pl-10'} value={p.clientPhone || ''} onChange={e => set({ clientPhone: e.target.value })} placeholder="05xx xxx xx xx" /></div>
        </Field>
      </div>
    </div>
  );

  const renderBudget = () => (
    <div className="space-y-6">
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <Field label={tr ? 'Para birimi' : 'Currency'} always language={language}>
          <div className="grid grid-cols-3 gap-1 p-1 rounded-xl bg-slate-100 dark:bg-slate-800">
            {[Currency.TRY, Currency.USD, Currency.EUR].map(c => (
              <button key={c} type="button" onClick={() => set({ currency: c })} className={`h-9 rounded-lg text-xs font-bold transition-all ${p.currency === c ? 'bg-white dark:bg-slate-900 shadow-sm text-indigo-600' : 'text-slate-500'}`}>{sym(c)} {c}</button>
            ))}
          </div>
        </Field>
        <Field label={tr ? 'Bütçe (KDV hariç)' : 'Budget (excl. VAT)'} field="budget" settings={settings} language={language} error={errOf('budget')}>
          <div className="relative"><span className="absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-400 font-bold">{sym(p.currency)}</span>
            <input type="number" min={0} className={inputCls(errOf('budget')) + ' pl-9 font-bold'} value={p.budget || ''} onChange={e => recalcMoney(Number(e.target.value), Number(p.taxRate || 0))} /></div>
        </Field>
        <Field label={tr ? 'KDV oranı (%)' : 'VAT rate (%)'} always language={language}>
          <input type="number" min={0} max={100} className={inputCls()} value={p.taxRate ?? ''} onChange={e => recalcMoney(Number(p.budget || 0), Number(e.target.value))} />
          <div className="flex gap-1 mt-1.5">
            {[0, 1, 10, 20].map(r => <button key={r} type="button" onClick={() => recalcMoney(Number(p.budget || 0), r)} className={`h-7 px-2.5 rounded-lg text-[11px] font-bold border transition-colors ${Number(p.taxRate) === r ? 'border-indigo-500 text-indigo-600 bg-indigo-50 dark:bg-indigo-500/10' : 'border-slate-200 dark:border-slate-700 text-slate-500 hover:border-slate-300'}`}>%{r}</button>)}
          </div>
        </Field>
      </div>

      {(p.budget || 0) > 0 && (
        <div className="grid grid-cols-3 gap-2 animate-in fade-in duration-300">
          {[[tr ? 'Ara toplam' : 'Subtotal', p.budget || 0], [`${tr ? 'KDV' : 'VAT'} %${p.taxRate || 0}`, p.taxAmount || 0], [tr ? 'Genel toplam' : 'Grand total', totalOf(p)]].map(([l, v], i) => (
            <div key={l as string} className={`rounded-xl p-3 ${i === 2 ? 'bg-indigo-600 text-white' : 'bg-slate-50 dark:bg-white/[0.03]'}`}>
              <p className={`text-[11px] ${i === 2 ? 'text-indigo-100' : 'text-slate-400'}`}>{l}</p>
              <p className="text-base font-bold mt-0.5">{showFinancials ? fmtMoney(v as number, p.currency) : '••••'}</p>
            </div>
          ))}
        </div>
      )}

      <Field label={tr ? 'Ödeme yapısı' : 'Payment structure'} always language={language}>
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-2">
          {([
            [PaymentType.CASH, tr ? 'Peşin' : 'Upfront', tr ? 'Tek seferde tam ödeme' : 'Single full payment'],
            [PaymentType.INSTALLMENT, tr ? 'Taksitli' : 'Installments', tr ? 'Aylık eşit taksitler' : 'Equal monthly'],
            [PaymentType.MILESTONE, tr ? 'Ön / Son ödeme' : 'Milestone', tr ? '%30 başta, %70 teslimde' : '30% upfront, 70% on delivery'],
          ] as const).map(([k, l, d]) => {
            const on = (p.paymentType || PaymentType.CASH) === k;
            return (
              <button key={k} type="button" onClick={() => setPaymentType(k)} className={`text-left p-3.5 rounded-xl border transition-all ${on ? 'border-indigo-500 bg-indigo-50 dark:bg-indigo-500/10 ring-4 ring-indigo-500/10' : 'border-slate-200 dark:border-slate-700 hover:border-slate-300'}`}>
                <p className={`text-sm font-semibold ${on ? 'text-indigo-700 dark:text-indigo-200' : 'text-slate-800 dark:text-slate-100'}`}>{l}</p>
                <p className="text-[11px] text-slate-400 mt-0.5">{d}</p>
              </button>
            );
          })}
        </div>
      </Field>

      {p.paymentType && p.paymentType !== PaymentType.CASH && (
        <div className="rounded-2xl border border-slate-200 dark:border-slate-700 overflow-hidden animate-in fade-in slide-in-from-bottom-2 duration-300">
          <div className="flex flex-wrap items-center justify-between gap-2 px-4 py-3 bg-slate-50 dark:bg-white/[0.03] border-b border-slate-200 dark:border-slate-700">
            <div className="flex items-center gap-2">
              <p className="text-sm font-semibold text-slate-800 dark:text-slate-100">{tr ? 'Ödeme planı' : 'Payment plan'}</p>
              {p.paymentType === PaymentType.INSTALLMENT && !isEditing && (
                <div className="flex items-center gap-1 ml-2">
                  <input type="number" min={1} max={36} value={count} onChange={e => { const n = Math.max(1, Math.min(36, Number(e.target.value) || 1)); setCount(n); setInstallments(buildPlan(p, PaymentType.INSTALLMENT, n, tr)); }} className="w-14 h-8 px-2 rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-sm text-center" />
                  <span className="text-xs text-slate-500">{tr ? 'taksit' : 'installments'}</span>
                </div>
              )}
            </div>
            <div className="flex items-center gap-2">
              <span className={`text-xs font-semibold px-2 py-1 rounded-lg ${Math.abs(remaining) <= 0.1 ? 'bg-emerald-50 text-emerald-700 dark:bg-emerald-500/10 dark:text-emerald-300' : 'bg-rose-50 text-rose-700 dark:bg-rose-500/10 dark:text-rose-300'}`}>
                {Math.abs(remaining) <= 0.1 ? (tr ? 'Toplam eşleşti ✓' : 'Totals match ✓') : `${tr ? 'Fark' : 'Diff'}: ${showFinancials ? fmtMoney(remaining, p.currency) : '••'}`}
              </span>
              <button type="button" onClick={equalize} title={tr ? 'Eşit dağıt' : 'Distribute equally'} className="h-8 px-2.5 rounded-lg text-xs font-semibold border border-slate-200 dark:border-slate-700 text-slate-600 dark:text-slate-300 hover:text-indigo-600 inline-flex items-center gap-1"><Divide size={13} /> {tr ? 'Eşitle' : 'Equalize'}</button>
            </div>
          </div>
          <div className="divide-y divide-slate-100 dark:divide-slate-800 max-h-[320px] overflow-y-auto custom-scrollbar">
            {(p.installments || []).map((inst, i) => (
              <div key={inst.id} className="grid grid-cols-12 gap-2 items-center px-4 py-2.5">
                <input className="col-span-12 sm:col-span-3 h-9 px-2.5 rounded-lg border border-transparent hover:border-slate-200 focus:border-indigo-400 bg-transparent text-sm font-semibold outline-none" value={inst.label} onChange={e => updateInst(i, { label: e.target.value })} />
                <div className="col-span-5 sm:col-span-3 relative"><span className="absolute left-2.5 top-1/2 -translate-y-1/2 text-xs text-slate-400">{sym(p.currency)}</span>
                  <input type="number" className="w-full h-9 pl-6 pr-2 rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-sm font-semibold outline-none focus:border-indigo-400" value={inst.amount} onChange={e => updateInst(i, { amount: Number(e.target.value) })} /></div>
                <input type="date" className="col-span-5 sm:col-span-3 h-9 px-2 rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-xs outline-none focus:border-indigo-400" value={inst.dueDate} onChange={e => updateInst(i, { dueDate: e.target.value })} />
                <input type="url" placeholder={tr ? 'Ödeme linki' : 'Pay link'} className="hidden sm:block sm:col-span-2 h-9 px-2 rounded-lg border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 text-xs outline-none focus:border-indigo-400" value={inst.paymentLink || ''} onChange={e => updateInst(i, { paymentLink: e.target.value })} />
                <div className="col-span-2 sm:col-span-1 flex justify-end">
                  {inst.isPaid
                    ? <span className="text-[10px] font-bold text-emerald-600">{tr ? 'Ödendi' : 'Paid'}</span>
                    : <button type="button" onClick={() => setInstallments((p.installments || []).filter((_, k) => k !== i))} className="p-1.5 rounded-lg text-slate-400 hover:text-rose-600 hover:bg-rose-50"><Trash2 size={14} /></button>}
                </div>
              </div>
            ))}
          </div>
          <button type="button" onClick={() => setInstallments([...(p.installments || []), { id: `inst-${Date.now()}`, amount: Math.max(0, remaining), dueDate: addMonths((p.installments || []).slice(-1)[0]?.dueDate || p.startDate || todayISO(), 1), isPaid: false, label: tr ? `${(p.installments || []).length + 1}. Ödeme` : `Payment ${(p.installments || []).length + 1}` }])}
            className="w-full h-10 text-xs font-semibold text-indigo-600 hover:bg-indigo-50 dark:hover:bg-indigo-500/10 inline-flex items-center justify-center gap-1.5 border-t border-slate-100 dark:border-slate-800"><Plus size={14} /> {tr ? 'Ödeme ekle' : 'Add payment'}</button>
          {errOf('payments') && <p className="px-4 pb-3 text-[11px] font-semibold text-rose-600 flex items-center gap-1"><AlertCircle size={12} /> {errOf('payments')}</p>}
        </div>
      )}
    </div>
  );

  const renderFiles = () => {
    const contractReq = isFieldRequired(settings, 'contract');
    const gddReq = isFieldRequired(settings, 'gdd');
    return (
      <div className="space-y-6">
        <Field label={tr ? 'Sözleşmeler' : 'Contracts'} field="contract" settings={settings} language={language} error={errOf('contract')}>
          <div className="space-y-2">
            {(p.contracts || []).map(d => (
              <div key={d.id} className="flex items-center gap-3 p-3 rounded-xl border border-slate-200 dark:border-slate-700 animate-in fade-in slide-in-from-bottom-2 duration-200">
                <span className="p-2 rounded-lg bg-indigo-50 dark:bg-indigo-500/10 text-indigo-600"><FileText size={16} /></span>
                <div className="flex-1 min-w-0"><p className="text-sm font-semibold truncate">{d.name}</p><p className="text-[11px] text-slate-400 uppercase">{d.fileType} · {d.uploadDate}</p></div>
                <button type="button" onClick={() => set({ contracts: (p.contracts || []).filter(x => x.id !== d.id) })} className="p-1.5 rounded-lg text-slate-400 hover:text-rose-600 hover:bg-rose-50"><Trash2 size={14} /></button>
              </div>
            ))}
            <button type="button" onClick={() => pickFile('.pdf,.doc,.docx,.png,.jpg', f => set({ contracts: [...(p.contracts || []), toDoc(f, 'contract')] }))}
              className={`w-full flex items-center justify-center gap-2 h-14 rounded-xl border-2 border-dashed text-sm font-semibold transition-colors ${errOf('contract') ? 'border-rose-300 text-rose-600' : 'border-slate-200 dark:border-slate-700 text-slate-500 hover:border-indigo-400 hover:text-indigo-600'}`}>
              <Upload size={16} /> {tr ? 'Sözleşme yükle' : 'Upload contract'}{contractReq ? ' *' : ''}
            </button>
          </div>
        </Field>

        <Field label={tr ? 'GDD / analiz dokümanı' : 'GDD / spec document'} field="gdd" settings={settings} language={language} error={errOf('gdd')}>
          {p.gddUrl ? (
            <div className="flex items-center gap-3 p-4 rounded-xl bg-emerald-50 dark:bg-emerald-500/10 border border-emerald-200 dark:border-emerald-500/20 animate-in fade-in zoom-in-95 duration-300">
              <span className="p-2 rounded-lg bg-emerald-500 text-white"><Check size={16} /></span>
              <div className="flex-1"><p className="text-sm font-semibold text-emerald-800 dark:text-emerald-200">{tr ? 'GDD yüklendi' : 'GDD uploaded'}</p>
                {!isEditing && <p className="text-[11px] text-emerald-700/80 dark:text-emerald-300/80 flex items-center gap-1"><Bot size={12} /> {tr ? 'Kaydedince yapay zeka görevleri otomatik oluşturacak.' : 'AI will generate tasks on save.'}</p>}</div>
              <button type="button" onClick={() => set({ gddUrl: '' })} className="p-1.5 rounded-lg text-emerald-700 hover:bg-emerald-100"><Trash2 size={14} /></button>
            </div>
          ) : (
            <button type="button" onClick={() => pickFile('.pdf,.doc,.docx,.md,.txt', f => set({ gddUrl: URL.createObjectURL(f) }))}
              className={`w-full flex flex-col items-center justify-center gap-1 py-8 rounded-xl border-2 border-dashed transition-colors ${errOf('gdd') ? 'border-rose-300 text-rose-600' : 'border-slate-200 dark:border-slate-700 text-slate-500 hover:border-indigo-400 hover:text-indigo-600'}`}>
              <Upload size={22} />
              <span className="text-sm font-semibold">{tr ? 'GDD yükle' : 'Upload GDD'}{gddReq ? ' *' : ''}</span>
              <span className="text-[11px] text-slate-400 flex items-center gap-1"><Bot size={12} /> {tr ? 'Yüklenirse görevler yapay zekayla oluşturulur' : 'AI generates tasks from it'}</span>
            </button>
          )}
        </Field>

        <Field label={tr ? 'Diğer dokümanlar' : 'Other documents'} language={language}>
          <div className="flex flex-wrap gap-2">
            {(p.documents || []).map(d => (
              <span key={d.id} className="inline-flex items-center gap-1.5 h-8 px-2.5 rounded-lg bg-slate-100 dark:bg-white/5 text-xs font-semibold">
                <FileText size={13} /> <span className="max-w-[160px] truncate">{d.name}</span>
                <button type="button" onClick={() => set({ documents: (p.documents || []).filter(x => x.id !== d.id) })} className="hover:text-rose-500"><X size={12} /></button>
              </span>
            ))}
            <button type="button" onClick={() => pickFile('*', f => set({ documents: [...(p.documents || []), toDoc(f, 'document')] }))} className="inline-flex items-center gap-1.5 h-8 px-3 rounded-lg border border-dashed border-slate-300 dark:border-slate-600 text-xs font-semibold text-slate-500 hover:text-indigo-600 hover:border-indigo-400"><Plus size={13} /> {tr ? 'Doküman ekle' : 'Add document'}</button>
          </div>
        </Field>
      </div>
    );
  };

  const renderReview = () => {
    const rows: { step: StepKey; label: string; value: React.ReactNode }[] = [
      { step: 'basics', label: tr ? 'Proje' : 'Project', value: <>{type.emoji} {p.name || '—'}</> },
      { step: 'basics', label: tr ? 'Öncelik / Durum' : 'Priority / Status', value: `${p.priority ? (tr ? PRIORITY_META[p.priority].tr : p.priority) : '—'} · ${p.status === 'On Hold' ? (tr ? 'Askıda' : 'On hold') : p.status === 'Completed' ? (tr ? 'Tamamlandı' : 'Done') : (tr ? 'Aktif' : 'Active')}` },
      { step: 'plan', label: tr ? 'Takvim' : 'Schedule', value: `${p.startDate || '—'} → ${p.deliveryDate || '—'}${durationDays !== null ? ` (${durationDays} ${tr ? 'gün' : 'days'})` : ''}` },
      { step: 'plan', label: tr ? 'Ekip' : 'Team', value: [users.find(u => u.id === p.projectManagerId)?.name && `${tr ? 'Yönetici' : 'PM'}: ${users.find(u => u.id === p.projectManagerId)?.name}`, team.map(u => u.name).join(', ')].filter(Boolean).join(' · ') || '—' },
      { step: 'client', label: tr ? 'Müşteri' : 'Client', value: [p.client, p.clientContactName, p.clientEmail, p.clientPhone].filter(Boolean).join(' · ') || '—' },
      { step: 'budget', label: tr ? 'Bütçe' : 'Budget', value: showFinancials ? `${fmtMoney(totalOf(p), p.currency)} (${tr ? 'KDV dahil' : 'incl. VAT'}) · ${(p.installments || []).length || 1} ${tr ? 'ödeme' : 'payment(s)'}` : '••••' },
      { step: 'files', label: tr ? 'Dosyalar' : 'Files', value: `${(p.contracts || []).length} ${tr ? 'sözleşme' : 'contract'} · ${p.gddUrl ? 'GDD ✓' : 'GDD —'} · ${(p.documents || []).length} ${tr ? 'doküman' : 'docs'}` },
    ];
    return (
      <div className="space-y-5">
        {errors.length > 0 ? (
          <div className="p-4 rounded-2xl bg-rose-50 dark:bg-rose-500/10 border border-rose-100 dark:border-rose-500/20">
            <p className="text-sm font-semibold text-rose-700 dark:text-rose-300 mb-2">{tr ? `Kaydetmeden önce ${errors.length} konuyu tamamlayın:` : `Complete ${errors.length} item(s):`}</p>
            <ul className="space-y-1">
              {errors.map((e, i) => {
                const s = steps.find(st => STEP_FIELDS[st.key].includes(e.field));
                return <li key={i}><button type="button" onClick={() => { setTouched(true); s && goTo(s.key); }} className="text-xs text-rose-600 dark:text-rose-300 hover:underline flex items-center gap-1.5"><AlertCircle size={12} /> {e.message} {s && <span className="text-rose-400">→ {s.label}</span>}</button></li>;
              })}
            </ul>
          </div>
        ) : (
          <div className="p-4 rounded-2xl bg-emerald-50 dark:bg-emerald-500/10 border border-emerald-100 dark:border-emerald-500/20 flex items-center gap-3 animate-in fade-in zoom-in-95">
            <span className="p-2 rounded-xl bg-emerald-500 text-white"><Check size={18} /></span>
            <p className="text-sm font-semibold text-emerald-800 dark:text-emerald-200">{tr ? 'Her şey hazır. Projeyi kaydedebilirsiniz.' : 'All set. You can save the project.'}</p>
          </div>
        )}
        <div className="rounded-2xl border border-slate-200 dark:border-slate-700 divide-y divide-slate-100 dark:divide-slate-800">
          {rows.map((r, i) => (
            <div key={i} className="flex items-start gap-3 px-4 py-3">
              <p className="w-32 shrink-0 text-xs font-semibold text-slate-400 pt-0.5">{r.label}</p>
              <p className="flex-1 text-sm text-slate-800 dark:text-slate-100 break-words">{r.value}</p>
              <button type="button" onClick={() => goTo(r.step)} className="text-xs font-semibold text-indigo-600 hover:underline shrink-0">{tr ? 'Düzenle' : 'Edit'}</button>
            </div>
          ))}
        </div>
        {p.description && <p className="text-sm text-slate-600 dark:text-slate-300 whitespace-pre-wrap leading-relaxed">{p.description}</p>}
      </div>
    );
  };

  const content: Record<StepKey, () => React.ReactNode> = { basics: renderBasics, plan: renderPlan, client: renderClient, budget: renderBudget, files: renderFiles, review: renderReview };

  return (
    <ModalPortal>
      <div className="fixed inset-0 z-[1100] flex items-center justify-center p-0 sm:p-4" role="dialog" aria-modal="true">
        <div className="absolute inset-0 bg-slate-950/60 backdrop-blur-md pc-backdrop" onClick={requestClose} />
        <div className="relative w-full max-w-6xl h-full sm:h-[min(92vh,880px)] bg-white dark:bg-slate-900 sm:rounded-[28px] shadow-2xl flex flex-col overflow-hidden pc-pop border border-white/10">
          {/* BAŞLIK */}
          <div className="flex items-center gap-3 px-5 sm:px-6 py-4 border-b border-slate-100 dark:border-slate-800" style={{ paddingTop: 'max(env(safe-area-inset-top, 0px), 1rem)' }}>
            <span className={`w-10 h-10 shrink-0 rounded-xl bg-gradient-to-br ${type.grad} flex items-center justify-center text-lg shadow-md`}>{type.emoji}</span>
            <div className="flex-1 min-w-0">
              <h3 className="text-lg font-bold text-slate-900 dark:text-white truncate">{isEditing ? (tr ? 'Projeyi düzenle' : 'Edit project') : (tr ? 'Yeni proje' : 'New project')}{p.name ? <span className="text-slate-400 font-medium"> · {p.name}</span> : null}</h3>
              <p className="text-xs text-slate-400">{tr ? `Adım ${idx + 1}/${steps.length} · ${steps[idx].label}` : `Step ${idx + 1}/${steps.length} · ${steps[idx].label}`}{!isEditing && dirty ? (tr ? ' · Taslak otomatik kaydediliyor' : ' · Draft autosaved') : ''}</p>
            </div>
            {confirmClose ? (
              <div className="flex items-center gap-2 animate-in fade-in slide-in-from-right-4 duration-200">
                <span className="hidden sm:inline text-xs font-semibold text-rose-600">{tr ? 'Değişiklikler kaybolacak' : 'Changes will be lost'}</span>
                <button onClick={() => setConfirmClose(false)} className="h-9 px-3 rounded-lg text-xs font-semibold text-slate-600 hover:bg-slate-100 dark:hover:bg-white/5">{tr ? 'Vazgeç' : 'Cancel'}</button>
                <button onClick={onClose} className="h-9 px-3 rounded-lg text-xs font-semibold text-white bg-rose-600 hover:bg-rose-500">{tr ? 'Kapat' : 'Discard'}</button>
              </div>
            ) : (
              <>
                {onOpenSettings && <button onClick={() => { onClose(); onOpenSettings(); }} title={tr ? 'Zorunlu alan ayarları' : 'Required field settings'} className="p-2 rounded-xl text-slate-400 hover:text-indigo-600 hover:bg-slate-100 dark:hover:bg-white/5"><SettingsIcon size={18} /></button>}
                <button onClick={requestClose} className="p-2 rounded-xl text-slate-400 hover:text-slate-700 hover:bg-slate-100 dark:hover:bg-white/5" aria-label="Close"><X size={20} /></button>
              </>
            )}
          </div>

          {/* İlerleme çubuğu */}
          <div className="h-1 bg-slate-100 dark:bg-slate-800"><div className="h-full bg-gradient-to-r from-indigo-500 via-violet-500 to-orange-400 transition-all duration-500" style={{ width: `${((idx + 1) / steps.length) * 100}%` }} /></div>

          {/* Mobil adım şeridi */}
          <div className="md:hidden flex gap-1.5 px-4 py-2.5 overflow-x-auto border-b border-slate-100 dark:border-slate-800">
            {steps.map((s, i) => {
              const errs = touched ? stepErrors(s.key) : 0;
              return (
                <button key={s.key} onClick={() => goTo(s.key)} className={`shrink-0 h-8 px-3 rounded-full text-xs font-semibold inline-flex items-center gap-1.5 ${s.key === step ? 'bg-indigo-600 text-white' : errs ? 'bg-rose-50 text-rose-600' : 'bg-slate-100 dark:bg-white/5 text-slate-500'}`}>
                  {i + 1}. {s.label}{errs ? ` (${errs})` : ''}
                </button>
              );
            })}
          </div>

          {draftAvailable && (
            <div className="flex flex-wrap items-center gap-3 px-5 sm:px-6 py-2.5 bg-amber-50 dark:bg-amber-500/10 border-b border-amber-100 dark:border-amber-500/20 animate-in fade-in slide-in-from-top-2">
              <RotateCcw size={15} className="text-amber-600" />
              <p className="flex-1 text-xs font-semibold text-amber-800 dark:text-amber-200">{tr ? `Kaydedilmemiş bir taslak bulundu: "${draftAvailable.name}"` : `Unsaved draft found: "${draftAvailable.name}"`}</p>
              <button onClick={() => { setP(draftAvailable); setCount(draftAvailable.installments?.length || 3); setDraftAvailable(null); toast.info(tr ? 'Taslak geri yüklendi' : 'Draft restored'); }} className="h-8 px-3 rounded-lg text-xs font-semibold bg-amber-600 text-white hover:bg-amber-500">{tr ? 'Geri yükle' : 'Restore'}</button>
              <button onClick={() => { try { localStorage.removeItem(DRAFT_KEY); } catch {} setDraftAvailable(null); }} className="h-8 px-3 rounded-lg text-xs font-semibold text-amber-700 hover:bg-amber-100 dark:hover:bg-amber-500/20">{tr ? 'Sil' : 'Discard'}</button>
            </div>
          )}

          {/* GÖVDE */}
          <div className="flex-1 flex min-h-0">
            {/* Adım listesi */}
            <nav className="hidden md:flex w-60 shrink-0 flex-col gap-1 p-4 border-r border-slate-100 dark:border-slate-800 overflow-y-auto">
              {steps.map((s, i) => {
                const Icon = s.icon;
                const errs = stepErrors(s.key);
                const active = s.key === step;
                const done = i < idx && !errs;
                return (
                  <button key={s.key} onClick={() => goTo(s.key)} className={`relative flex items-center gap-3 p-2.5 rounded-xl text-left transition-all ${active ? 'bg-indigo-50 dark:bg-indigo-500/10' : 'hover:bg-slate-50 dark:hover:bg-white/[0.03]'}`}>
                    <span className={`w-9 h-9 shrink-0 rounded-xl flex items-center justify-center transition-all ${active ? 'bg-indigo-600 text-white shadow-md shadow-indigo-500/30' : touched && errs ? 'bg-rose-50 text-rose-600 dark:bg-rose-500/10' : done ? 'bg-emerald-50 text-emerald-600 dark:bg-emerald-500/10' : 'bg-slate-100 text-slate-500 dark:bg-white/5'}`}>
                      {done && !active ? <Check size={16} /> : <Icon size={16} />}
                    </span>
                    <span className="min-w-0">
                      <span className={`block text-sm font-semibold truncate ${active ? 'text-indigo-700 dark:text-indigo-200' : 'text-slate-700 dark:text-slate-200'}`}>{s.label}</span>
                      <span className="block text-[11px] text-slate-400 truncate">{s.desc}</span>
                    </span>
                    {touched && errs > 0 && <span className="absolute right-2 top-1/2 -translate-y-1/2 min-w-[18px] h-[18px] px-1 rounded-full bg-rose-500 text-white text-[10px] font-bold flex items-center justify-center animate-in zoom-in-50">{errs}</span>}
                  </button>
                );
              })}
              <div className="mt-auto pt-4 text-[11px] text-slate-400 space-y-1">
                <p><kbd className="px-1 rounded border border-slate-200 dark:border-slate-700">Ctrl</kbd> + <kbd className="px-1 rounded border border-slate-200 dark:border-slate-700">Enter</kbd> {tr ? 'kaydet' : 'save'}</p>
                <p><kbd className="px-1 rounded border border-slate-200 dark:border-slate-700">Esc</kbd> {tr ? 'kapat' : 'close'}</p>
              </div>
            </nav>

            {/* İçerik */}
            <div ref={contentRef} className="flex-1 min-w-0 overflow-y-auto custom-scrollbar">
              <div key={step} className={`p-5 sm:p-8 max-w-3xl animate-in fade-in duration-300 ${dir === 1 ? 'slide-in-from-right-4' : 'slide-in-from-left-4'}`}>
                <h4 className="text-xl font-bold text-slate-900 dark:text-white">{steps[idx].label}</h4>
                <p className="text-sm text-slate-400 mb-6">{steps[idx].desc}</p>
                {content[step]()}
              </div>
            </div>

            {/* Canlı önizleme */}
            <aside className="hidden xl:flex w-72 shrink-0 flex-col gap-4 p-5 border-l border-slate-100 dark:border-slate-800 bg-slate-50/60 dark:bg-white/[0.02] overflow-y-auto">
              <p className="text-[10px] font-black uppercase tracking-[0.2em] text-slate-400">{tr ? 'Canlı önizleme' : 'Live preview'}</p>
              <div className="relative rounded-2xl bg-white dark:bg-slate-900 border border-slate-100 dark:border-slate-800 p-4 overflow-hidden shadow-sm">
                <span className={`absolute inset-x-0 top-0 h-1 bg-gradient-to-r ${type.grad}`} />
                <div className="flex flex-wrap gap-1 mb-2">
                  <span className="text-[10px] font-semibold px-1.5 py-0.5 rounded-md bg-slate-100 dark:bg-white/5">{type.emoji} {tr ? type.tr : type.en}</span>
                  {p.priority && <span className={`text-[10px] font-semibold px-1.5 py-0.5 rounded-md ${PRIORITY_META[p.priority].chip}`}>{tr ? PRIORITY_META[p.priority].tr : p.priority}</span>}
                </div>
                <p className={`font-bold leading-snug ${p.name ? 'text-slate-900 dark:text-white' : 'text-slate-300 italic'}`}>{p.name || (tr ? 'Proje adı' : 'Project name')}</p>
                <p className="text-xs text-slate-400 truncate">{p.client || (tr ? 'Müşteri' : 'Client')}</p>
                <div className="mt-3 h-1.5 rounded-full bg-slate-100 dark:bg-white/5"><div className="h-full rounded-full bg-gradient-to-r from-indigo-500 to-violet-500 transition-all duration-500" style={{ width: `${p.progress || 0}%` }} /></div>
                <div className="flex items-center justify-between mt-3 text-[11px] text-slate-500">
                  <span>{p.deliveryDate || (tr ? 'Teslim yok' : 'No date')}</span>
                  <span className="font-bold text-slate-900 dark:text-white">{showFinancials && totalOf(p) ? fmtMoney(totalOf(p), p.currency) : '—'}</span>
                </div>
                {team.length > 0 && <div className="flex -space-x-1.5 mt-3">{team.slice(0, 5).map(u => <span key={u.id} title={u.name} className="w-6 h-6 rounded-full ring-2 ring-white dark:ring-slate-900 bg-indigo-500 text-white text-[9px] font-bold flex items-center justify-center">{u.name?.[0]}</span>)}</div>}
              </div>

              <div className="rounded-2xl bg-white dark:bg-slate-900 border border-slate-100 dark:border-slate-800 p-4">
                <div className="flex items-center justify-between mb-2">
                  <p className="text-xs font-semibold text-slate-600 dark:text-slate-300">{tr ? 'Zorunlu alanlar' : 'Required fields'}</p>
                  <p className="text-xs font-bold text-indigo-600">{requiredDone}/{requiredKeys.length}</p>
                </div>
                <div className="h-1.5 rounded-full bg-slate-100 dark:bg-white/5 mb-3"><div className={`h-full rounded-full transition-all duration-500 ${requiredDone === requiredKeys.length ? 'bg-emerald-500' : 'bg-indigo-500'}`} style={{ width: `${(requiredDone / Math.max(1, requiredKeys.length)) * 100}%` }} /></div>
                <ul className="space-y-1">
                  {requiredKeys.map(k => {
                    const ok = !errors.some(e => e.field === k);
                    const label = k === 'name' ? (tr ? 'Proje adı' : 'Name') : (tr ? PROJECT_FIELDS.find(f => f.key === k)?.tr : PROJECT_FIELDS.find(f => f.key === k)?.en);
                    const s = steps.find(st => STEP_FIELDS[st.key].includes(k));
                    return (
                      <li key={k}>
                        <button type="button" onClick={() => s && goTo(s.key)} className={`w-full flex items-center gap-2 text-xs ${ok ? 'text-slate-400' : 'text-slate-700 dark:text-slate-200 hover:text-indigo-600'}`}>
                          <span className={`w-4 h-4 rounded-full flex items-center justify-center transition-colors ${ok ? 'bg-emerald-500 text-white' : 'border-2 border-slate-300 dark:border-slate-600'}`}>{ok && <Check size={10} strokeWidth={3} />}</span>
                          <span className={ok ? 'line-through' : ''}>{label}</span>
                        </button>
                      </li>
                    );
                  })}
                  {errors.some(e => e.field === 'payments') && <li className="text-xs text-rose-600 flex items-center gap-1.5"><AlertCircle size={12} /> {tr ? 'Ödeme planı tutmuyor' : 'Payment plan mismatch'}</li>}
                </ul>
              </div>
            </aside>
          </div>

          {/* ALT ÇUBUK */}
          <div className="flex items-center gap-2 px-5 sm:px-6 py-3 border-t border-slate-100 dark:border-slate-800 bg-white/90 dark:bg-slate-900/90" style={{ paddingBottom: 'max(env(safe-area-inset-bottom, 0px), 0.75rem)' }}>
            <button onClick={prev} disabled={idx === 0} className="h-10 px-3 sm:px-4 rounded-xl text-sm font-semibold text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-white/5 disabled:opacity-30 inline-flex items-center gap-1"><ChevronLeft size={16} /> <span className="hidden sm:inline">{tr ? 'Geri' : 'Back'}</span></button>
            <div className="flex-1" />
            {step !== 'review' && (
              <button onClick={next} className="h-10 px-4 rounded-xl text-sm font-semibold border border-slate-200 dark:border-slate-700 text-slate-700 dark:text-slate-200 hover:border-indigo-300 hover:text-indigo-600 inline-flex items-center gap-1">{tr ? 'İleri' : 'Next'} <ChevronRight size={16} /></button>
            )}
            <button onClick={submit} disabled={saving} className="h-10 px-5 rounded-xl text-sm font-semibold text-white bg-indigo-600 hover:bg-indigo-500 disabled:opacity-60 shadow-lg shadow-indigo-500/25 inline-flex items-center gap-2">
              {saving ? <Loader2 size={16} className="animate-spin" /> : <Save size={16} />}
              {isEditing ? (tr ? 'Güncelle' : 'Update') : (tr ? 'Projeyi oluştur' : 'Create project')}
            </button>
          </div>
        </div>
      </div>
    </ModalPortal>
  );
};

export default ProjectFormPanel;
