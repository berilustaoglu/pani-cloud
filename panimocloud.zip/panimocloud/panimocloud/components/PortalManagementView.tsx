import React, { useMemo, useState } from 'react';
import { Shield, ExternalLink, Copy, Settings2, Globe, Lock, ListChecks, Wallet, Users, MessageSquare, FileCheck2, FileX2, Eye, Briefcase, QrCode } from 'lucide-react';
import { Project, PortalSettings, Task, TaskStatus } from '../types';
import { PageHeader, KpiGrid, SearchBox, Segmented, Field, EmptyState, Sheet, inputCls, cardCls } from './ui/Kit';
import { GrowBar } from './ui/Motion';
import { toast } from '../services/toast';

interface Props {
  projects: Project[];
  tasks: Task[];
  language: 'tr' | 'en';
  onSelectProject: (projectId: string) => void;
  onUpdateProject: (project: Project) => Promise<void>;
}

const DEFAULTS: PortalSettings = { showTasks: true, showFinancials: true, showTeam: true, isPublic: true, themeColor: '#6366f1' };
const COLORS = ['#6366f1', '#0ea5e9', '#10b981', '#f59e0b', '#ef4444', '#ec4899', '#8b5cf6', '#0f172a'];

const PortalManagementView: React.FC<Props> = ({ projects, tasks, language, onUpdateProject }) => {
  const tr = language === 'tr';
  const [search, setSearch] = useState('');
  const [scope, setScope] = useState<'active' | 'all'>('active');
  const [stateF, setStateF] = useState<'all' | 'on' | 'off' | 'pending'>('all');
  const [edit, setEdit] = useState<Project | null>(null);
  const [saving, setSaving] = useState(false);

  const urlOf = (p: Project) => `${window.location.origin}${window.location.pathname}?portal=${p.id}&mode=standalone`;
  const settingsOf = (p: Project): PortalSettings => ({ ...DEFAULTS, ...(p.portalSettings || {}) });
  const progressOf = (p: Project) => {
    const t = tasks.filter(x => x.projectId === p.id);
    return t.length ? Math.round((t.filter(x => x.status === TaskStatus.DONE).length / t.length) * 100) : (p.progress || 0);
  };
  const docsOf = (p: Project) => [...(p.documents || []), ...(p.contracts || [])];
  const pendingOf = (p: Project) => docsOf(p).filter(d => d.approvalStatus === 'pending').length;
  const rejectedOf = (p: Project) => docsOf(p).filter(d => d.approvalStatus === 'rejected').length;

  const base = projects.filter(p => scope === 'all' || p.status === 'Active' || p.status === 'Revizyonda');
  const stats = useMemo(() => ({
    on: base.filter(p => settingsOf(p).isPublic).length,
    off: base.filter(p => !settingsOf(p).isPublic).length,
    pending: base.reduce((a, p) => a + pendingOf(p), 0),
    rejected: base.reduce((a, p) => a + rejectedOf(p), 0),
  }), [base]);

  const q = search.trim().toLocaleLowerCase('tr-TR');
  const list = base.filter(p => {
    const s = settingsOf(p);
    if (stateF === 'on' && !s.isPublic) return false;
    if (stateF === 'off' && s.isPublic) return false;
    if (stateF === 'pending' && !pendingOf(p) && !rejectedOf(p)) return false;
    return !q || [p.name, p.client].join(' ').toLocaleLowerCase('tr-TR').includes(q);
  }).sort((a, b) => (pendingOf(b) + rejectedOf(b)) - (pendingOf(a) + rejectedOf(a)) || a.name.localeCompare(b.name, 'tr'));

  const quickToggle = async (p: Project) => {
    const s = settingsOf(p);
    await onUpdateProject({ ...p, portalSettings: { ...s, isPublic: !s.isPublic } });
    toast(s.isPublic ? (tr ? `${p.name} portalı kapatıldı` : 'Portal disabled') : (tr ? `${p.name} portalı yayında` : 'Portal live'), s.isPublic ? 'info' : 'success');
  };
  const copy = (p: Project) => { navigator.clipboard.writeText(urlOf(p)); toast.success(tr ? 'Portal bağlantısı kopyalandı' : 'Link copied'); };
  const save = async () => {
    if (!edit) return;
    setSaving(true);
    try { await onUpdateProject(edit); toast.success(tr ? 'Portal ayarları kaydedildi' : 'Saved'); setEdit(null); } finally { setSaving(false); }
  };

  const Switch: React.FC<{ on: boolean; onClick: () => void; label: string; desc: string; icon: React.ElementType }> = ({ on, onClick, label, desc, icon: I }) => (
    <button type="button" onClick={onClick} className={`w-full flex items-center gap-3 p-3 rounded-xl border text-left transition-all ${on ? 'border-indigo-200 bg-indigo-50/60 dark:border-indigo-500/30 dark:bg-indigo-500/10' : 'border-slate-200 dark:border-slate-700'}`}>
      <span className={`p-2 rounded-lg ${on ? 'bg-indigo-600 text-white' : 'bg-slate-100 dark:bg-slate-800 text-slate-400'}`}><I size={15} /></span>
      <span className="flex-1 min-w-0"><span className="block text-sm font-semibold text-slate-800 dark:text-slate-100">{label}</span><span className="block text-[11px] text-slate-400">{desc}</span></span>
      <span className={`w-10 h-6 rounded-full p-0.5 transition-colors ${on ? 'bg-indigo-600' : 'bg-slate-200 dark:bg-slate-700'}`}><span className={`block w-5 h-5 rounded-full bg-white shadow transition-transform ${on ? 'translate-x-4' : ''}`} /></span>
    </button>
  );

  const es = edit ? settingsOf(edit) : DEFAULTS;
  const setS = (patch: Partial<PortalSettings>) => edit && setEdit({ ...edit, portalSettings: { ...es, ...patch } });

  return (
    <div className="space-y-5 pb-10">
      <PageHeader title={tr ? 'Müşteri Portalları' : 'Client Portals'} subtitle={tr ? 'Müşterilerinizin projeyi canlı izlediği bağlantıları yönetin.' : 'Manage live client tracking links.'} />

      <KpiGrid items={[
        { label: tr ? 'Yayındaki portal' : 'Live portals', value: stats.on, icon: Globe, grad: 'from-emerald-500 to-teal-600', sub: `${base.length} ${tr ? 'projeden' : 'projects'}`, bar: base.length ? (stats.on / base.length) * 100 : 0, onClick: () => setStateF(stateF === 'on' ? 'all' : 'on'), active: stateF === 'on' },
        { label: tr ? 'Kapalı portal' : 'Disabled', value: stats.off, icon: Lock, grad: 'from-slate-500 to-slate-700', sub: tr ? 'Müşteri erişemez' : 'No client access', onClick: () => setStateF(stateF === 'off' ? 'all' : 'off'), active: stateF === 'off' },
        { label: tr ? 'Onay bekleyen belge' : 'Awaiting approval', value: stats.pending, icon: FileCheck2, grad: 'from-amber-500 to-orange-600', sub: tr ? 'Müşteri onayında' : 'With client', onClick: () => setStateF(stateF === 'pending' ? 'all' : 'pending'), active: stateF === 'pending' },
        { label: tr ? 'Reddedilen belge' : 'Rejected docs', value: stats.rejected, icon: FileX2, grad: 'from-rose-500 to-red-600', sub: tr ? 'Geri bildirim var' : 'Has feedback', onClick: () => setStateF(stateF === 'pending' ? 'all' : 'pending') },
      ]} />

      <div className={`${cardCls} p-3 flex flex-col lg:flex-row gap-2`}>
        <Segmented<'active' | 'all'> value={scope} onChange={setScope} options={[{ value: 'active', label: tr ? 'Aktif projeler' : 'Active' }, { value: 'all', label: tr ? 'Tüm projeler' : 'All' }]} />
        <SearchBox value={search} onChange={setSearch} placeholder={tr ? 'Proje veya müşteri ara…' : 'Search…'} />
      </div>

      {list.length === 0 ? <div className={cardCls}><EmptyState icon={Briefcase} text={tr ? 'Eşleşen proje yok' : 'No projects'} /></div> : (
        <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-3 pc-stagger">
          {list.map(p => {
            const s = settingsOf(p); const pr = progressOf(p); const pend = pendingOf(p); const rej = rejectedOf(p);
            return (
              <div key={p.id} className={`${cardCls} p-4 flex flex-col gap-3 pc-lift relative overflow-hidden`}>
                <span className="absolute inset-x-0 top-0 h-1" style={{ background: s.isPublic ? s.themeColor : '#cbd5e1' }} />
                <div className="flex items-start gap-3">
                  <span className="w-10 h-10 shrink-0 rounded-xl text-white flex items-center justify-center shadow-md" style={{ background: s.themeColor }}><Shield size={18} /></span>
                  <div className="min-w-0 flex-1"><p className="text-sm font-semibold text-slate-800 dark:text-slate-100 truncate">{p.name}</p><p className="text-[11px] text-slate-400 truncate">{p.client}</p></div>
                  <button onClick={() => quickToggle(p)} title={s.isPublic ? (tr ? 'Portalı kapat' : 'Disable') : (tr ? 'Portalı aç' : 'Enable')} className={`shrink-0 text-[11px] font-semibold px-2 py-1 rounded-md inline-flex items-center gap-1 transition-colors ${s.isPublic ? 'bg-emerald-50 text-emerald-700 hover:bg-emerald-100 dark:bg-emerald-500/10 dark:text-emerald-300' : 'bg-slate-100 text-slate-500 hover:bg-slate-200 dark:bg-white/5'}`}>
                    {s.isPublic ? <><span className="w-1.5 h-1.5 rounded-full bg-emerald-500 pc-dot-pulse" />{tr ? 'Yayında' : 'Live'}</> : <><Lock size={11} />{tr ? 'Kapalı' : 'Off'}</>}
                  </button>
                </div>
                <div><div className="flex justify-between text-[11px] mb-1"><span className="text-slate-400">{tr ? 'Müşterinin gördüğü ilerleme' : 'Progress shown'}</span><b className="text-slate-700 dark:text-slate-200">%{pr}</b></div><GrowBar value={pr} className="bg-indigo-500" /></div>
                <div className="flex flex-wrap gap-1.5">
                  {[[s.showTasks, ListChecks, tr ? 'Görevler' : 'Tasks'], [s.showFinancials, Wallet, tr ? 'Ödemeler' : 'Payments'], [s.showTeam, Users, tr ? 'Ekip' : 'Team']].map(([on, I, l]: any) => (
                    <span key={l} className={`text-[10px] font-semibold px-2 py-0.5 rounded-md inline-flex items-center gap-1 ${on ? 'bg-indigo-50 text-indigo-700 dark:bg-indigo-500/10 dark:text-indigo-300' : 'bg-slate-100 text-slate-400 line-through dark:bg-white/5'}`}><I size={10} />{l}</span>
                  ))}
                  {pend > 0 && <span className="text-[10px] font-semibold px-2 py-0.5 rounded-md bg-amber-50 text-amber-700 dark:bg-amber-500/10 dark:text-amber-300">{pend} {tr ? 'onay bekliyor' : 'pending'}</span>}
                  {rej > 0 && <span className="text-[10px] font-semibold px-2 py-0.5 rounded-md bg-rose-50 text-rose-700 dark:bg-rose-500/10 dark:text-rose-300">{rej} {tr ? 'reddedildi' : 'rejected'}</span>}
                  {(p.clientFeedback?.length || 0) > 0 && (() => { const fb = p.clientFeedback!; const avg = fb.reduce((a, x) => a + x.score, 0) / fb.length; const last = fb[fb.length - 1]; return <span title={last.comment ? `${tr ? 'Son yorum' : 'Last comment'}: ${last.comment}` : undefined} className={`text-[10px] font-semibold px-2 py-0.5 rounded-md ${avg >= 4 ? 'bg-emerald-50 text-emerald-700 dark:bg-emerald-500/10 dark:text-emerald-300' : 'bg-amber-50 text-amber-700 dark:bg-amber-500/10 dark:text-amber-300'}`}>★ {avg.toFixed(1)} · {fb.length} {tr ? 'değerlendirme' : 'ratings'}</span>; })()}
                </div>
                <div className="mt-auto pt-2 border-t border-slate-100 dark:border-slate-800 flex items-center gap-1.5">
                  <button onClick={() => copy(p)} className="flex-1 min-w-0 h-8 px-2.5 rounded-lg bg-slate-50 dark:bg-white/[0.03] text-[11px] font-mono text-slate-500 hover:text-indigo-600 inline-flex items-center gap-1.5 truncate"><Copy size={12} className="shrink-0" /><span className="truncate">?portal={p.id}</span></button>
                  <a href={urlOf(p)} target="_blank" rel="noreferrer" title={tr ? 'Müşteri gözünden aç' : 'Open as client'} className="p-2 rounded-lg text-slate-400 hover:text-indigo-600 hover:bg-indigo-50 dark:hover:bg-white/5"><Eye size={15} /></a>
                  <a href={`https://api.qrserver.com/v1/create-qr-code/?size=300x300&data=${encodeURIComponent(urlOf(p))}`} target="_blank" rel="noreferrer" title="QR" className="p-2 rounded-lg text-slate-400 hover:text-indigo-600 hover:bg-indigo-50 dark:hover:bg-white/5"><QrCode size={15} /></a>
                  <button onClick={() => setEdit({ ...p })} title={tr ? 'Ayarlar' : 'Settings'} className="p-2 rounded-lg text-slate-400 hover:text-indigo-600 hover:bg-indigo-50 dark:hover:bg-white/5"><Settings2 size={15} /></button>
                </div>
              </div>
            );
          })}
        </div>
      )}

      <Sheet open={!!edit} language={language} title={tr ? 'Portal ayarları' : 'Portal settings'} subtitle={edit ? `${edit.name} · ${edit.client}` : ''} icon={Shield} onClose={() => setEdit(null)} onSubmit={save} saving={saving}
        footerLeft={edit ? <a href={urlOf(edit)} target="_blank" rel="noreferrer" className="text-xs font-semibold text-indigo-600 hover:underline inline-flex items-center gap-1"><ExternalLink size={12} />{tr ? 'Portalı aç' : 'Open portal'}</a> : undefined}>
        {edit && <>
          <Switch on={es.isPublic} onClick={() => setS({ isPublic: !es.isPublic })} icon={Globe} label={tr ? 'Portal yayında' : 'Portal live'} desc={tr ? 'Kapalıyken bağlantı "erişim yok" ekranı gösterir' : 'Off = link shows no-access'} />
          <div className="space-y-2">
            <p className="text-xs font-semibold text-slate-500">{tr ? 'Müşterinin görebilecekleri' : 'Visible to client'}</p>
            <Switch on={es.showTasks} onClick={() => setS({ showTasks: !es.showTasks })} icon={ListChecks} label={tr ? 'Görevler ve ilerleme' : 'Tasks & progress'} desc={tr ? 'Görev listesi ve tamamlanma oranı' : 'Task list'} />
            <Switch on={es.showFinancials} onClick={() => setS({ showFinancials: !es.showFinancials })} icon={Wallet} label={tr ? 'Ödeme planı' : 'Payment plan'} desc={tr ? 'Taksitler, ödenen ve kalan tutarlar' : 'Installments'} />
            <Switch on={es.showTeam} onClick={() => setS({ showTeam: !es.showTeam })} icon={Users} label={tr ? 'Proje ekibi' : 'Team'} desc={tr ? 'Projede çalışan ekip üyeleri' : 'Team members'} />
          </div>
          <Field label={tr ? 'Tema rengi' : 'Theme color'}>
            <div className="flex flex-wrap gap-2 items-center">
              {COLORS.map(c => <button key={c} type="button" onClick={() => setS({ themeColor: c })} className={`w-8 h-8 rounded-full transition-transform ${es.themeColor === c ? 'ring-4 ring-offset-2 ring-indigo-500/30 scale-110' : 'hover:scale-105'}`} style={{ background: c }} />)}
              <input type="color" value={es.themeColor || '#6366f1'} onChange={e => setS({ themeColor: e.target.value })} className="w-8 h-8 rounded-full cursor-pointer border-0 bg-transparent" />
            </div>
          </Field>
          <Field label={tr ? 'Karşılama mesajı' : 'Welcome message'} hint={`${(es.customMessage || '').length}/280`}>
            <textarea rows={3} maxLength={280} className={inputCls() + ' !h-auto py-2.5 resize-none'} value={es.customMessage || ''} onChange={e => setS({ customMessage: e.target.value })} placeholder={tr ? 'Örn: Merhaba! Projenizin güncel durumunu buradan takip edebilirsiniz.' : 'Shown on portal entry'} />
          </Field>
          <div className="rounded-2xl overflow-hidden border border-slate-200 dark:border-slate-700">
            <div className="h-14 px-4 flex items-center gap-3 text-white" style={{ background: es.themeColor }}><Shield size={18} /><div className="min-w-0"><p className="text-sm font-bold truncate">{edit.name}</p><p className="text-[10px] opacity-80">{tr ? 'Önizleme' : 'Preview'}</p></div></div>
            <div className="p-4 space-y-2 bg-white dark:bg-slate-900">
              {es.customMessage && <p className="text-xs text-slate-600 dark:text-slate-300 flex gap-2"><MessageSquare size={13} className="shrink-0 mt-0.5" style={{ color: es.themeColor }} />{es.customMessage}</p>}
              <div className="h-2 rounded-full bg-slate-100 dark:bg-slate-800 overflow-hidden"><div className="h-full rounded-full transition-all" style={{ width: `${progressOf(edit)}%`, background: es.themeColor }} /></div>
              <p className="text-[10px] text-slate-400">{[es.showTasks && (tr ? 'Görevler' : 'Tasks'), es.showFinancials && (tr ? 'Ödemeler' : 'Payments'), es.showTeam && (tr ? 'Ekip' : 'Team')].filter(Boolean).join(' · ') || (tr ? 'Yalnızca genel ilerleme' : 'Progress only')}</p>
            </div>
          </div>
        </>}
      </Sheet>
    </div>
  );
};

export default PortalManagementView;
