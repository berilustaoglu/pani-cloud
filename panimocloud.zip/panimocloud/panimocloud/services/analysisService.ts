
import { AIAnalysis, FinancialForecast, StaffAIAnalysis, Currency, Project, Task, Transaction, UserActivity, UserRole, Subscription, LicenseSale, ServiceSale, AttendanceRecord, Customer, User } from '../types';

/**
 * Hyper-Advanced heuristic-based "Local AI" system.
 * Provides detailed business intelligence, risk assessment, and predictive modeling.
 */

export function analyzeOperationsLocal(
    tasks: Task[],
    transactions: Transaction[],
    projects: Project[],
    language: 'tr' | 'en' = 'tr'
): AIAnalysis {
    const today = new Date();
    
    // 1. Task analysis (Bottlenecks & Power Users)
    const totalTasks = tasks.length;
    const completedTasks = tasks.filter(t => t.status === 'Done');
    const blockedTasks = tasks.filter(t => t.status === 'Blocked');
    const overdueTasks = tasks.filter(t => t.status !== 'Done' && t.deadline && new Date(t.deadline) < today);
    const taskCompletionRate = totalTasks > 0 ? (completedTasks.length / totalTasks) * 100 : 0;

    // Leaderboard (Simple "Star Performer" check)
    const userStats: Record<string, number> = {};
    completedTasks.forEach(t => { 
        t.assignedTo.forEach(uid => { userStats[uid] = (userStats[uid] || 0) + 1; });
    });
    const starPerformer = Object.entries(userStats).sort((a,b) => b[1] - a[1])[0];

    // 2. Project Risk Analysis (Budget usage vs Progress)
    const projectRisks: string[] = [];
    projects.filter(p => p.status === 'Active').forEach(p => {
        const spent = transactions.filter(t => t.projectId === p.id && t.type === 'Expense').reduce((sum, t) => sum + t.amount, 0);
        const budgetUsageStr = p.budget > 0 ? (spent / p.budget) * 100 : 0;
        
        // If budget used > progress by more than 20%
        if (budgetUsageStr > p.progress + 20) {
            projectRisks.push(p.name);
        }
    });

    // 3. Financial Analysis (Profitability & Categories)
    const totalIncome = transactions.filter(t => t.type === 'Income').reduce((sum, t) => sum + t.amount, 0);
    const totalExpense = transactions.filter(t => t.type === 'Expense').reduce((sum, t) => sum + t.amount, 0);
    const profitMargin = totalIncome > 0 ? ((totalIncome - totalExpense) / totalIncome) * 100 : 0;

    const expenseCategories: Record<string, number> = {};
    transactions.filter(t => t.type === 'Expense').forEach(t => {
        expenseCategories[t.category] = (expenseCategories[t.category] || 0) + t.amount;
    });
    const topExpenseCategory = Object.entries(expenseCategories).sort((a,b) => b[1] - a[1])[0];

    // 4. Efficiency Score
    let efficiencyScore = Math.round((taskCompletionRate * 0.4) + (Math.min(profitMargin + 50, 100) * 0.3) - (blockedTasks.length * 2) - (projectRisks.length * 5));
    
    const suggestions: string[] = [];
    let summary = "";

    if (language === 'tr') {
        const health = profitMargin > 20 ? "Çok İyi" : profitMargin > 0 ? "Orta" : "Zayıf";
        summary = `İşletme şu an ${efficiencyScore}/100 verimlilik puanına sahip. Gelir-gider dengesi '${health}' durumunda.`;
        
        if (projectRisks.length > 0) {
            suggestions.push(`DİKKAT: ${projectRisks.join(", ")} projelerinde bütçe kullanımı ilerleme hızının çok üzerinde. Kaynak yönetimi şart.`);
        }
        if (starPerformer) {
            suggestions.push(`Star Performans: ID:${starPerformer[0]} kullanıcısı en çok iş tamamlayan üye (${starPerformer[1]} görev).`);
        }
        if (blockedTasks.length > 0) suggestions.push(`${blockedTasks.length} adet bloke görev operasyonu yavaşlatıyor.`);
        if (topExpenseCategory && topExpenseCategory[1] > (totalIncome * 0.4)) {
            suggestions.push(`'${topExpenseCategory[0]}' giderleri gelirin %40'ına ulaştı. Kemer sıkma politikası gerekebilir.`);
        }
        if (suggestions.length < 2) suggestions.push("Sistemler dengeli. Mevcut büyüme modelini ölçeklendirmeyi düşünebilirsiniz.");
    } else {
        const health = profitMargin > 20 ? "Excellent" : profitMargin > 0 ? "Fair" : "Poor";
        summary = `Efficiency is at ${efficiencyScore}/100. Financial health is '${health}'.`;
        if (projectRisks.length > 0) suggestions.push(`Risk: Budget overrun suspected in ${projectRisks.join(", ")}.`);
        if (starPerformer) suggestions.push(`Leaderboard: User ${starPerformer[0]} is leading with ${starPerformer[1]} closures.`);
    }

    return {
        summary,
        efficiencyScore: Math.max(0, Math.min(100, efficiencyScore)),
        financialHealth: language === 'tr' 
            ? (profitMargin > 20 ? "Çok İyi" : profitMargin > 0 ? "Orta" : "Zayıf")
            : (profitMargin > 20 ? "Excellent" : profitMargin > 0 ? "Fair" : "Poor"),
        suggestions
    };
}

export function analyzeStaffPerformanceLocal(
    staffName: string,
    activityLogs: UserActivity[],
    appUsageLogs: any[],
    language: 'tr' | 'en' = 'tr'
): StaffAIAnalysis {
    const totalLogs = activityLogs.length;
    const activeLogs = activityLogs.filter(l => l.tabStatus === 'Active' && !l.isIdle).length;
    const productivityScore = totalLogs > 0 ? Math.round((activeLogs / totalLogs) * 100) : 50;

    const summary = language === 'tr'
        ? `${staffName} genel olarak ${productivityScore}% verimlilikle çalışıyor. Aktif pencere kullanımı stabil.`
        : `${staffName} is working with ${productivityScore}% overall efficiency. Active window usage is stable.`;

    const suggestions = language === 'tr'
        ? ["Düzenli mola vermeyi teşvik edin.", "En yoğun çalışma saatlerini analiz edin."]
        : ["Encourage taking regular breaks.", "Analyze peak working hours."];

    return {
        date: new Date().toISOString(),
        performanceScore: productivityScore,
        productivityScore: productivityScore,
        summary,
        focusApps: (appUsageLogs || []).slice(0, 3).map(a => a.appName || "App"),
        distractionApps: [],
        suggestions,
        bottlenecks: [],
        screenshotCount: activityLogs.length,
        isIdle: activityLogs.some(l => l.isIdle)
    };
}

export function predictFinancialsLocal(
    transactions: Transaction[],
    projects: Project[],
    deals: any[],
    subscriptions: Subscription[],
    licenseSales: LicenseSale[],
    serviceSales: ServiceSale[],
    language: 'tr' | 'en' = 'tr'
): FinancialForecast {
    const now = new Date();
    const ninetyDaysAgo = new Date();
    ninetyDaysAgo.setDate(ninetyDaysAgo.getDate() - 90);
    
    const txDates = transactions.filter(t => new Date(t.date) >= ninetyDaysAgo).map(t => new Date(t.date).getTime());
    let monthsSpanned = 3;
    if (txDates.length > 0) {
        const oldestTx = Math.min(...txDates);
        const daysDiff = (now.getTime() - oldestTx) / (1000 * 60 * 60 * 24);
        monthsSpanned = Math.max(1, Math.min(3, Math.ceil(daysDiff / 30)));
    }

    const recentExpenses = transactions.filter(t => t.type === 'Expense' && new Date(t.date) >= ninetyDaysAgo);
    const avgMonthlyExpense = recentExpenses.reduce((sum, t) => sum + t.amount, 0) / monthsSpanned;

    const recentIncome = transactions.filter(t => t.type === 'Income' && new Date(t.date) >= ninetyDaysAgo);
    const avgHistoricalIncome = recentIncome.reduce((sum, t) => sum + t.amount, 0) / monthsSpanned;

    const monthlySubIncome = subscriptions.filter(s => s.status === 'Active')
        .reduce((sum, s) => sum + (s.billingCycle === 'Yıllık' ? s.amount / 12 : s.amount), 0);
    
    const monthlyServiceIncome = serviceSales.filter(s => s.status === 'Active')
        .reduce((sum, s) => sum + (s.billingCycle === 'Yıllık' ? s.amount / 12 : s.amount), 0);

    const monthlyLicenseIncome = licenseSales.filter(s => s.status === 'Active')
        .reduce((sum, s) => sum + (s.amount / 12), 0);

    const totalRecurringIncome = monthlySubIncome + monthlyServiceIncome + monthlyLicenseIncome;
    const avgMonthlyIncome = Math.max(avgHistoricalIncome, totalRecurringIncome);

    const totalPipelineValue = (deals || []).filter(d => d.status !== 'Won' && d.status !== 'Lost')
                                            .reduce((sum: number, d: any) => sum + (d.value || 0), 0);
    const medianPipeline = totalPipelineValue * 0.3;
    const optimisticPipeline = totalPipelineValue * 0.6;

    const currentBalance = transactions.filter(t => t.type === 'Income').reduce((sum, t) => sum + t.amount, 0) -
                           transactions.filter(t => t.type === 'Expense').reduce((sum, t) => sum + t.amount, 0);

    const runwayMonths = avgMonthlyExpense > 0 ? Math.floor(currentBalance / avgMonthlyExpense) : 12;

    const risks = [];
    const opportunities = [];

    if (language === 'tr') {
        if (runwayMonths < 3) risks.push("KRİTİK: Nakit rezerviniz 3 aydan az. Ek gelir veya gider kısıtlaması şart.");
        if (avgMonthlyExpense > avgMonthlyIncome && currentBalance < (avgMonthlyExpense * 2)) risks.push("Harcama hızı tehlikeli seviyede (Bern rate > Income).");
        opportunities.push(`Pipeline'da bekleyen ${totalPipelineValue.toLocaleString()} değerindeki fırsatların %60'ını (Optimistik) kazanırsanız ${runwayMonths + 6} ay rahatlarsınız.`);
        opportunities.push("Sözleşmeli servislerden gelen aylık sabit geliriniz: " + Math.round(totalRecurringIncome).toLocaleString() + " " + Currency.TRY);
    } else {
        if (runwayMonths < 3) risks.push("Critical Runway Warning.");
        opportunities.push("Focus on recurring revenue growth.");
    }

    return {
        forecast: {
            nextMonth: { income: Math.round(avgMonthlyIncome + (medianPipeline / 3)), expense: Math.round(avgMonthlyExpense) },
            threeMonth: { income: Math.round((avgMonthlyIncome * 3) + medianPipeline), expense: Math.round(avgMonthlyExpense * 3) }
        },
        confidence: 85,
        risks,
        opportunities,
        strategicAdvice: language === 'tr' 
            ? `Şu anki rezervle ${runwayMonths > 12 ? '12+' : runwayMonths} ay hayatta kalabilirsiniz. Aylık sabit geliriniz (~${Math.round(totalRecurringIncome)}) operasyonel giderlerinizin %${Math.round((totalRecurringIncome/avgMonthlyExpense)*100)||0} kadarını karşıılıyor.`
            : `Survival estimate: ${runwayMonths > 12 ? '12+' : runwayMonths} months. Recurring income covers ${Math.round((totalRecurringIncome/avgMonthlyExpense)*100)||0}% of expenses.`
    };
}

export function performSystemAuditLocal(
    users: User[],
    projects: Project[],
    tasks: Task[],
    transactions: Transaction[],
    subscriptions: Subscription[],
    serviceSales: ServiceSale[],
    attendance: AttendanceRecord[],
    customers: Customer[],
    language: 'tr' | 'en' = 'tr'
): AIAnalysis {
    const suggestions: string[] = [];
    
    const staffStats = users.map(u => {
        const userTasks = tasks.filter(t => t.assignedTo.includes(u.id));
        const completed = userTasks.filter(t => t.status === 'Done').length;
        const total = userTasks.length;
        const attRecords = attendance.filter(a => a.userId === u.id).length;
        return { name: u.name, completed, total, attendance: attRecords };
    });
    
    const customerRevenue: Record<string, number> = {};
    projects.forEach(p => {
        const income = transactions.filter(t => t.projectId === p.id && t.type === 'Income').reduce((sum, t) => sum + t.amount, 0);
        customerRevenue[p.client] = (customerRevenue[p.client] || 0) + income;
    });
    const totalRevenue = Object.values(customerRevenue).reduce((sum, val) => sum + val, 0);
    const topClient = Object.entries(customerRevenue).sort((a,b) => b[1] - a[1])[0];
    const concentrationRisk = topClient && totalRevenue > 0 ? (topClient[1] / totalRevenue) * 100 : 0;

    const monthlyOpEx = subscriptions.reduce((sum, s) => sum + (s.billingCycle === 'Yıllık' ? s.amount / 12 : s.amount), 0);
    const estimatedPayroll = users.reduce((sum, u) => sum + (u.monthlySalary || 0), 0);
    const totalMonthlyCost = monthlyOpEx + estimatedPayroll;

    if (language === 'tr') {
        suggestions.push(`Aylık sabit maliyet (Maaş+Abonelik): ~${Math.round(totalMonthlyCost).toLocaleString()} TL.`);
        if (concentrationRisk > 50) {
            suggestions.push(`Risk: Gelirinizin %${Math.round(concentrationRisk)}'i tek bir müşteriye (${topClient[0]}) bağımlı.`);
        }
        if (totalRevenue > 0 && totalMonthlyCost > 0) {
            const roi = (totalRevenue / (totalMonthlyCost * 12)).toFixed(2);
            suggestions.push(`Tahmini Yıllık ROI: ${roi}.`);
        }
        const highPerformers = staffStats.filter(s => s.completed > 5);
        if (highPerformers.length > 0) {
            suggestions.push(`${highPerformers.length} personel yüksek verimlilikle çalışıyor.`);
        }
    } else {
        suggestions.push(`Monthly cost: ~${Math.round(totalMonthlyCost).toLocaleString()}.`);
        if (concentrationRisk > 50) suggestions.push(`High client concentration on ${topClient[0]}.`);
    }

    return {
        summary: language === 'tr' 
            ? "Stratejik sistem denetimi tamamlandı. Şirket sürdürülebilirlik analizi sonuçları aşağıdadır." 
            : "Strategic audit complete. Sustainability markers analyzed.",
        efficiencyScore: 75,
        financialHealth: concentrationRisk > 50 ? (language === 'tr' ? "Orta Risk" : "Moderate Risk") : (language === 'tr' ? "İyi" : "Good"),
        suggestions: suggestions.slice(0, 5)
    };
}
