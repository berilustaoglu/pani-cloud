import { Project, Task, TaskStatus, ProjectPriority, ProjectType } from '../types';
import { dayDiff, localISO } from './insights';

export type ProjectRisk = 'ok' | 'watch' | 'risk' | 'critical';

export interface ProjectMetrics {
  daysLeft: number | null;          // teslime kalan gün (negatif = gecikti)
  totalDays: number | null;         // başlangıç → teslim süresi
  plannedProgress: number | null;   // takvime göre olması gereken ilerleme
  scheduleGap: number | null;       // gerçek - planlanan (negatif = geride)
  tasksTotal: number;
  tasksDone: number;
  tasksOverdue: number;
  tasksBlocked: number;
  paidAmount: number;
  totalAmount: number;
  overduePayments: number;
  overdueAmount: number;
  nextPayment?: { label: string; dueDate: string; amount: number };
  risk: ProjectRisk;
  riskReasons: string[];
}

export const PRIORITY_ORDER: Record<ProjectPriority, number> = { Critical: 0, High: 1, Medium: 2, Low: 3 };

export const PRIORITY_META: Record<ProjectPriority, { tr: string; en: string; chip: string; dot: string }> = {
  Critical: { tr: 'Kritik', en: 'Critical', chip: 'bg-rose-50 text-rose-700 dark:bg-rose-500/10 dark:text-rose-300', dot: 'bg-rose-500' },
  High: { tr: 'Yüksek', en: 'High', chip: 'bg-orange-50 text-orange-700 dark:bg-orange-500/10 dark:text-orange-300', dot: 'bg-orange-500' },
  Medium: { tr: 'Orta', en: 'Medium', chip: 'bg-sky-50 text-sky-700 dark:bg-sky-500/10 dark:text-sky-300', dot: 'bg-sky-500' },
  Low: { tr: 'Düşük', en: 'Low', chip: 'bg-slate-100 text-slate-600 dark:bg-white/5 dark:text-slate-300', dot: 'bg-slate-400' },
};

export const TYPE_META: Record<string, { emoji: string; tr: string; en: string; grad: string }> = {
  [ProjectType.GAME]: { emoji: '🎮', tr: 'Oyun', en: 'Game', grad: 'from-violet-500 to-indigo-600' },
  [ProjectType.AI]: { emoji: '🧠', tr: 'Yapay Zeka', en: 'AI', grad: 'from-fuchsia-500 to-pink-600' },
  [ProjectType.MOBILE]: { emoji: '📱', tr: 'Mobil', en: 'Mobile', grad: 'from-sky-500 to-blue-600' },
  [ProjectType.SYSTEM]: { emoji: '🖥️', tr: 'Sistem', en: 'System', grad: 'from-slate-500 to-slate-700' },
  [ProjectType.VR_AR]: { emoji: '👓', tr: 'VR/AR', en: 'VR/AR', grad: 'from-teal-500 to-emerald-600' },
  [ProjectType.WEB]: { emoji: '🌐', tr: 'Web', en: 'Web', grad: 'from-cyan-500 to-sky-600' },
  [ProjectType.OTHER]: { emoji: '✨', tr: 'Diğer', en: 'Other', grad: 'from-amber-500 to-orange-600' },
};

export const RISK_META: Record<ProjectRisk, { tr: string; en: string; chip: string; bar: string }> = {
  ok: { tr: 'Yolunda', en: 'On track', chip: 'bg-emerald-50 text-emerald-700 dark:bg-emerald-500/10 dark:text-emerald-300', bar: 'bg-emerald-500' },
  watch: { tr: 'Takipte', en: 'Watch', chip: 'bg-amber-50 text-amber-700 dark:bg-amber-500/10 dark:text-amber-300', bar: 'bg-amber-400' },
  risk: { tr: 'Riskli', en: 'At risk', chip: 'bg-orange-50 text-orange-700 dark:bg-orange-500/10 dark:text-orange-300', bar: 'bg-orange-500' },
  critical: { tr: 'Kritik', en: 'Critical', chip: 'bg-rose-50 text-rose-700 dark:bg-rose-500/10 dark:text-rose-300', bar: 'bg-rose-500' },
};

const parse = (s: string) => { const [y, m, d] = s.slice(0, 10).split('-').map(Number); return new Date(y, m - 1, d); };

export const computeProjectMetrics = (p: Project, tasks: Task[], language: 'tr' | 'en'): ProjectMetrics => {
  const tr = language === 'tr';
  const today = localISO();
  const active = p.status === 'Active' || p.status === 'Revizyonda';
  const daysLeft = p.deliveryDate ? dayDiff(p.deliveryDate) : null;

  let totalDays: number | null = null;
  let plannedProgress: number | null = null;
  if (p.startDate && p.deliveryDate && p.deliveryDate >= p.startDate) {
    totalDays = Math.max(1, Math.round((parse(p.deliveryDate).getTime() - parse(p.startDate).getTime()) / 86400000));
    const elapsed = Math.round((parse(today).getTime() - parse(p.startDate).getTime()) / 86400000);
    plannedProgress = Math.max(0, Math.min(100, Math.round((elapsed / totalDays) * 100)));
  }
  const scheduleGap = plannedProgress !== null ? (p.progress || 0) - plannedProgress : null;

  const pt = tasks.filter(t => t.projectId === p.id);
  const open = pt.filter(t => t.status !== TaskStatus.DONE);
  const tasksOverdue = open.filter(t => (dayDiff(t.deadline) ?? 0) < 0).length;

  const inst = p.installments || [];
  const totalAmount = p.totalAmountWithTax || p.budget || 0;
  const paidAmount = inst.length
    ? inst.reduce((s, i) => s + (i.isPaid ? i.amount : (i.paidAmount || 0)), 0)
    : (p.status === 'Completed' ? totalAmount : 0);
  const overdueList = inst.filter(i => !i.isPaid && i.dueDate < today);
  const upcoming = inst.filter(i => !i.isPaid && i.dueDate >= today).sort((a, b) => a.dueDate.localeCompare(b.dueDate))[0];

  const reasons: string[] = [];
  let score = 0;
  if (active && daysLeft !== null && daysLeft < 0) { score += 3; reasons.push(tr ? `Teslim ${Math.abs(daysLeft)} gün gecikti` : `Delivery ${Math.abs(daysLeft)}d late`); }
  else if (active && daysLeft !== null && daysLeft <= 7 && (p.progress || 0) < 80) { score += 2; reasons.push(tr ? `Teslime ${daysLeft} gün, ilerleme %${p.progress}` : `${daysLeft}d left at ${p.progress}%`); }
  if (active && scheduleGap !== null && scheduleGap <= -25) { score += 2; reasons.push(tr ? `Plandan %${Math.abs(scheduleGap)} geride` : `${Math.abs(scheduleGap)}% behind plan`); }
  else if (active && scheduleGap !== null && scheduleGap <= -10) { score += 1; reasons.push(tr ? `Plandan %${Math.abs(scheduleGap)} geride` : `${Math.abs(scheduleGap)}% behind plan`); }
  if (overdueList.length) { score += 2; reasons.push(tr ? `${overdueList.length} ödeme gecikmiş` : `${overdueList.length} payment(s) overdue`); }
  if (active && tasksOverdue) { score += tasksOverdue > 2 ? 2 : 1; reasons.push(tr ? `${tasksOverdue} görev gecikmiş` : `${tasksOverdue} task(s) overdue`); }
  if (active && open.some(t => t.status === TaskStatus.BLOCKED)) { score += 1; reasons.push(tr ? 'Engellenen görev var' : 'Blocked task'); }

  const risk: ProjectRisk = !active ? 'ok' : score >= 5 ? 'critical' : score >= 3 ? 'risk' : score >= 1 ? 'watch' : 'ok';

  return {
    daysLeft, totalDays, plannedProgress, scheduleGap,
    tasksTotal: pt.length, tasksDone: pt.length - open.length, tasksOverdue, tasksBlocked: open.filter(t => t.status === TaskStatus.BLOCKED).length,
    paidAmount, totalAmount,
    overduePayments: overdueList.length,
    overdueAmount: overdueList.reduce((s, i) => s + i.amount - (i.paidAmount || 0), 0),
    nextPayment: upcoming ? { label: upcoming.label, dueDate: upcoming.dueDate, amount: upcoming.amount } : undefined,
    risk, riskReasons: reasons,
  };
};

export const daysLeftText = (d: number | null, language: 'tr' | 'en') => {
  if (d === null) return language === 'tr' ? 'Tarih yok' : 'No date';
  if (d === 0) return language === 'tr' ? 'Bugün teslim' : 'Due today';
  if (d < 0) return language === 'tr' ? `${Math.abs(d)} gün gecikti` : `${Math.abs(d)}d overdue`;
  return language === 'tr' ? `${d} gün kaldı` : `${d}d left`;
};
