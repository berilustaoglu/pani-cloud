// Yönetim Merkezi için tüm modüllerden aksiyon gerektiren durumları,
// KPI'ları, takvimi ve iş yükünü çıkaran saf (yan etkisiz) hesaplama katmanı.
import {
  Project, Task, TaskStatus, Invoice, Debt, Subscription, LicenseSale, ServiceSale, Deal, DealStatus,
  CRMActivity, LeaveRequest, AttendanceRecord, InventoryItem, PurchaseOrder, Ticket, ExtraJob, Meeting,
  User, Currency, Transaction, BillingCycle, AlertSettings, DEFAULT_ALERT_SETTINGS
} from '../types';

export type Severity = 'critical' | 'high' | 'medium' | 'low';
export type InsightCategory = 'projects' | 'tasks' | 'finance' | 'sales' | 'crm' | 'hr' | 'inventory' | 'support';

export interface Insight {
  id: string;
  severity: Severity;
  category: InsightCategory;
  title: string;
  detail: string;
  tab: string;
  date?: string;
  amountTRY?: number;
}

export interface TimelineEvent {
  id: string;
  date: string; // YYYY-MM-DD
  label: string;
  kind: 'delivery' | 'installment' | 'meeting' | 'billing' | 'leave' | 'task' | 'purchase' | 'deal';
  tab: string;
}

export interface WorkloadRow {
  user: User;
  open: number;
  overdue: number;
  blocked: number;
  doneTotal: number;
  avgProgress: number;
  onLeave: boolean;
  clockedIn: boolean;
}

export interface InsightInput {
  language: 'tr' | 'en';
  canSeeFinance: boolean;
  rates: { TRY: number; EUR: number };
  users: User[];
  projects: Project[];
  tasks: Task[];
  transactions: Transaction[];
  invoices: Invoice[];
  debts: Debt[];
  subscriptions: Subscription[];
  sales: LicenseSale[];
  serviceSales: ServiceSale[];
  deals: Deal[];
  crmActivities: CRMActivity[];
  leaveRequests: LeaveRequest[];
  attendance: AttendanceRecord[];
  inventoryItems: InventoryItem[];
  purchaseOrders: PurchaseOrder[];
  tickets: Ticket[];
  extraJobs: ExtraJob[];
  meetings: Meeting[];
  alerts?: AlertSettings;
}

export const SEVERITY_WEIGHT: Record<Severity, number> = { critical: 8, high: 4, medium: 1.5, low: 0.5 };
const SEVERITY_ORDER: Record<Severity, number> = { critical: 0, high: 1, medium: 2, low: 3 };

// --- Tarih yardımcıları (yerel saat dilimi) ---
export const localISO = (d = new Date()) =>
  `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;

const parseDay = (s?: string): Date | null => {
  if (!s) return null;
  const m = /^(\d{4})-(\d{2})-(\d{2})/.exec(s);
  if (m && s.length <= 10) return new Date(+m[1], +m[2] - 1, +m[3]);
  const d = new Date(s);
  if (isNaN(d.getTime())) return null;
  return new Date(d.getFullYear(), d.getMonth(), d.getDate());
};

/** Bugünden hedef tarihe gün farkı (negatif = geçmiş). */
export const dayDiff = (s?: string): number | null => {
  const d = parseDay(s);
  if (!d) return null;
  const today = parseDay(localISO())!;
  return Math.round((d.getTime() - today.getTime()) / 86400000);
};

/** Proje askıda ve askı süresi dolmamış mı? (Süresiz askı da sayılır.) Askıdaki projeler uyarı üretmez. */
export const isProjectSuspended = (p?: Pick<Project, 'status' | 'holdUntil'> | null): boolean =>
  !!p && p.status === 'On Hold' && (!p.holdUntil || p.holdUntil >= localISO());

/** Askı süresi dolmuş ama proje hâlâ askıda mı? */
export const isHoldExpired = (p?: Pick<Project, 'status' | 'holdUntil'> | null): boolean =>
  !!p && p.status === 'On Hold' && !!p.holdUntil && p.holdUntil < localISO();

/** Askıdaki projelerin id kümesi: görev uyarılarını süzmek için. */
export const suspendedProjectIds = (projects: Pick<Project, 'id' | 'status' | 'holdUntil'>[]): Set<string> =>
  new Set(projects.filter(isProjectSuspended).map(p => p.id));

/** Görev askıdaki bir projeye mi ait? (Gecikme uyarısı/sayacı üretmez.) */
export const isTaskSuspended = (t: Pick<Task, 'projectId'>, suspended: Set<string>) => !!t.projectId && suspended.has(t.projectId);

const isSnoozed = (snoozeUntil?: string) => {
  const diff = dayDiff(snoozeUntil);
  return diff !== null && diff >= 0;
};

export const toTRY = (amount: number, currency: Currency | undefined, rates: { TRY: number; EUR: number }) => {
  const a = Number(amount) || 0;
  if (!currency || currency === Currency.TRY) return a;
  if (currency === Currency.USD) return a * (rates.TRY || 1);
  if (currency === Currency.EUR) return (a / (rates.EUR || 1)) * (rates.TRY || 1);
  return a;
};

export const formatTRY = (n: number) =>
  '₺' + Math.round(n).toLocaleString('tr-TR');

// Ek iş kalan tahsilat (ödeme kayıtları varsa onlardan)
const remainingOf = (j: ExtraJob) => {
  const total = Number(j.totalAmountWithTax || j.price || 0);
  const paid = j.payments && j.payments.length ? j.payments.reduce((s, p) => s + (Number(p.amount) || 0), 0) : (j.paymentStatus === 'Ödendi' ? total : 0);
  return Math.max(0, total - paid);
};

const sym = (c?: Currency) => (c === Currency.TRY ? '₺' : c === Currency.EUR ? '€' : '$');
const money = (n: number, c?: Currency) => `${sym(c)}${(Number(n) || 0).toLocaleString('tr-TR', { maximumFractionDigits: 0 })}`;

export const buildInsights = (input: InsightInput): Insight[] => {
  const { language, canSeeFinance, rates } = input;
  const A = { ...DEFAULT_ALERT_SETTINGS, ...(input.alerts || {}) };
  const tr = language === 'tr';
  const out: Insight[] = [];
  const projectName = (id?: string) => input.projects.find(p => p.id === id)?.name || '—';
  const daysTxt = (n: number) => tr ? `${Math.abs(n)} gün` : `${Math.abs(n)} day${Math.abs(n) === 1 ? '' : 's'}`;
  const today = localISO();
  // Askıya alınan projeler ve görevleri askı süresince uyarı üretmez
  const suspended = suspendedProjectIds(input.projects);

  // ---------------- GÖREVLER ----------------
  input.tasks.forEach(t => {
    if (t.status === TaskStatus.DONE || isTaskSuspended(t, suspended)) return;
    const diff = dayDiff(t.deadline);
    if (t.status === TaskStatus.BLOCKED) {
      out.push({
        id: `task-blocked-${t.id}`, severity: 'high', category: 'tasks', tab: 'tasks',
        title: tr ? `Engellenen görev: ${t.title}` : `Blocked task: ${t.title}`,
        detail: `${projectName(t.projectId)} · ${t.blockedReason || (tr ? 'Neden belirtilmemiş' : 'No reason given')}`,
        date: t.deadline,
      });
    }
    if (diff !== null && diff < 0) {
      out.push({
        id: `task-overdue-${t.id}`, severity: diff < -7 ? 'critical' : 'high', category: 'tasks', tab: 'tasks',
        title: tr ? `Geciken görev: ${t.title}` : `Overdue task: ${t.title}`,
        detail: `${projectName(t.projectId)} · ${daysTxt(diff)} ${tr ? 'gecikti' : 'late'} · %${t.progress || 0}`,
        date: t.deadline,
      });
    } else if (diff !== null && diff <= 1) {
      out.push({
        id: `task-due-${t.id}`, severity: 'medium', category: 'tasks', tab: 'tasks',
        title: tr ? `${diff === 0 ? 'Bugün' : 'Yarın'} teslim: ${t.title}` : `Due ${diff === 0 ? 'today' : 'tomorrow'}: ${t.title}`,
        detail: `${projectName(t.projectId)} · %${t.progress || 0}`,
        date: t.deadline,
      });
    }
    if (!t.assignedTo || t.assignedTo.length === 0) {
      out.push({
        id: `task-unassigned-${t.id}`, severity: 'low', category: 'tasks', tab: 'tasks',
        title: tr ? `Atanmamış görev: ${t.title}` : `Unassigned task: ${t.title}`,
        detail: projectName(t.projectId),
      });
    }
  });

  // ---------------- PROJELER ----------------
  input.projects.forEach(p => {
    if (p.status === 'Completed' || suspended.has(p.id)) return;
    if (isHoldExpired(p)) {
      out.push({
        id: `proj-hold-end-${p.id}`, severity: 'medium', category: 'projects', tab: 'projects',
        title: tr ? `Askı süresi doldu: ${p.name}` : `Hold period ended: ${p.name}`,
        detail: tr ? `${p.client} · projeyi devam ettirin ya da askıyı uzatın` : `${p.client} · resume or extend the hold`,
        date: p.holdUntil,
      });
    }
    const diff = dayDiff(p.deliveryDate);
    if (diff !== null && diff < 0) {
      out.push({
        id: `proj-late-${p.id}`, severity: 'critical', category: 'projects', tab: 'projects',
        title: tr ? `Teslim tarihi geçti: ${p.name}` : `Delivery overdue: ${p.name}`,
        detail: `${p.client} · ${daysTxt(diff)} ${tr ? 'gecikme' : 'late'} · %${p.progress || 0}`,
        date: p.deliveryDate,
      });
    } else if (diff !== null && diff <= A.deliveryRiskDays && (p.progress || 0) < 80) {
      out.push({
        id: `proj-risk-${p.id}`, severity: 'high', category: 'projects', tab: 'projects',
        title: tr ? `Teslim riski: ${p.name}` : `Delivery risk: ${p.name}`,
        detail: tr ? `${daysTxt(diff)} kaldı, ilerleme %${p.progress || 0}` : `${daysTxt(diff)} left, progress ${p.progress || 0}%`,
        date: p.deliveryDate,
      });
    }
    if (canSeeFinance) {
      (p.installments || []).forEach(inst => {
        if (inst.isPaid) return;
        const d = dayDiff(inst.dueDate);
        const remaining = (inst.amount || 0) - (inst.paidAmount || 0);
        if (d === null || remaining <= 0) return;
        if (d < 0) {
          out.push({
            id: `inst-late-${p.id}-${inst.id}`, severity: 'critical', category: 'finance', tab: 'projects',
            title: tr ? `Tahsil edilmemiş taksit: ${p.name}` : `Overdue installment: ${p.name}`,
            detail: `${inst.label} · ${money(remaining, p.currency)} · ${daysTxt(d)} ${tr ? 'gecikti' : 'late'}`,
            date: inst.dueDate, amountTRY: toTRY(remaining, p.currency, rates),
          });
        } else if (d <= 7) {
          out.push({
            id: `inst-soon-${p.id}-${inst.id}`, severity: 'medium', category: 'finance', tab: 'projects',
            title: tr ? `Yaklaşan tahsilat: ${p.name}` : `Upcoming collection: ${p.name}`,
            detail: `${inst.label} · ${money(remaining, p.currency)} · ${daysTxt(d)} ${tr ? 'sonra' : 'left'}`,
            date: inst.dueDate, amountTRY: toTRY(remaining, p.currency, rates),
          });
        }
      });
    }
  });

  // ---------------- FİNANS ----------------
  if (canSeeFinance) {
    input.invoices.forEach(inv => {
      const d = dayDiff(inv.date);
      if (d === null) return;
      if (inv.status === 'Sent' && d < -A.invoiceUnpaidDays) {
        out.push({
          id: `inv-unpaid-${inv.id}`, severity: 'high', category: 'finance', tab: 'invoices',
          title: tr ? `Ödenmemiş fatura: ${inv.invoiceNumber}` : `Unpaid invoice: ${inv.invoiceNumber}`,
          detail: `${inv.customerName} · ${money(inv.totalAmount, inv.currency)} · ${daysTxt(d)}`,
          date: inv.date, amountTRY: toTRY(inv.totalAmount, inv.currency, rates),
        });
      } else if (inv.status === 'Draft' && d < -7) {
        out.push({
          id: `inv-draft-${inv.id}`, severity: 'low', category: 'finance', tab: 'invoices',
          title: tr ? `Taslakta bekleyen fatura: ${inv.invoiceNumber || inv.customerName}` : `Stale draft invoice: ${inv.invoiceNumber || inv.customerName}`,
          detail: `${inv.customerName} · ${money(inv.totalAmount, inv.currency)}`,
          date: inv.date,
        });
      }
    });

    input.debts.forEach(debt => {
      if (debt.isPaid) return;
      const d = dayDiff(debt.dueDate);
      if (d === null) return;
      const lent = debt.type === 'Lent';
      if (d < 0 || d <= 7) {
        out.push({
          id: `debt-${debt.id}`, severity: d < 0 ? 'high' : 'medium', category: 'finance', tab: 'accounting',
          title: lent
            ? (tr ? `Alacak vadesi ${d < 0 ? 'geçti' : 'yaklaşıyor'}: ${debt.personName}` : `Receivable ${d < 0 ? 'overdue' : 'due soon'}: ${debt.personName}`)
            : (tr ? `Borç vadesi ${d < 0 ? 'geçti' : 'yaklaşıyor'}: ${debt.personName}` : `Debt ${d < 0 ? 'overdue' : 'due soon'}: ${debt.personName}`),
          detail: `${money(debt.remainingAmount, debt.currency)} · ${daysTxt(d)} ${d < 0 ? (tr ? 'gecikti' : 'late') : (tr ? 'kaldı' : 'left')}`,
          date: debt.dueDate, amountTRY: toTRY(debt.remainingAmount, debt.currency, rates),
        });
      }
    });

    input.subscriptions.forEach(s => {
      if (s.status !== 'Active' || isSnoozed(s.snoozeUntil)) return;
      const d = dayDiff(s.nextBillingDate);
      if (d === null || d > A.subscriptionWarnDays) return;
      out.push({
        id: `sub-${s.id}`, severity: d < 0 ? 'high' : 'medium', category: 'finance', tab: 'accounting',
        title: tr ? `Abonelik ödemesi: ${s.name}` : `Subscription payment: ${s.name}`,
        detail: `${s.provider} · ${money(s.amount, s.currency)} · ${d < 0 ? `${daysTxt(d)} ${tr ? 'gecikti' : 'late'}` : d === 0 ? (tr ? 'bugün' : 'today') : `${daysTxt(d)} ${tr ? 'sonra' : 'left'}`}`,
        date: s.nextBillingDate, amountTRY: toTRY(s.amount, s.currency, rates),
      });
    });

    // ---------------- SATIŞ ----------------
    input.sales.forEach(s => {
      if (s.status !== 'Active' || isSnoozed(s.snoozeUntil)) return;
      const d = dayDiff(s.expiryDate);
      if (d === null || d > A.licenseWarnDays) return;
      out.push({
        id: `lic-${s.id}`, severity: d < 0 ? 'high' : d <= 7 ? 'medium' : 'low', category: 'sales', tab: 'sales',
        title: tr ? `Lisans ${d < 0 ? 'süresi doldu' : 'yenilemesi yaklaşıyor'}: ${s.customerName}` : `License ${d < 0 ? 'expired' : 'renewal due'}: ${s.customerName}`,
        detail: `${s.productName} · ${money(s.amount, s.currency)} · ${daysTxt(d)}`,
        date: s.expiryDate,
      });
    });
    input.serviceSales.forEach(s => {
      if (s.status !== 'Active' || isSnoozed(s.snoozeUntil)) return;
      const d = dayDiff(s.nextBillingDate);
      if (d === null || d > 7) return;
      out.push({
        id: `svc-${s.id}`, severity: d < 0 ? 'high' : 'medium', category: 'sales', tab: 'sales',
        title: tr ? `Hizmet faturalandırması: ${s.customerName}` : `Service billing: ${s.customerName}`,
        detail: `${s.serviceName} · ${money(s.amount, s.currency)} · ${daysTxt(d)} ${d < 0 ? (tr ? 'gecikti' : 'late') : (tr ? 'kaldı' : 'left')}`,
        date: s.nextBillingDate, amountTRY: toTRY(s.amount, s.currency, rates),
      });
    });

    input.extraJobs.forEach(j => {
      if (j.status === 'Tamamlandı' && j.paymentStatus !== 'Ödendi') {
        out.push({
          id: `xjob-pay-${j.id}`, severity: 'medium', category: 'finance', tab: 'extrajobs',
          title: tr ? `Tahsilat bekleyen ek iş: ${j.title}` : `Extra job awaiting payment: ${j.title}`,
          detail: `${j.clientName} · ${tr ? "kalan" : "left"} ${money(remainingOf(j), j.currency)} · ${j.paymentStatus}`,
          amountTRY: toTRY(remainingOf(j), j.currency, rates),
        });
      }
    });
  }

  input.extraJobs.forEach(j => {
    if (j.status === 'Tamamlandı' || j.status === 'İptal') return;
    const d = dayDiff(j.deadline);
    if (d !== null && d < 0) {
      out.push({
        id: `xjob-late-${j.id}`, severity: 'high', category: 'projects', tab: 'extrajobs',
        title: tr ? `Geciken ek iş: ${j.title}` : `Overdue extra job: ${j.title}`,
        detail: `${j.clientName} · ${daysTxt(d)} ${tr ? 'gecikti' : 'late'}`, date: j.deadline,
      });
    }
  });

  // ---------------- CRM ----------------
  input.deals.forEach(deal => {
    if (deal.status === DealStatus.WON || deal.status === DealStatus.LOST) return;
    const close = dayDiff(deal.expectedCloseDate);
    const idle = dayDiff(deal.updatedAt);
    if (close !== null && close < 0) {
      out.push({
        id: `deal-close-${deal.id}`, severity: 'high', category: 'crm', tab: 'crm',
        title: tr ? `Kapanış tarihi geçen fırsat: ${deal.companyName || deal.contactName}` : `Deal past close date: ${deal.companyName || deal.contactName}`,
        detail: `${deal.status} · ${canSeeFinance ? money(deal.value, deal.currency) + ' · ' : ''}${daysTxt(close)}`,
        date: deal.expectedCloseDate,
      });
    } else if (idle !== null && idle < -A.dealIdleDays) {
      out.push({
        id: `deal-idle-${deal.id}`, severity: 'medium', category: 'crm', tab: 'crm',
        title: tr ? `Hareketsiz fırsat: ${deal.companyName || deal.contactName}` : `Stalled deal: ${deal.companyName || deal.contactName}`,
        detail: tr ? `${daysTxt(idle)} güncellenmedi · ${deal.status}` : `No update for ${daysTxt(idle)} · ${deal.status}`,
      });
    }
  });
  input.crmActivities.forEach(a => {
    if (a.status !== 'Pending' || !a.reminderDate) return;
    if (new Date(a.reminderDate).getTime() <= Date.now()) {
      const deal = input.deals.find(d => d.id === a.dealId);
      out.push({
        id: `crm-rem-${a.id}`, severity: 'high', category: 'crm', tab: 'crm',
        title: tr ? `Takip hatırlatması: ${deal?.companyName || deal?.contactName || a.type}` : `Follow-up due: ${deal?.companyName || deal?.contactName || a.type}`,
        detail: `${a.type} · ${a.userName} · ${a.description.slice(0, 60)}`,
        date: a.reminderDate,
      });
    }
  });

  // ---------------- İK ----------------
  const pendingLeaves = input.leaveRequests.filter(l => l.status === 'Pending');
  pendingLeaves.forEach(l => {
    out.push({
      id: `leave-${l.id}`, severity: dayDiff(l.startDate) !== null && dayDiff(l.startDate)! <= 2 ? 'high' : 'medium', category: 'hr', tab: 'leave',
      title: tr ? `İzin onayı bekliyor: ${l.userName}` : `Leave awaiting approval: ${l.userName}`,
      detail: `${l.type} · ${l.startDate} → ${l.endDate}`, date: l.startDate,
    });
  });
  input.attendance.forEach(a => {
    if (a.clockOut || !a.date || a.date >= today) return;
    if ((dayDiff(a.date) ?? 0) < -14) return;
    out.push({
      id: `att-open-${a.id}`, severity: 'medium', category: 'hr', tab: 'attendance',
      title: tr ? `Kapatılmamış mesai: ${a.userName}` : `Unclosed shift: ${a.userName}`,
      detail: `${a.date} · ${tr ? 'giriş' : 'in'} ${a.clockIn}`, date: a.date,
    });
  });

  // ---------------- DEPO ----------------
  input.inventoryItems.forEach(item => {
    if (item.currentQuantity > item.minQuantity) return;
    out.push({
      id: `stock-${item.id}`, severity: item.currentQuantity <= 0 ? 'critical' : 'high', category: 'inventory', tab: 'inventory',
      title: item.currentQuantity <= 0
        ? (tr ? `Stok tükendi: ${item.name}` : `Out of stock: ${item.name}`)
        : (tr ? `Kritik stok: ${item.name}` : `Low stock: ${item.name}`),
      detail: `SKU ${item.sku} · ${item.currentQuantity}/${item.minQuantity}${item.location ? ' · ' + item.location : ''}`,
    });
  });
  input.purchaseOrders.forEach(po => {
    if (po.status !== 'Ordered') return;
    const d = dayDiff(po.expectedDelivery);
    if (d !== null && d < 0) {
      out.push({
        id: `po-${po.id}`, severity: 'high', category: 'inventory', tab: 'purchasing',
        title: tr ? `Geciken sipariş: ${po.orderNumber}` : `Late purchase order: ${po.orderNumber}`,
        detail: `${po.vendorName} · ${daysTxt(d)} ${tr ? 'gecikti' : 'late'}`, date: po.expectedDelivery,
      });
    }
  });

  // ---------------- DESTEK ----------------
  input.tickets.forEach(tk => {
    if (tk.status === 'Resolved' || tk.status === 'Closed') return;
    const age = dayDiff(tk.createdAt) ?? 0;
    const noReply = !(tk.responses || []).some(r => !r.isClient);
    let sev: Severity | null = null;
    if (tk.priority === 'Critical') sev = 'critical';
    else if (tk.priority === 'High') sev = 'high';
    else if (noReply && age <= -A.ticketNoReplyDays) sev = 'medium';
    else if (tk.status === 'Open') sev = 'low';
    if (!sev) return;
    out.push({
      id: `ticket-${tk.id}`, severity: sev, category: 'support', tab: 'tickets',
      title: tr ? `Açık talep: ${tk.title}` : `Open ticket: ${tk.title}`,
      detail: `${projectName(tk.projectId)} · ${tk.priority} · ${noReply ? (tr ? 'yanıtsız' : 'no reply') : tk.status}`,
      date: tk.createdAt,
    });
  });

  return out.sort((a, b) => SEVERITY_ORDER[a.severity] - SEVERITY_ORDER[b.severity] || (a.date || '').localeCompare(b.date || ''));
};

/** 0-100 arası genel sağlık skoru ve kategori skorları. */
export const computeHealth = (insights: Insight[]) => {
  const cats: InsightCategory[] = ['projects', 'tasks', 'finance', 'sales', 'crm', 'hr', 'inventory', 'support'];
  const byCat = Object.fromEntries(cats.map(c => {
    const penalty = insights.filter(i => i.category === c).reduce((s, i) => s + SEVERITY_WEIGHT[i.severity], 0);
    return [c, Math.max(0, Math.round(100 - penalty * 4))];
  })) as Record<InsightCategory, number>;
  const total = insights.reduce((s, i) => s + SEVERITY_WEIGHT[i.severity], 0);
  const overall = Math.max(0, Math.round(100 * Math.exp(-total / 80)));
  return { overall, byCat };
};

export const buildTimeline = (input: InsightInput, days = 14): TimelineEvent[] => {
  const tr = input.language === 'tr';
  const ev: TimelineEvent[] = [];
  const within = (s?: string) => { const d = dayDiff(s); return d !== null && d >= 0 && d <= days; };
  const day = (s: string) => localISO(parseDay(s)!);

  input.projects.forEach(p => {
    if (p.status !== 'Completed' && within(p.deliveryDate)) ev.push({ id: `tl-p-${p.id}`, date: day(p.deliveryDate!), label: `${tr ? 'Teslim' : 'Delivery'}: ${p.name}`, kind: 'delivery', tab: 'projects' });
    if (input.canSeeFinance) (p.installments || []).forEach(i => {
      if (!i.isPaid && within(i.dueDate)) ev.push({ id: `tl-i-${p.id}-${i.id}`, date: day(i.dueDate), label: `${i.label} · ${p.name}`, kind: 'installment', tab: 'projects' });
    });
  });
  input.meetings.forEach(m => {
    if (m.status !== 'cancelled' && m.status !== 'completed' && within(m.date)) ev.push({ id: `tl-m-${m.id}`, date: day(m.date), label: `${m.time} · ${m.title}`, kind: 'meeting', tab: 'meetings' });
  });
  if (input.canSeeFinance) {
    input.subscriptions.forEach(s => { if (s.status === 'Active' && within(s.nextBillingDate)) ev.push({ id: `tl-s-${s.id}`, date: day(s.nextBillingDate), label: s.name, kind: 'billing', tab: 'accounting' }); });
    input.serviceSales.forEach(s => { if (s.status === 'Active' && within(s.nextBillingDate)) ev.push({ id: `tl-ss-${s.id}`, date: day(s.nextBillingDate), label: `${s.customerName} · ${s.serviceName}`, kind: 'billing', tab: 'sales' }); });
  }
  input.leaveRequests.forEach(l => { if (l.status === 'Approved' && within(l.startDate)) ev.push({ id: `tl-l-${l.id}`, date: day(l.startDate), label: `${l.userName} · ${l.type}`, kind: 'leave', tab: 'leave' }); });
  input.purchaseOrders.forEach(po => { if (po.status === 'Ordered' && within(po.expectedDelivery)) ev.push({ id: `tl-po-${po.id}`, date: day(po.expectedDelivery!), label: `${po.orderNumber} · ${po.vendorName}`, kind: 'purchase', tab: 'purchasing' }); });
  input.deals.forEach(d => { if (d.status !== DealStatus.WON && d.status !== DealStatus.LOST && within(d.expectedCloseDate)) ev.push({ id: `tl-d-${d.id}`, date: day(d.expectedCloseDate!), label: d.companyName || d.contactName, kind: 'deal', tab: 'crm' }); });
  input.tasks.forEach(t => { if (t.status !== TaskStatus.DONE && within(t.deadline)) ev.push({ id: `tl-t-${t.id}`, date: day(t.deadline), label: t.title, kind: 'task', tab: 'tasks' }); });

  return ev.sort((a, b) => a.date.localeCompare(b.date));
};

export const buildWorkload = (input: InsightInput): WorkloadRow[] => {
  const today = localISO();
  const suspended = suspendedProjectIds(input.projects);
  return input.users
    .filter(u => u.role !== 'Admin')
    .map(user => {
      const mine = input.tasks.filter(t => (t.assignedTo || []).includes(user.id));
      const open = mine.filter(t => t.status !== TaskStatus.DONE);
      const overdue = open.filter(t => (dayDiff(t.deadline) ?? 0) < 0 && !isTaskSuspended(t, suspended));
      const onLeave = input.leaveRequests.some(l => l.userId === user.id && l.status === 'Approved' && l.startDate <= today && l.endDate >= today);
      const clockedIn = input.attendance.some(a => a.userId === user.id && a.date === today && !a.clockOut);
      return {
        user,
        open: open.length,
        overdue: overdue.length,
        blocked: open.filter(t => t.status === TaskStatus.BLOCKED).length,
        doneTotal: mine.length - open.length,
        avgProgress: open.length ? Math.round(open.reduce((s, t) => s + (t.progress || 0), 0) / open.length) : 100,
        onLeave,
        clockedIn,
      };
    })
    .sort((a, b) => b.overdue - a.overdue || b.open - a.open);
};

/** Üst seviye KPI'lar. */
export const buildKpis = (input: InsightInput, insights: Insight[]) => {
  const { rates } = input;
  const today = localISO();
  const openTasks = input.tasks.filter(t => t.status !== TaskStatus.DONE);
  const suspended = suspendedProjectIds(input.projects);
  const activeProjects = input.projects.filter(p => p.status === 'Active');
  const receivables = input.projects.reduce((sum, p) => sum + (p.installments || [])
    .filter(i => !i.isPaid).reduce((s, i) => s + toTRY((i.amount || 0) - (i.paidAmount || 0), p.currency, rates), 0), 0);
  const overdueReceivables = insights.filter(i => i.id.startsWith('inst-late-')).reduce((s, i) => s + (i.amountTRY || 0), 0);
  const openDeals = input.deals.filter(d => d.status !== DealStatus.WON && d.status !== DealStatus.LOST);
  const stageProb: Record<string, number> = { Lead: .1, Proposal: .35, Negotiation: .65 };
  const pipeline = openDeals.reduce((s, d) => s + toTRY(d.value, d.currency, rates), 0);
  const weightedPipeline = openDeals.reduce((s, d) => s + toTRY(d.value, d.currency, rates) * (stageProb[d.status] ?? .2), 0);
  const won = input.deals.filter(d => d.status === DealStatus.WON).length;
  const lost = input.deals.filter(d => d.status === DealStatus.LOST).length;
  const monthKey = today.slice(0, 7);
  const monthIncome = input.transactions.filter(t => t.type === 'Income' && t.date?.startsWith(monthKey)).reduce((s, t) => s + toTRY(t.amount, t.currency, rates), 0);
  const monthExpense = input.transactions.filter(t => t.type === 'Expense' && t.date?.startsWith(monthKey)).reduce((s, t) => s + toTRY(t.amount, t.currency, rates), 0);
  const staff = input.users.filter(u => u.role !== 'Admin');
  const presentToday = new Set(input.attendance.filter(a => a.date === today).map(a => a.userId));
  const onLeaveToday = input.leaveRequests.filter(l => l.status === 'Approved' && l.startDate <= today && l.endDate >= today).length;
  const stockValue = input.inventoryItems.reduce((s, i) => s + toTRY(i.unitPrice * i.currentQuantity, i.currency, rates), 0);
  const openTickets = input.tickets.filter(t => t.status !== 'Resolved' && t.status !== 'Closed');
  const monthlySubCost = input.subscriptions.filter(s => s.status === 'Active')
    .reduce((s, sub) => s + toTRY(sub.billingCycle === BillingCycle.YEARLY ? sub.amount / 12 : sub.amount, sub.currency, rates), 0);

  return {
    activeProjects: activeProjects.length,
    avgProjectProgress: activeProjects.length ? Math.round(activeProjects.reduce((s, p) => s + (p.progress || 0), 0) / activeProjects.length) : 0,
    openTasks: openTasks.length,
    overdueTasks: openTasks.filter(t => (dayDiff(t.deadline) ?? 0) < 0 && !isTaskSuspended(t, suspended)).length,
    blockedTasks: openTasks.filter(t => t.status === TaskStatus.BLOCKED).length,
    completionRate: input.tasks.length ? Math.round(((input.tasks.length - openTasks.length) / input.tasks.length) * 100) : 0,
    receivables, overdueReceivables,
    monthIncome, monthExpense, monthNet: monthIncome - monthExpense,
    monthlySubCost,
    pipeline, weightedPipeline, openDeals: openDeals.length,
    winRate: won + lost ? Math.round((won / (won + lost)) * 100) : 0,
    staffCount: staff.length,
    presentToday: staff.filter(s => presentToday.has(s.id)).length,
    onLeaveToday,
    pendingLeaves: input.leaveRequests.filter(l => l.status === 'Pending').length,
    stockValue,
    lowStock: input.inventoryItems.filter(i => i.currentQuantity <= i.minQuantity).length,
    openPOs: input.purchaseOrders.filter(p => p.status === 'Ordered').length,
    openTickets: openTickets.length,
    criticalTickets: openTickets.filter(t => t.priority === 'Critical' || t.priority === 'High').length,
  };
};
