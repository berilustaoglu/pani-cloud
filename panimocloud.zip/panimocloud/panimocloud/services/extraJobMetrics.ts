import { ExtraJob, ExtraJobPaymentStatus, ExtraJobStatus } from '../types';
import { dayDiff } from './insights';

export const EXTRA_JOB_CATEGORIES = ['Tasarım', 'Yazılım', 'Danışmanlık', 'Bakım / Destek', 'İçerik', 'Eğitim', 'Diğer'];

export const STATUS_META: Record<ExtraJobStatus, { tr: string; en: string; chip: string; dot: string; col: string }> = {
  'Bekliyor': { tr: 'Bekliyor', en: 'Waiting', chip: 'bg-amber-50 text-amber-700 dark:bg-amber-500/10 dark:text-amber-300', dot: 'bg-amber-400', col: 'from-amber-400 to-orange-400' },
  'Yapılıyor': { tr: 'Yapılıyor', en: 'In progress', chip: 'bg-sky-50 text-sky-700 dark:bg-sky-500/10 dark:text-sky-300', dot: 'bg-sky-500', col: 'from-sky-400 to-indigo-500' },
  'Tamamlandı': { tr: 'Tamamlandı', en: 'Done', chip: 'bg-emerald-50 text-emerald-700 dark:bg-emerald-500/10 dark:text-emerald-300', dot: 'bg-emerald-500', col: 'from-emerald-400 to-teal-500' },
  'İptal': { tr: 'İptal', en: 'Cancelled', chip: 'bg-slate-100 text-slate-500 dark:bg-white/5 dark:text-slate-400', dot: 'bg-slate-400', col: 'from-slate-300 to-slate-400' },
};

export const PAYMENT_META: Record<ExtraJobPaymentStatus, { tr: string; en: string; chip: string }> = {
  'Ödenmedi': { tr: 'Ödenmedi', en: 'Unpaid', chip: 'bg-rose-50 text-rose-700 dark:bg-rose-500/10 dark:text-rose-300' },
  'Kısmi Ödeme': { tr: 'Kısmi ödeme', en: 'Partial', chip: 'bg-orange-50 text-orange-700 dark:bg-orange-500/10 dark:text-orange-300' },
  'Ödendi': { tr: 'Ödendi', en: 'Paid', chip: 'bg-emerald-50 text-emerald-700 dark:bg-emerald-500/10 dark:text-emerald-300' },
};

export const jobTotal = (j: Partial<ExtraJob>) => Number(j.totalAmountWithTax || j.price || 0);

/** Tahsil edilen tutar: ödeme kayıtları varsa onların toplamı; eski kayıtlarda "Ödendi" ise tamamı. */
export const jobPaid = (j: Partial<ExtraJob>) => {
  if (j.payments && j.payments.length) return j.payments.reduce((s, p) => s + (Number(p.amount) || 0), 0);
  return j.paymentStatus === 'Ödendi' ? jobTotal(j) : 0;
};

export const derivePaymentStatus = (j: Partial<ExtraJob>): ExtraJobPaymentStatus => {
  if (!j.payments || !j.payments.length) return j.paymentStatus || 'Ödenmedi';
  const paid = jobPaid(j), total = jobTotal(j);
  if (total > 0 && paid >= total - 0.01) return 'Ödendi';
  return paid > 0 ? 'Kısmi Ödeme' : 'Ödenmedi';
};

export const jobDaysLeft = (j: Partial<ExtraJob>) => (j.deadline ? dayDiff(j.deadline) : null);
export const isJobOpen = (j: Partial<ExtraJob>) => j.status === 'Bekliyor' || j.status === 'Yapılıyor';
export const isJobOverdue = (j: Partial<ExtraJob>) => { const d = jobDaysLeft(j); return isJobOpen(j) && d !== null && d < 0; };
