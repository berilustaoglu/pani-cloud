import { addDoc, collection } from 'firebase/firestore';
import { db } from '../firebase';
import { AuditLog, AuditAction, AuditEntity, User } from '../types';

export const logAudit = async (
  currentUser: User,
  action: AuditAction,
  entityType: AuditEntity,
  details: string,
  entityId?: string
) => {
  try {
    const logData: Omit<AuditLog, 'id'> = {
      userId: currentUser.id,
      userName: currentUser.name,
      action,
      entityType,
      entityId,
      details,
      timestamp: new Date().toISOString(),
    };
    
    await addDoc(collection(db, 'audit_logs'), logData);
  } catch (error) {
    console.error('Failed to log audit event:', error);
  }
};
