export type ToastType = 'success' | 'error' | 'warning' | 'info';

export interface ToastItem {
  id: string;
  message: string;
  type: ToastType;
  duration: number;
}

type Listener = (toasts: ToastItem[]) => void;

let toasts: ToastItem[] = [];
const listeners = new Set<Listener>();

const emit = () => listeners.forEach(l => l(toasts));

// Mesaj içeriğinden tür tahmini (eski alert() çağrıları için)
const inferType = (message: string): ToastType => {
  const m = message.toLocaleLowerCase('tr-TR');
  if (/(hata|başarısız|error|failed|reddedildi|bulunamadı|not found)/.test(m)) return 'error';
  if (/(lütfen|please|eksik|missing|zaten|already|only|sadece)/.test(m)) return 'warning';
  if (/(başarı|kaydedildi|kopyalandı|gönderildi|iletildi|atandı|tamamlandı|harika|success|saved|copied|sent|assigned|completed|awesome)/.test(m)) return 'success';
  return 'info';
};

export const toast = (message: unknown, type?: ToastType, duration = 4200) => {
  const text = String(message ?? '');
  const item: ToastItem = {
    id: `${Date.now()}_${Math.random().toString(36).slice(2, 7)}`,
    message: text,
    type: type || inferType(text),
    duration,
  };
  toasts = [...toasts.slice(-4), item];
  emit();
  return item.id;
};

toast.success = (m: string, d?: number) => toast(m, 'success', d);
toast.error = (m: string, d?: number) => toast(m, 'error', d);
toast.warning = (m: string, d?: number) => toast(m, 'warning', d);
toast.info = (m: string, d?: number) => toast(m, 'info', d);

export const dismissToast = (id: string) => {
  toasts = toasts.filter(t => t.id !== id);
  emit();
};

export const subscribeToasts = (listener: Listener) => {
  listeners.add(listener);
  listener(toasts);
  return () => { listeners.delete(listener); };
};
