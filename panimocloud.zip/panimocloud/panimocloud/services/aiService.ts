
import { AIAnalysis, FinancialForecast, StaffAIAnalysis, Currency, Project, Task, Transaction, TaskStatus, UserActivity, Subscription, LicenseSale, ServiceSale, AttendanceRecord, Customer, User, Deal, InventoryItem } from '../types';
import * as LocalAnalysis from './analysisService';

// Yapay zekâ çağrıları sunucu fonksiyonundan (aiGenerate) geçer; API anahtarı tarayıcıya hiç gelmez.
const callAI = async (prompt: string, tier: 'fast' | 'pro' = 'fast', file?: { data: string; mimeType: string }): Promise<string> => {
    const [{ getFunctions, httpsCallable }, { app }] = await Promise.all([import('firebase/functions'), import('../firebase')]);
    const fn = httpsCallable<{ prompt: string; tier: string; file?: { data: string; mimeType: string } }, { text: string }>(getFunctions(app), 'aiGenerate');
    const res = await fn({ prompt, tier, ...(file ? { file } : {}) });
    return res.data.text;
};

// Geliştirici kendi bilgisayarında yerel bir AI sunucusu çalıştırıyorsa: VITE_LOCAL_AI_URL=http://localhost:8000
const LOCAL_AI_URL: string = ((import.meta as any).env?.VITE_LOCAL_AI_URL) || "";
const USE_LOCAL_AI = !!LOCAL_AI_URL;

async function callGemini(prompt: string, fileData?: { data: string, mimeType: string }): Promise<any> {
    const textOriginal = await callAI(prompt, 'fast', fileData);
    const text = textOriginal.replace(/```json|```/g, "").trim();
    try {
        return JSON.parse(text);
    } catch (e) {
        console.error("JSON Parse Error. Raw response:", textOriginal);
        throw new Error("AI returned invalid JSON format.");
    }
}


export async function analyzeOperations(
    tasks: Task[],
    transactions: Transaction[],
    projects: Project[],
    users: User[],
    language: 'tr' | 'en' = 'tr'
): Promise<AIAnalysis> {
    const userMap = users.reduce((acc, u) => ({ ...acc, [u.id]: u.name }), {} as Record<string, string>);
    const mappedTasks = tasks.slice(0, 15).map(t => ({
        title: t.title,
        status: t.status,
        assignees: (t.assignedTo || []).map(id => userMap[id] || 'Bilinmeyen Personel'),
        projectName: projects.find(p => p.id === t.projectId)?.name || 'Genel'
    }));

    const local = LocalAnalysis.analyzeOperationsLocal(tasks, transactions, projects, language);
    try {
        const prompt = `Görevin: Verilen verileri analiz et. Önemli: Asla sistem ID'lerini kullanma, sadece kullanıcı isimlerini kullan. 
        Analiz Edilecek Görevler: ${JSON.stringify(mappedTasks)}, 
        İşlemler (Son 10): ${JSON.stringify(transactions.slice(0, 10))}. 
        Şu formatta JSON döndür: {summary, efficiencyScore, financialHealth, suggestions}. 
        Dil: ${language === 'tr' ? 'Türkçe' : 'English'}`;
        
        if (USE_LOCAL_AI) {
            try {
                const res = await fetch(`${LOCAL_AI_URL}/api/analyze`, {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ prompt, language })
                });
                if (res.ok) {
                    const data = await res.json();
                    return JSON.parse(data.response.replace(/```json|```/g, "").strip() || "{}");
                }
            } catch (e) {
                console.error("Local AI Error, falling back to Gemini", e);
            }
        }
        return await callGemini(prompt);
    } catch (error) {
        return local;
    }
}

export async function analyzeStaffPerformance(
    staffName: string,
    activityLogs: any[],
    appUsageLogs: any[],
    language: 'tr' | 'en' = 'tr'
): Promise<StaffAIAnalysis> {
    const local = LocalAnalysis.analyzeStaffPerformanceLocal(staffName, activityLogs, appUsageLogs, language);
    try {
        const prompt = `Analyze Staff ${staffName}: Activity: ${JSON.stringify(activityLogs.slice(0, 5))}. Return JSON. Language: ${language}`;
        const result = await callGemini(prompt);
        return { ...result, date: new Date().toISOString() };
    } catch (error) {
        return local;
    }
}

export async function predictFinancials(
    transactions: Transaction[],
    projects: Project[],
    deals: Deal[],
    subscriptions: Subscription[],
    licenseSales: LicenseSale[],
    serviceSales: ServiceSale[],
    language: 'tr' | 'en' = 'tr'
): Promise<FinancialForecast> {
    const local = LocalAnalysis.predictFinancialsLocal(transactions, projects, deals, subscriptions, licenseSales, serviceSales, language);
    try {
        const cleanedTrans = transactions.slice(0, 20).map(t => ({ type: t.type, amount: t.amount, category: t.category, date: t.date }));
        const prompt = `Predict Financials: Transactions: ${JSON.stringify(cleanedTrans)}. Return JSON {forecast: {nextMonth, threeMonth}, risks, opportunities, strategicAdvice}. Language: ${language}`;
        return await callGemini(prompt);
    } catch (error) {
        return local;
    }
}

export async function performSystemAudit(
    users: User[],
    projects: Project[],
    tasks: Task[],
    transactions: Transaction[],
    subscriptions: Subscription[],
    serviceSales: ServiceSale[],
    attendance: AttendanceRecord[],
    customers: Customer[],
    language: 'tr' | 'en' = 'tr'
): Promise<AIAnalysis> {
    const userMap = users.reduce((acc, u) => ({ ...acc, [u.id]: u.name }), {} as Record<string, string>);
    const local = LocalAnalysis.performSystemAuditLocal(users, projects, tasks, transactions, subscriptions, serviceSales, attendance, customers, language);
    try {
        const prompt = `Sistem Denetimi: 
        Personel Sayısı: ${users.length} (İsimler: ${users.map(u => u.name).join(', ')}), 
        Proje Sayısı: ${projects.length},
        Abonelikler: ${subscriptions.length}. 
        Lütfen tüm verileri analiz et ve sistemdeki aksaklıkları/başarıları raporla. Asla teknik ID kullanma, sadece isim kullan.
        JSON formatı: {summary, efficiencyScore, financialHealth, suggestions}. Dil: ${language}`;
        
        return await callGemini(prompt);
    } catch (error) {
        return local;
    }
}
export async function analyzeFinancialDocument(
    content: string,
    language: 'tr' | 'en' = 'tr',
    fileData?: { data: string, mimeType: string }
): Promise<{
    amount: number,
    currency: Currency,
    category: string,
    description: string,
    date: string,
    type: 'Income' | 'Expense'
}> {
    try {
        const prompt = `Carefully analyze the provided financial document (image/PDF). Extract the absolute following data:
        1. amount: The total numerical value (e.g., 1500.50).
        2. currency: One of "USD", "TRY", or "EUR".
        3. category: A short category name in ${language}.
        4. description: A clear description of the purchase/income in ${language}.
        5. date: Date in YYYY-MM-DD format (if missing, use today: ${new Date().toISOString().split('T')[0]}).
        6. type: "Income" or "Expense".
        
        Return ONLY a JSON object: { "amount": number, "currency": string, "category": string, "description": string, "date": string, "type": string }.
        Additional context if provided: "${content}"`;
        
        return await callGemini(prompt, fileData);
    } catch (error) {
        console.error("AI Document Analysis Error:", error);
        throw error;
    }
}

// --- NEW AI FEATURES ---

export async function askCopilot(
    prompt: string,
    contextData: any,
    language: 'tr' | 'en' = 'tr'
): Promise<string> {
    try {
        const fullPrompt = `Sen PanimoCloud ERP sisteminin akıllı yapay zeka asistanı "Panimo Copilot"sun. 
Kullanıcı sana sistem verileriyle ilgili veya genel asistanlık soruları soracak.
Verilen şu JSON bağlam verisini kullanarak kullanıcının sorusunu yanıtla: 
${JSON.stringify(contextData)}
Kullanıcının sorusu: "${prompt}"
Lütfen anlaşılır, profesyonel, markdown destekli ve yardımcı bir dilde (${language === 'tr' ? 'Türkçe' : 'İngilizce'}) cevap ver. Düz metin (string) döndür, JSON DEĞİL.`;
        
        if (USE_LOCAL_AI) {
            try {
                const res = await fetch(`${LOCAL_AI_URL}/api/chat`, {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ prompt, contextData, language })
                });
                if (res.ok) {
                    const data = await res.json();
                    return data.response;
                }
            } catch (e) {
                console.error("Local AI Error in Copilot, falling back to Gemini", e);
            }
        }

        return await callAI(fullPrompt, 'pro');
    } catch (error) {
        console.error("Copilot Error:", error);
        return language === 'tr' ? "Üzgünüm, şu anda yanıt veremiyorum." : "Sorry, I cannot respond right now.";
    }
}

export async function predictDealSuccess(
    deal: Deal,
    language: 'tr' | 'en' = 'tr'
): Promise<{ score: number, reason: string }> {
    try {
        const prompt = `Lütfen aşağıdaki satış/fırsat (deal) verisine bakarak anlaşmanın olumlu (won) sonuçlanma ihtimalini değerlendir.
Fırsat Değeri: ${deal.value} ${deal.currency}
Aşama/Durum: ${deal.status}
Kişi: ${deal.contactName}
Şirket: ${deal.companyName || '-'}
Notlar: ${deal.notes || '-'}

SADECE ŞU YAPIDA JSON DÖNDÜR: { "score": 85, "reason": "Açıklama metni" }
"score" 0 ile 100 arasında bir sayı olmalı. "reason" kısmı ${language === 'tr' ? 'Türkçe' : 'İngilizce'} ve kısa bir açıklama içermeli.`;
        return await callGemini(prompt);
    } catch (error) {
        return { score: 50, reason: "Analiz edilemedi." };
    }
}

export async function generateSubTasks(
    projectDescription: string,
    staffList: User[],
    language: 'tr' | 'en' = 'tr'
): Promise<{ title: string, description: string, assignedTo: string[], estimatedHours: number, priority: string }[]> {
    try {
        const staffNames = staffList.map(s => `${s.name} (Role: ${s.role})`).join(", ");
        const prompt = `Görev: Aşağıdaki proje tanımını analiz et ve bu projeyi en fazla 5 anlamlı alt göreve (subtask) böl.
Proje Tanımı: "${projectDescription}"
Mevcut Personeller: ${staffNames}

SADECE ŞU FORMATTA BİR JSON DİZİSİ (Array) DÖNDÜR:
[
  {
    "title": "Görev Başlığı",
    "description": "Görev açıklaması",
    "assignedTo": ["personelin tam adı veya ID kullanma sadece İsim"],
    "estimatedHours": 10,
    "priority": "High" veya "Medium" veya "Low"
  }
]
Dil: ${language === 'tr' ? 'Türkçe' : 'İngilizce'}`;
        const result = await callGemini(prompt);
        // Ensure result is an array
        return Array.isArray(result) ? result : [];
    } catch (error) {
        console.error("Task Gen Error:", error);
        return [];
    }
}

export async function analyzeInventoryRisks(
    inventoryItems: InventoryItem[],
    language: 'tr' | 'en' = 'tr'
): Promise<{ riskyItems: { itemId: string, itemName: string, riskLevel: string, suggestion: string }[], overallAdvice: string }> {
    try {
        const filtered = inventoryItems.map(i => ({ id: i.id, name: i.name, currentQuantity: i.currentQuantity, minQuantity: i.minQuantity }));
        const prompt = `Aşağıdaki stok (inventory) verilerini analiz et ve tükenmek üzere olan veya riskli seviyeye inen ürünleri tespit et.
Stok Verileri: ${JSON.stringify(filtered)}

SADECE ŞU YAPIDA JSON DÖNDÜR:
{
  "riskyItems": [
    { "itemId": "123", "itemName": "Ürün Adı", "riskLevel": "High", "suggestion": "Öneri" }
  ],
  "overallAdvice": "Genel tavsiye metni"
}
RiskLevel "High", "Medium", "Low" olabilir. Dil: ${language === 'tr' ? 'Türkçe' : 'İngilizce'}`;
        
        return await callGemini(prompt);
    } catch (error) {
        return { riskyItems: [], overallAdvice: "Stok analizinde hata oluştu." };
    }
}

export async function draftMessageReply(
    incomingMessage: string,
    language: 'tr' | 'en' = 'tr',
    tone: 'Professional' | 'Friendly' | 'Negative' = 'Friendly'
): Promise<string> {
    try {
        const prompt = `Şu gelen mesaja uygun bir yanıt taslağı oluştur.
Gelen Mesaj: "${incomingMessage}"
İstenen Ton/Tutum: ${tone} (Professional: Kurumsal/Resmi, Friendly: Samimi/Olumlu, Negative: Kibarca Reddetme/Olumsuz)

SADECE YANIT METNİNİ VER, ekstra açıklama yapma. Dil: ${language === 'tr' ? 'Türkçe' : 'İngilizce'}`;
        
        return (await callAI(prompt, 'fast')).trim();
    } catch (error) {
        return language === 'tr' ? "Yapay zeka yanıt oluşturamadı." : "AI could not draft a response.";
    }
}

export async function analyzeProjectRisk(
    project: Project,
    tasks: Task[],
    language: 'tr' | 'en' = 'tr'
): Promise<{ riskScore: number, riskFactors: string[], mitigationSuggestions: string[] }> {
    try {
        const projectTasks = tasks.filter(t => t.projectId === project.id);
        const overdueTasks = projectTasks.filter(t => t.deadline < new Date().toISOString() && t.status !== TaskStatus.DONE);
        
        const context = {
            projectName: project.name,
            budget: project.budget,
            progress: project.progress,
            totalTasks: projectTasks.length,
            overdueTasks: overdueTasks.length,
            deliveryDate: project.deliveryDate
        };

        const prompt = `Proje risk analizi yap. Veriler: ${JSON.stringify(context)}. 
        Risk skoru (0-100), risk faktörleri ve çözüm önerileri döndür.
        JSON formatı: { "riskScore": number, "riskFactors": string[], "mitigationSuggestions": string[] }.
        Dil: ${language === 'tr' ? 'Türkçe' : 'İngilizce'}`;
        
        return await callGemini(prompt);
    } catch (error) {
        return { riskScore: 50, riskFactors: ["Analiz yapılamadı"], mitigationSuggestions: ["Sistem yöneticisine başvurun"] };
    }
}

export async function generateClientInsight(
    customer: Customer,
    projects: Project[],
    language: 'tr' | 'en' = 'tr'
): Promise<{ nextPossibleNeed: string, satisfactionScore: number, retentionStrategy: string }> {
    try {
        const clientProjects = projects.filter(p => p.client === customer.name);
        const context = {
            customerName: customer.name,
            company: customer.company,
            projectHistory: clientProjects.map(p => ({ type: p.projectType, status: p.status, budget: p.budget }))
        };

        const prompt = `Müşteri içgörü analizi yap. Veriler: ${JSON.stringify(context)}. 
        Bir sonraki olası ihtiyacı, memnuniyet skorunu ve elde tutma stratejisini döndür.
        JSON formatı: { "nextPossibleNeed": string, "satisfactionScore": number, "retentionStrategy": string }.
        Dil: ${language === 'tr' ? 'Türkçe' : 'İngilizce'}`;
        
        return await callGemini(prompt);
    } catch (error) {
        return { nextPossibleNeed: "Bilinmiyor", satisfactionScore: 70, retentionStrategy: "Düzenli iletişim kurun" };
    }
}
