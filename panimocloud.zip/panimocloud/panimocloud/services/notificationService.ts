import { addDoc, collection, doc, updateDoc, arrayUnion, writeBatch } from 'firebase/firestore';
import { db, auth } from '../firebase';
import { SystemNotification } from '../types';

/**
 * Sistem bildirimi oluşturur. Uygulama içi panelde görünür; Cloud Function (onSystemNotificationCreated)
 * aynı kaydı hedef kişilerin cihazlarına push olarak da gönderir.
 * userId verilirse yalnızca o kişiye, verilmezse yönetici/müdürlere gider.
 */
export const pushNotification = async (
  title: string,
  description: string,
  type: 'warning' | 'info' | 'success' | 'error' = 'info',
  tab?: string,
  userId?: string
) => {
  try {
    const notif: Omit<SystemNotification, 'id'> = {
      title,
      description,
      type,
      createdAt: new Date().toISOString(),
      readBy: [],
      ...(tab ? { tab } : {}),
      ...(userId ? { userId } : {}),
      ...(auth.currentUser?.uid ? { createdBy: auth.currentUser.uid } : {}),
    };
    await addDoc(collection(db, 'system_notifications'), notif);
  } catch (error) {
    // Giriş yapmamış kullanıcı (ör. müşteri portalı) doğrudan yazamaz; portal kendi sunucu fonksiyonunu kullanır
    console.error('Failed to push notification:', error);
  }
};

/** Bildirimleri okundu olarak işaretler */
export const markNotificationsRead = async (ids: string[], userId: string) => {
  if (!ids.length) return;
  try {
    if (ids.length === 1) { await updateDoc(doc(db, 'system_notifications', ids[0]), { readBy: arrayUnion(userId) }); return; }
    for (let i = 0; i < ids.length; i += 400) {
      const batch = writeBatch(db);
      ids.slice(i, i + 400).forEach(id => batch.update(doc(db, 'system_notifications', id), { readBy: arrayUnion(userId) }));
      await batch.commit();
    }
  } catch (error) {
    console.error('Failed to mark notifications read:', error);
  }
};
