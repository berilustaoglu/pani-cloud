import { Project, ProjectFormField, ProjectFormSettings, DEFAULT_PROJECT_FORM_SETTINGS } from '../types';

export interface ProjectFieldMeta {
  key: ProjectFormField;
  group: 'general' | 'details' | 'client' | 'files';
  tr: string;
  en: string;
  hintTr: string;
  hintEn: string;
}

// Proje formundaki ayarlanabilir alanlar (Proje adı her zaman zorunludur)
export const PROJECT_FIELDS: ProjectFieldMeta[] = [
  { key: 'client', group: 'general', tr: 'Müşteri', en: 'Client', hintTr: 'Projenin müşteri / firma adı', hintEn: 'Client or company name' },
  { key: 'projectType', group: 'general', tr: 'Proje Tipi', en: 'Project Type', hintTr: 'Oyun, mobil, web vb.', hintEn: 'Game, mobile, web, etc.' },
  { key: 'budget', group: 'general', tr: 'Bütçe', en: 'Budget', hintTr: 'Sıfırdan büyük bütçe girilmeli', hintEn: 'Budget must be greater than zero' },
  { key: 'startDate', group: 'general', tr: 'Başlangıç Tarihi', en: 'Start Date', hintTr: 'Projenin başladığı gün', hintEn: 'Project kickoff date' },
  { key: 'deliveryDate', group: 'general', tr: 'Teslim Tarihi', en: 'Delivery Date', hintTr: 'Planlanan teslim günü', hintEn: 'Planned delivery date' },
  { key: 'description', group: 'details', tr: 'Açıklama / Kapsam', en: 'Description / Scope', hintTr: 'Projenin kısa tanımı ve kapsamı', hintEn: 'Short description and scope' },
  { key: 'priority', group: 'details', tr: 'Öncelik', en: 'Priority', hintTr: 'Düşük, orta, yüksek, kritik', hintEn: 'Low, medium, high, critical' },
  { key: 'projectManager', group: 'details', tr: 'Proje Yöneticisi', en: 'Project Manager', hintTr: 'Projeden sorumlu kişi', hintEn: 'Person responsible' },
  { key: 'team', group: 'details', tr: 'Proje Ekibi', en: 'Project Team', hintTr: 'En az bir ekip üyesi seçilmeli', hintEn: 'At least one member' },
  { key: 'tags', group: 'details', tr: 'Etiketler', en: 'Tags', hintTr: 'Arama ve filtreleme için etiketler', hintEn: 'Tags for search & filters' },
  { key: 'estimatedHours', group: 'details', tr: 'Tahmini Efor (saat)', en: 'Estimated Hours', hintTr: 'Toplam tahmini çalışma saati', hintEn: 'Total estimated hours' },
  { key: 'repoUrl', group: 'details', tr: 'Repo / Proje Linki', en: 'Repo / Project Link', hintTr: 'GitHub, Figma, Drive vb.', hintEn: 'GitHub, Figma, Drive, etc.' },
  { key: 'clientContactName', group: 'client', tr: 'Yetkili Kişi', en: 'Contact Person', hintTr: 'Müşteri tarafındaki muhatap', hintEn: 'Client-side contact' },
  { key: 'clientEmail', group: 'client', tr: 'Yetkili E-posta', en: 'Contact Email', hintTr: 'Geçerli bir e-posta adresi', hintEn: 'Valid email address' },
  { key: 'clientPhone', group: 'client', tr: 'Yetkili Telefon', en: 'Contact Phone', hintTr: 'İletişim numarası', hintEn: 'Contact number' },
  { key: 'gdd', group: 'files', tr: 'GDD / Analiz Dokümanı', en: 'GDD / Spec Document', hintTr: 'Yüklenirse AI görevleri otomatik oluşturur', hintEn: 'AI generates tasks when uploaded' },
  { key: 'contract', group: 'files', tr: 'Sözleşme', en: 'Contract', hintTr: 'En az bir sözleşme dosyası', hintEn: 'At least one contract file' },
];

export const PROJECT_FIELD_GROUPS: Record<ProjectFieldMeta['group'], { tr: string; en: string }> = {
  general: { tr: 'Genel Bilgiler', en: 'General' },
  details: { tr: 'Detaylar & Ekip', en: 'Details & Team' },
  client: { tr: 'Müşteri İletişim', en: 'Client Contact' },
  files: { tr: 'Dosyalar', en: 'Files' },
};

export const isFieldRequired = (settings: ProjectFormSettings | undefined, key: ProjectFormField) => {
  const req = settings?.required ?? DEFAULT_PROJECT_FORM_SETTINGS.required;
  return !!req[key];
};

export type ProjectErrorKey = ProjectFormField | 'name' | 'progress' | 'payments';
export interface ProjectFieldError { field: ProjectErrorKey; message: string }

/** Ayarlara göre alan bazlı hata listesi döner. */
export const validateProjectFieldsDetailed = (p: Partial<Project>, settings: ProjectFormSettings | undefined, language: 'tr' | 'en'): ProjectFieldError[] => {
  const tr = language === 'tr';
  const errs: ProjectFieldError[] = [];
  const add = (field: ProjectErrorKey, message: string) => errs.push({ field, message });
  const missing = (key: ProjectFormField) => {
    const meta = PROJECT_FIELDS.find(f => f.key === key)!;
    add(key, tr ? `${meta.tr} zorunludur.` : `${meta.en} is required.`);
  };
  const req = (key: ProjectFormField) => isFieldRequired(settings, key);
  const empty = (v: unknown) => v === undefined || v === null || (typeof v === 'string' && !v.trim());

  if (empty(p.name)) add('name', tr ? 'Proje adı zorunludur.' : 'Project name is required.');
  if (req('client') && empty(p.client)) missing('client');
  if (req('projectType') && empty(p.projectType)) missing('projectType');
  if (req('budget') && (!p.budget || p.budget <= 0)) add('budget', tr ? 'Bütçe sıfırdan büyük olmalıdır.' : 'Budget must be greater than zero.');
  if (req('startDate') && empty(p.startDate)) missing('startDate');
  if (req('deliveryDate') && empty(p.deliveryDate)) missing('deliveryDate');
  if (req('description') && empty(p.description)) missing('description');
  if (req('priority') && empty(p.priority)) missing('priority');
  if (req('projectManager') && empty(p.projectManagerId)) missing('projectManager');
  if (req('team') && !(p.teamMemberIds && p.teamMemberIds.length)) missing('team');
  if (req('tags') && !(p.tags && p.tags.length)) missing('tags');
  if (req('estimatedHours') && !(p.estimatedHours && p.estimatedHours > 0)) missing('estimatedHours');
  if (req('repoUrl') && empty(p.repoUrl)) missing('repoUrl');
  if (req('clientContactName') && empty(p.clientContactName)) missing('clientContactName');
  if (req('clientEmail') && empty(p.clientEmail)) missing('clientEmail');
  if (req('clientPhone') && empty(p.clientPhone)) missing('clientPhone');
  if (req('gdd') && empty(p.gddUrl)) add('gdd', tr ? 'GDD yüklemesi zorunludur.' : 'GDD upload is mandatory.');
  if (req('contract') && !(p.contracts && p.contracts.length)) missing('contract');

  // Biçim kontrolleri (alan doluysa her zaman)
  if (!empty(p.clientEmail) && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(p.clientEmail!)) add('clientEmail', tr ? 'Yetkili e-posta adresi geçersiz.' : 'Contact email is invalid.');
  if (!empty(p.repoUrl) && !/^https?:\/\//i.test(p.repoUrl!)) add('repoUrl', tr ? 'Repo linki http:// veya https:// ile başlamalı.' : 'Repo link must start with http(s)://');
  if (p.startDate && p.deliveryDate && p.startDate > p.deliveryDate) add('deliveryDate', tr ? 'Teslim tarihi başlangıçtan önce olamaz.' : 'Delivery cannot be before start.');
  if (p.progress !== undefined && (p.progress < 0 || p.progress > 100)) add('progress', tr ? 'İlerleme 0-100 arasında olmalı.' : 'Progress must be 0-100.');
  return errs;
};

/** Geriye dönük uyumluluk: sadece mesajlar. */
export const validateProjectFields = (p: Partial<Project>, settings: ProjectFormSettings | undefined, language: 'tr' | 'en'): string[] =>
  validateProjectFieldsDetailed(p, settings, language).map(e => e.message);
