
import React from 'react';
import ReactDOM from 'react-dom/client';
import App from './App';
import './styles/animations.css';

// Register Service Worker for PWA
if ('serviceWorker' in navigator) {
  window.addEventListener('load', () => {
    navigator.serviceWorker.register('/service-worker.js')
      .then(registration => {
        console.log('SW registered: ', registration);
      })
      .catch(registrationError => {
        console.log('SW registration failed: ', registrationError);
      });
  });

  // Handle automatic reload when a new service worker takes over (helps with white screen issues)
  let refreshing = false;
  navigator.serviceWorker.addEventListener('controllerchange', () => {
    if (!refreshing) {
      refreshing = true;
      window.location.reload();
    }
  });
}

// iOS: klavye açılınca tarayıcı tüm belgeyi yukarı iter ve kapanınca çoğu zaman geri getirmez.
// Uygulama kendi kapsayıcılarında kaydığı için belge her zaman en üstte olmalı; odak kalkınca sıfırla.
const isTyping = () => { const el = document.activeElement as HTMLElement | null; return !!el && (el.tagName === 'INPUT' || el.tagName === 'TEXTAREA' || el.tagName === 'SELECT' || el.isContentEditable); };
const resetDocScroll = () => { if (!isTyping() && (window.scrollY || document.documentElement.scrollTop || document.body.scrollTop)) { window.scrollTo(0, 0); document.documentElement.scrollTop = 0; document.body.scrollTop = 0; } };
window.addEventListener('focusout', () => setTimeout(resetDocScroll, 120));
window.addEventListener('scroll', () => { if (!isTyping()) resetDocScroll(); }, { passive: true });
window.visualViewport?.addEventListener('resize', () => setTimeout(resetDocScroll, 120));

// iOS ana ekran (standalone) + saydam durum çubuğu: iOS görünür yüksekliği durum çubuğu kadar eksik
// bildirir ve altta boşluk kalır. Bu modda kökün yüksekliğini cihazın gerçek ekran boyundan veriyoruz.
const isIOS = /iPhone|iPad|iPod/.test(navigator.userAgent) || (navigator.platform === 'MacIntel' && navigator.maxTouchPoints > 1);
const isStandalone = (navigator as any).standalone === true || window.matchMedia('(display-mode: standalone)').matches;
const setAppHeight = () => {
  let h = window.innerHeight;
  if (isIOS && isStandalone) {
    const landscape = window.innerWidth > window.innerHeight;
    const screenH = landscape ? Math.min(screen.width, screen.height) : Math.max(screen.width, screen.height);
    if (screenH > h) h = screenH;
  }
  // Yükseklik okunamazsa (ör. sekme gizliyken) değişkeni kaldır; CSS %100'e düşer
  if (h > 0) document.documentElement.style.setProperty('--app-h', h + 'px');
  else document.documentElement.style.removeProperty('--app-h');
};
setAppHeight();
window.addEventListener('resize', setAppHeight);
window.addEventListener('orientationchange', () => setTimeout(setAppHeight, 300));

const rootElement = document.getElementById('root');
if (!rootElement) {
  throw new Error("Could not find root element to mount to");
}

const root = ReactDOM.createRoot(rootElement);
root.render(
  <React.StrictMode>
    <App />
  </React.StrictMode>
);
