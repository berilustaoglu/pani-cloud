
export enum UserRole {
  ADMIN = 'Admin',
  STAFF = 'Staff',
  ACCOUNTANT = 'Accountant',
  MANAGER = 'Manager',
  SALES = 'Sales'
}

export enum TaskStatus {
  TODO = 'To Do',
  DOING = 'Doing',
  DONE = 'Done',
  BLOCKED = 'Blocked'
}

export enum PaymentType {
  CASH = 'Peşin',
  INSTALLMENT = 'Taksitli',
  MILESTONE = 'Milestone (Ön/Son Ödeme)'
}

export enum Currency {
  USD = 'USD',
  TRY = 'TRY',
  EUR = 'EUR'
}

export enum BillingCycle {
  MONTHLY = 'Aylık',
  YEARLY = 'Yıllık'
}

export interface Subscription {
  id: string;
  name: string;
  provider: string;
  amount: number;
  currency: Currency;
  billingCycle: BillingCycle;
  startDate: string;
  nextBillingDate: string;
  snoozeUntil?: string;
  status: 'Active' | 'Cancelled';
  category: string;
  documentUrl?: string;
  documentName?: string;
}

export interface LicenseSale {
  id: string;
  customerName: string;
  productName: string;
  saleDate: string;
  expiryDate: string;
  amount: number;
  currency: Currency;
  status: 'Active' | 'Expired' | 'Refunded';
  licenseKey?: string;
  snoozeUntil?: string;
}

export interface ServiceSale {
  id: string;
  customerName: string;
  serviceName: string;
  amount: number;
  currency: Currency;
  billingCycle: BillingCycle;
  nextBillingDate: string;
  status: 'Active' | 'Paused' | 'Cancelled';
  snoozeUntil?: string;
}

export interface Installment {
  id: string;
  amount: number;
  dueDate: string;
  isPaid: boolean;
  paidAmount?: number;
  label: string;
  paymentLink?: string;
}

export interface ProjectDocument {
  id: string;
  name: string;
  type: 'contract' | 'document';
  fileType: string;
  uploadDate: string;
  url?: string;
  approvalStatus?: 'pending' | 'approved' | 'rejected';
  feedback?: string;
}

export interface StaffAIAnalysis {
  id?: string;
  userId?: string;
  date: string; // ISO Date
  performanceScore: number; // 0-100 (kept for compatibility if needed, but adding productivity)
  productivityScore: number; // 0-100
  summary: string;
  focusApps: string[];
  distractionApps: string[];
  suggestions: string[];
  bottlenecks: string[];
  screenshotCount: number;
  isIdle?: boolean;
}

// --- CRM TYPES ---
export enum DealStatus {
  LEAD = 'Lead',
  PROPOSAL = 'Proposal',
  NEGOTIATION = 'Negotiation',
  WON = 'Won',
  LOST = 'Lost'
}

export type CRMActivityType = 'Call' | 'Email' | 'Meeting' | 'Note';

export interface CRMActivity {
  id: string;
  dealId: string;
  userId: string;
  userName: string;
  type: CRMActivityType;
  description: string;
  date: string; // ISO string for when the activity happened/created
  reminderDate?: string; // ISO string for follow-up reminder
  status: 'Pending' | 'Completed';
}

export interface Deal {
  id: string;
  contactName: string;
  companyName?: string;
  email?: string;
  phone?: string;
  value: number;
  currency: Currency;
  status: DealStatus;
  notes: string;
  createdAt: string;
  updatedAt: string;
  assignedAdminId: string;
  expectedCloseDate?: string;
  aiScore?: number;
  proposalUrl?: string;
  taxRate?: number;
  taxAmount?: number;
  totalAmountWithTax?: number;
}

export interface StaffDocument {
  id: string;
  userId: string;
  projectId: string;
  projectName: string;
  fileName: string;
  fileType: string;
  uploadDate: string;
  note: string;
  fileUrl: string;
  sharedById?: string;
  sharedByName?: string;
  fileSize?: number;   // bayt
  readAt?: string;     // alıcının ilk açtığı an
}

export interface User {
  id: string;
  name: string;
  email: string;
  password?: string;
  role: UserRole;
  avatar: string;
  status: 'Online' | 'Offline' | 'Busy';
  tcNo?: string;
  phone?: string;
  jobTitle?: string;
  iban?: string;
  bankName?: string;
  fcmToken?: string;          // eski: tek cihaz
  fcmTokens?: string[];       // tüm cihazların push anahtarları
  notificationPrefs?: { staffOnline?: boolean; chat?: boolean; system?: boolean };
  monthlySalary?: number;
  salaryCurrency?: Currency;
  permissions?: string[];
  annualLeaveAllowance?: number;
  usedLeaveDays?: number;
  kpiScore?: number;
}

export interface HRSettings {
  id?: string;
  dailyWorkHours: number;
  defaultAnnualLeaveDays: number;
}

export interface FinanceSettings {
  id?: string;
  defaultTaxRate: number;
  defaultCurrency?: Currency;      // yeni kayıtlarda varsayılan para birimi
  reportingCurrency?: Currency;    // raporlarda toplamların gösterildiği para birimi
  incomeCategories?: string[];
  expenseCategories?: string[];
}

export interface CompanySettings {
  id?: string;
  name?: string;
  legalName?: string;
  taxOffice?: string;
  taxNumber?: string;
  address?: string;
  phone?: string;
  email?: string;
  website?: string;
  iban?: string;
  logoUrl?: string;
}

/** Yönetim Merkezi uyarı eşikleri (gün) */
export interface AlertSettings {
  id?: string;
  deliveryRiskDays: number;     // teslime bu kadar gün kala ilerleme düşükse risk
  invoiceUnpaidDays: number;    // gönderilmiş fatura bu kadar gün ödenmezse uyarı
  dealIdleDays: number;         // fırsat bu kadar gün güncellenmezse hareketsiz
  subscriptionWarnDays: number; // abonelik ödemesine bu kadar gün kala uyarı
  licenseWarnDays: number;      // lisans bitişine bu kadar gün kala uyarı
  ticketNoReplyDays: number;    // talep bu kadar gün yanıtsız kalırsa uyarı
}

export const DEFAULT_ALERT_SETTINGS: AlertSettings = {
  deliveryRiskDays: 7, invoiceUnpaidDays: 30, dealIdleDays: 14, subscriptionWarnDays: 7, licenseWarnDays: 30, ticketNoReplyDays: 3,
};

export const DEFAULT_INCOME_CATEGORIES = ['Oyun Satışı', 'Yazılım Hizmet Bedeli', 'Proje Taksit Ödemesi', 'Ek İş (Freelance)', 'Abonelik Geliri', 'Yatırım / Sermaye', 'Danışmanlık', 'Diğer'];
export const DEFAULT_EXPENSE_CATEGORIES = ['Personel Maaşları', 'Sunucu ve Bulut Giderleri', 'Yazılım Lisans Giderleri', 'Ofis Kirası ve Faturalar', 'Reklam ve Pazarlama', 'Donanım Alımı', 'Vergi ve Yasal Ödemeler', 'Yemek ve Ulaşım', 'Borç Ödemesi', 'Diğer'];

export interface Customer {
  id: string;
  name: string;
  phone: string;
  email?: string;
  company?: string;
  taxOffice?: string;
  taxNumber?: string;
  address?: string;
  notes?: string;
  gender?: 'Male' | 'Female';
}

export interface InvoiceItem {
  description: string;
  quantity: number;
  unitPrice: number;
  taxRate: number;
}

export interface Invoice {
  id: string;
  invoiceNumber: string;
  ettn: string;
  customerId: string;
  customerName: string;
  customerTaxNo: string;
  customerTaxOffice: string;
  customerAddress: string;
  date: string;
  items: InvoiceItem[];
  subtotal: number;
  taxTotal: number;
  withholdingTotal?: number; // Stopaj/Tevkifat
  totalAmount: number;
  paymentMethod?: string;
  status: 'Draft' | 'Sent' | 'Cancelled' | 'Paid';
  notes?: string;
  currency?: Currency;
  isEInvoice?: boolean;
  eInvoiceId?: string;
  eInvoiceUrl?: string;
  dueDate?: string;      // vade tarihi
  paidDate?: string;     // tahsil tarihi
}

export enum ProjectType {
  GAME = 'Oyun Geliştirme',
  AI = 'Yapay Zeka Cözümü',
  MOBILE = 'Mobil Uygulama Geliştirme',
  SYSTEM = 'Sistem Geliştirme',
  VR_AR = 'VR/AR Cözümleri',
  WEB = 'Web Geliştirme',
  OTHER = 'Diğer'
}

export interface PortalSettings {
  showFinancials: boolean;
  showTeam: boolean;
  showTasks: boolean;
  customMessage?: string;
  themeColor?: string;
  isPublic: boolean;
}

export interface Project {
  id: string;
  name: string;
  client: string;
  status: 'Active' | 'Completed' | 'On Hold' | 'Revizyonda';
  /** Askıya alma: bu tarihe (dahil) kadar projeden ve görevlerinden uyarı üretilmez. Boşsa süresiz askı. */
  holdUntil?: string;
  holdSince?: string;
  holdReason?: string;
  budget: number;
  currency: Currency;
  taxRate?: number;
  taxAmount?: number;
  totalAmountWithTax?: number;
  progress: number;
  paymentType: PaymentType;
  projectType: ProjectType;
  installments: Installment[];
  documents: ProjectDocument[];
  contracts: ProjectDocument[];
  deliveryDate?: string;
  gddUrl?: string;
  gddTasksGenerated?: boolean;
  portalToken?: string;
  portalSettings?: PortalSettings;
  // Genişletilmiş proje bilgileri
  description?: string;
  priority?: ProjectPriority;
  startDate?: string;
  projectManagerId?: string;
  teamMemberIds?: string[];
  tags?: string[];
  estimatedHours?: number;
  repoUrl?: string;
  customerId?: string;
  clientContactName?: string;
  clientEmail?: string;
  clientPhone?: string;
  clientFeedback?: { score: number; comment?: string; date: string }[]; // müşteri portalından gelen değerlendirmeler
}

export type ProjectPriority = 'Low' | 'Medium' | 'High' | 'Critical';

// Proje formunda zorunluluğu ayarlardan yönetilebilen alanlar
export type ProjectFormField =
  | 'client' | 'projectType' | 'budget' | 'startDate' | 'deliveryDate' | 'gdd' | 'contract'
  | 'description' | 'priority' | 'projectManager' | 'team' | 'tags' | 'estimatedHours' | 'repoUrl'
  | 'clientContactName' | 'clientEmail' | 'clientPhone';

export interface ProjectFormSettings {
  id?: string;
  required: Partial<Record<ProjectFormField, boolean>>;
}

export const DEFAULT_PROJECT_FORM_SETTINGS: ProjectFormSettings = {
  required: { client: true, projectType: true, budget: true, gdd: true },
};

export interface ChecklistItem {
  id: string;
  text: string;
  isCompleted: boolean;
}

export interface Task {
  id: string;
  projectId: string;
  title: string;
  assignedTo: string[];
  status: TaskStatus;
  deadline: string;
  progress: number;
  blockedReason?: string;
  notes?: string;
  managerNotes?: string;
  dependencyId?: string;
  checklist?: ChecklistItem[];
}

export interface Transaction {
  id: string;
  type: 'Income' | 'Expense';
  amount: number;
  currency: Currency;
  category: string;
  date: string;
  description: string;
  taxRate?: number;
  taxAmount?: number;
  totalAmountWithTax?: number;
  projectId?: string;
  documentUrl?: string;
  documentName?: string;
  documentType?: string;
}

export interface DebtPayment {
  id: string;
  amount: number;
  date: string;
  note?: string;
}

export interface Debt {
  id: string;
  type: 'Borrowed' | 'Lent';
  amount: number;
  currency: Currency;
  personName: string;
  description: string;
  date: string;
  dueDate?: string;
  isPaid: boolean;
  remainingAmount: number;
  payments?: DebtPayment[];
  documentUrl?: string;
  documentName?: string;
}

export type PersonnelTransactionType = 'Salary' | 'Advance' | 'Bonus' | 'Deduction';

export interface PersonnelTransaction {
  id: string;
  userId: string;
  userName: string;
  amount: number;
  currency: Currency;
  date: string;
  type: PersonnelTransactionType;
  month?: string; // e.g. "2024-03" for Salaries
  description: string;
}

export interface SalaryPayment {
  id: string;
  userId: string;
  userName: string;
  amount: number;
  currency: Currency;
  date: string; // Payment date
  month: string; // The month being paid for (e.g., "2024-03")
  description: string;
}

export interface AttendanceRecord {
  id: string;
  userId: string;
  userName: string;
  date: string;
  clockIn: string;
  clockOut?: string;
  location?: {
    lat: number;
    lng: number;
    address?: string;
  };
}

export interface AIAnalysis {
  summary: string;
  efficiencyScore: number;
  suggestions: string[];
  financialHealth: string;
}

export interface FinancialForecast {
  forecast: {
    nextMonth: { income: number, expense: number },
    threeMonth: { income: number, expense: number }
  };
  confidence: number;
  risks: string[];
  opportunities: string[];
  strategicAdvice: string;
}

export interface SMSConfig {
  usercode: string;
  password: string;
  msgheader: string;
}

export interface SMSLog {
  id: string;
  to: string;
  message: string;
  date: string;
  status: 'Sent' | 'Failed';
}

export interface SMSTemplate {
  id: string;
  title: string;
  content: string;
}

export interface ChatMessage {
  id: string;
  channelId: string; // 'general', 'announcements' or 'dm_uid1_uid2'
  senderId: string;
  senderName: string;
  senderAvatar: string;
  text: string;
  createdAt: string; // ISO String
  type: 'text' | 'image' | 'system' | 'poll' | 'event';
  readBy?: string[]; // Array of user IDs who have read the message
}
export interface UserActivity {
  id: string; // userId
  tabStatus: 'Active' | 'Blurred';
  lastActivity: string; // ISO String
  isIdle: boolean;
  currentScreen?: string; // Optional: Screenshot or sharing status
  lastScreenshot?: string; // ISO String
}

export interface ScreenRequest {
  id: string;
  fromId: string;
  toId: string;
  status: 'Pending' | 'Accepted' | 'Rejected' | 'Expired';
  timestamp: string;
  signalData?: string; // WebRTC signaling data
}

export interface ScreenshotLog {
  id: string;
  userId: string;
  userName: string;
  imageUrl: string;
  timestamp: string; // ISO String
  analysis?: string; // AI analysis of what's on screen
}

// --- NEW ERP MODULES ---

export type LeaveType = 'Yıllık İzin' | 'Mazeret İzni' | 'Hastalık/Rapor' | 'Ücretsiz İzin' | 'Diğer';

export interface LeaveRequest {
  id: string;
  userId: string;
  userName: string;
  type: LeaveType;
  startDate: string; // YYYY-MM-DD
  endDate: string; // YYYY-MM-DD
  reason: string;
  status: 'Pending' | 'Approved' | 'Rejected' | 'Cancelled';
  requestDate: string; // ISO
  managerNotes?: string;
  documentUrl?: string; // Optional medical report or form
  includeWeekends?: boolean;
}

export interface InventoryItem {
  id: string;
  sku: string;
  name: string;
  description: string;
  category: string;
  currentQuantity: number;
  minQuantity: number;
  unitPrice: number;
  currency: Currency;
  location?: string; // e.g., 'Depo A', 'Raf 3'
  lastUpdated: string;
  unit?: string; // adet, kg, kutu...
  movements?: StockMovement[];
}

export interface StockMovement {
  id: string;
  type: 'in' | 'out' | 'adjust';
  quantity: number;     // pozitif miktar (adjust için yeni stok - eski stok)
  date: string;         // ISO
  note?: string;
  userName?: string;
}

export interface Vendor {
  id: string;
  name: string;
  contactName: string;
  phone: string;
  email: string;
  taxOffice: string;
  taxNumber: string;
  address?: string;
  notes?: string;
}

export interface PurchaseOrderItem {
  itemId?: string; // Maps to InventoryItem id, optional for non-inventory services
  name: string;
  quantity: number;
  unitPrice: number;
}

export interface PurchaseOrder {
  id: string;
  orderNumber: string;
  vendorId: string;
  vendorName: string;
  items: PurchaseOrderItem[];
  totalAmount: number;
  currency: Currency;
  status: 'Draft' | 'Ordered' | 'Received' | 'Cancelled';
  date: string;
  expectedDelivery?: string;
  notes?: string;
}

export type ExtraJobStatus = 'Bekliyor' | 'Yapılıyor' | 'Tamamlandı' | 'İptal';
export type ExtraJobPaymentStatus = 'Ödenmedi' | 'Kısmi Ödeme' | 'Ödendi';

export interface ExtraJob {
  id: string;
  title: string;
  description: string;
  clientName: string;
  price: number;
  currency: Currency;
  taxRate?: number;
  taxAmount?: number;
  totalAmountWithTax?: number;
  deadline?: string;
  status: ExtraJobStatus;
  paymentStatus: ExtraJobPaymentStatus;
  assignedTo: string[]; // User IDs
  createdAt: string;
  updatedAt: string;
  // Genişletilmiş alanlar
  category?: string;
  priority?: ProjectPriority;
  startDate?: string;
  estimatedHours?: number;
  customerId?: string;
  notes?: string;
  payments?: ExtraJobPayment[];
}

export interface ExtraJobPayment {
  id: string;
  amount: number; // KDV dahil tahsil edilen tutar
  date: string;   // YYYY-MM-DD
  note?: string;
}

export type AuditAction = 'CREATE' | 'UPDATE' | 'DELETE' | 'LOGIN' | 'OTHER';
export type AuditEntity = 'Project' | 'Task' | 'Invoice' | 'User' | 'Deal' | 'Transaction' | 'System' | 'Other';

export interface AuditLog {
  id: string;
  userId: string;
  userName: string;
  action: AuditAction;
  entityType: AuditEntity;
  entityId?: string;
  details: string;
  timestamp: string; // ISO string
}

export interface SystemNotification {
  id: string;
  userId?: string; // Optional: If specific to a user
  type: 'warning' | 'info' | 'success' | 'error';
  title: string;
  description: string;
  tab?: string;
  createdAt: string;
  readBy: string[]; // User IDs who read this
  createdBy?: string; // bildirimi oluşturan kullanıcı (kendisine push gitmez)
}

export type TicketStatus = 'Open' | 'In Progress' | 'Resolved' | 'Closed';
export type TicketPriority = 'Low' | 'Medium' | 'High' | 'Critical';

export interface Ticket {
  id: string;
  projectId: string;
  title: string;
  description: string;
  status: TicketStatus;
  priority: TicketPriority;
  createdAt: string;
  updatedAt: string;
  responses: TicketResponse[];
}

export interface TicketResponse {
  id: string;
  userId: string; // admin/staff ID, or 'client' if it's from the client
  message: string;
  createdAt: string;
  isClient: boolean;
}

export interface Meeting {
  id: string;
  title: string;
  description?: string;
  date: string; // YYYY-MM-DD
  time: string; // HH:mm
  participants: string[]; // User IDs
  createdBy: string;
  status: 'scheduled' | 'active' | 'completed' | 'cancelled';
  roomName: string; // Jitsi Room Name
  durationMinutes?: number;
  notes?: string; // toplantı sonrası notlar / kararlar
}
